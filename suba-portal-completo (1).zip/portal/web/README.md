# Monetize · Área de Membros (Mentoria Suba o Padrão)

Portal da mentoria com duas áreas: **Mentorado** (mobile-first) e **Painel administrativo** (mentor/admin).
Front-end em HTML, CSS e JavaScript puro, sem build e sem dependências. Abra `index.html` (login); ele leva para
`aluno.html` ou `mentor.html`.

## Primeiro acesso

O portal vem **zerado**: sem turmas, alunos, aulas, tarefas ou avisos, e sem usuário de demonstração.

1. **Defina o acesso do mentor antes de publicar.** Abra `ferramentas/gerar-acesso.html` no navegador, informe
   nome, e-mail e senha, e cole a linha gerada dentro de `ACESSO_MENTOR`, no arquivo `config.js`.
   Não existe tela de cadastro de mentor: só entra no painel quem está nesse arquivo.
2. Publique o portal e entre com esse e-mail e senha. No painel, cadastre a turma e os alunos (com o e-mail de cada um).
3. Ao cadastrar o aluno, **você define a senha dele** (ou usa "Sugerir"). O portal mostra o e-mail e a senha uma
   única vez, com botões para enviar por WhatsApp ou e-mail. O aluno pode trocar a senha depois, no perfil.
4. Em **Turmas**, libere a **Roda da Vida inicial** quando quiser que a turma preencha, e a **final** no encerramento.

O `config.js` guarda só o resumo criptográfico da senha (SHA-256, 5.000 rodadas), nunca a senha. Como o arquivo é
público, use uma senha longa e que você não usa em outro lugar. Para trocar a senha ou incluir outro mentor, gere
uma nova linha. A pasta `ferramentas/` não precisa ser publicada.

Só vêm preenchidas as competências iniciais (menu Competências) e as perguntas frequentes (menu Suporte); as duas
listas são editáveis. Se um aluno esquecer a senha, use **Redefinir senha** na ficha dele e repasse a nova.

> **Atenção antes de divulgar para os alunos.** Nesta versão os dados ficam guardados no navegador de quem usa
> (`localStorage`), não em um servidor. O que o mentor cadastra no computador dele **não aparece** no celular do
> aluno. Para o portal funcionar com mentor e alunos em aparelhos diferentes é preciso um servidor com banco de
> dados e login (veja "Para colocar em produção"). Use **Configurações → Cópia de segurança** para guardar os dados.

## Acesso temporário de admin (apague antes de divulgar)

O `config.js` traz um acesso temporário (`admin.temp@subaopadrao.com`) só para navegar e ajustar o portal.
No painel, **Ver como aluno** abre a área do mentorado; sem aluno cadastrado, o portal cria um "Aluno de teste".
O aviso no topo tem o botão **Voltar ao painel**. Antes de divulgar o portal, apague a linha temporária do
`config.js`, cadastre o acesso definitivo com `ferramentas/gerar-acesso.html` e remova o Aluno de teste.

## O que mudou nesta versão (v4)

- **Aula de verdade** (`js/aluno/player.js`, `js/aluno/aulas.js`): o vídeo abre dentro da página da aula
  (YouTube não listado, Vimeo, arquivo MP4 ou Google Drive). O portal lembra onde o aluno parou (`S.prog`), retoma do
  mesmo ponto e marca a aula como assistida sozinho ao passar de 90% (configurável). Pular para o fim não conta:
  é preciso ter tocado pelo menos metade do vídeo. Material de apoio (PDF, slides, planilhas, links) ao lado do vídeo.
- **Presença em um toque** (`js/mentor/chamada.js`): chamada com quatro estados (Presente, Atrasado, Falta,
  Falta justificada com motivo) e o atalho "Marcar todos presentes".
- **Frequência** (`js/mentor/frequencia.js`, `js/aluno/frequencia.js`): mínimo configurável (padrão 75%,
  geral ou por turma) ligado ao certificado; conta só os encontros desde a matrícula; gravação assistida compensa a
  falta (opcional); o aluno justifica a falta pelo portal e o mentor aprova ou recusa.
- **E-mail, WhatsApp e lembretes automáticos** (`js/compartilhado/core/actions.js`, Notificações): toda notificação gera a versão de
  e-mail e de WhatsApp na fila de envio. `autoRun()` envia sozinho os lembretes de aula, prazo, tarefa em atraso,
  gravação não assistida, frequência e etapas do plano. Com um webhook (n8n, Make, Zapier) o envio sai sem clique.
- **Agenda integrada**: botão "Adicionar ao Google Calendar" e arquivo `.ics` em cada encontro, e a agenda completa.
- **Dia a dia do aluno**: rascunho automático da entrega, perfil completo (foto, edição dos dados, canais de aviso,
  exportar e excluir dados, LGPD), diário e anotações por aula (com opção de compartilhar com o mentor), plano de ação
  (metas com etapas, prazos e acompanhamento) e Ajuda e suporte (perguntas frequentes e chamados).
- **Turmas com unidades**: cada turma pode ser dividida em unidades com a quantidade de aulas de cada uma; o portal
  cria as aulas que faltam em sequência.
- Quem usava a v3 mantém os dados: a migração é automática (`normal()` em `js/compartilhado/core/store.js`).

## Como abrir (importante para o vídeo)

O YouTube só toca dentro da aula quando o portal é aberto por um endereço `http://` ou `https://`. Abrindo o
`index.html` direto do computador aparece o "Erro 153" do YouTube. Duas formas de abrir certo:

- **No seu computador:** dois cliques em `abrir-portal.sh` (Linux e Mac) ou `abrir-portal.bat` (Windows). Ele abre o
  portal em `http://localhost:8080`. Precisa do Python 3 instalado (já vem no Linux e no Mac).
- **Publicado:** em qualquer hospedagem com https.

Os dados ficam guardados por endereço. Para levar o que você já cadastrou de um endereço para outro, use
**Configurações → Cópia de segurança** (baixar no antigo, restaurar no novo).

## Estrutura

O portal tem **três páginas**, cada uma carregando só o que usa:

| Página | Para quem | CSS | JS |
|---|---|---|---|
| `index.html` | Login e primeiro acesso | `css/base/*` + `css/login.css` | núcleo compartilhado + `js/login/` |
| `aluno.html` | Mentorado | `css/base/*` + `css/aluno.css` | `js/compartilhado/` + `js/aluno/` |
| `mentor.html` | Mentor / admin | `css/base/*` + `css/mentor.css` | `js/compartilhado/` + `js/mentor/` |

```
suba-o-padrao/
├── index.html                  Login. Depois de entrar, leva para aluno.html ou mentor.html
├── aluno.html                  Área do mentorado
├── mentor.html                 Painel do mentor
├── config.js                   ACESSO DO MENTOR: e-mail e resumo da senha (edite antes de publicar)
├── ferramentas/gerar-acesso.html   Gera a linha do config.js (não precisa publicar)
├── abrir-portal.sh / .bat      Abre o portal em http://localhost:8080 (necessário para o YouTube)
├── assets/img/                 Marca, imagem do login (login.jpg), boas-vindas do aluno (boas-vindas.jpg), imagem de fundo e arte do certificado
├── css/
│   ├── base/                   Comum às três páginas (carregado em ordem numérica)
│   │   ├── 01-tokens.css       Cores, fontes, tema claro/escuro (identidade visual)
│   │   ├── 02-base.css         Reset e tipografia
│   │   ├── 03-layout.css       Barra lateral, topo, área principal
│   │   ├── 04-componentes.css  Cartão, botão, etiqueta, barra, formulário, abas, tabela
│   │   ├── 05-jornada.css      Escada dos encontros
│   │   ├── 06-aulas.css        Lista de tópicos e ficha de dados
│   │   ├── 07-agenda.css       Calendário
│   │   ├── 08-rotina.css       Hábitos, treinos, leituras
│   │   ├── 09-roda-da-vida.css Roda da Vida
│   │   ├── 10-modal-toast.css  Modal, aviso rápido, menu do celular
│   │   ├── 11-turmas-anexos-certificado.css  Etiquetas de turma, anexos, certificado
│   │   ├── 12-marca.css        Identidade Monetize e vitrine de Recomendações
│   │   ├── 13-frequencia-plano-suporte.css   Barras de frequência, plano de ação, chamados, interruptores
│   │   ├── 14-responsivo.css   Tablet e celular (carregado depois do CSS do setor)
│   │   └── 15-impressao.css    Exportação em PDF
│   ├── login.css               Só da página de login
│   ├── aluno.css               Só da área do mentorado (início, player, frequência, diário, perfil, ajuda)
│   └── mentor.css              Só do painel (turmas, chamada, mapa de frequência, notificações, automação)
└── js/
    ├── compartilhado/          Usado pelas duas áreas (e o núcleo, também pelo login)
    │   ├── core/               utils, icons, files, store (estado e sessão), selectors (regras), actions (notificações)
    │   ├── data/               constants (regras fixas) e seed (estado inicial, zerado)
    │   ├── ui/                 components, widgets (calendário, certificado, agenda), recs, midia, shell, router
    │   └── telas/              Telas que aluno e mentor veem iguais: rotina, plano (de ação), chamados, lgpd
    ├── login/auth.js           Login, senha, aceite de termos
    ├── aluno/                  Uma funcionalidade por arquivo: inicio, aulas, player, agenda, frequencia, tarefas,
    │                           diario, recomendacoes, evolucao, mural, notificacoes, perfil, ajuda + app.js
    └── mentor/                 visao-geral, turmas, alunos, aluno-ficha, aulas, chamada, frequencia, tarefas,
                                avaliacoes, metas, competencias, recomendacoes, mural, notificacoes, suporte,
                                certificados, relatorios, configuracoes + app.js
```

## Arquitetura

O fluxo é sempre o mesmo, em uma direção:

```
ação do usuário → altera o estado (S) → actions.js (histórico + notificação + toast) → render() → página
```

- **Estado** (`compartilhado/core/store.js`): um único objeto `S` com turmas, alunos, aulas, tarefas, notas etc.,
  mais a **sessão** (`U`), que fica guardada no navegador para valer de uma página para a outra.
- **Regras** (`compartilhado/core/selectors.js`): tudo que é calculado fica aqui e nunca é salvo. Ex.: `freq(aid)`,
  `fin(aid)`, `pautaLib(aula)`, `atrasada(aid, tarefa)`.
- **Páginas**: cada função `S_*` (aluno) ou `A_*` (mentor) devolve o HTML da tela; as ações ficam no mesmo arquivo.
- **Cada área tem um `app.js`** com o menu e o mapa de páginas (`APP`). O roteador compartilhado
  (`compartilhado/ui/router.js`) confere a sessão, chama `APP.view()` e desenha a moldura.

Para adicionar uma página: crie o arquivo em `js/aluno/` ou `js/mentor/`, registre em `PAGINAS` e no menu do
`app.js` daquela área, e inclua a tag `<script>` no HTML correspondente (antes do `app.js`).

Duas decisões que valem saber:

- **Scripts comuns, não módulos (`import`/`export`).** Módulos não carregam com a página aberta direto do arquivo
  (`file://`), e os botões do portal chamam funções pelo nome (`onclick`). Por isso a ordem das tags `<script>`
  nos HTML importa: compartilhado primeiro, setor depois, `app.js` por último.
- **A separação organiza o código, mas não é segurança.** Os dados continuam no navegador; quem protege o painel
  do mentor de verdade é o servidor, com login real e cada perfil recebendo só os seus dados.

## Para colocar em produção (o que a equipe de TI precisa trocar)

| Hoje (dados no navegador) | Produção (com servidor) |
|---|---|
| `seed.js` devolve o estado inicial vazio | Carregar da API no login |
| `save()` grava no `localStorage` | Cada ação chama o endpoint correspondente |
| `login()` confere a senha do mentor no `config.js` e a do aluno no navegador; `setSessao()` guarda o perfil | Autenticação real no servidor (e-mail + senha, Google na fase 2) e token de sessão |
| `despachar()` põe e-mail e WhatsApp na fila (envio com um clique ou por webhook) | Envio direto pelo servidor (provedor de e-mail e API oficial do WhatsApp) |
| `autoRun()` confere os lembretes quando alguém abre o portal | A mesma rotina em um agendador do servidor, em horário fixo |
| Foto do perfil e materiais ficam no navegador | Upload para o armazenamento do servidor |
| `print()` gera o PDF pelo navegador | Geração de PDF no servidor para certificado |
| `fput()/fget()` guardam anexos no IndexedDB | Upload dos anexos para o armazenamento do servidor |

As regras de negócio do levantamento de requisitos (prazos de 7 dias, idade mínima 18 anos, liberação de pauta na
véspera, Roda final no encerramento da turma, acesso somente leitura após conclusão, escalonamento de atrasos, histórico nunca
apagado) já estão implementadas em `compartilhado/core/selectors.js` e nas páginas, e servem de especificação para o back-end.
