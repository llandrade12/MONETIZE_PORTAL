/**
 * sw.js
 * Serviço em segundo plano do aplicativo (PWA).
 *
 * 1. Guarda as páginas, estilos, scripts e imagens que a pessoa já abriu, para o portal abrir mesmo com a
 *    internet falhando. Com internet, vale sempre a versão do servidor; a cópia guardada só entra quando a
 *    rede não responde. Os dados (tudo em api/) nunca são guardados aqui.
 * 2. Mostra as notificações push e, no toque, abre o portal na página do aviso.
 */
'use strict';

const CACHE = 'area-de-membros-v1';

self.addEventListener('install', () => self.skipWaiting());

self.addEventListener('activate', e => e.waitUntil((async () => {
  for (const k of await caches.keys())
    if (k != CACHE)
      await caches.delete(k);
  await self.clients.claim();
})()));

self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if (r.method != 'GET' || u.origin != self.location.origin || /\/(api|agenda)\//.test(u.pathname))
    return;
  e.respondWith((async () => {
    const cache = await caches.open(CACHE);
    try {
      const resp = await fetch(r);
      if (resp.ok && resp.type == 'basic')
        cache.put(r, resp.clone());
      return resp;
    }
    catch (erro) {
      const guardado = await cache.match(r, { ignoreSearch: r.mode == 'navigate' }) || (r.mode == 'navigate' ? await cache.match(new URL('index.html', self.registration.scope).href) : null);
      if (guardado)
        return guardado;
      throw erro;
    }
  })());
});

self.addEventListener('push', e => {
  let d = {};
  try {
    d = e.data ? e.data.json() : {};
  }
  catch (x) {
    d = { b: e.data ? e.data.text() : '' };
  }
  e.waitUntil(self.registration.showNotification(d.t || 'Área de Membros', {
    body: d.b || '', icon: 'assets/img/icone-192.png', badge: 'assets/img/icone-badge.png', lang: 'pt-BR', data: { u: d.u || './' }
  }));
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  const alvo = new URL((e.notification.data && e.notification.data.u) || './', self.registration.scope);
  const ir = (/[#&]ir=([A-Za-z]+)/.exec(alvo.hash) || [])[1];
  e.waitUntil((async () => {
    const abertas = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const c of abertas) {
      if (new URL(c.url).pathname == alvo.pathname) {
        await c.focus();
        if (ir)
          c.postMessage({ ir });
        return;
      }
    }
    await self.clients.openWindow(alvo.href);
  })());
});
