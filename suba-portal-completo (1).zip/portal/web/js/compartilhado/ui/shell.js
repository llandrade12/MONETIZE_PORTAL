/**
 * compartilhado/ui/shell.js
 * Moldura da aplicação: barra lateral, topo, navegação inferior do celular e tema.
 * Os itens de menu vêm de cada setor: SNAV/SMORE em aluno/app.js e ANAV/badgeA em mentor/app.js.
 */
'use strict';

function openSide() {
  $('.side')?.classList.add('open');
  $('.scrim')?.classList.add('on');
}

function closeSide() {
  $('.side')?.classList.remove('open');
  $('.scrim')?.classList.remove('on');
}

function openSheet() {
  $('#sheet').classList.add('on');
}

function closeSheet() {
  $('#sheet')?.classList.remove('on');
}

function theme() {
  const r = document.documentElement, cur = r.getAttribute('data-theme') || (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark');
  const n = cur == 'light' ? 'dark' : 'light';
  r.setAttribute('data-theme', n);
  try {
    localStorage.setItem('sop-theme', n);
  }
  catch (e) {
  }
  render();
}

try {
  const t = localStorage.getItem('sop-theme');
  if (t)
    document.documentElement.setAttribute('data-theme', t);
}
catch (e) {
}

const TITLES = {
  inicio: 'Início', aulas: 'Aulas', aula: 'Aula', agenda: 'Agenda', tarefas: 'Tarefas', evolucao: 'Minha evolução', rotina: 'Rotina e hábitos', mural: 'Mural', perfil: 'Perfil e certificado', notificacoes: 'Notificações', frequencia: 'Minha frequência', diario: 'Diário e anotações', ajuda: 'Ajuda e suporte', freq: 'Frequência', suporte: 'Suporte',
  visao: 'Visão geral', recs: 'Recomendações', turmas: 'Turmas', alunos: 'Alunos', alunoD: 'Ficha do aluno', aulasA: 'Aulas e cronograma', tarefasA: 'Tarefas', avaliacoes: 'Notas e avaliações', metas: 'Metas e planos de ação', comps: 'Competências', muralA: 'Mural de avisos', comunicacao: 'Notificações', certificados: 'Certificados', relatorios: 'Relatórios', config: 'Configurações'
};

function shell(content, { title, crumb = '' }) {
  const adm = isAdm(), me = adm ? null : ME(), nU = adm ? 0 : unread(me.id);
  const navHtml = adm ? ANAV.map(([g, it]) => `<div class="grp">${g}</div>` + it.map(([k, l, i]) => {
    const b = badgeA(k);
    return `<button class="nv ${R.p == k || (R.p == 'alunoD' && k == 'alunos') ? 'on' : ''}" onclick="nav('${k}')">${ic(i)}<span>${l}</span>${b ? `<span class="bd">${b}</span>` : ''}</button>`;
  }).join('')).join('')
    : `<div style="height:6px"></div>` + SNAV.map(([k, l, i]) => `<button class="nv ${R.p == k || (R.p == 'aula' && k == 'aulas') ? 'on' : ''}" onclick="nav('${k}')">${ic(i)}<span>${l}</span></button>`).join('');
  const t = adm ? null : turmaDe(me.id), dark = (document.documentElement.getAttribute('data-theme') || (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark')) == 'dark';
  return `<div class="shell ${adm ? 'adm' : 'stu'}">
<aside class="side"><div class="brand">${MARK}<div><b>${BRAND.nome}</b><span>${adm ? 'Painel do mentor' : 'Área de Membros'}</span></div></div>
${adm ? `<label class="ctx"><small>Turma em gestão</small><span class="ctxs"><i style="background:${ctx() ? E(turmaById(ctx()).cor) : 'conic-gradient(' + (S.turmas.map(x => x.cor).concat(S.turmas.length ? [S.turmas[0].cor] : ['#555', '#555']).join(',')) + ')'}"></i><select aria-label="Turma em gestão" onchange="setCtx(this.value)"><option value="0">Todas as turmas</option>${S.turmas.map(x => `<option value="${x.id}" ${x.id == ctx() ? 'selected' : ''}>${E(tnome(x))}</option>`).join('')}</select></span></label>` : ''}
<nav aria-label="Menu principal">${navHtml}</nav>
<div class="foot"><div class="me">${adm ? `<div class="av">${ini(S.mentor)}</div><div style="flex:1;min-width:0"><b>${E(S.mentor)}</b><small>Mentor / Administrador</small></div>` : `<button class="me-l" title="Abrir meu perfil" onclick="nav('perfil')">${avatar(me)}<span style="flex:1;min-width:0"><b>${E(me.nome)}</b><small>${E(tnome(t))}</small></span></button>`}<button class="ib" style="width:32px;height:32px;background:#111;border-color:#262626;color:#999" aria-label="Sair" title="Sair" onclick="logout()">${ic('logout')}</button></div></div></aside>
<div class="scrim" onclick="closeSide()"></div>
<div class="ws">
${U.preview ? `<div class="banner">${ic('eye')}<span>Você está vendo o portal como <b>${E(me.nome)}</b>. Ações aqui afetam os dados dele.</span><button class="btn sm" onclick="exitPreview()">Voltar ao painel</button></div>` : ''}
${!adm && ro() ? `<div class="banner">${ic('lock')}<span>Turma concluída. Seu acesso agora é somente para consulta.</span></div>` : ''}
<header class="top"><button class="ib" id="mb" aria-label="Abrir menu" onclick="openSide()">${ic('menu')}</button>
<div class="tt">${crumb ? `<div class="crumb">${crumb}</div>` : ''}<h2>${title}</h2></div>
${adm ? `<button class="btn s sm hide-m" onclick="previewAs()">${ic('eye')}Ver como aluno</button>` : ''}
<button class="ib" aria-label="Alternar tema claro ou escuro" title="Tema" onclick="theme()">${ic(dark ? 'sun' : 'moon')}</button>
${adm ? `<button class="ib" aria-label="Alertas para você" title="Alertas para você" onclick="ST.comunicacao='mentor';nav('comunicacao')">${ic('bell')}${unreadM() ? `<span class="bd dot">${unreadM()}</span>` : ''}</button>` : `<button class="ib" aria-label="Notificações" onclick="nav('notificacoes')">${ic('bell')}${nU ? `<span class="bd dot">${nU}</span>` : ''}</button>`}
</header>
<main id="main">${content}</main></div>
${adm ? '' : `<nav class="bnav" aria-label="Navegação">${[['inicio', 'Início', 'home'], ['aulas', 'Aulas', 'play'], ['tarefas', 'Tarefas', 'check'], ['evolucao', 'Evolução', 'chart']].map(([k, l, i]) => `<button class="${R.p == k || (R.p == 'aula' && k == 'aulas') ? 'on' : ''}" onclick="nav('${k}')">${ic(i)}${l}</button>`).join('')}<button class="${SMORE.includes(R.p) ? 'on' : ''}" onclick="openSheet()">${ic('dots')}Mais${nU ? `<span class="bd">${nU}</span>` : ''}</button></nav>
<div class="sheet" id="sheet" onclick="if(event.target==this)closeSheet()"><div class="pn"><div class="grab"></div>${SMORE.map(k => k == 'notificacoes' ? [k, 'Notificações', 'bell'] : SNAV.find(x => x[0] == k)).map(([k, l, i]) => `<button class="nv ${R.p == k ? 'on' : ''}" style="color:#d9d1c0" onclick="nav('${k}')">${ic(i)}<span>${l}</span>${k == 'notificacoes' && nU ? `<span class="bd">${nU}</span>` : ''}</button>`).join('')}<button class="nv" style="color:#d9d1c0" onclick="logout()">${ic('logout')}<span>Sair</span></button></div></div>`}
</div>`;
}

function logout() {
  sair();
}

