/**
 * compartilhado/ui/recs.js
 * Recomendações do mentor (livros, audiolivros, vídeos, podcasts e filmes).
 * A mesma vitrine é usada pelo mentor (com edição) e pelo mentorado (com "quero ver" e "concluído").
 */
'use strict';

/* tipo: [singular, plural, ícone, verbo, formato da capa] */
const RTIPOS = {
  livro: ['Livro', 'Livros', 'book', 'Ler', 'p'],
  audio: ['Audiolivro', 'Audiolivros', 'headphones', 'Ouvir', 'p'],
  video: ['Vídeo', 'Vídeos', 'video', 'Assistir', 'w'],
  podcast: ['Podcast', 'Podcasts', 'mic', 'Ouvir', 'q'],
  filme: ['Filme', 'Filmes', 'film', 'Assistir', 'p']
};

const recsDe = aid => S.recs.filter(r => inT(r, aid ? (aluno(aid) || {}).turma || -1 : ctx()));

const ytId = u => (String(u || '').match(/(?:[?&]v=|youtu\.be\/|\/embed\/|\/shorts\/|\/live\/)([\w-]{11})/) || [])[1] || '';

/* Nome da plataforma a partir do link, para o botão dizer aonde ele leva. */
function plataforma(u) {
  let h = '';
  try {
    h = new URL(u).hostname.replace(/^www\./, '');
  }
  catch (e) {
    return '';
  }
  const M = [['youtu', 'YouTube'], ['spotify', 'Spotify'], ['drive.google', 'Google Drive'], ['docs.google', 'Google Drive'], ['audible', 'Audible'], ['amazon', 'Amazon'], ['amzn', 'Amazon'], ['podcasts.apple', 'Apple Podcasts'], ['music.apple', 'Apple Music'], ['deezer', 'Deezer'], ['vimeo', 'Vimeo'], ['netflix', 'Netflix'], ['primevideo', 'Prime Video'], ['soundcloud', 'SoundCloud'], ['skeelo', 'Skeelo'], ['storytel', 'Storytel']];
  return (M.find(m => h.includes(m[0])) || [, h])[1];
}

/* Capa: imagem enviada, miniatura do YouTube ou capa tipográfica gerada pelo portal. */
function recCapa(r) {
  const T = RTIPOS[r.tipo] || RTIPOS.livro, y = ytId(r.url), img = r.capa || (y ? 'https://i.ytimg.com/vi/' + y + '/hqdefault.jpg' : '');
  const v = 1 + Math.floor(hsh(r.t + r.tipo) * 3);
  return `<span class="rcv ${T[4]} ${img ? 'img' : 'g' + v}">${img ? `<img src="${E(img)}" alt="" loading="lazy" onerror="this.parentNode.classList.remove('img');this.parentNode.classList.add('g${v}');this.remove()">` : ''}<span class="rcg"><span class="rct">${ic(T[2])}${T[0]}</span><b>${E(r.t)}</b><small>${E(r.autor || '')}</small></span>${T[4] == 'w' ? `<span class="rpl">${ic('play')}</span>` : ''}</span>`;
}

/* Botões de acesso ao conteúdo. */
function recAcoes(r, sm = true) {
  const T = RTIPOS[r.tipo] || RTIPOS.livro, p = plataforma(r.url), c = sm ? 'sm' : '';
  return (safeUrl(r.url) ? `<a class="btn ${c}" href="${E(safeUrl(r.url))}" target="_blank" rel="noopener" onclick="event.stopPropagation()">${ic(r.tipo == 'video' || r.tipo == 'filme' ? 'play' : r.tipo == 'livro' ? 'ext' : 'headphones')}${T[3]}${p ? ' no ' + E(p) : ''}</a>` : '') +
    (r.file ? `<button class="btn ${safeUrl(r.url) ? 's' : ''} ${c}" data-n="${E(r.file.name)}" onclick="event.stopPropagation();fopen('${r.file.id}',this.dataset.n)">${ic('download')}Baixar PDF</button>` : '');
}

/* Marcação do mentorado: quero ver / concluído. */
function recSt(id, v) {
  const k = ME().id + '-' + id;
  if (S.recSt[k] == v)
    delete S.recSt[k];
  else
    S.recSt[k] = v;
  save();
  keep();
  render();
  if ($('#modal').classList.contains('on'))
    recVer(id);
}

function recMarca(r) {
  if (isAdm()) {
    const n = Object.keys(S.recSt).filter(k => k.endsWith('-' + r.id) && S.recSt[k] == 'feito').length;
    return `<span class="sm-t">${n ? n + ' concluíram' : 'Ninguém concluiu ainda'}</span>`;
  }
  const s = S.recSt[ME().id + '-' + r.id], d = ro() ? 'disabled' : '';
  return `<span class="rmk"><button class="${s == 'quero' ? 'on' : ''}" ${d} aria-pressed="${s == 'quero'}" title="Salvar para depois" onclick="event.stopPropagation();recSt('${r.id}','quero')">${ic('bookmark')}<span>${s == 'quero' ? 'Salvo' : 'Salvar'}</span></button><button class="${s == 'feito' ? 'on ok' : ''}" ${d} aria-pressed="${s == 'feito'}" title="Marcar como concluído" onclick="event.stopPropagation();recSt('${r.id}','feito')">${ic('ok')}<span>${s == 'feito' ? 'Concluído' : 'Concluir'}</span></button></span>`;
}

function recCard(r) {
  const T = RTIPOS[r.tipo] || RTIPOS.livro, p = plataforma(r.url);
  return `<article class="rc ${T[4]}" tabindex="0" role="button" aria-label="${E(T[0] + ': ' + r.t)}" onclick="recVer('${r.id}')" onkeydown="if(event.key=='Enter')recVer('${r.id}')">${recCapa(r)}<div class="rcb"><h3>${E(r.t)}</h3>${r.autor ? `<p class="rca">${E(r.autor)}</p>` : ''}${T[4] != 'p' && r.desc ? `<p class="rcd">${E(r.desc)}</p>` : ''}<div class="rcf">${p || r.file ? `<span class="sm-t">${E(p || 'PDF')}${p && r.file ? ' e PDF' : ''}</span>` : '<span></span>'}${recMarca(r)}</div></div></article>`;
}

/* Destaque no topo da vitrine. */
function recDestaque(r) {
  const T = RTIPOS[r.tipo] || RTIPOS.livro;
  return `<section class="rfe"><div class="rfe-c" onclick="recVer('${r.id}')">${recCapa(r)}</div><div class="rfe-b"><span class="tag gd">${ic('star')}Destaque do mentor</span><h1>${E(r.t)}</h1>${r.autor ? `<p class="rca">${E(T[0])} de ${E(r.autor)}</p>` : `<p class="rca">${E(T[0])}</p>`}${r.desc ? `<p class="rfe-d">${E(r.desc)}</p>` : ''}<div class="row" style="margin-top:18px">${recAcoes(r, false)}<button class="btn s" onclick="recVer('${r.id}')">Ver detalhes</button></div></div></section>`;
}

/* Vitrine completa. adm = mostra a visão do mentor. */
function recVitrine(aid) {
  const L = recsDe(aid), f = ST.recT || 'todos', K = Object.keys(RTIPOS).filter(k => L.some(r => r.tipo == k));
  if (!L.length)
    return '';
  const pin = L.find(r => r.pin), show = K.filter(k => f == 'todos' || f == k);
  const meus = aid ? L.filter(r => S.recSt[aid + '-' + r.id] == 'quero') : [];
  return (pin && f == 'todos' ? recDestaque(pin) : '') +
    `<div class="rfil" role="group" aria-label="Filtrar por tipo"><button class="${f == 'todos' ? 'on' : ''}" onclick="ST.recT='todos';keep();render()">Tudo <i>${L.length}</i></button>${K.map(k => `<button class="${f == k ? 'on' : ''}" onclick="ST.recT='${k}';keep();render()">${ic(RTIPOS[k][2])}${RTIPOS[k][1]} <i>${L.filter(r => r.tipo == k).length}</i></button>`).join('')}${meus.length ? `<button class="${f == 'salvos' ? 'on' : ''}" onclick="ST.recT='salvos';keep();render()">${ic('bookmark')}Salvos <i>${meus.length}</i></button>` : ''}</div>` +
    (f == 'salvos' ? `<div class="rgrid mix">${meus.map(recCard).join('')}</div>` : show.map(k => `<section class="rsec"><h2>${RTIPOS[k][1]}</h2><div class="rgrid ${RTIPOS[k][4]}">${L.filter(r => r.tipo == k).map(recCard).join('')}</div></section>`).join('') || empty('Nada neste filtro', 'Escolha outro tipo de conteúdo.'));
}

/* Detalhe de uma recomendação. */
function recVer(id) {
  const r = S.recs.find(x => x.id == id);
  if (!r)
    return;
  const T = RTIPOS[r.tipo] || RTIPOS.livro, adm = isAdm();
  modal(E(r.t), `<div class="rdt ${T[4]}">${recCapa(r)}<div><div class="row" style="gap:8px;margin-bottom:10px">${tag(T[0], 'gd')}${r.comp ? tag(r.comp, '') : ''}${adm ? tchips(r.turmas) : ''}</div>${r.autor ? `<p class="rca" style="font-size:15px">${E(r.autor)}</p>` : ''}${r.desc ? `<div class="rwhy"><span class="sm-t">Por que o mentor recomenda</span><p>${E(r.desc)}</p></div>` : ''}<div class="row" style="margin-top:16px">${recAcoes(r, false) || '<span class="sm-t">Sem link ou arquivo. Procure pelo título na sua plataforma preferida.</span>'}</div><div style="margin-top:16px">${recMarca(r)}</div><p class="sm-t" style="margin:14px 0 0">Recomendado por ${E(r.por || S.mentor)} em ${E((r.at || '').slice(0, 10))}</p></div></div>`, { wide: true, cancel: 'Fechar' });
  if (adm)
    $('.mf').insertAdjacentHTML('afterbegin', `<button class="btn d" onclick="closeM();setTimeout(()=>recDel('${id}'),30)">${ic('trash')}Excluir</button><span style="flex:1"></span><button class="btn s" onclick="closeM();setTimeout(()=>recForm('${id}'),30)">${ic('edit')}Editar</button>`);
}
