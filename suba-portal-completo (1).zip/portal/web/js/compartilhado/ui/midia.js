/**
 * compartilhado/ui/midia.js
 * Vídeo e materiais: reconhece de onde é o link da gravação (YouTube, Vimeo, MP4, Drive),
 * lê o progresso do aluno e classifica o material de apoio. Usado pelo aluno (player) e pelo mentor (cadastro).
 */
'use strict';

/* Descobre de onde é o vídeo a partir do link colado pelo mentor. */
function vsrc(u) {
  u = safeUrl(u);
  if (!u)
    return null;
  let m;
  if ((m = u.match(/(?:youtu\.be\/|youtube(?:-nocookie)?\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/|live\/))([\w-]{11})/)))
    return { k: 'yt', id: m[1], nome: 'YouTube', auto: true };
  if ((m = u.match(/vimeo\.com\/(?:video\/)?(\d+)(?:[/?](?:h=)?([0-9a-f]{6,}))?/)))
    return { k: 'vimeo', id: m[1], h: m[2] || '', nome: 'Vimeo', auto: true };
  if (/\.(mp4|webm|ogg|m4v|mov)(\?|#|$)/i.test(u))
    return { k: 'file', u, nome: 'Arquivo de vídeo', auto: true };
  if ((m = u.match(/drive\.google\.com\/file\/d\/([\w-]+)/)))
    return { k: 'frame', u: 'https://drive.google.com/file/d/' + m[1] + '/preview', nome: 'Google Drive', auto: false };
  return { k: 'frame', u, nome: 'Link incorporado', auto: false };
}

const progDe = (aid, n) => S.prog[aid + '-' + n] || { t: 0, d: 0, w: 0, p: 0 };

function mtipo(m) {
  const n = (m.file ? m.file.name : m.u || '').toLowerCase(), x = (n.split(/[?#]/)[0].match(/\.(\w{2,4})$/) || [])[1] || '';
  if (x == 'pdf')
    return ['PDF', 'pdf'];
  if (['ppt', 'pptx', 'key'].includes(x) || /docs\.google\.com\/presentation|canva\.com|slides/.test(n))
    return ['Slides', 'ppt'];
  if (['xls', 'xlsx', 'csv'].includes(x) || /docs\.google\.com\/spreadsheets/.test(n))
    return ['Planilha', 'xls'];
  if (['doc', 'docx'].includes(x) || /docs\.google\.com\/document/.test(n))
    return ['Documento', 'doc'];
  if (['png', 'jpg', 'jpeg'].includes(x))
    return ['Imagem', 'img'];
  return [m.file ? 'Arquivo' : 'Link', 'lnk'];
}

/* Link que pode ser aberto dentro do portal (Drive, Docs, Slides, PDF). */
function embedU(u) {
  u = safeUrl(u);
  let m;
  if ((m = u.match(/drive\.google\.com\/file\/d\/([\w-]+)/)))
    return 'https://drive.google.com/file/d/' + m[1] + '/preview';
  if ((m = u.match(/docs\.google\.com\/(presentation|document|spreadsheets)\/d\/([\w-]+)/)))
    return 'https://docs.google.com/' + m[1] + '/d/' + m[2] + '/' + (m[1] == 'presentation' ? 'embed' : 'preview');
  return '';
}
