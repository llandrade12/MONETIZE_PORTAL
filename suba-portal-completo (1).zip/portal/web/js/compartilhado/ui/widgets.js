/**
 * compartilhado/ui/widgets.js
 * Blocos compartilhados entre aluno e admin: escada, radar, linha de aula, calendário, aviso e certificado.
 */
'use strict';

/* Escada dos encontros da turma em contexto. */
function climb() {
  const L = aulasCtx(), n = nextAula();
  if (!L.length)
    return '';
  return `<div class="climb" role="img" aria-label="${realizadas().length} de ${L.length} encontros realizados">${L.map((a, i) => `<i class="${aulaLib(a) ? (a.status == 'parcial' ? 'p' : 'd') : n && a.n == n.n ? 'c' : ''}" style="height:${Math.round(18 + (i + 1) / L.length * 82)}%;max-width:28px" title="Aula ${i + 1}: ${E(a.nome)}"></i>`).join('')}</div>`;
}

function radar(r, big = true) {
  const pt = (i, v) => {
    const a = i / 8 * 2 * Math.PI - Math.PI / 2;
    return [(Math.cos(a) * v * 10).toFixed(1), (Math.sin(a) * v * 10).toFixed(1)];
  };
  let h = '';
  [2, 4, 6, 8, 10].forEach(v => h += `<polygon points="${AREAS.map((_, i) => pt(i, v).join(',')).join(' ')}" fill="none" stroke="var(--ln2)" stroke-width=".6"/>`);
  AREAS.forEach((a, i) => {
    const [x, y] = pt(i, 10);
    h += `<line x1="0" y1="0" x2="${x}" y2="${y}" stroke="var(--ln2)" stroke-width=".5"/>`;
    const [lx, ly] = pt(i, 12.4);
    h += `<text x="${lx}" y="${+ly + 3}" fill="var(--t2)" font-size="8.5" font-family="Manrope,sans-serif" font-weight="600" text-anchor="middle">${a}</text>`;
  });
  h += `<polygon points="${r.ini.map((v, i) => pt(i, v).join(',')).join(' ')}" fill="#8a8a8a" fill-opacity=".14" stroke="#9a958c" stroke-width="1.4" stroke-dasharray="3 2"/>`;
  if (r.finSent || isAdm())
    h += `<polygon points="${r.fin.map((v, i) => pt(i, v).join(',')).join(' ')}" fill="#fdb621" fill-opacity=".2" stroke="#fdb621" stroke-width="1.8"/>`;
  return `<svg class="radar" viewBox="-150 -140 300 285" role="img" aria-label="Gráfico Roda da Vida">${h}</svg><div class="legend"><span><i style="background:#9a958c"></i>Inicial</span><span><i style="background:#fdb621"></i>Final</span></div>`;
}

/* ---------- Calendário ---------- */

/* Eventos por dia. aid = visão do aluno; sem aid = painel (turma em contexto). */
function evMap(aid) {
  const tid = aid ? (aluno(aid).turma || -1) : ctx(), ev = {}, add = (d, o) => (ev[d] = ev[d] || []).push(o);
  aulasDe(tid).forEach(a => add(a.date, {
    k: 'a', h: a.hora, t: a.nome, s: (a.comp ? 'Aula de ' + a.comp : 'Aula') + ', ' + a.hora + (a.aberta ? ', aberta a convidados' : ''), tur: a.turmas, go: `nav('aula',${a.n})`, adm: `aulaMenu(${a.n})`, cal: a.status == 'agendada' ? `calAdd('a',${a.n})` : ''
  }));
  S.eventos.filter(e => inT(e, tid)).forEach(e => add(e.d, { k: 'x', h: '', t: e.t, s: 'Evento', tur: e.turmas || [], go: '', adm: `evMenu('${e.id}')`, cal: `calAdd('x','${e.id}')` }));
  (aid ? tarefasDe(aid) : ST.calPz ? tarefasCtx() : []).forEach(t => add(aid ? due(aid, t) : t.due, { k: 't', h: '', t: 'Prazo: ' + t.t, s: 'Tarefa', tur: t.turmas || [], go: "nav('tarefas')", adm: `taskForm(${t.id})` }));
  for (const d in ev)
    ev[d].sort((a, b) => (a.h || '99').localeCompare(b.h || '99'));
  return ev;
}

/* Cor principal de um evento: a da turma, quando é de uma turma só. */
const evCor = e => e.tur.length == 1 && turmaById(e.tur[0]) ? turmaById(e.tur[0]).cor : '';

function calNav(d) {
  const [y, m] = (ST.cal || hoje().slice(0, 7)).split('-').map(Number), n = new Date(y, m - 1 + d, 1);
  ST.cal = n.getFullYear() + '-' + p2(n.getMonth() + 1);
  keep();
  render();
}

function calendar(aid) {
  const adm = isAdm() && !aid, v = sub('agenda', adm ? 'mes' : 'lista'), ev = evMap(aid);
  const [Y, M1] = (ST.cal || hoje().slice(0, 7)).split('-').map(Number), M = M1 - 1;
  const act = e => adm ? e.adm : e.go;
  const head = `<div class="toolbar"><div class="seg"><button class="${v == 'mes' ? 'on' : ''}" onclick="ST.agenda='mes';render()">Mês</button><button class="${v == 'lista' ? 'on' : ''}" onclick="ST.agenda='lista';render()">Lista</button></div>${adm ? `<label class="chk" style="font-size:13px;align-items:center"><input type="checkbox" ${ST.calPz ? 'checked' : ''} onchange="ST.calPz=this.checked;keep();render()"> Mostrar prazos de tarefas</label>` : ''}
  ${v == 'mes' ? `<div class="row" style="margin-left:auto;flex-wrap:nowrap"><button class="btn q sm" onclick="ST.cal='';keep();render()">Hoje</button><button class="ib" aria-label="Mês anterior" onclick="calNav(-1)">${ic('left')}</button><b class="calm">${MESL[M]} ${Y}</b><button class="ib" aria-label="Próximo mês" onclick="calNav(1)">${ic('right')}</button></div>` : ''}</div>`;
  const leg = `<div class="legend callg">${adm ? S.turmas.map(t => `<span><i style="background:${E(t.cor)}"></i>${E(tnome(t))}</span>`).join('') : `<span><i style="background:var(--gd)"></i>Aula</span>`}${adm && !ST.calPz ? '' : `<span><i style="background:var(--in)"></i>Prazo de tarefa</span>`}<span><i style="background:var(--ok)"></i>Evento</span></div>`;
  if (v == 'mes') {
    const first = new Date(Y, M, 1), days = new Date(Y, M + 1, 0).getDate();
    let g = DOW.map(d => `<div class="h">${d}</div>`).join('') + '<div class="o"></div>'.repeat(first.getDay());
    for (let d = 1; d <= days; d++) {
      const k = `${Y}-${p2(M + 1)}-${p2(d)}`;
      g += `<div class="${k == hoje() ? 'td' : ''} ${adm ? 'add' : ''}" ${adm ? `onclick="novaAula('${k}')" title="Clique para adicionar uma aula em ${DF(k)}"` : ''}><div class="dn">${d}</div>${(ev[k] || []).map(e => `<button class="ev ${e.k}" ${evCor(e) ? `style="--c:${E(evCor(e))}"` : ''} title="${E((e.h ? e.h + ' ' : '') + e.t + (adm ? ' · ' + (e.tur.length ? e.tur.map(i => tnome(turmaById(i))).join(' + ') : 'Todas as turmas') : ''))}" onclick="event.stopPropagation();${act(e)}"><span class="et">${e.h ? `<b>${e.h}</b> ` : ''}${E(e.t)}</span>${adm ? `<span class="ep">${tchips(e.tur)}</span>` : ''}</button>`).join('')}</div>`;
    }
    return head + `<div class="tw" style="border-radius:14px"><div class="cal ${adm ? 'adm' : ''}">${g}</div></div>` + leg + (adm ? `<p class="sm-t" style="margin-top:8px">Clique em um dia para adicionar uma aula. A cor e a sigla mostram a turma de cada encontro.</p>` : '');
  }
  const keys = Object.keys(ev).filter(k => k >= hoje()).sort(), groups = {};
  keys.forEach(k => (groups[k.slice(0, 7)] = groups[k.slice(0, 7)] || []).push(k));
  return head + (Object.keys(groups).map(m => `<div class="sec" style="margin-top:8px"><h4 style="margin:18px 0 10px">${MESL[+m.slice(5) - 1]} ${m.slice(0, 4)}</h4><div class="card agl">${groups[m].map(k => ev[k].map(e => `<div class="li"><div class="dbox ${e.k == 'a' ? 'gd' : ''}" ${evCor(e) && adm ? `style="border-color:${E(evCor(e))}"` : ''}><b>${D(k).getDate()}</b><small>${DOW[D(k).getDay()]}</small></div><div class="grow"><b>${E(e.t)}</b><span class="sm-t">${E(e.s)}</span>${adm ? `<div class="row" style="gap:6px;margin-top:6px">${tchips(e.tur, false)}</div>` : ''}</div>${e.cal ? `<button class="btn q sm" title="Adicionar à minha agenda (Google Calendar ou .ics)" aria-label="Adicionar à agenda" onclick="${e.cal}">${ic('calplus')}<span class="hide-m">Agenda</span></button>` : ''}${act(e) ? `<button class="btn s sm" onclick="${act(e)}">${adm ? 'Abrir' : 'Ver'}</button>` : ''}</div>`).join('')).join('')}</div></div>`).join('') || empty('Calendário vazio', adm ? 'Nenhuma aula, evento ou prazo daqui para frente.' : 'Sua turma ainda não tem encontros agendados.', adm ? `<button class="btn" onclick="novaAula()">${ic('plus')}Adicionar aula</button>` : '')) + (keys.length ? leg : '');
}

const wkSel = (k, fn) => {
  const w = ST[k] ?? week();
  return `<div class="wk">${Array.from({ length: SEM }, (_, i) => `<button class="${i == w ? 'on' : ''}" onclick="ST['${k}']=${i};keep();render()"><b>Semana ${i + 1}</b><small>${DF(wkD(i))} a ${DF(wkD(i, 6))}</small><small>${fn(i)}</small></button>`).join('')}</div>`;
};

/* ---------- Mural ---------- */

/* alvo do aviso: 'todos', 't<id da turma>' ou o id de um aluno. */
const alvoNome = a => a.alvo == 'todos' ? '' : String(a.alvo)[0] == 't' ? tnome(turmaById(String(a.alvo).slice(1))) : nm(a.alvo);

function avisosFor(id) {
  const t = 't' + ((aluno(id) || {}).turma || 0);
  return [...S.avisos].filter(a => a.alvo == 'todos' || a.alvo == id || a.alvo == t).sort((a, b) => (b.pin - a.pin) || (S.avisos.indexOf(b) - S.avisos.indexOf(a)));
}

/* Autor de um comentário. O aluno não recebe o cadastro dos colegas: o servidor manda o nome junto do comentário. */
const quemComentou = c => !c.aid ? S.mentor : aluno(c.aid) ? nm(c.aid) : c.nome || 'Colega de turma';

function avisoCard(a, adm) {
  return `<article class="card ${a.pin ? 'gold' : ''}"><div class="row sp" style="align-items:flex-start;gap:12px"><div class="row" style="gap:12px;flex:1;min-width:0;flex-wrap:nowrap"><div class="av">${ini(a.autor)}</div><div style="min-width:0"><b>${E(a.autor)}</b><div class="sm-t">${E(a.at)}${a.alvo != 'todos' ? ', para ' + E(alvoNome(a)) : ''}</div></div></div><div class="row">${a.pin ? tag('Fixado', 'gd') : ''}${adm ? `<button class="btn q sm" onclick="pinA('${a.id}')">${a.pin ? 'Desafixar' : 'Fixar'}</button><button class="btn q sm" aria-label="Excluir aviso" onclick="delA('${a.id}')">${ic('trash')}</button>` : ''}</div></div>
<h3 style="font:600 22px/1.2 var(--dp);margin:14px 0 6px">${E(a.t)}</h3><p style="white-space:pre-line;margin:0">${E(a.m)}</p>
<div style="margin-top:14px;border-top:1px solid var(--ln);padding-top:12px">${a.coms.map(c => `<div class="row" style="gap:10px;align-items:flex-start;margin-bottom:10px;flex-wrap:nowrap"><div class="av" style="width:28px;height:28px;font-size:10.5px">${ini(quemComentou(c))}</div><div><b style="font-size:13px">${E(quemComentou(c))}</b> <span class="sm-t">${E(c.at)}</span><div style="font-size:13.5px">${E(c.txt)}</div></div></div>`).join('')}
<div class="row" style="flex-wrap:nowrap"><input id="cm-${a.id}" placeholder="Escreva um comentário" ${!adm && ro() ? 'disabled' : ''} onkeydown="if(event.key=='Enter')comentar('${a.id}')"><button class="ib" aria-label="Enviar comentário" onclick="comentar('${a.id}')">${ic('send')}</button></div></div></article>`;
}

function comentar(id) {
  const v = val('cm-' + id);
  if (!v)
    return;
  const a = S.avisos.find(x => x.id == id);
  a.coms.push({ aid: isAdm() ? 0 : ME().id, txt: v, at: stamp() });
  done('Comentário publicado');
}

/* ---------- Certificado (arte oficial em assets/img/certificado.jpg) ---------- */

/* Textos que entram sobre a arte. */
function certData(id) {
  const a = aluno(id), t = turmaDe(id), c = certDe(id), dt = c.iso || hoje(), d = D(dt);
  const per = t.inicio && t.fim ? 'Realizada de ' + DFY(t.inicio) + ' a ' + DFY(t.fim) : t.fim ? 'Concluída em ' + DFY(t.fim) : t.inicio ? 'Iniciada em ' + DFY(t.inicio) : 'Mentoria concluída';
  return {
    nome: a.nome,
    linha: per + (t.carga ? ', com carga horária de ' + t.carga + ' horas.' : '.'),
    mentor: S.mentor,
    local: (t.cidade ? t.cidade + ', ' : '') + d.getDate() + ' de ' + MESL[d.getMonth()].toLowerCase() + ' de ' + d.getFullYear(),
    fs: Math.max(2.3, Math.min(4.4, 4.4 - Math.max(0, a.nome.length - 22) * .085))
  };
}

function certHtml(id) {
  const c = certData(id);
  return `<div class="certx"><img src="assets/img/certificado.jpg" alt="Certificado de conclusão da Mentoria Suba o Padrão"><div class="cx-n" style="font-size:${c.fs}cqw">${E(c.nome)}</div><div class="cx-l">${E(c.linha)}</div><div class="cx-m">${E(c.mentor)}</div><div class="cx-d">${E(c.local)}</div></div>`;
}

function verCert(id) {
  modal('Certificado', certHtml(id), { wide: true, cancel: 'Fechar', label: 'Baixar PDF', sub: E(nm(id)) + ', ' + E(tnome(turmaDe(id))), ok: () => {
      printCert(id);
      return false;
    } });
  $('#mbox').classList.add('cw');
  $('.mf').insertAdjacentHTML('afterbegin', `<button class="btn s" onclick="certPng(${id})">${ic('image')}Baixar imagem</button><span style="flex:1"></span>`);
}

/* PDF: imprime só o certificado, em A4 paisagem, sem margens. */
function printCert(id) {
  let r = $('#printroot');
  if (!r) {
    r = document.createElement('div');
    r.id = 'printroot';
    document.body.appendChild(r);
  }
  r.innerHTML = certHtml(id) + '<style>@page{size:A4 landscape;margin:0}</style>';
  document.documentElement.classList.add('pc');
  const end = () => {
    document.documentElement.classList.remove('pc');
    r.innerHTML = '';
    removeEventListener('afterprint', end);
  };
  addEventListener('afterprint', end);
  const img = r.querySelector('img'), go = () => setTimeout(() => print(), 80);
  if (img.complete)
    go();
  else
    img.onload = go;
}

/* PNG em alta resolução, desenhado em canvas com os mesmos textos e posições. */
async function certPng(id) {
  const c = certData(id), img = $('#mbox .certx img');
  try {
    if (document.fonts && document.fonts.load)
      await Promise.all([document.fonts.load('600 40px "Cormorant Garamond"'), document.fonts.load('500 40px "Cormorant Garamond"')]);
    const W = 2982, H = 2110, cv = document.createElement('canvas'), g = cv.getContext('2d'), F = (w, s) => `${w} ${Math.round(s * W / 100)}px "Cormorant Garamond", Georgia, serif`;
    cv.width = W;
    cv.height = H;
    g.drawImage(img, 0, 0, W, H);
    g.textAlign = 'center';
    g.textBaseline = 'alphabetic';
    const gr = g.createLinearGradient(0, H * .49, 0, H * .565);
    gr.addColorStop(0, '#fbe6a3');
    gr.addColorStop(.5, '#f0c45a');
    gr.addColorStop(1, '#c9932c');
    g.fillStyle = gr;
    g.font = F(600, c.fs);
    g.fillText(c.nome, W * .5, H * .553);
    g.fillStyle = '#f3efe6';
    g.font = F(500, 1.46);
    g.textBaseline = 'middle';
    g.fillText(c.linha, W * .5, H * .7225);
    g.font = F(500, 1.34);
    g.fillText(c.local, W * .7265, H * .8865);
    g.textBaseline = 'alphabetic';
    g.fillStyle = '#efe7d4';
    g.font = F(600, 1.75);
    g.fillText(c.mentor, W * .2735, H * .822);
    const blob = await new Promise((res, rej) => cv.toBlob(b => b ? res(b) : rej(new Error('vazio')), 'image/png'));
    const u = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = u;
    a.download = 'certificado-' + c.nome.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-') + '.png';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(u), 5000);
    toast('Imagem do certificado baixada');
  }
  catch (e) {
    toast('Não foi possível gerar a imagem. Use "Baixar PDF".');
  }
}

/* ---------- Agenda integrada: Google Calendar e arquivo .ics ---------- */

/* Monta o evento de agenda de uma aula ('a') ou de um evento do calendário ('x'). */
function calEv(k, id) {
  if (k == 'a') {
    const a = aulaN(id);
    if (!a)
      return null;
    const lk = pautaLib(a) || isAdm() ? safeUrl(a.link) : '';
    return { id: 'aula-' + a.n, t: BRAND.nome + ' · ' + a.nome, date: a.date, hora: a.hora, dur: a.dur || 120, local: lk, desc: ['Encontro da mentoria com ' + a.mentor + '.', a.obj && (pautaLib(a) || isAdm()) ? 'Pauta: ' + a.obj : '', lk ? 'Link da reunião: ' + lk : 'O link da reunião fica na página da aula, no portal.'].filter(Boolean).join('\n') };
  }
  const e = S.eventos.find(x => x.id == id);
  return e ? { id: 'evento-' + e.id, t: BRAND.nome + ' · ' + e.t, date: e.d, hora: '', desc: 'Evento da mentoria.' } : null;
}

function calAdd(k, id) {
  const ev = calEv(k, id);
  if (!ev)
    return;
  ST.calEv = ev;
  modal('Adicionar à minha agenda', `<div class="card flat" style="margin-bottom:14px"><b>${E(ev.t)}</b><div class="sm-t">${DL(ev.date)}${ev.hora ? ', ' + ev.hora : ' · dia inteiro'}</div></div>
<div style="display:grid;gap:8px"><a class="btn" style="justify-content:flex-start" href="${E(gcalUrl(ev))}" target="_blank" rel="noopener" onclick="closeM()">${ic('calplus')}Adicionar ao Google Calendar</a>
<button class="btn s" style="justify-content:flex-start" onclick="baixar(slug(ST.calEv.t)+'.ics',icsText([ST.calEv]),'text/calendar');closeM();toast('Arquivo .ics baixado. Abra para adicionar à agenda.')">${ic('download')}Baixar arquivo .ics (Apple, Outlook e outros)</button></div>
<p class="sm-t" style="margin:12px 0 0">O convite já vai com lembrete de 1 hora antes. Se a aula for reagendada, adicione de novo.</p>`, { cancel: 'Fechar' });
}

/*
 * Assinatura da agenda: um endereço próprio de cada pessoa, que o Google Agenda, o iPhone e o Outlook
 * consultam sozinhos. Mudou a data de uma aula no portal, muda na agenda de quem assinou.
 */
function assinarAgenda() {
  const u = API.srv.agenda || '';
  if (!u)
    return toast('A agenda por assinatura não está disponível agora');
  const cal = u.replace(/^https?:/, 'webcal:');
  modal('Assinar a agenda', `<p class="mu" style="margin:0 0 14px">${isAdm() ? 'Os encontros, eventos e prazos de todas as turmas' : 'Os encontros, eventos e prazos da sua turma'} passam a aparecer na sua agenda e se atualizam sozinhos quando uma data muda. Você assina uma vez só.</p>
<div style="display:grid;gap:8px"><a class="btn" style="justify-content:flex-start" href="https://calendar.google.com/calendar/r?cid=${encodeURIComponent(cal)}" target="_blank" rel="noopener">${ic('calplus')}Assinar no Google Agenda</a>
<a class="btn s" style="justify-content:flex-start" href="${E(cal)}">${ic('cal')}Assinar no iPhone, Mac ou Outlook</a>
<button class="btn s" style="justify-content:flex-start" onclick="navigator.clipboard&&navigator.clipboard.writeText('${E(u)}').then(()=>toast('Endereço da agenda copiado'),()=>toast('Copie o endereço manualmente'))">${ic('copy')}Copiar o endereço da agenda</button></div>
<div class="card flat" style="margin-top:14px;padding:12px 14px"><span class="sm-t">Endereço da sua agenda</span><p style="margin:4px 0 0;font:500 12.5px ui-monospace,Menlo,Consolas,monospace;word-break:break-all">${E(u)}</p></div>
<p class="sm-t" style="margin:12px 0 0">No Google Agenda, abra pelo computador para assinar; depois a agenda aparece também no celular. O Google atualiza as agendas assinadas algumas vezes por dia, então uma mudança pode levar algumas horas para aparecer lá. Este endereço é só seu: não compartilhe.</p>`, { cancel: 'Fechar' });
}

/* Agenda completa do aluno (ou da turma em contexto, no painel) em um único .ics. */
function icsAll() {
  const aid = isAdm() ? 0 : ME().id, tid = aid ? (aluno(aid).turma || -1) : ctx(), h = hoje();
  const evs = aulasDe(tid).filter(a => a.status == 'agendada' && a.date >= h).map(a => calEv('a', a.n))
    .concat(S.eventos.filter(e => inT(e, tid) && e.d >= h).map(e => calEv('x', e.id)))
    .concat((aid ? tarefasDe(aid).filter(t => !S.ent[aid + '-' + t.id]) : tarefasCtx()).filter(t => (aid ? due(aid, t) : t.due) >= h).map(t => ({ id: 'tarefa-' + t.id, t: 'Prazo: ' + t.t, date: aid ? due(aid, t) : t.due, hora: '', desc: 'Prazo de entrega da tarefa na Área de Membros.' })));
  if (!evs.length)
    return toast('Não há encontros futuros para exportar');
  baixar('agenda-mentoria.ics', icsText(evs, BRAND.nome + ' · Mentoria'), 'text/calendar');
  toast(evs.length + ' compromisso(s) no arquivo .ics');
}
