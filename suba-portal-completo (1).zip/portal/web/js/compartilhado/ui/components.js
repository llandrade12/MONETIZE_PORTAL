/**
 * compartilhado/ui/components.js
 * Componentes de interface: tag, barra, abas, campo de formulário, toast e modal.
 */
'use strict';

/* Avatar: foto do aluno, quando ele enviou, ou as iniciais. */
const avatar = (a, cls = '') => `<div class="av ${cls}">${a && a.foto ? `<img src="${E(a.foto)}" alt="">` : ini(a && a.nome)}</div>`;

const tag = (t, c = '') => `<span class="tag ${c}"><i></i>${E(t)}</span>`;

const bar = (v, c = '') => `<div class="bar ${c}"><i style="width:${Math.max(0, Math.min(100, v))}%"></i></div>`;

const empty = (t, s, btn = '') => `<div class="empty"><b>${t}</b>${s}${btn ? '<div style="margin-top:14px">' + btn + '</div>' : ''}</div>`;

const tabs = (page, arr, def) => {
  const c = ST[page] || def || arr[0][0];
  return `<div class="tabs" role="tablist">${arr.map(([k, l, n]) => `<button role="tab" aria-selected="${k == c}" class="${k == c ? 'on' : ''}" onclick="ST['${page}']='${k}';render()">${l}${n != null && n !== '' ? `<span class="c">${n}</span>` : ''}</button>`).join('')}</div>`;
};

const sub = (page, def) => ST[page] || def;

const F = (label, html, hint = '') => `<label class="f"><span>${label}</span>${html}${hint ? `<small>${hint}</small>` : ''}</label>`;

const val = id => {
  const el = document.getElementById(id);
  return el ? el.value.trim() : '';
};

let tT;

function toast(m) {
  const t = $('#toast');
  t.innerHTML = ic('ok') + '<span>' + E(m) + '</span>';
  t.classList.add('on');
  clearTimeout(tT);
  tT = setTimeout(() => t.classList.remove('on'), 2800);
}

function modal(title, body, { ok, label = 'Confirmar', wide = false, danger = false, cancel = 'Cancelar', sub = '' } = {}) {
  delete $('#modal').dataset.re;
  $('#mbox').className = wide ? 'w' : '';
  $('#mbox').innerHTML = `<div class="mh"><div><h2>${title}</h2>${sub ? `<p class="mu" style="margin:4px 0 0">${sub}</p>` : ''}</div><button class="ib" aria-label="Fechar" onclick="closeM()">${ic('x')}</button></div><div class="mb">${body}</div>${ok || cancel ? `<div class="mf">${cancel ? `<button class="btn s" onclick="closeM()">${cancel}</button>` : ''}${ok ? `<button class="btn ${danger ? 'd' : ''}" id="mok">${label}</button>` : ''}</div>` : ''}`;
  $('#modal').classList.add('on');
  if (ok)
    $('#mok').onclick = () => {
      if (ok() !== false)
        closeM();
    };
  setTimeout(() => {
    const f = $('#mbox input,#mbox textarea,#mbox select'), box = $('#mbox');
    /* Leva o cursor ao primeiro campo, a não ser que a pessoa já esteja em outro campo da janela. */
    if (f && innerWidth > 760 && !(box && box.contains(document.activeElement) && /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)))
      f.focus();
  }, 40);
}

function closeM() {
  const m = $('#modal');
  m.classList.remove('on');
  /* Modais que mudam algo sem botão de confirmar (ex.: rascunho) pedem para redesenhar a tela ao fechar. */
  if (m.dataset.re) {
    delete m.dataset.re;
    if (U) {
      keep();
      render();
    }
  }
}

/* ---------- Turmas: etiquetas coloridas e seletor ---------- */

/* Etiqueta com a cor da turma. curto = usa a sigla. */
const tchip = (t, curto = false) => t && t.id ? `<span class="tc" style="--c:${E(t.cor || TCORES[0])}" title="${E(tnome(t))}"><i></i>${E(curto ? tsig(t) : tnome(t))}</span>` : `<span class="tc none"><i></i>Sem turma</span>`;

/* Etiquetas das turmas de uma aula/tarefa/evento. Lista vazia = todas. */
const tchips = (ids, curto = true) => ids && ids.length ? ids.map(id => turmaById(id)).filter(Boolean).map(t => tchip(t, curto)).join('') : `<span class="tc all"><i></i>Todas</span>`;

/* Caixas de seleção de turmas para formulários. */
const tpick = (sel = []) => `<div class="tpick">${S.turmas.map(t => `<label class="tk" style="--c:${E(t.cor)}"><input type="checkbox" class="tkc" value="${t.id}" ${sel.includes(t.id) ? 'checked' : ''}><i></i><span>${E(tnome(t))}</span></label>`).join('') || '<span class="sm-t">Nenhuma turma cadastrada. Cadastre em Turmas.</span>'}</div>`;

const tpicked = () => $$('#mbox .tkc').filter(c => c.checked).map(c => +c.value);

/* Filtro de turma do painel (muda a turma em contexto). */
const tfilter = () => `<div class="tfil" role="group" aria-label="Filtrar por turma"><button class="${ctx() ? '' : 'on'}" onclick="setCtx(0)">Todas</button>${S.turmas.map(t => `<button class="${ctx() == t.id ? 'on' : ''}" style="--c:${E(t.cor)}" onclick="setCtx(${t.id})"><i></i>${E(tsig(t))}</button>`).join('')}</div>`;

function setCtx(id) {
  S.turmaAtual = +id || 0;
  save();
  keep();
  render();
}

/* Troca da própria senha (campos s0 = atual, s1 = nova, s2 = confirmação). Quem confere e grava é o servidor. */
async function trocarSenha() {
  const n = $('#s1').value;
  if (!senhaForte(n))
    return toast('Use 8+ caracteres com letras e números');
  if (n != $('#s2').value)
    return toast('As senhas não coincidem');
  try {
    await chamar('POST', '/api/conta/senha', { atual: $('#s0').value, nova: n });
  }
  catch (e) {
    return toast(e.msg);
  }
  closeM();
  logA('Alterou a própria senha');
  save();
  toast('Senha alterada. Os outros aparelhos foram desconectados.');
}

/* Janela de troca da própria senha (aluno no perfil, mentor em Configurações). */
function senha() {
  if (U.preview)
    return toast('Você está na visão do mentor. Para trocar a senha do aluno, use "Redefinir senha" na ficha dele.');
  modal('Alterar senha', F('Senha atual', '<input id="s0" type="password" autocomplete="current-password">') + F('Nova senha', '<input id="s1" type="password" autocomplete="new-password">', 'Mínimo de 8 caracteres, com letras e números.') + F('Confirmar nova senha', '<input id="s2" type="password" autocomplete="new-password">'), { label: 'Salvar nova senha', ok: () => {
      trocarSenha();
      return false;
    } });
}
