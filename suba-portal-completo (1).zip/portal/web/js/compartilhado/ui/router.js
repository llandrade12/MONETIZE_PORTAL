/**
 * compartilhado/ui/router.js
 * Roteador das áreas logadas (aluno.html e mentor.html).
 * Cada área declara APP = { role, inicio, view() } no seu app.js; view() devolve { html, title, crumb } da rota atual.
 */
'use strict';

function nav(p, a = null) {
  R = { p, a };
  closeSide();
  closeSheet();
  render();
  scrollTo(0, 0);
}

/* A página só abre para o perfil certo. Sem sessão (ou com outro perfil), volta para o login. */
function guarda() {
  if (U && U.role == APP.role && (U.role == 'admin' || U.preview || S.termos[U.aid]))
    return true;
  if (!U) {
    /* Sem sessão: depois de entrar, a pessoa volta para a página (e o aviso) que tentou abrir. */
    try {
      sessionStorage.setItem('sop-destino', PAG[APP.role] + (R.p && R.p != APP.inicio && /^[A-Za-z]+$/.test(R.p) ? '#ir=' + R.p : ''));
    }
    catch (e) {
    }
  }
  location.replace(U && U.role != APP.role && (U.role == 'admin' || U.preview || S.termos[U.aid]) ? PAG[U.role] : PAG.login);
  return false;
}

function render() {
  if (!guarda())
    return;
  if (APP.antes)
    APP.antes();
  const v = APP.view(), y = scrollY;
  if (!v)
    return;
  $('#app').innerHTML = shell(v.html, v);
  if (R.keep)
    scrollTo(0, y);
  R.keep = false;
  try {
    sessionStorage.setItem('sop-rota-' + APP.role, JSON.stringify({ p: R.p, a: R.a }));
  }
  catch (e) {
  }
}

/* Primeira tela: a última rota aberta nesta aba, ou a inicial da área. */
function iniciar() {
  document.addEventListener('keydown', e => {
    if (e.key == 'Escape') {
      closeM();
      closeSide();
      closeSheet();
    }
  });
  R = { p: APP.inicio, a: null };
  try {
    const r = JSON.parse(sessionStorage.getItem('sop-rota-' + APP.role) || 'null');
    if (r && r.p)
      R = r;
  }
  catch (e) {
  }
  irPeloEndereco();
  addEventListener('hashchange', () => {
    if (irPeloEndereco())
      render();
  });
  /* Toque em uma notificação com o portal já aberto: o serviço em segundo plano avisa para onde ir. */
  if (navigator.serviceWorker)
    navigator.serviceWorker.addEventListener('message', e => {
      if (e.data && e.data.ir && /^[A-Za-z]+$/.test(e.data.ir))
        nav(e.data.ir);
    });
  render();
}

/* Links dos avisos (e-mail e notificação) chegam como pagina.html#ir=tarefas: abre direto a tela indicada. */
function irPeloEndereco() {
  const m = /[#&]ir=([A-Za-z]+)/.exec(location.hash);
  if (!m)
    return false;
  R = { p: m[1], a: null };
  try {
    history.replaceState(null, '', location.pathname + location.search);
  }
  catch (e) {
  }
  return true;
}
