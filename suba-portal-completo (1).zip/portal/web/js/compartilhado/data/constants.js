/**
 * compartilhado/data/constants.js
 * Regras de negócio fixas: competências, áreas da Roda, critérios, hábitos, metas e cores das turmas.
 */
'use strict';

const AREAS = ['Saúde', 'Família', 'Finanças', 'Carreira', 'Espiritual', 'Social', 'Lazer', 'Mental'];

const CRIT = {
  'Caráter': 'Íntegro, cumpre promessas, assume erros sem desculpas.', 'Competência': 'Domina a função e entrega com excelência e velocidade.', 'Cultura': 'Vive o ritmo da empresa de forma natural.', 'Conexão': 'Inteligência emocional e bom relacionamento com o time.', 'Chamado': 'Demonstra ambição saudável para crescer.', 'Constância': 'Mantém alta performance sem se abalar por cansaço.', 'Cabeça de dono': 'Pensa em lucro, processos e melhoria do negócio.', 'Coachabilidade': 'Aceita feedback duro e muda rápido.', 'Capacidade resolutiva': 'Traz soluções, não crises.', 'Comunicação persuasiva': 'Fala com clareza, impacto e domínio de scripts.'
};

const HABITS = ['Estudo da palavra', 'Oração', 'Aula do curso', 'Limite de rede social', 'Alimentação limpa', 'Jejum'];

const LEIT = {
  livros: ['Livros', 2, 'Livro'], audiolivros: ['Audiolivros', 4, 'Audiolivro'], filmes: ['Filmes', 7, 'Filme'], videos: ['Vídeos', 7, 'Vídeo'], podcasts: ['Podcasts', 7, 'Podcast']
};

const WT = ['Musculação', 'Corrida', 'Caminhada', 'Bike', 'Futebol', 'Funcional', 'Natação', 'Alongamento', 'Outro'];

const BIB = [['Provérbios', 31], ['Efésios', 6], ['Tiago', 5], ['1 Pedro', 5]];

const SEM = 10;

/* Cores para identificar cada turma no calendário e nas listas. */
const TCORES = ['#fdb621', '#5aa9e6', '#6cc08b', '#e8795e', '#b48bea', '#4fc4c0', '#e684b4', '#a5b84c'];

/* Arquivos aceitos na entrega de tarefas. */
const FEXT = ['pdf', 'ppt', 'pptx', 'xls', 'xlsx', 'csv', 'doc', 'docx', 'txt', 'png', 'jpg', 'jpeg', 'zip'];

const FMAX = 20;

/* ---------- Regras configuráveis (o mentor altera em Configurações e em Notificações > Automação) ----------
 * Os mesmos padrões existem no servidor (backend, classe Padroes): ao mudar um, mude nos dois lugares.
 * As competências e as perguntas frequentes iniciais são gravadas pelo servidor na instalação.
 */
const CFG0 = {
  freqMin: 75,        /* frequência mínima (%) para o certificado */
  certFreq: true,     /* certificado depende da frequência mínima */
  compensa: true,     /* quem assistiu à gravação tem a falta compensada */
  justAbona: true,    /* falta justificada aprovada não reduz a frequência */
  pctVisto: 90,       /* % do vídeo para marcar a aula como assistida */
  autoOn: true,       /* lembretes automáticos ligados */
  lembAula: 1,        /* dias de antecedência do lembrete de aula */
  lembPrazo: 2,       /* dias de antecedência do lembrete de prazo */
  atrasoCada: 3,      /* repete o aviso de tarefa em atraso a cada N dias */
  escala: 7,          /* dias de atraso para avisar o mentor */
  canais: { email: true, whats: true },
  webhook: '', mentorEmail: '', mentorTel: ''
};

/* Situações de presença. */
const PST = {
  P: ['Presente', 'ok', 'Presente'], A: ['Atrasado', 'wn', 'Atraso'], F: ['Falta', 'er', 'Falta'], J: ['Falta justificada', 'in', 'Justif.'], C: ['Compensada pela gravação', 'gd', 'Comp.'], '': ['Sem registro', '', '—']
};

const CHCAT = ['Acesso', 'Pagamento', 'Problema técnico', 'Outro'];

/* Arquivos aceitos como material de apoio da aula. */
const MEXT = ['pdf', 'ppt', 'pptx', 'key', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'png', 'jpg', 'jpeg', 'zip', 'mp3'];
