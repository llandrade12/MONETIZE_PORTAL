/**
 * compartilhado/data/seed.js
 * Formato inicial da rotina de um aluno (hábitos, treinos, leituras, estudo bíblico e objetivos).
 * O portal nasce zerado: os dados vêm sempre do servidor (veja core/api.js e core/store.js).
 */
'use strict';

function rotBlank() {
  const r = {
    hab: {}, treino: Array.from({ length: SEM }, () => [{}, {}, {}]), bib: {}, obj: Array.from({ length: 5 }, () => ({ t: '', m: ['', '', '', '', ''], done: [0, 0, 0, 0, 0] }))
  };
  for (const k in LEIT)
    r[k] = Array.from({ length: LEIT[k][1] }, () => ({}));
  return r;
}
