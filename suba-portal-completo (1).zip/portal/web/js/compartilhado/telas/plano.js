/**
 * compartilhado/telas/plano.js
 * Plano de ação: o cartão da meta com etapas, prazos e acompanhamento.
 * O aluno edita o plano; o mentor vê o mesmo cartão, avalia e comenta.
 */
'use strict';

const META_ST = { proposta: ['Aguardando aprovação', 'in'], aprovada: ['Em andamento', 'gd'], ajustar: ['Ajuste solicitado', 'wn'], feita: ['Concluída', 'ok'] };

const metaSt = m => m.feita ? META_ST.feita : META_ST[m.st];

/* Cartão de uma meta com seu plano. edit = o aluno pode mexer; adm = visão do mentor. */
function metaCard(m, edit, adm) {
  const p = metaPct(m), late = m.etapas.filter(etapaAtrasada).length, prox = m.etapas.filter(e => !e.feito && e.prazo).sort((a, b) => a.prazo < b.prazo ? -1 : 1)[0];
  return `<article class="card pa ${m.feita ? 'ok' : late ? 'late' : ''}"><div class="row sp" style="align-items:flex-start;gap:12px"><div style="flex:1;min-width:200px"><div class="row" style="gap:8px;margin-bottom:6px">${tag(...metaSt(m))}${late ? tag(late + ' etapa(s) em atraso', 'er') : ''}${m.prazo ? `<span class="sm-t">até ${DFY(m.prazo)}</span>` : ''}</div><h3>${E(m.t)}</h3>${adm ? `<span class="sm-t">${E(nm(m.aid))}</span>` : ''}</div>
<div class="pa-p"><b>${p}%</b><span class="sm-t">${m.etapas.filter(e => e.feito).length} de ${m.etapas.length} etapa(s)</span></div></div>
<div style="margin:12px 0 4px">${bar(p, m.feita ? 'ok' : '')}</div>
${m.obs ? `<p class="sm-t" style="margin:10px 0 0">Mentor: ${E(m.obs)}</p>` : ''}
${m.etapas.length ? `<div class="pa-l">${m.etapas.map(e => `<div class="pa-e ${e.feito ? 'dn' : etapaAtrasada(e) ? 'lt' : ''}"><label class="chk"><input type="checkbox" ${e.feito ? 'checked' : ''} ${edit ? '' : 'disabled'} onchange="etapaTog('${m.id}','${e.id}')"><span>${E(e.t)}</span></label><span class="row" style="gap:6px;flex-wrap:nowrap">${e.feito ? `<span class="sm-t">feita em ${E((e.at || '').slice(0, 5))}</span>` : edit ? `<input type="date" class="pa-d" aria-label="Prazo da etapa" value="${e.prazo || ''}" onchange="etapaPrazo('${m.id}','${e.id}',this.value)">` : `<span class="sm-t">${e.prazo ? DF(e.prazo) : 'sem prazo'}</span>`}${edit && !e.feito ? `<button class="btn q sm" aria-label="Remover etapa" onclick="etapaDel('${m.id}','${e.id}')">${ic('x')}</button>` : ''}</span></div>`).join('')}</div>` : `<p class="mu" style="margin:12px 0 0">${edit ? 'Quebre a meta em etapas pequenas, com prazo. É isso que transforma a meta em plano.' : 'Ainda sem etapas.'}</p>`}
${edit && !m.feita ? `<div class="pa-add"><input id="pe-${m.id}" placeholder="Nova etapa (ex.: Mapear os indicadores atuais)" onkeydown="if(event.key=='Enter')etapaAdd('${m.id}')"><input type="date" id="pd-${m.id}" aria-label="Prazo da nova etapa"><button class="btn s sm" onclick="etapaAdd('${m.id}')">${ic('plus')}Etapa</button></div>` : ''}
${m.checkins.length ? `<div class="pa-ck"><span class="sm-t">Acompanhamento</span>${m.checkins.slice(0, adm ? 6 : 3).map(c => `<div class="pa-c"><span class="sm-t">${E(c.at)}${c.who ? ' · ' + E(c.who) : ''}</span><p>${E(c.txt)}</p></div>`).join('')}</div>` : ''}
<div class="row" style="margin-top:14px">${edit && m.st == 'ajustar' ? `<button class="btn sm" onclick="proporMeta('${m.id}')">Ajustar e reenviar</button>` : ''}${edit && m.st == 'aprovada' && !m.feita ? `<button class="btn s sm" onclick="metaCheck('${m.id}')">${ic('msg')}Registrar acompanhamento</button>${p == 100 || !m.etapas.length ? `<button class="btn sm" onclick="metaFim('${m.id}')">${ic('ok')}Concluir meta</button>` : ''}` : ''}${edit && m.st == 'proposta' ? `<button class="btn q sm" onclick="proporMeta('${m.id}')">Editar</button>` : ''}${adm && m.st == 'proposta' ? `<button class="btn sm" onclick="metaAval('${m.id}')">Avaliar</button>` : ''}${adm && m.st != 'proposta' ? `<button class="btn s sm" onclick="metaCheck('${m.id}')">${ic('msg')}Comentar</button>` : ''}</div></article>`;
}

const metaDe = id => S.metas.find(x => x.id == id);

/* Registro de acompanhamento: o aluno conta como está indo; o mentor comenta. */
function metaCheck(mid) {
  const m = metaDe(mid), adm = isAdm();
  modal(adm ? 'Comentar o plano' : 'Registrar acompanhamento', F(adm ? 'Comentário para o aluno' : 'Como está o andamento?', `<textarea id="mck" rows="4" placeholder="${adm ? 'Orientação, ajuste de rota, reconhecimento' : 'O que avançou, o que travou, qual o próximo passo'}"></textarea>`), { sub: E(m.t), label: 'Salvar', ok: () => {
      if (val('mck').length < 4) {
        toast('Escreva o registro');
        return false;
      }
      m.checkins.unshift({ at: stamp(), txt: val('mck'), who: adm ? S.mentor : '' });
      if (adm)
        notify('Comentário no seu plano de ação', 'E-mail + push', '"' + m.t + '": ' + val('mck'), m.aid, 'evolucao');
      else
        notifyM('Acompanhamento de ' + nm(m.aid), '"' + m.t + '" (' + metaPct(m) + '%): ' + val('mck').slice(0, 140), 'metas');
      keep();
      done(adm ? 'Comentário enviado ao aluno' : 'Acompanhamento registrado');
    } });
}
