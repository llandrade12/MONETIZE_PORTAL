/**
 * compartilhado/telas/lgpd.js
 * LGPD: reúne e exporta tudo o que o portal guarda sobre um aluno.
 * O aluno baixa os próprios dados; o mentor exporta pela ficha do aluno.
 */
'use strict';

/* Tudo o que o portal guarda sobre um aluno, em formato legível. */
function lgpdDados(aid) {
  const a = aluno(aid), pre = aid + '-', porChave = o => Object.fromEntries(Object.entries(o).filter(([k]) => k.startsWith(pre)).map(([k, v]) => [k.slice(pre.length), v]));
  const { foto, ...cad } = a;
  const nomeA = n => (aulaN(n) || {}).nome || 'aula ' + n, nomeT = i => (S.tarefas.find(t => t.id == i) || {}).t || 'tarefa ' + i;
  const ren = (o, fn) => Object.fromEntries(Object.entries(o).map(([k, v]) => [fn(k), v]));
  return {
    gerado_em: new Date().toISOString(), portal: BRAND.nome + ' · Área de Membros',
    cadastro: { ...cad, tem_foto: !!foto }, turma: tnome(turmaDe(aid)), termos_aceitos_em: S.termos[aid] || null,
    frequencia: (f => ({ percentual: f.pct, presencas: f.ok, encontros: f.n, minimo: f.min }))(freq(aid)),
    presenca_por_aula: ren(porChave(S.pres), nomeA), motivos_de_falta: ren(porChave(S.presObs), nomeA), justificativas: S.just.filter(j => j.aid == aid),
    aulas_assistidas: Object.keys(porChave(S.vis)).map(nomeA), progresso_dos_videos: ren(porChave(S.prog), nomeA),
    entregas: ren(porChave(S.ent), nomeT), rascunhos: ren(porChave(S.rasc), nomeT), notas: ren(porChave(S.notas), nomeT), prazos_reabertos: ren(porChave(S.prazo), nomeT),
    contestacoes: S.contest.filter(c => c.aid == aid), metas_e_plano_de_acao: S.metas.filter(m => m.aid == aid), roda_da_vida: S.roda[aid] || null,
    rotina: S.rot[aid] || null, competencias_ajustadas: S.compA[aid] || null, recomendacoes: porChave(S.recSt),
    diario: S.diario.filter(d => d.aid == aid), chamados: S.chamados.filter(c => c.aid == aid),
    notificacoes: S.inbox.filter(i => i.aid == aid), mensagens_enviadas: S.fila.filter(f => f.aid == aid).map(({ c, to, ev, at, st }) => ({ canal: c, para: to, assunto: ev, em: at, situacao: st })),
    comentarios_no_mural: S.avisos.flatMap(v => v.coms.filter(c => c.aid == aid).map(c => ({ aviso: v.t, ...c })))
  };
}

function lgpdExport(aid) {
  const a = aluno(aid);
  baixar('meus-dados-' + slug(a.nome) + '.json', JSON.stringify(lgpdDados(aid), null, 2), 'application/json');
  logA('Exportou os dados de ' + a.nome + ' (LGPD)');
  save();
  toast('Arquivo com os dados baixado');
}
