/**
 * compartilhado/telas/chamados.js
 * Chamados de suporte: a conversa do chamado é a mesma tela para o aluno e para o mentor.
 * Cada chamado em S.chamados: { id, aid, cat, t, st: aberto|respondido|resolvido, at, upd, msgs: [{ adm, txt, at }] }.
 */
'use strict';

const CH_ST = { aberto: ['Aguardando a equipe', 'wn'], respondido: ['Respondido', 'in'], resolvido: ['Resolvido', 'ok'] };

/* Conversa do chamado (aluno e mentor usam a mesma tela). */
function chVer(cid) {
  const c = S.chamados.find(x => x.id == cid), adm = isAdm();
  modal(E(c.t), `<div class="row" style="gap:8px;margin-bottom:12px">${tag(c.cat, 'gd')}${tag(...CH_ST[c.st])}</div><div class="chat">${c.msgs.map(m => `<div class="msg ${m.adm ? 'adm' : ''} ${m.adm == adm ? 'me' : ''}"><span class="sm-t">${E(m.adm ? 'Equipe' : nm(c.aid).split(' ')[0])} · ${E(m.at)}</span><p>${E(m.txt)}</p></div>`).join('')}</div>` +
    (c.st == 'resolvido' && !adm ? `<p class="sm-t" style="margin:12px 0 0">Chamado resolvido. Se o problema voltar, responda abaixo para reabrir.</p>` : '') +
    `<div style="height:12px"></div>` + F(adm ? 'Responder ao aluno' : 'Responder', `<textarea id="c9" rows="3" ${!adm && ro() ? 'disabled' : ''}></textarea>`), { wide: true, sub: adm ? E(nm(c.aid)) + ' · aberto em ' + E(c.at) : 'Aberto em ' + E(c.at), cancel: 'Fechar', label: 'Enviar resposta', ok: () => chResp(cid, false) });
  if (c.st != 'resolvido')
    $('.mf').insertAdjacentHTML('afterbegin', `<button class="btn s" onclick="if(chResp('${cid}',true)!==false)closeM()">${ic('ok')}${adm ? 'Resolver' : 'Marcar como resolvido'}</button><span style="flex:1"></span>`);
  const ch = $('#mbox .chat');
  ch.scrollTop = ch.scrollHeight;
}

function chResp(cid, fim) {
  const c = S.chamados.find(x => x.id == cid), adm = isAdm(), t = val('c9');
  if (!fim && t.length < 2) {
    toast('Escreva a resposta');
    return false;
  }
  if (t)
    c.msgs.push({ adm, txt: t, at: stamp() });
  c.st = fim ? 'resolvido' : adm ? 'respondido' : 'aberto';
  c.upd = stamp();
  if (adm)
    notify(fim ? 'Chamado resolvido' : 'Resposta no seu chamado', 'E-mail + WhatsApp', '"' + c.t + '"' + (t ? ': ' + t : ''), c.aid, 'ajuda');
  else if (!fim)
    notifyM('Nova resposta no chamado de ' + nm(c.aid), c.t + ': ' + t.slice(0, 140), 'suporte');
  keep();
  done(fim ? 'Chamado resolvido' : 'Resposta enviada', (fim ? 'Resolveu' : 'Respondeu') + ' o chamado "' + c.t + '"');
}
