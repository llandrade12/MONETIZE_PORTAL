/**
 * compartilhado/telas/rotina.js
 * Rotina e hábitos. A mesma tela serve ao aluno (preenche) e ao mentor (consulta na ficha do aluno).
 */
'use strict';

function S_rotina(id = ME().id, admView = false) {
  const t = sub('rotina', 'hab'), r = rot(id);
  const hp = HABITS.reduce((s, h) => s + Object.keys(r.hab).filter(k => k.startsWith(h + '|') && r.hab[k] == 'y').length, 0);
  return (admView ? '' : `<p class="mu" style="max-width:640px">Seu registro diário de disciplina. É aqui que o padrão vira rotina.</p>`) +
    tabs('rotina', [['hab', 'Hábitos diários'], ['treino', 'Treinos', r.treino.filter(w => w.filter(x => x.status == 'Treinei').length >= 3).length + '/' + SEM], ['leit', 'Leituras e conteúdos'], ['bib', 'Estudo bíblico', pct(Object.keys(r.bib).length, BIB.reduce((s, b) => s + b[1], 0)) + '%'], ['obj', 'Objetivos']]) +
    (t == 'treino' ? rTreino(id, r) : t == 'leit' ? rLeit(id, r) : t == 'bib' ? rBib(id, r) : t == 'obj' ? rObj(id, r) : rHab(id, r));
}

const rdis = () => ro() && !isAdm() ? 'disabled' : '';

function rset(id, path, v) {
  const r = rot(id);
  const k = path.split('.');
  let o = r;
  for (let i = 0; i < k.length - 1; i++)
    o = o[k[i]];
  o[k[k.length - 1]] = v;
  save();
  keep();
  render();
}

function rHab(id, r) {
  const w = ST.hw ?? week(), cnt = i => HABITS.reduce((s, h) => s + Array.from({ length: 7 }, (_, d) => r.hab[h + '|' + i + '-' + d] == 'y' ? 1 : 0).reduce((a, b) => a + b, 0), 0), tot = HABITS.length * 7 - 6;
  return wkSel('hw', i => pct(cnt(i), tot) + '% cumprido') + `<div class="card"><div class="ch"><h3>Semana ${w + 1}</h3>${tag(pct(cnt(w), tot) + '% cumprido', pct(cnt(w), tot) >= 70 ? 'ok' : 'gd')}</div><div style="overflow-x:auto"><table class="hab"><tr><th></th>${Array.from({ length: 7 }, (_, d) => `<th>${DOW[D(wkD(w, d)).getDay()]}<br><span style="font-weight:500">${DF(wkD(w, d))}</span></th>`).join('')}</tr>
  ${HABITS.map(h => `<tr><td>${h}</td>${Array.from({ length: 7 }, (_, d) => {
    if (h == 'Jejum' && d != 3)
      return '<td></td>';
    const k = h + '|' + w + '-' + d, v = r.hab[k] || '';
    return `<td><button class="hc ${v == 'y' ? 'y' : v == 'n' ? 'n' : ''}" ${rdis()} aria-label="${h} ${DF(wkD(w, d))}: ${v == 'y' ? 'cumprido' : v == 'n' ? 'não cumprido' : 'sem registro'}" onclick="habT(${id},'${k}')">${v == 'y' ? ic('ok') : v == 'n' ? ic('x') : ''}</button></td>`;
  }).join('')}</tr>`).join('')}</table></div>
  <p class="sm-t" style="margin:10px 0 0">Toque uma vez para cumprido, duas para não cumprido, três para limpar. Jejum é registrado uma vez por semana.</p></div>`;
}

function habT(id, k) {
  const r = rot(id), v = r.hab[k] || '';
  r.hab[k] = v == '' ? 'y' : v == 'y' ? 'n' : '';
  save();
  keep();
  render();
}

function rTreino(id, r) {
  const w = ST.tw ?? week(), ws = r.treino[w], dn = x => x.filter(y => y.status == 'Treinei').length;
  const inp = (p, v, ph = '', ty = 'text') => `<input type="${ty}" value="${E(v || '')}" placeholder="${ph}" ${rdis()} onchange="rset(${id},'${p}',this.value)">`;
  const sel = (p, v, o, bl) => `<select ${rdis()} onchange="rset(${id},'${p}',this.value)"><option value="">${bl}</option>${o.map(x => `<option ${x == v ? 'selected' : ''}>${x}</option>`).join('')}</select>`;
  return wkSel('tw', i => Math.min(3, dn(r.treino[i])) + '/3 treinos') + `<div class="card"><div class="ch"><h3>Meta da semana: 3 treinos</h3>${tag(dn(ws) + ' de 3', dn(ws) >= 3 ? 'ok' : 'gd')}</div>` +
    ws.map((x, i) => {
      const p = 'treino.' + w + '.' + i, T = x.type, run = ['Corrida', 'Caminhada', 'Bike'].includes(T);
      return `<div class="slot"><div class="row sp" style="margin-bottom:12px"><b>${i < 3 ? 'Treino ' + (i + 1) : 'Treino extra'}</b><label class="chk"><input type="checkbox" ${x.status == 'Treinei' ? 'checked' : ''} ${rdis()} onchange="rset(${id},'${p}.status',this.checked?'Treinei':'')"> Treinei</label></div>
  <div class="fx">${F('Tipo', sel(p + '.type', T, WT, 'Selecione'))}${F('Data', inp(p + '.date', x.date, '', 'date'))}${run ? F('Distância (km)', inp(p + '.km', x.km, '0,0')) + F('Tempo', inp(p + '.dur', x.dur, 'mm:ss')) + F('Pace', '<div class="pace">' + pace(x.km, x.dur) + '</div>') : T ? F('Foco', inp(p + '.focus', x.focus, 'Ex.: peito e tríceps')) + F('Duração (min)', inp(p + '.dur', x.dur)) : ''}</div></div>`;
    }).join('') +
    `<button class="btn s sm" style="margin-top:12px" ${rdis()} onclick="rot(${id}).treino[${w}].push({});save();keep();render()">${ic('plus')}Treino extra</button></div>`;
}

function rLeit(id, r) {
  const c = ST.leit || 'livros', [L, n, s] = LEIT[c], items = r[c], ok = x => x.status == 'Concluído';
  const inp = (p, v, ph = '', ty = 'text') => `<input type="${ty}" value="${E(v || '')}" placeholder="${ph}" ${rdis()} onchange="rset(${id},'${p}',this.value)">`;
  return `<div class="g4" style="grid-template-columns:repeat(auto-fit,minmax(130px,1fr));margin-bottom:16px">${Object.keys(LEIT).map(k => {
    const d = r[k].filter(ok).length, N = LEIT[k][1];
    return `<button class="kpi" style="text-align:left;cursor:pointer;${k == c ? 'border-color:var(--gd);background:var(--gds)' : ''}" onclick="ST.leit='${k}';keep();render()"><span class="lb">${LEIT[k][0]}</span><span class="num" style="font-size:28px">${d}/${N}</span>${bar(pct(d, N))}</button>`;
  }).join('')}</div>
  <div class="card"><div class="ch"><h3>Meta do período: ${n} ${L.toLowerCase()}</h3></div>${items.map((x, i) => {
    const p = c + '.' + i, f = x.fap || {};
    return `<div class="slot"><div class="row sp" style="margin-bottom:10px"><b>${i < n ? s + ' ' + (i + 1) : s + ' extra'}</b><label class="chk"><input type="checkbox" ${ok(x) ? 'checked' : ''} ${rdis()} onchange="rset(${id},'${p}.status',this.checked?'Concluído':'')"> Concluído</label></div>
  <div class="fx">${F('Título', inp(p + '.title', x.title))}${c == 'livros' || c == 'audiolivros' ? F('Autor', inp(p + '.author', x.author)) : ''}${c == 'podcasts' ? F('Apresentador', inp(p + '.pres', x.pres)) : ''}</div>
  <details class="fap" ${f.f || f.a || f.p ? 'open' : ''}><summary>Método FAP: fato, aprendizado e prática</summary><div class="fx">${['f', 'a', 'p'].map((k, j) => F(['Fato', 'Aprendizado', 'Prática'][j], `<textarea rows="2" ${rdis()} onchange="rset(${id},'${p}.fap',Object.assign(rot(${id}).${c}[${i}].fap||{},{${k}:this.value}))">${E(f[k] || '')}</textarea>`)).join('')}</div></details></div>`;
  }).join('')}
  <button class="btn s sm" style="margin-top:12px" ${rdis()} onclick="rot(${id}).${c}.push({});save();keep();render()">${ic('plus')}${s} extra</button></div>`;
}

function rBib(id, r) {
  const tot = BIB.reduce((s, b) => s + b[1], 0), d = Object.keys(r.bib).length;
  return `<div class="g3" style="margin-bottom:16px"><div class="kpi"><span class="lb">Progresso</span><span class="num gold">${pct(d, tot)}%</span>${bar(pct(d, tot))}</div><div class="kpi"><span class="lb">Capítulos lidos</span><span class="num">${d}/${tot}</span></div><div class="kpi"><span class="lb">Faltam</span><span class="num">${tot - d}</span></div></div>` +
    BIB.map(([b, n]) => {
      const c = Array.from({ length: n }, (_, i) => r.bib[b + '-' + (i + 1)] ? 1 : 0).reduce((a, x) => a + x, 0);
      return `<div class="card"><div class="ch"><h3>${b}</h3>${tag(c + '/' + n + ' capítulos', c == n ? 'ok' : 'gd')}</div><div class="chips">${Array.from({ length: n }, (_, i) => {
        const k = b + '-' + (i + 1), on = r.bib[k];
        return `<button class="${on ? 'on' : ''}" ${rdis()} aria-pressed="${!!on}" onclick="bibT(${id},'${k}')">${i + 1}</button>`;
      }).join('')}</div></div>`;
    }).join('');
}

function bibT(id, k) {
  const r = rot(id);
  if (r.bib[k])
    delete r.bib[k];
  else
    r.bib[k] = 1;
  save();
  keep();
  render();
}

function rObj(id, r) {
  return `<p class="mu" style="max-width:640px">Defina até 5 objetivos para os próximos 12 meses e divida cada um em 5 fases. Marque cada fase concluída.</p><div class="g2">${r.obj.map((o, i) => {
    const d = o.done.filter(Boolean).length;
    return `<div class="card"><div class="row sp" style="margin-bottom:10px"><span class="num gold" style="font-size:26px">${i + 1}</span>${o.t ? tag(d + '/5 fases', d == 5 ? 'ok' : 'gd') : ''}</div>
  ${F('Objetivo', `<input value="${E(o.t)}" placeholder="Descreva o objetivo" ${rdis()} onchange="rset(${id},'obj.${i}.t',this.value)">`)}
  ${o.m.map((m, j) => `<div class="row" style="gap:8px;margin-bottom:8px;flex-wrap:nowrap"><input type="checkbox" aria-label="Fase ${j + 1} concluída" ${o.done[j] ? 'checked' : ''} ${rdis()} onchange="rset(${id},'obj.${i}.done.${j}',this.checked?1:0)"><input value="${E(m)}" placeholder="Fase ${j + 1}" ${rdis()} onchange="rset(${id},'obj.${i}.m.${j}',this.value)"></div>`).join('')}</div>`;
  }).join('')}</div>`;
}
