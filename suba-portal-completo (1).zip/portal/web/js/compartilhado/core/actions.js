/**
 * compartilhado/core/actions.js
 * Efeitos colaterais comuns: histórico de auditoria, notificações e confirmação visual.
 *
 * Quem entrega as notificações fora do portal é o servidor: quando a notificação é gravada, ele envia o
 * push, o e-mail e (com o serviço de automação ligado) o WhatsApp. Aqui o portal só registra o aviso.
 */
'use strict';

function logA(m) {
  S.log.unshift({ id: uid(), at: stamp(), who: isAdm() ? S.mentor : nm(ME().id), m });
  if (S.log.length > 500)
    S.log.length = 500;
}

/**
 * Canais externos que valem para o aluno neste aviso: [e-mail, WhatsApp].
 * É a mesma regra que o servidor aplica ao enviar: o pedido ("somente no portal", "e-mail", "WhatsApp"),
 * os canais ligados pelo mentor e a preferência do próprio aluno.
 */
function canaisDe(aid, canal = 'e-mail + whatsapp') {
  const a = aluno(aid);
  if (!a || /somente|só no portal/i.test(canal))
    return [0, 0];
  const pref = a.canais || {}, g = S.cfg.canais || {};
  return [/e-?mail/i.test(canal) && g.email && pref.email !== false && a.email ? 1 : 0, /whats/i.test(canal) && g.whats && pref.whats !== false && digits(a.tel).length >= 10 ? 1 : 0];
}

/**
 * Registra uma notificação.
 * aids: 'all' (alunos ativos da turma em contexto), um id, uma lista de ids ou de alunos.
 */
function notify(ev, canal, txt, aids, go = 'inicio') {
  const list = aids == 'all' ? ativos().map(a => a.id) : [].concat(aids).map(a => a && a.id || a);
  if (!list.length)
    return;
  let em = 0, wa = 0;
  list.forEach(aid => {
    S.inbox.unshift({ id: uid(), aid, t: ev, m: txt, at: stamp(), lido: false, go, canal });
    const r = canaisDe(aid, canal);
    em += r[0];
    wa += r[1];
  });
  S.notif.unshift({
    id: uid(), at: stamp(), ev, canal: ['Portal'].concat(em ? ['e-mail'] : [], wa ? ['WhatsApp'] : []).join(' + '), dest: list.length > 3 ? list.length + ' alunos' : list.map(nm).join(', '), auto: false
  });
  if (S.notif.length > 300)
    S.notif.length = 300;
}

/* ---------- Links de envio manual (fila de e-mail e WhatsApp do painel) ---------- */

const waLink = (tel, txt) => {
  let d = digits(tel);
  if (d.length <= 11)
    d = '55' + d;
  return 'https://wa.me/' + d + '?text=' + encodeURIComponent(txt);
};

const mailLink = (to, as, txt) => 'mailto:' + encodeURIComponent(to) + '?subject=' + encodeURIComponent(as) + '&body=' + encodeURIComponent(txt);

/* Alerta para o mentor: sino do painel, push e, se ele cadastrou e-mail ou WhatsApp em Automação, também nesses canais. */
function notifyM(t, m, go = 'visao', arg = null) {
  S.inboxM.unshift({ id: uid(), t, m, at: stamp(), lido: false, go, arg, auto: false });
  if (S.inboxM.length > 200)
    S.inboxM.length = 200;
}

/* ---------- Lembretes automáticos ---------- */

/**
 * Os lembretes (aula, prazo, atraso, gravação, frequência e plano de ação) são conferidos pelo servidor,
 * de tempos em tempos, e cada um sai uma vez só. force = pede uma conferência agora, logo depois de o
 * que acabou de ser alterado (uma chamada, por exemplo) estar salvo.
 */
function autoRun(force) {
  if (force && U && U.role == 'admin')
    aposSalvar(() => chamar('POST', '/api/lembretes/rodar').then(conferir, () => 0));
  return 0;
}

function done(msg, logMsg) {
  logA(logMsg || msg);
  save();
  render();
  toast(msg);
}

const keep = () => {
  R.keep = true;
};
