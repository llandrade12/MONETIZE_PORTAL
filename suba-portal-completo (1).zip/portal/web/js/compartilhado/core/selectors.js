/**
 * compartilhado/core/selectors.js
 * Cálculos derivados do estado: turmas, notas ponderadas, presença, entregas, prazos e liberação de conteúdo.
 * Nada aqui é salvo: tudo é recalculado a partir de S.
 */
'use strict';

const hoje = () => S.hoje || ISO(new Date());

const isAdm = () => U && U.role == 'admin';

const aluno = id => S.alunos.find(a => a.id == id);

const nm = id => (aluno(id) || {}).nome || '—';

const ME = () => aluno(U && U.aid || 1);

/* ---------- Turmas ---------- */

const turmaById = id => S.turmas.find(t => t.id == id);

const SEMT = { id: 0, nome: 'Sem turma', edicao: '', sigla: '—', cor: '#7a766f', status: '', inicio: '', fim: '' };

const turmaDe = aid => turmaById((aluno(aid) || {}).turma) || SEMT;

/* Turma em contexto: no painel é a turma escolhida no menu (0 = todas); para o aluno é a turma dele. */
const ctx = () => isAdm() ? (turmaById(S.turmaAtual) ? S.turmaAtual : 0) : (ME() || {}).turma || -1;

const tnome = t => t ? t.nome + (t.edicao ? ', ' + t.edicao : '') : 'Sem turma';

const tsig = t => t.sigla || (t.nome.split(' ').filter(w => w.length > 1).map(w => w[0]).join('').slice(0, 3).toUpperCase() + ' ' + (String(t.edicao).match(/\d+/) || [''])[0]).trim();

const ctxNome = () => ctx() ? tnome(turmaById(ctx())) : 'Todas as turmas';

/* Item com lista de turmas (aula, tarefa, evento). Lista vazia = vale para todas. */
const inT = (x, tid) => !tid || !x.turmas || !x.turmas.length || x.turmas.includes(tid);

const alunosCtx = () => S.alunos.filter(a => !ctx() || a.turma == ctx());

const ativos = () => alunosCtx().filter(a => a.status == 'ativo');

/* Alunos ativos atingidos por uma aula/tarefa/evento. */
const alvoDe = x => S.alunos.filter(a => a.status == 'ativo' && a.turma && inT(x, a.turma));

const ro = () => !isAdm() && turmaDe(ME().id).status == 'Concluída';

/* ---------- Competências (cadastradas pelo mentor) ---------- */

const CK = () => S.compL.map(c => c.nome);

const cpeso = c => (S.compL.find(x => x.nome == c) || {}).peso || 0;

/* ---------- Aulas ---------- */

const aulaN = n => S.aulas.find(a => a.n == n);

const byDate = (a, b) => (a.date + a.hora).localeCompare(b.date + b.hora) || a.n - b.n;

const aulasDe = tid => S.aulas.filter(a => inT(a, tid)).sort(byDate);

const aulasCtx = () => aulasDe(ctx());

/* Número de ordem da aula dentro da turma em contexto. */
const ord = a => aulasCtx().indexOf(a) + 1 || aulasDe(0).indexOf(a) + 1;

const aulaLib = a => a.status == 'realizada' || a.status == 'parcial';

const pautaLib = a => aulaLib(a) || diff(a.date, hoje()) <= 1;

const realizadas = (tid = ctx()) => aulasDe(tid).filter(aulaLib);

const nextAula = (tid = ctx()) => aulasDe(tid).find(a => a.status == 'agendada' && a.date >= hoje());

const semRegistro = () => aulasCtx().filter(a => a.status == 'agendada' && diff(hoje(), a.date) >= 1);

/* ---------- Tarefas ---------- */

const tarefasDe = aid => S.tarefas.filter(t => inT(t, (aluno(aid) || {}).turma || -1));

const tarefasCtx = () => S.tarefas.filter(t => inT(t, ctx()));

const due = (aid, t) => S.prazo[aid + '-' + t.id] || t.due;

const tLib = t => (t.lib || addD(t.due, -7)) <= hoje();

const tarefasLib = () => tarefasCtx().filter(tLib);

const atrasada = (aid, t) => tLib(t) && !S.ent[aid + '-' + t.id] && due(aid, t) < hoje();

const atrasos = aid => tarefasDe(aid).filter(t => atrasada(aid, t));

const tStatus = (aid, t) => {
  const k = aid + '-' + t.id;
  if (!tLib(t))
    return ['Em breve', ''];
  if (S.notas[k] != null)
    return ['Avaliada', 'ok'];
  if (S.ent[k])
    return ['Entregue', 'in'];
  if (atrasada(aid, t))
    return ['Não entregue', 'er'];
  const d = diff(due(aid, t), hoje());
  return [d <= 2 ? 'Vence ' + (d == 0 ? 'hoje' : d == 1 ? 'amanhã' : 'em 2 dias') : 'Pendente', d <= 2 ? 'wn' : 'gd'];
};

/* ---------- Competências (por aluno) ---------- */

const mediaC = aid => {
  const r = {};
  S.tarefas.forEach(t => {
    const n = S.notas[aid + '-' + t.id];
    if (n != null)
      (r[t.comp] = r[t.comp] || []).push(n);
  });
  return r;
};

/* Ajuste individual feito pelo mentor: { nota, peso, obs } por competência. */
const compA = (aid, c) => (S.compA[aid] || {})[c] || {};

const has = v => v != null && v !== '';

/* Média calculada pelas notas das tarefas. */
const compAuto = (aid, c) => {
  const v = mediaC(aid)[c];
  return v ? avg(v) : null;
};

/* Nota da competência: a definida pelo mentor para o aluno, ou a média das tarefas. */
const compAvg = (aid, c) => has(compA(aid, c).nota) ? +compA(aid, c).nota : compAuto(aid, c);

/* Peso da competência para este aluno: o individual, ou o padrão. */
const pesoDe = (aid, c) => has(compA(aid, c).peso) ? +compA(aid, c).peso : cpeso(c);

const fin = aid => {
  let s = 0, p = 0;
  CK().forEach(c => {
    const v = compAvg(aid, c), w = pesoDe(aid, c);
    if (v != null) {
      s += v * w;
      p += w;
    }
  });
  return p ? s / p : null;
};

/* ---------- Indicadores por aluno (sempre na turma do próprio aluno) ---------- */

const realDe = aid => realizadas((aluno(aid) || {}).turma || -1);

/* ---------- Presença e frequência ---------- */

/* Situação lançada na chamada: P presente, A atrasado, F falta, J falta justificada, '' sem registro. */
const pst = (aid, n) => S.pres[aid + '-' + n] || '';

const presOk = (aid, n) => pst(aid, n) == 'P' || pst(aid, n) == 'A';

/* Frequência mínima da turma (a turma pode ter a sua; senão vale a geral). */
const freqMin = tid => {
  const t = turmaById(tid);
  return t && has(t.freqMin) ? +t.freqMin : +S.cfg.freqMin;
};

/* Encontros que contam para o aluno: os realizados na turma dele DESDE a matrícula. */
const freqBase = aid => {
  const a = aluno(aid) || {};
  return realDe(aid).filter(x => !a.mat || x.date >= a.mat);
};

/* Situação efetiva em um encontro: além da chamada, a gravação assistida compensa a falta (se a regra estiver ligada). */
const freqSt = (aid, a) => {
  const s = pst(aid, a.n);
  if (s == 'P' || s == 'A' || s == 'J')
    return s;
  return S.cfg.compensa && S.vis[aid + '-' + a.n] ? 'C' : 'F';
};

const contaPres = s => s == 'P' || s == 'A' || s == 'C' || (s == 'J' && S.cfg.justAbona);

/* Total de encontros previstos para o aluno (cadastrados ou planejados nas unidades da turma). */
const totalPrev = aid => {
  const a = aluno(aid) || {}, t = turmaDe(aid), L = aulasDe(t.id || -1).filter(x => x.status != 'cancelada');
  const depois = L.filter(x => !a.mat || x.date >= a.mat).length, plan = (t.unidades || []).reduce((s, u) => s + (+u.qtd || 0), 0);
  return Math.max(depois, plan - (L.length - depois));
};

/* Resumo da frequência do aluno. */
function freq(aid) {
  const B = freqBase(aid), st = B.map(a => freqSt(aid, a)), ok = st.filter(contaPres).length, min = freqMin((aluno(aid) || {}).turma), tot = totalPrev(aid);
  const maxF = Math.floor(tot * (100 - min) / 100 + 1e-9), faltas = B.length - ok;
  return {
    B, st, ok, n: B.length, pct: B.length ? pct(ok, B.length) : 100, min, tot, maxF, faltas, restam: maxF - faltas,
    abaixo: B.length > 0 && pct(ok, B.length) < min, perdeu: faltas > maxF
  };
}

const presPct = aid => freq(aid).n ? freq(aid).pct : 0;

/* Justificativas de falta aguardando o mentor. */
const justPend = () => S.just.filter(j => j.st == 'pendente' && inCtxAid(j.aid));

const inCtxAid = aid => !isAdm() || !ctx() || (aluno(aid) || {}).turma == ctx();

/* ---------- Unidades da turma ---------- */

const unDe = (a, tid) => ((turmaById(tid) || {}).unidades || []).find(u => u.id == (a.un || {})[tid]);

const aulasUn = (tid, uid) => aulasDe(tid).filter(a => (a.un || {})[tid] == uid);

const entPct = aid => {
  const L = tarefasDe(aid).filter(tLib);
  return pct(L.filter(t => S.ent[aid + '-' + t.id]).length, L.length);
};

const visPct = aid => pct(realDe(aid).filter(a => S.vis[aid + '-' + a.n]).length, realDe(aid).length);

/* Engajamento: média dos indicadores que já têm dados. */
const engaj = aid => {
  const v = [entPct(aid)];
  if (realDe(aid).length)
    v.push(presPct(aid), visPct(aid));
  return Math.round(avg(v));
};

const mediaPct = fn => {
  const at = ativos();
  return at.length ? Math.round(at.reduce((s, a) => s + fn(a.id), 0) / at.length) : 0;
};

const chAbertos = () => S.chamados.filter(c => c.st == 'aberto' && inCtxAid(c.aid)).length;

const unreadM = () => S.inboxM.filter(i => !i.lido).length;

/* ---------- Plano de ação ---------- */

const metaPct = m => m.etapas.length ? pct(m.etapas.filter(e => e.feito).length, m.etapas.length) : (m.feita ? 100 : 0);

const etapaAtrasada = e => !e.feito && e.prazo && e.prazo < hoje();

const pendC = () => S.contest.filter(c => !c.resp).length;

const pendM = () => S.metas.filter(m => m.st == 'proposta').length;

const unread = aid => S.inbox.filter(i => i.aid == aid && !i.lido).length;

const age = s => {
  const b = D(s), n = D(hoje());
  let a = n.getFullYear() - b.getFullYear();
  if (n.getMonth() < b.getMonth() || (n.getMonth() == b.getMonth() && n.getDate() < b.getDate()))
    a--;
  return a;
};

/* ---------- Certificado e Roda da Vida ---------- */

const certDe = aid => S.certs[(aluno(aid) || {}).turma] || { on: false, at: '' };

/* Atingiu a frequência mínima (ou o mentor liberou por exceção)? */
const certElig = aid => !S.cfg.certFreq || !freq(aid).abaixo || !!S.certLib[aid];

const certOpen = aid => !!certDe(aid).on && certElig(aid);

/* Roda da Vida: é o mentor quem libera, para a turma toda, a inicial e depois a final (em Turmas). */
const rodaIniOpen = aid => !!turmaDe(aid).rodaIni;

const finOpen = aid => !!turmaDe(aid).rodaFin;

/* ---------- Semanas da rotina (contadas a partir do início da turma do aluno) ---------- */

const wkAid = () => isAdm() ? (R.p == 'alunoD' ? R.a : ST.asel) : ME().id;

const wbase = () => turmaDe(wkAid()).inicio || (aluno(wkAid()) || {}).mat || addD(hoje(), -27);

const week = () => Math.max(0, Math.min(SEM - 1, Math.floor(diff(hoje(), wbase()) / 7)));

const wkD = (w, d = 0) => addD(wbase(), 7 * w + d);

const rot = id => {
  const r = S.rot[id], b = rotBlank();
  if (!r || typeof r != 'object')
    return S.rot[id] = b;
  /* Completa o que faltar no registro guardado (ex.: uma lista criada em uma versão mais nova do portal). */
  for (const k in b)
    if (Array.isArray(b[k]) ? !Array.isArray(r[k]) : !r[k] || typeof r[k] != 'object')
      r[k] = b[k];
  for (let w = 0; w < SEM; w++)
    if (!Array.isArray(r.treino[w]))
      r.treino[w] = [{}, {}, {}];
  return r;
};

function pace(km, d) {
  km = parseFloat(String(km || '').replace(',', '.'));
  const p = String(d || '').split(':').map(Number);
  const m = p.length == 3 ? p[0] * 60 + p[1] + p[2] / 60 : p.length == 2 ? p[0] + p[1] / 60 : p[0];
  if (!km || !m || isNaN(m))
    return '—';
  const x = m / km;
  let a = Math.floor(x), b = Math.round((x - a) * 60);
  if (b == 60) {
    a++;
    b = 0;
  }
  return a + ':' + p2(b) + ' /km';
}
