/**
 * compartilhado/core/files.js
 * Arquivos anexados: entregas dos alunos, materiais de aula e PDFs das recomendações.
 * Os arquivos ficam no servidor (API /api/arquivos). O registro guarda só { id, name, size, type }.
 */
'use strict';

/* Envia o arquivo. Devolve true quando o servidor confirmou o recebimento. */
async function fput(id, arquivo) {
  try {
    const r = await fetch('api/arquivos/' + encodeURIComponent(id) + '?nome=' + encodeURIComponent(arquivo.name || 'arquivo') + '&tipo=' + encodeURIComponent(arquivo.type || ''), {
      method: 'PUT', headers: { 'X-Portal': '1', 'Content-Type': 'application/octet-stream' }, credentials: 'same-origin', body: arquivo
    });
    if (!r.ok) {
      const j = await r.json().catch(() => null);
      FILES.erro = (j && j.msg) || 'Não foi possível enviar o arquivo';
    }
    return r.ok;
  }
  catch (e) {
    FILES.erro = 'Sem conexão: o arquivo não foi enviado';
    return false;
  }
}

/* Último motivo de falha de envio, para a tela mostrar. */
const FILES = { erro: '' };

/* Baixa o arquivo (Blob), ou null se ele não existe ou a pessoa não pode vê-lo. */
async function fget(id) {
  try {
    const r = await fetch('api/arquivos/' + encodeURIComponent(id), { credentials: 'same-origin' });
    return r.ok ? await r.blob() : null;
  }
  catch (e) {
    return null;
  }
}

async function fdel(id) {
  try {
    await fetch('api/arquivos/' + encodeURIComponent(id), { method: 'DELETE', headers: { 'X-Portal': '1' }, credentials: 'same-origin' });
  }
  catch (e) {
  }
}

/* Baixa/abre um anexo. */
async function fopen(id, name) {
  const b = await fget(id);
  if (!b)
    return toast('Arquivo não encontrado');
  const u = URL.createObjectURL(b), a = document.createElement('a');
  a.href = u;
  a.download = name || 'arquivo';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(u), 5000);
}

const fext = n => (String(n).split('.').pop() || '').toLowerCase();

const fsize = b => b > 1048576 ? (b / 1048576).toFixed(1).replace('.', ',') + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';

/* Etiqueta visual de um anexo. rm = código JS para o botão de remover (opcional). */
const fileChip = (f, rm = '') => `<span class="fchip"><b class="fx-${E(fext(f.name))}">${E(fext(f.name).toUpperCase().slice(0, 4) || 'ARQ')}</b><span class="fn"><span>${E(f.name)}</span><small>${fsize(f.size)}</small></span>${rm ? `<button type="button" class="fb" aria-label="Remover ${E(f.name)}" onclick="${rm}">${ic('x')}</button>` : f.id ? `<button type="button" class="fb" aria-label="Baixar ${E(f.name)}" title="Baixar" data-n="${E(f.name)}" onclick="fopen('${f.id}',this.dataset.n)">${ic('download')}</button>` : ''}</span>`;
