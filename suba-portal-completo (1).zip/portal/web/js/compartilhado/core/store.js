/**
 * compartilhado/core/store.js
 * Estado global da aplicação (S), quem está logado (U), rota (R) e o catálogo das coleções de dados.
 *
 * Os dados ficam no servidor. Ao abrir uma página, o portal baixa o que a pessoa pode ver e monta o
 * objeto S; cada alteração feita na tela muda S e chama save(), que envia só o que mudou
 * (veja core/api.js). Nada de turma, aluno, aula ou nota fica guardado no navegador.
 */
'use strict';

const PAG = { admin: 'mentor.html', aluno: 'aluno.html', login: 'index.html' };

/**
 * Coleções de S: [tipo, campo-chave, mais novo primeiro].
 * tipo 'l' = lista de registros, 'm' = dicionário chave -> valor, 'v' = valor único.
 * A mesma lista existe no servidor (backend, classe Colecoes): ao criar uma coleção, acrescente nos dois lugares.
 */
const COLECOES = {
  turmas: ['l', 'id'], alunos: ['l', 'id'], aulas: ['l', 'n'], eventos: ['l', 'id'], tarefas: ['l', 'id'], recs: ['l', 'id', 1], avisos: ['l', 'id'], faq: ['l', 'id'],
  metas: ['l', 'id'], contest: ['l', 'id'], just: ['l', 'id', 1], diario: ['l', 'id', 1], chamados: ['l', 'id', 1], lgpd: ['l', 'id', 1], inbox: ['l', 'id', 1], fila: ['l', 'id', 1],
  inboxM: ['l', 'id', 1], notif: ['l', 'id', 1], log: ['l', 'id', 1],
  ent: ['m'], notas: ['m'], prazo: ['m'], pres: ['m'], presObs: ['m'], vis: ['m'], prog: ['m'], rasc: ['m'], recSt: ['m'],
  roda: ['m'], rot: ['m'], compA: ['m'], termos: ['m'], certLib: ['m'], priv: ['m'], aval: ['m'], nlog: ['m'], certs: ['m'],
  cfg: ['v'], compL: ['v'], mentor: ['v'], mentores: ['v']
};

/* Campos que toda tela espera encontrar em um registro, mesmo que ele tenha sido criado sem eles. */
function normalReg(c, r) {
  if (!r || typeof r != 'object')
    return r;
  if (c == 'aulas') {
    r.mats = r.mats || [];
    r.dur = r.dur || 120;
    r.un = r.un || {};
    r.turmas = r.turmas || [];
    r.topicos = r.topicos || [];
    r.hist = r.hist || [];
  }
  else if (c == 'turmas')
    r.unidades = r.unidades || [];
  else if (c == 'metas') {
    r.etapas = r.etapas || [];
    r.checkins = r.checkins || [];
  }
  else if (c == 'alunos')
    r.canais = r.canais || { email: true, whats: true };
  else if (c == 'avisos')
    r.coms = r.coms || [];
  else if (c == 'chamados')
    r.msgs = r.msgs || [];
  return r;
}

/* Completa o estado recebido do servidor com tudo o que as telas esperam (coleções vazias e regras padrão). */
function normal(o) {
  for (const c in COLECOES) {
    const t = COLECOES[c][0];
    if (t == 'l') {
      o[c] = Array.isArray(o[c]) ? o[c] : [];
      o[c].forEach(r => normalReg(c, r));
    }
    else if (t == 'm')
      o[c] = o[c] && typeof o[c] == 'object' && !Array.isArray(o[c]) ? o[c] : {};
  }
  o.cfg = Object.assign({}, CFG0, o.cfg || {});
  o.cfg.canais = Object.assign({}, CFG0.canais, o.cfg.canais || {});
  o.compL = Array.isArray(o.compL) ? o.compL : [];
  o.mentores = Array.isArray(o.mentores) ? o.mentores : [];
  o.mentor = o.mentor || 'Mentor';
  o.v = 6;
  o.hoje = '';
  /* A turma em gestão no painel é uma preferência de quem usa: fica só neste navegador. */
  try {
    o.turmaAtual = +localStorage.getItem('sop-turma') || 0;
  }
  catch (e) {
    o.turmaAtual = 0;
  }
  return o;
}

let S = normal({});

/**
 * Quem está usando a página: { role: 'admin', email, nome } ou { role: 'aluno', aid }.
 * Mentor vendo o portal como um aluno: { role: 'aluno', aid, preview: true, mentor: e-mail do mentor }.
 */
let U = null;

let R = { p: 'inicio', a: null };

const ST = {};

/* Define U a partir da sessão confirmada pelo servidor (API.eu). */
function definirUsuario() {
  const eu = API.eu, area = typeof APP == 'undefined' ? '' : APP.role;
  if (!eu)
    return U = null;
  if (eu.role == 'admin') {
    let ver = 0;
    try {
      ver = +sessionStorage.getItem('sop-ver-como') || 0;
    }
    catch (e) {
    }
    U = area == 'aluno' && ver && S.alunos.some(a => a.id == ver) ? { role: 'aluno', aid: ver, preview: true, mentor: eu.email } : { role: 'admin', email: eu.email, nome: eu.nome, mid: eu.id };
  }
  else {
    U = { role: 'aluno', aid: eu.aid };
    /* Todo aluno tem a sua Roda da Vida, mesmo antes de o mentor liberar o preenchimento. */
    if (!S.roda[eu.aid])
      S.roda[eu.aid] = { ini: Array(8).fill(5), fin: Array(8).fill(5), iniSent: false, finSent: false };
  }
  return U;
}

/* Mentor passa a ver o portal como um aluno (só nesta aba) ou volta ao painel (id vazio). */
function verComo(id) {
  try {
    if (id)
      sessionStorage.setItem('sop-ver-como', id);
    else
      sessionStorage.removeItem('sop-ver-como');
  }
  catch (e) {
  }
}

/* Vai para a página do perfil (ou para o login), depois de garantir que tudo foi enviado ao servidor. */
async function irPara(k) {
  /* Uma troca de página por vez (a tela pode ser redesenhada enquanto o envio termina). */
  if (API.indo)
    return;
  API.indo = true;
  await salvarAgora();
  let destino = PAG[k];
  try {
    /* Quem chegou por um link de aviso (e-mail ou notificação) e precisou entrar segue para a página do aviso. */
    const d = sessionStorage.getItem('sop-destino');
    sessionStorage.removeItem('sop-destino');
    if (d && k != 'login' && d.indexOf(PAG[k]) == 0)
      destino = d;
  }
  catch (e) {
  }
  location.href = destino;
}

/* Encerra a sessão no servidor e volta para o login. */
async function sair() {
  await salvarAgora();
  verComo(0);
  try {
    if (typeof pushAoSair == 'function')
      await pushAoSair();
    await chamar('POST', '/api/auth/sair');
  }
  catch (e) {
  }
  location.href = PAG.login;
}

/**
 * Início de toda página: baixa o estado do servidor, descobre quem está logado e só então desenha a tela.
 * Sem sessão, U fica nulo: a página de login mostra o formulário e as demais voltam para o login.
 */
async function boot(fn) {
  try {
    await carregarEstado();
  }
  catch (e) {
    if (e.status != 401)
      return telaSemConexao(fn, e);
    API.eu = null;
    S = normal({});
  }
  definirUsuario();
  iniciarSincronia();
  if (typeof pushVincular == 'function')
    pushVincular();
  fn();
}

function telaSemConexao(fn, e) {
  const app = document.getElementById('app');
  app.innerHTML = `<div class="semcx"><img src="assets/img/monetize-icone.png" alt=""><h2>${navigator.onLine === false ? 'Você está sem internet' : 'Não foi possível falar com o servidor'}</h2><p>${navigator.onLine === false ? 'Conecte-se e toque em "Tentar de novo".' : 'Pode ser uma instabilidade passageira. Tente de novo em instantes.'}</p><button class="btn" id="semcxb">Tentar de novo</button></div>`;
  document.getElementById('semcxb').onclick = () => {
    app.innerHTML = '';
    boot(fn);
  };
}
