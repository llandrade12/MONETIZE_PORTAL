/**
 * compartilhado/core/pwa.js
 * O portal como aplicativo (PWA): registro do serviço em segundo plano (sw.js), convite para instalar
 * na tela inicial do celular e notificações push neste aparelho.
 */
'use strict';

const PWA = {
  reg: null,            /* serviço em segundo plano registrado */
  convite: null,        /* evento do navegador que permite mostrar "Instalar" (Android e computador) */
  instalado: (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true,
  push: 'conferindo',   /* conferindo | ligado | desligado | bloqueado | sem-suporte */
  sub: null
};

const ehIOS = () => /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform == 'MacIntel' && navigator.maxTouchPoints > 1);

if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol))
  navigator.serviceWorker.register('sw.js').then(r => {
    PWA.reg = r;
    pushConferir();
  }, () => pushConferir());
else
  PWA.push = 'sem-suporte';

addEventListener('beforeinstallprompt', e => {
  e.preventDefault();
  PWA.convite = e;
  conviteAtualizar();
});

addEventListener('appinstalled', () => {
  PWA.convite = null;
  PWA.instalado = true;
  conviteAtualizar();
});

/* ---------- Instalar na tela inicial ---------- */

const pwaPodeInstalar = () => !PWA.instalado && (!!PWA.convite || ehIOS());

/* Botão "Instalar aplicativo" (some quando já está instalado ou o navegador não oferece a instalação). */
function pwaConvite() {
  return `<div id="pwac">${pwaPodeInstalar() ? `<button type="button" class="btn s full pwab" onclick="pwaInstalar()">${ic('download')}Instalar aplicativo no celular</button>` : ''}</div>`;
}

function conviteAtualizar() {
  const el = document.getElementById('pwac');
  if (el)
    el.outerHTML = pwaConvite();
}

async function pwaInstalar() {
  if (PWA.convite) {
    PWA.convite.prompt();
    try {
      await PWA.convite.userChoice;
    }
    catch (e) {
    }
    PWA.convite = null;
    return conviteAtualizar();
  }
  modal('Instalar no iPhone ou iPad', `<ol class="topics" style="padding-left:18px;margin:0"><li>Abra este endereço no <b>Safari</b>.</li><li>Toque no botão <b>Compartilhar</b> (o quadrado com a seta para cima).</li><li>Escolha <b>Adicionar à Tela de Início</b> e confirme.</li></ol><p class="mu" style="margin:14px 0 0">O portal passa a abrir como um aplicativo, e é só com ele instalado que o iPhone entrega as notificações.</p>`, { cancel: 'Entendi' });
}

/* ---------- Notificações push neste aparelho ---------- */

const pushSuporte = () => 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;

function b64Bytes(s) {
  const t = atob((s + '==='.slice((s.length + 3) % 4)).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from(t, c => c.charCodeAt(0));
}

/* Descobre a situação das notificações neste aparelho e, se estiverem ligadas, confirma a inscrição para quem está logado. */
async function pushConferir() {
  const antes = PWA.push;
  try {
    if (!pushSuporte() || !PWA.reg)
      PWA.push = 'sem-suporte';
    else if (Notification.permission == 'denied')
      PWA.push = 'bloqueado';
    else {
      PWA.sub = await PWA.reg.pushManager.getSubscription();
      PWA.push = PWA.sub && Notification.permission == 'granted' ? 'ligado' : 'desligado';
    }
  }
  catch (e) {
    PWA.push = 'sem-suporte';
  }
  pushVincular();
  if (antes != PWA.push && typeof APP != 'undefined' && typeof redesenhar == 'function' && U && !ocupado())
    redesenhar();
}

/* O aparelho pode trocar de dono (outra pessoa entra no mesmo celular): a inscrição acompanha quem está logado. */
function pushVincular() {
  if (PWA.push == 'ligado' && PWA.sub && U && !U.preview && !PWA.vinculado) {
    PWA.vinculado = true;
    chamar('POST', '/api/push/inscrever', PWA.sub.toJSON()).catch(() => PWA.vinculado = false);
  }
}

async function pushLigar() {
  if (!pushSuporte() || !PWA.reg) {
    toast(ehIOS() && !PWA.instalado ? 'No iPhone, instale o aplicativo na Tela de Início para receber notificações' : 'Este navegador não recebe notificações');
    return redesenhar();
  }
  let p = 'default';
  try {
    p = await Notification.requestPermission();
  }
  catch (e) {
  }
  if (p != 'granted') {
    PWA.push = p == 'denied' ? 'bloqueado' : 'desligado';
    toast('As notificações estão bloqueadas neste navegador. Libere nas configurações do site.');
    return redesenhar();
  }
  try {
    PWA.sub = await PWA.reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64Bytes(API.srv.push) });
    await chamar('POST', '/api/push/inscrever', PWA.sub.toJSON());
    PWA.vinculado = true;
    PWA.push = 'ligado';
    chamar('POST', '/api/push/teste').catch(() => 0);
    toast('Notificações ligadas neste aparelho');
  }
  catch (e) {
    toast('Não foi possível ligar as notificações neste aparelho');
  }
  redesenhar();
}

async function pushDesligar() {
  try {
    if (PWA.sub) {
      await chamar('POST', '/api/push/remover', { endpoint: PWA.sub.endpoint }).catch(() => 0);
      await PWA.sub.unsubscribe();
    }
  }
  catch (e) {
  }
  PWA.sub = null;
  PWA.vinculado = false;
  PWA.push = 'desligado';
  toast('Notificações desligadas neste aparelho');
  redesenhar();
}

/* Ao sair, o aparelho deixa de receber os avisos de quem estava logado. */
async function pushAoSair() {
  if (PWA.sub && PWA.vinculado)
    await chamar('POST', '/api/push/remover', { endpoint: PWA.sub.endpoint }).catch(() => 0);
}

/* Interruptor "Notificações neste aparelho", usado no perfil do aluno e na automação do mentor. */
function pushSwitch() {
  const st = PWA.push, txt = {
    conferindo: 'Conferindo…', ligado: 'Ligadas. Os avisos chegam mesmo com o portal fechado.', desligado: 'Receba os avisos na tela do celular ou do computador, mesmo com o portal fechado.',
    bloqueado: 'Bloqueadas neste navegador. Libere as notificações nas configurações do site e volte aqui.',
    'sem-suporte': ehIOS() && !PWA.instalado ? 'No iPhone: instale o aplicativo na Tela de Início e ligue por aqui.' : 'Este navegador não oferece notificações.'
  }[st];
  return `<label class="sw"><span class="grow"><b>Notificações neste aparelho</b><small>${txt}</small></span><input type="checkbox" ${st == 'ligado' ? 'checked' : ''} ${st == 'conferindo' || st == 'bloqueado' || (st == 'sem-suporte' && !(ehIOS() && !PWA.instalado)) || (U && U.preview) ? 'disabled' : ''} onchange="this.checked?pushLigar():pushDesligar()"><i></i></label>${pwaPodeInstalar() ? `<button type="button" class="btn s sm" style="margin-top:10px" onclick="pwaInstalar()">${ic('download')}Instalar aplicativo</button>` : ''}`;
}
