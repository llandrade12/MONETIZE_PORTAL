/**
 * compartilhado/core/utils.js
 * Funções puras: datas, formatação, escape de HTML, identificadores e agenda.
 */
'use strict';

const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];

const p2 = n => String(n).padStart(2, '0');

const D = s => {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d);
};

const ISO = d => d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate());

const addD = (s, n) => {
  const d = D(s);
  d.setDate(d.getDate() + n);
  return ISO(d);
};

const diff = (a, b) => Math.round((D(a) - D(b)) / 864e5);

const MES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];

const MESL = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

const DOW = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];

const DF = s => s ? p2(D(s).getDate()) + '/' + p2(D(s).getMonth() + 1) : '—';

const DFY = s => s ? DF(s) + '/' + D(s).getFullYear() : '—';

const DL = s => {
  if (!s)
    return '—';
  const d = D(s);
  return DOW[d.getDay()] + ', ' + d.getDate() + ' de ' + MES[d.getMonth()];
};

const E = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const safeUrl = u => /^https:\/\//i.test(String(u || '').trim()) ? String(u).trim() : '';

const pct = (a, b) => b ? Math.round(a / b * 100) : 0;

const avg = a => a.length ? a.reduce((x, y) => x + y, 0) / a.length : null;

const f1 = n => n == null ? '—' : (Math.round(n * 10) / 10).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 });

const ini = n => E(String(n || '?').split(' ').filter(Boolean).slice(0, 2).map(x => x[0]).join('').toUpperCase());

const stamp = () => {
  const d = new Date();
  return p2(d.getDate()) + '/' + p2(d.getMonth() + 1) + '/' + d.getFullYear() + ' ' + p2(d.getHours()) + ':' + p2(d.getMinutes());
};

/* Identificador único: hora + contador desta página + trecho aleatório (não repete nem em laços rápidos). */
let UIDN = 0;

const uid = () => Date.now().toString(36) + (UIDN++ % 1296).toString(36).padStart(2, '0') + Math.random().toString(36).slice(2, 6);

const hsh = s => {
  let h = 2166136261;
  for (const c of String(s)) {
    h ^= c.charCodeAt(0);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) / 4294967295;
};

/* ---------- Download, tempo de vídeo, telefone e agenda (.ics / Google Calendar) ---------- */

function baixar(nome, conteudo, mime = 'text/plain') {
  const u = URL.createObjectURL(conteudo instanceof Blob ? conteudo : new Blob([conteudo], { type: mime + ';charset=utf-8' })), a = document.createElement('a');
  a.href = u;
  a.download = nome;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(u), 5000);
}

const slug = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

const fmtT = s => {
  s = Math.max(0, Math.floor(s || 0));
  const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60);
  return (h ? h + ':' + p2(m) : m) + ':' + p2(s % 60);
};

const digits = s => String(s || '').replace(/\D/g, '');

/* Data e hora locais em UTC no formato de agenda: 20260115T230000Z */
const calUTC = (date, hora, min = 0) => {
  const [y, m, d] = date.split('-').map(Number), [h, mi] = (hora || '00:00').split(':').map(Number);
  return new Date(y, m - 1, d, h, mi + min).toISOString().replace(/[-:]/g, '').replace(/\.\d+/, '');
};

const calDay = date => date.replace(/-/g, '');

/* ev = { id, t, date, hora (vazio = dia inteiro), dur (min), desc, local } */
function gcalUrl(ev) {
  const dates = ev.hora ? calUTC(ev.date, ev.hora) + '/' + calUTC(ev.date, ev.hora, ev.dur || 120) : calDay(ev.date) + '/' + calDay(addD(ev.date, 1));
  return 'https://calendar.google.com/calendar/render?action=TEMPLATE&text=' + encodeURIComponent(ev.t) + '&dates=' + dates + '&details=' + encodeURIComponent(ev.desc || '') + (ev.local ? '&location=' + encodeURIComponent(ev.local) : '');
}

function icsText(evs, nome = 'Mentoria') {
  const esc = s => String(s || '').replace(/\\/g, '\\\\').replace(/\r?\n/g, '\\n').replace(/([,;])/g, '\\$1');
  const fold = l => l.length > 60 ? l.match(/.{1,60}/g).join('\r\n ') : l;
  const now = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d+/, '');
  const L = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Monetize//Area de Membros//PT-BR', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', 'X-WR-CALNAME:' + esc(nome)];
  evs.forEach(ev => {
    L.push('BEGIN:VEVENT', 'UID:' + ev.id + '@monetize-area-de-membros', 'DTSTAMP:' + now);
    if (ev.hora)
      L.push('DTSTART:' + calUTC(ev.date, ev.hora), 'DTEND:' + calUTC(ev.date, ev.hora, ev.dur || 120));
    else
      L.push('DTSTART;VALUE=DATE:' + calDay(ev.date), 'DTEND;VALUE=DATE:' + calDay(addD(ev.date, 1)));
    L.push('SUMMARY:' + esc(ev.t));
    if (ev.desc)
      L.push('DESCRIPTION:' + esc(ev.desc));
    if (ev.local)
      L.push('LOCATION:' + esc(ev.local));
    if (ev.hora)
      L.push('BEGIN:VALARM', 'ACTION:DISPLAY', 'DESCRIPTION:' + esc(ev.t), 'TRIGGER:-PT60M', 'END:VALARM');
    L.push('END:VEVENT');
  });
  L.push('END:VCALENDAR');
  return L.map(fold).join('\r\n');
}

/* ---------- Senhas ----------
 * A senha é conferida e guardada pelo servidor (só o resumo dela). Aqui fica apenas a regra de formato.
 */
const senhaForte = s => s.length >= 8 && /\d/.test(s) && /[a-z]/i.test(s);
