/**
 * compartilhado/core/api.js
 * Conversa com o servidor: baixa o estado, envia o que mudou e busca o que os outros mudaram.
 *
 * Como funciona:
 *   1. carregarEstado() baixa tudo o que a pessoa pode ver e guarda um retrato (API.base) do que o servidor tem.
 *   2. As telas alteram S e chamam save(). Pouco depois, sincronizar() compara S com o retrato e envia
 *      só as diferenças, registro por registro e campo por campo.
 *   3. A cada 20 segundos (e ao voltar para a aba), conferir() pergunta ao servidor o que mudou desde a
 *      última vez e aplica em S, sem atrapalhar quem está digitando.
 */
'use strict';

const API = {
  eu: null,            /* quem o servidor diz que está logado */
  srv: {},             /* informações do servidor: e-mail ligado, chave do push, endereço da agenda */
  rev: 0,              /* número da última alteração já recebida */
  base: {},            /* retrato do servidor: base[coleção][chave] = JSON do registro */
  enviando: false, conferindo: false, sujo: false, falhas: 0,
  timer: null, relogio: null, fila: [], blocos: [], pedindoIds: false, ligado: false
};

const CABECALHOS = { 'X-Portal': '1', 'Content-Type': 'application/json' };

/*
 * Chamada à API. Devolve o JSON da resposta; em erro, lança { status, erro, msg }.
 * O endereço é relativo à pasta da página: o portal funciona na raiz do domínio ou em uma subpasta.
 */
async function chamar(metodo, url, corpo) {
  let r;
  try {
    r = await fetch(url.replace(/^\//, ''), { method: metodo, headers: CABECALHOS, credentials: 'same-origin', cache: 'no-store', body: corpo === undefined ? undefined : JSON.stringify(corpo) });
  }
  catch (e) {
    throw { status: 0, erro: 'sem-conexao', msg: 'Sem conexão com o servidor' };
  }
  let j = null;
  try {
    j = await r.json();
  }
  catch (e) {
  }
  if (!r.ok)
    throw { status: r.status, erro: (j && j.erro) || 'erro', msg: (j && j.msg) || 'Não foi possível concluir. Tente de novo.' };
  return j || {};
}

/* ---------- Estado completo ---------- */

async function carregarEstado() {
  const r = await chamar('GET', '/api/estado');
  API.eu = r.eu;
  API.srv = r.srv || {};
  S = normal(r.dados || {});
  API.rev = r.rev || 0;
  API.base = retrato();
  API.sujo = false;
}

const chaveReg = (c, r) => String(r[COLECOES[c][1]]);

/* JSON de cada registro de S, por coleção e chave. */
function retrato() {
  const b = {};
  for (const c in COLECOES) {
    const t = COLECOES[c][0], m = b[c] = {};
    if (t == 'l')
      S[c].forEach(r => {
        if (r && r[COLECOES[c][1]] != null)
          m[chaveReg(c, r)] = JSON.stringify(r);
      });
    else if (t == 'm') {
      for (const k in S[c])
        if (S[c][k] != null)
          m[k] = JSON.stringify(S[c][k]);
    }
    else if (S[c] != null)
      m._ = JSON.stringify(S[c]);
  }
  return b;
}

/* ---------- O que mudou aqui e ainda não foi enviado ---------- */

const ehObjeto = v => v && typeof v == 'object' && !Array.isArray(v);

/* Operações a enviar e o novo retrato de cada registro alterado (null = removido). */
function diferencas() {
  const ops = [], novo = {};
  for (const c in COLECOES) {
    const t = COLECOES[c][0], base = API.base[c] || {}, vistos = {};
    const item = (k, v) => {
      if (v == null)
        return;
      vistos[k] = 1;
      const j = JSON.stringify(v);
      if (base[k] === j)
        return;
      (novo[c] = novo[c] || {})[k] = j;
      const antes = base[k] === undefined ? null : JSON.parse(base[k]);
      if (!ehObjeto(antes) || !ehObjeto(v))
        return ops.push({ c, k, v });
      /* Registro que já existia: vão só os campos que mudaram, para não desfazer o que outra pessoa alterou. */
      const set = {}, del = [];
      for (const f in v)
        if (v[f] !== undefined && JSON.stringify(v[f]) !== JSON.stringify(antes[f]))
          set[f] = v[f];
      for (const f in antes)
        if (v[f] === undefined)
          del.push(f);
      ops.push({ c, k, set, del });
    };
    if (t == 'l')
      S[c].forEach(r => {
        if (r && r[COLECOES[c][1]] != null)
          item(chaveReg(c, r), r);
      });
    else if (t == 'm') {
      for (const k in S[c])
        item(k, S[c][k]);
    }
    else
      item('_', S[c]);
    if (t != 'v')
      for (const k in base)
        if (!vistos[k]) {
          ops.push({ c, k, rm: true });
          (novo[c] = novo[c] || {})[k] = null;
        }
  }
  return { ops, novo };
}

/* ---------- Envio ---------- */

/* As telas chamam save() depois de alterar S. O envio sai logo em seguida, juntando alterações próximas. */
function save() {
  try {
    localStorage.setItem('sop-turma', S.turmaAtual || 0);
  }
  catch (e) {
  }
  if (!U)
    return;
  API.sujo = true;
  agendarEnvio(150);
}

function agendarEnvio(ms) {
  clearTimeout(API.timer);
  API.timer = setTimeout(sincronizar, ms);
}

const RECUSAS = {
  'email-em-uso': 'Este e-mail já é o login de outro aluno', 'email-de-mentor': 'Este e-mail já é o login de um mentor', 'email-invalido': 'E-mail inválido',
  'senha-fraca': 'Senha: use 8 ou mais caracteres, com letras e números', 'ja-avaliada': 'Esta entrega já foi avaliada e não pode mais ser alterada',
  'limite-por-hora': 'Muitas ações em pouco tempo. Aguarde um pouco e tente de novo', 'grande-demais': 'O conteúdo ficou grande demais para salvar',
  'foto-invalida': 'Não foi possível salvar esta foto. Tente uma imagem menor'
};

async function sincronizar() {
  clearTimeout(API.timer);
  if (API.enviando || !U)
    return;
  const { ops, novo } = diferencas();
  if (!ops.length) {
    API.sujo = false;
    avisoSync('');
    return depoisDeSalvar();
  }
  API.enviando = true;
  const lento = setTimeout(() => avisoSync('salvando'), 1500);
  try {
    const r = await chamar('POST', '/api/sync', { ops });
    clearTimeout(lento);
    for (const c in novo)
      for (const k in novo[c]) {
        API.base[c] = API.base[c] || {};
        if (novo[c][k] === null)
          delete API.base[c][k];
        else
          API.base[c][k] = novo[c][k];
      }
    const voltou = API.falhas > 0;
    API.falhas = 0;
    let mudou = aplicar(r.eco || []);
    if (r.recusadas && r.recusadas.length) {
      /* O servidor não aceitou alguma alteração: volta ao que está guardado lá, para a tela não mostrar algo que não existe. */
      const motivo = r.recusadas[0].motivo;
      await carregarEstado();
      definirUsuario();
      mudou = true;
      toast(RECUSAS[motivo] || 'Uma alteração não foi aceita pelo servidor e foi desfeita');
    }
    API.enviando = false;
    avisoSync(voltou ? 'ok' : '');
    /* Quem está digitando em um campo da página não é interrompido: a tela é refeita na próxima conferência. */
    if (mudou && !digitandoNaPagina())
      redesenhar();
    else if (mudou)
      API.redesenhar = true;
    if (diferencas().ops.length)
      return agendarEnvio(50);
    API.sujo = false;
    depoisDeSalvar();
  }
  catch (e) {
    clearTimeout(lento);
    API.enviando = false;
    if (e.status == 401)
      return sessaoTerminou();
    API.falhas++;
    avisoSync('erro');
    agendarEnvio(Math.min(30000, 2500 * API.falhas));
  }
}

/* Espera o envio terminar (ou desiste em 6 segundos, para a pessoa não ficar presa sem internet). */
function salvarAgora() {
  if (!U || (!API.enviando && !diferencas().ops.length))
    return Promise.resolve();
  return new Promise(res => {
    const fim = Date.now() + 6000;
    sincronizar();
    const t = setInterval(() => {
      if ((!API.enviando && !API.sujo) || API.falhas || Date.now() > fim) {
        clearInterval(t);
        res();
      }
    }, 60);
  });
}

/* Executa fn depois que tudo estiver salvo no servidor (ex.: pedir os lembretes logo após uma chamada). */
function aposSalvar(fn) {
  API.fila.push(fn);
  if (!API.sujo && !API.enviando)
    depoisDeSalvar();
}

function depoisDeSalvar() {
  const f = API.fila;
  API.fila = [];
  f.forEach(fn => {
    try {
      fn();
    }
    catch (e) {
    }
  });
}

/* ---------- O que mudou no servidor ---------- */

/* Troca o conteúdo de um objeto sem trocar o objeto (as telas abertas continuam apontando para ele). */
function substituir(alvo, novo) {
  if (Array.isArray(alvo) && Array.isArray(novo)) {
    alvo.length = 0;
    novo.forEach(x => alvo.push(x));
    return;
  }
  for (const k in alvo)
    delete alvo[k];
  Object.assign(alvo, novo);
}

/* Aplica em S (e no retrato) as alterações vindas do servidor. Devolve true se algo mudou na tela. */
function aplicar(mud) {
  let mudou = false;
  for (const m of mud) {
    const col = COLECOES[m.c];
    if (!col)
      continue;
    const t = col[0], base = API.base[m.c] = API.base[m.c] || {}, k = t == 'v' ? '_' : m.k;
    if (m.rm) {
      if (t == 'l') {
        const i = S[m.c].findIndex(r => chaveReg(m.c, r) == k);
        if (i >= 0) {
          S[m.c].splice(i, 1);
          mudou = true;
        }
      }
      else if (t == 'm' && k in S[m.c]) {
        delete S[m.c][k];
        mudou = true;
      }
      delete base[k];
      continue;
    }
    let v = m.v;
    if (t == 'v') {
      if (m.c == 'cfg') {
        v = Object.assign({}, CFG0, v || {});
        v.canais = Object.assign({}, CFG0.canais, v.canais || {});
      }
      if (JSON.stringify(S[m.c]) !== JSON.stringify(v)) {
        if (S[m.c] && typeof S[m.c] == 'object' && v && typeof v == 'object' && Array.isArray(S[m.c]) == Array.isArray(v))
          substituir(S[m.c], v);
        else
          S[m.c] = v;
        mudou = true;
      }
      base._ = JSON.stringify(S[m.c]);
      continue;
    }
    normalReg(m.c, v);
    const j = JSON.stringify(v);
    if (t == 'l') {
      const atual = S[m.c].find(r => chaveReg(m.c, r) == k);
      if (!atual) {
        col[2] ? S[m.c].unshift(v) : S[m.c].push(v);
        mudou = true;
      }
      else if (JSON.stringify(atual) !== j) {
        substituir(atual, v);
        mudou = true;
      }
    }
    else if (JSON.stringify(S[m.c][k]) !== j) {
      if (ehObjeto(S[m.c][k]) && ehObjeto(v))
        substituir(S[m.c][k], v);
      else
        S[m.c][k] = v;
      mudou = true;
    }
    base[k] = j;
  }
  return mudou;
}

/* Há algo aberto que não pode ser redesenhado agora? (janela aberta ou alguém digitando) */
function ocupado() {
  const m = document.getElementById('modal'), a = document.activeElement;
  if (m && m.classList.contains('on'))
    return true;
  return !!a && (a.tagName == 'TEXTAREA' || a.tagName == 'SELECT' || (a.tagName == 'INPUT' && !/^(checkbox|radio|button|submit|range|file)$/i.test(a.type)));
}

const digitandoNaPagina = () => {
  const a = document.activeElement, m = document.getElementById('modal');
  return ocupado() && !(m && m.contains(a));
};

function redesenhar() {
  API.redesenhar = false;
  /* Com um vídeo tocando a tela fica como está; os dados já foram atualizados e aparecem na próxima navegação. */
  if (!U || typeof render != 'function' || (typeof PL != 'undefined' && PL.n))
    return;
  if (typeof keep == 'function')
    keep();
  render();
}

/* Pergunta ao servidor o que mudou desde a última conferência. */
async function conferir() {
  if (!U || API.enviando || API.conferindo || document.hidden)
    return;
  if (diferencas().ops.length)
    return agendarEnvio(0);
  if (ocupado())
    return;
  API.conferindo = true;
  try {
    const r = await chamar('GET', '/api/mudancas?rev=' + API.rev);
    if (r.recarregar) {
      await carregarEstado();
      definirUsuario();
      return redesenhar();
    }
    if (!r.mud || !r.mud.length) {
      API.rev = r.rev;
      if (API.redesenhar)
        redesenhar();
      return;
    }
    /* Algo mudou aqui enquanto a resposta vinha: envia primeiro e confere de novo depois. */
    if (ocupado() || API.enviando || diferencas().ops.length)
      return;
    const eu = U.role == 'aluno' && !U.preview ? S.alunos.find(a => a.id == U.aid) : null, antes = eu ? eu.turma + '|' + eu.status : '';
    const mudou = aplicar(r.mud);
    API.rev = r.rev;
    /* Mudou a turma do aluno: o que ele pode ver é outro, então baixa tudo de novo. */
    if (eu && antes != eu.turma + '|' + eu.status) {
      await carregarEstado();
      definirUsuario();
      return redesenhar();
    }
    if (mudou)
      redesenhar();
  }
  catch (e) {
    if (e.status == 401)
      sessaoTerminou();
  }
  finally {
    API.conferindo = false;
  }
}

function sessaoTerminou() {
  if (API.terminou)
    return;
  API.terminou = true;
  clearInterval(API.relogio);
  try {
    sessionStorage.setItem('sop-msg', 'Sua sessão terminou. Entre de novo.');
    if (typeof APP != 'undefined')
      sessionStorage.setItem('sop-destino', PAG[APP.role] + (R.p && R.p != APP.inicio && /^[A-Za-z]+$/.test(R.p) ? '#ir=' + R.p : ''));
  }
  catch (e) {
  }
  if (location.pathname.split('/').pop() != PAG.login && location.pathname.slice(-1) != '/')
    location.replace(PAG.login);
}

/* Liga a conferência periódica e garante o envio ao sair da página. */
function iniciarSincronia() {
  if (API.ligado)
    return;
  API.ligado = true;
  API.relogio = setInterval(conferir, 20000);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden)
      sincronizar();
    else
      conferir();
  });
  addEventListener('focus', conferir);
  addEventListener('online', () => {
    agendarEnvio(0);
    conferir();
  });
  addEventListener('pagehide', enviarAoSair);
  /* Página restaurada pelo botão "voltar" do navegador: confere o que mudou enquanto esteve guardada. */
  addEventListener('pageshow', e => {
    if (e.persisted) {
      API.indo = false;
      conferir();
    }
  });
  addEventListener('beforeunload', e => {
    if (API.sujo && API.falhas) {
      e.preventDefault();
      e.returnValue = '';
    }
  });
}

/* Último envio, quando a pessoa fecha ou troca de página antes do envio normal sair. */
function enviarAoSair() {
  if (!U || API.enviando)
    return;
  const { ops, novo } = diferencas();
  if (!ops.length)
    return;
  const corpo = JSON.stringify({ ops });
  if (corpo.length > 60000)
    return sincronizar();
  try {
    fetch('api/sync', { method: 'POST', headers: CABECALHOS, credentials: 'same-origin', keepalive: true, body: corpo });
    for (const c in novo)
      for (const k in novo[c]) {
        API.base[c] = API.base[c] || {};
        if (novo[c][k] === null)
          delete API.base[c][k];
        else
          API.base[c][k] = novo[c][k];
      }
  }
  catch (e) {
  }
}

/* ---------- Aviso discreto de gravação ---------- */

function avisoSync(st) {
  let el = document.getElementById('sync');
  if (!el) {
    el = document.createElement('div');
    el.id = 'sync';
    el.setAttribute('role', 'status');
    document.body.appendChild(el);
  }
  clearTimeout(API.avisoT);
  el.className = st;
  el.textContent = st == 'erro' ? 'Sem conexão. Suas alterações serão enviadas quando a internet voltar.' : st == 'salvando' ? 'Salvando…' : st == 'ok' ? 'Conexão de volta. Tudo salvo.' : '';
  if (st == 'ok')
    API.avisoT = setTimeout(() => el.className = '', 3000);
}

/* ---------- Códigos numéricos (turma, aluno, aula, tarefa) ----------
 * O servidor entrega blocos de códigos; assim dois mentores criando ao mesmo tempo nunca recebem o mesmo número.
 */

function nid() {
  if (!API.blocos.length || API.blocos[0][0] > API.blocos[0][1]) {
    API.blocos.shift();
    if (!API.blocos.length) {
      /* Sem reserva (primeira criação da página, ou muitas de uma vez): busca um bloco na hora. */
      const x = new XMLHttpRequest();
      x.open('GET', 'api/ids', false);
      x.setRequestHeader('X-Portal', '1');
      x.send();
      if (x.status != 200)
        throw new Error('Sem conexão com o servidor para criar o registro');
      API.blocos.push(JSON.parse(x.responseText).ids);
    }
  }
  const b = API.blocos[0], id = b[0]++;
  if (API.blocos.length == 1 && b[1] - b[0] < 15 && !API.pedindoIds) {
    API.pedindoIds = true;
    chamar('GET', '/api/ids').then(r => API.blocos.push(r.ids), () => 0).then(() => API.pedindoIds = false);
  }
  return id;
}
