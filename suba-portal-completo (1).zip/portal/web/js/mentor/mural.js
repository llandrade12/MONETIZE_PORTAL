/**
 * mentor/mural.js
 * Página do admin: mural.
 */
'use strict';

function A_mural() {
  return `<div class="main2"><div class="stack">${[...S.avisos].sort((a, b) => (b.pin - a.pin) || (S.avisos.indexOf(b) - S.avisos.indexOf(a))).map(a => avisoCard(a, true)).join('') || empty('Nenhum aviso', 'Publique o primeiro aviso para a turma.')}</div>
<div class="card" style="position:sticky;top:90px"><h3 style="margin-bottom:14px">Novo aviso</h3>${F('Título', '<input id="mt">')}${F('Mensagem', '<textarea id="mm" rows="5"></textarea>')}${F('Enviar para', `<select id="ma"><option value="todos">Todos os alunos</option><optgroup label="Uma turma">${S.turmas.map(t => `<option value="t${t.id}" ${ctx() == t.id ? 'selected' : ''}>${E(tnome(t))}</option>`).join('')}</optgroup><optgroup label="Um aluno">${ativos().map(a => `<option value="${a.id}">${E(a.nome)}</option>`).join('')}</optgroup></select>`)}<label class="chk" style="margin-bottom:16px"><input type="checkbox" id="mp"> Fixar no topo</label><button class="btn full" onclick="pubA()">${ic('send')}Publicar e notificar</button><p class="sm-t" style="margin:10px 0 0">Os destinatários recebem push e e-mail imediatamente.</p></div></div>`;
}

function pubA() {
  if (!val('mt') || !val('mm'))
    return toast('Preencha título e mensagem');
  const v = val('ma'), alvo = v == 'todos' || v[0] == 't' ? v : +v;
  S.avisos.push({
    id: uid(), t: val('mt'), m: val('mm'), alvo, pin: $('#mp').checked, at: stamp(), autor: S.mentor, coms: []
  });
  notify('Novo aviso: ' + val('mt'), 'Push + e-mail', val('mm'), alvo == 'todos' ? S.alunos.filter(a => a.status == 'ativo') : v[0] == 't' ? S.alunos.filter(a => a.status == 'ativo' && 't' + a.turma == v) : alvo, 'mural');
  done('Aviso publicado');
}

function pinA(id) {
  const a = S.avisos.find(x => x.id == id);
  a.pin = !a.pin;
  done(a.pin ? 'Aviso fixado no topo' : 'Aviso desafixado');
}

function delA(id) {
  modal('Excluir aviso', '<p>O aviso deixa de aparecer para os alunos. Esta ação fica registrada no histórico.</p>', { label: 'Excluir', danger: true, ok: () => {
      S.avisos = S.avisos.filter(x => x.id != id);
      done('Aviso excluído');
    } });
}
