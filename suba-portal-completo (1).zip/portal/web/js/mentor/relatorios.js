/**
 * mentor/relatorios.js
 * Página do admin: relatorios.
 */
'use strict';

function A_rel() {
  const t = sub('relatorios', 'turma'), at = ativos();
  let body;
  if (t == 'aluno')
    body = `<div class="tw"><table><thead><tr><th>Aluno</th><th>Nota final</th>${CK().map(c => `<th class="hide-m">${c}</th>`).join('')}<th>Frequência</th><th>Entregas</th></tr></thead><tbody>${at.map(a => `<tr class="hov" onclick="nav('alunoD',${a.id})"><td><b>${E(a.nome)}</b></td><td><b class="gold">${f1(fin(a.id))}</b></td>${CK().map(c => `<td class="hide-m">${f1(compAvg(a.id, c))}</td>`).join('')}<td>${presPct(a.id)}%</td><td>${entPct(a.id)}%</td></tr>`).join('')}</tbody></table></div>`;
  else if (t == 'eng')
    body = `<div class="card">${[...at].sort((a, b) => engaj(b.id) - engaj(a.id)).map(a => `<div style="padding:12px 0;border-top:1px solid var(--ln)"><div class="row sp" style="margin-bottom:8px"><b>${E(a.nome)}</b><b class="gold">${engaj(a.id)}%</b></div><div class="g3" style="gap:10px">${[['Frequência', presPct(a.id)], ['Entregas', entPct(a.id)], ['Gravações assistidas', visPct(a.id)]].map(([l, v]) => `<div><div class="row sp sm-t" style="margin-bottom:4px"><span>${l}</span><span>${v}%</span></div>${bar(v)}</div>`).join('')}</div></div>`).join('')}</div>`;
  else {
    const rf = at.filter(a => S.roda[a.id].iniSent);
    body = `<div class="g3"><div class="kpi"><span class="lb">Aulas realizadas</span><span class="num">${realizadas().length}/${aulasCtx().length}</span>${bar(pct(realizadas().length, aulasCtx().length))}</div><div class="kpi"><span class="lb">Nota média</span><span class="num gold">${f1(avg(at.map(a => fin(a.id)).filter(x => x != null)))}</span></div><div class="kpi"><span class="lb">Roda inicial enviada</span><span class="num">${rf.length}/${at.length}</span></div></div>
  <div class="card sec" style="margin-top:16px"><h3 style="margin-bottom:12px">Presença por aula</h3><div class="climb" style="height:140px">${realizadas().map(a => {
      const al = alvoDe(a).filter(x => inCtx(x.id)), p = pct(al.filter(x => presOk(x.id, a.n)).length, al.length);
      return `<i class="d" style="height:${Math.max(4, p)}%;max-width:36px" title="${E(a.nome)}: ${p}%"></i>`;
    }).join('') || '<p class="mu" style="margin:0;align-self:center">Nenhuma aula realizada ainda.</p>'}</div></div>
  <div class="card"><h3 style="margin-bottom:12px">Média da turma por competência</h3>${CK().map(c => {
      const v = avg(at.map(a => compAvg(a.id, c)).filter(x => x != null));
      return `<div style="margin-bottom:12px"><div class="row sp" style="font-size:13px;margin-bottom:5px"><span>${c}</span><b>${f1(v)}</b></div>${bar((v || 0) * 10)}</div>`;
    }).join('')}</div>`;
  }
  return `<div class="row sp" style="margin-bottom:6px"><span></span><button class="btn s sm" onclick="csv()">${ic('copy')}Copiar CSV</button></div>` + tabs('relatorios', [['turma', 'Turma'], ['aluno', 'Por aluno'], ['eng', 'Engajamento']]) + body;
}

function csv() {
  const at = ativos(), rows = [['nome', 'email', 'turma', 'cargo', 'status', 'nota_final', ...CK(), 'frequencia', 'presentes', 'atrasos', 'faltas', 'justificadas', 'compensadas', 'entregas', 'engajamento'].join(';')].concat(alunosCtx().map(a => [a.nome, a.email, tnome(turmaById(a.turma)), a.cargo, a.status, f1(fin(a.id)), ...CK().map(c => f1(compAvg(a.id, c))), presPct(a.id) + '%', ...['P', 'A', 'F', 'J', 'C'].map(k => freq(a.id).st.filter(s => s == k).length), entPct(a.id) + '%', engaj(a.id) + '%'].join(';'))).join('\n');
  const done2 = () => toast('CSV copiado. Cole no Excel ou Google Sheets');
  if (navigator.clipboard && navigator.clipboard.writeText)
    navigator.clipboard.writeText(rows).then(done2, () => showCsv(rows));
  else
    showCsv(rows);
}

function showCsv(rows) {
  modal('Exportar CSV', `<textarea rows="10" readonly onclick="this.select()">${E(rows)}</textarea><p class="sm-t">Selecione, copie e cole no Excel ou Google Sheets.</p>`, { cancel: 'Fechar' });
}
