/**
 * mentor/suporte.js
 * Página do admin: suporte. Chamados dos alunos (acesso, pagamento, problema técnico) e
 * edição das perguntas frequentes que aparecem na Ajuda do aluno.
 */
'use strict';

function A_sup() {
  const f = sub('suporte', 'cham'), fs = ST.supF || 'abertos', C = S.chamados.filter(c => inCtx(c.aid));
  const L = C.filter(c => fs == 'todos' || (fs == 'abertos' ? c.st != 'resolvido' : c.st == 'resolvido'));
  let body;
  if (f == 'faq')
    body = `<div class="row sp" style="margin-bottom:14px"><p class="mu" style="margin:0;max-width:600px">Estas respostas aparecem em Ajuda e suporte, na área do aluno. Cada pergunta bem respondida aqui é um chamado a menos.</p><button class="btn" onclick="faqForm()">${ic('plus')}Nova pergunta</button></div><div class="card">${S.faq.map(q => `<div class="li"><div class="grow"><b>${E(q.q)}</b><span class="sm-t">${E(q.cat)} · ${E(q.a.slice(0, 110))}${q.a.length > 110 ? '…' : ''}</span></div><button class="btn q sm" aria-label="Editar pergunta" onclick="faqForm('${q.id}')">${ic('edit')}</button><button class="btn q sm" aria-label="Excluir pergunta" onclick="S.faq=S.faq.filter(x=>x.id!='${q.id}');keep();done('Pergunta excluída')">${ic('trash')}</button></div>`).join('') || '<p class="mu" style="margin:0">Nenhuma pergunta cadastrada.</p>'}</div>`;
  else
    body = `<div class="toolbar"><div class="seg">${[['abertos', 'Em aberto', C.filter(c => c.st != 'resolvido').length], ['resolvidos', 'Resolvidos', C.filter(c => c.st == 'resolvido').length], ['todos', 'Todos', C.length]].map(([k, l, n]) => `<button class="${fs == k ? 'on' : ''}" onclick="ST.supF='${k}';render()">${l} ${n}</button>`).join('')}</div>${tfilter()}</div>` +
      (L.length ? `<div class="card">${L.map(c => `<button class="li cht" onclick="chVer('${c.id}')">${avatar(aluno(c.aid))}<span class="grow"><b>${E(c.t)}</b><span class="sm-t">${E(nm(c.aid))} · ${E(c.cat)} · ${E(c.upd)} · ${E(c.msgs[c.msgs.length - 1].txt.slice(0, 80))}</span></span>${tag(...(c.st == 'aberto' ? ['Responder', 'er'] : CH_ST[c.st]))}</button>`).join('')}</div>` : empty('Nenhum chamado aqui', 'Quando um aluno abrir um chamado de acesso, pagamento ou problema técnico, ele aparece nesta lista.'));
  return `<p class="mu" style="max-width:680px">Canal de suporte, separado das dúvidas de conteúdo. O aluno abre o chamado na área dele; você responde aqui e ele é avisado por e-mail e WhatsApp.</p>` + tabs('suporte', [['cham', 'Chamados', chAbertos() || ''], ['faq', 'Perguntas frequentes', S.faq.length]], 'cham') + body;
}

function faqForm(id) {
  const q = id ? S.faq.find(x => x.id == id) : {}, cats = [...new Set(S.faq.map(x => x.cat).concat(['Acesso', 'Aulas', 'Frequência', 'Tarefas', 'Certificado', 'Pagamento']))];
  modal(id ? 'Editar pergunta' : 'Nova pergunta frequente', F('Categoria', `<input id="q1" list="qcat" value="${E(q.cat || '')}" placeholder="Ex.: Acesso"><datalist id="qcat">${cats.map(c => `<option value="${E(c)}">`).join('')}</datalist>`) + F('Pergunta', `<input id="q2" value="${E(q.q || '')}">`) + F('Resposta', `<textarea id="q3" rows="5">${E(q.a || '')}</textarea>`), { wide: true, label: 'Salvar', ok: () => {
      if (!val('q2') || !val('q3')) {
        toast('Preencha a pergunta e a resposta');
        return false;
      }
      const d = { cat: val('q1') || 'Geral', q: val('q2'), a: val('q3') };
      if (id)
        Object.assign(q, d);
      else
        S.faq.push({ id: 'q' + uid(), ...d });
      keep();
      done('Pergunta salva');
    } });
}
