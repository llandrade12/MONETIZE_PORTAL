/**
 * mentor/recomendacoes.js
 * Página do admin: recomendações. O mentor posta livros (PDF ou link), audiolivros, vídeos do YouTube,
 * podcasts (Spotify e outras plataformas) e filmes (link do Drive). A vitrine mostrada aqui é a mesma que o mentorado vê.
 */
'use strict';

function A_recs() {
  const L = recsDe(0);
  return `<div class="row sp" style="margin-bottom:18px"><p class="mu" style="margin:0;max-width:620px">Indique livros, audiolivros, vídeos, podcasts e filmes. O que você posta aparece para os mentorados exatamente como nesta vitrine.</p><span class="row">${tfilter()}<button class="btn" onclick="recForm()">${ic('plus')}Nova recomendação</button></span></div>` +
    (L.length ? recVitrine(0) : empty('Nenhuma recomendação publicada', ctx() ? 'Ainda não há recomendações para ' + E(ctxNome()) + '.' : 'Comece indicando um livro, um vídeo ou um podcast para os mentorados.', `<button class="btn" onclick="recForm()">${ic('plus')}Postar a primeira recomendação</button>`));
}

/* Rascunho do formulário: tipo, capa (data URL reduzida) e PDF. */
let RC = {};

const RDICA = {
  livro: ['Autor', 'Link do livro (opcional)', 'Loja, Drive ou página do livro. Você também pode anexar o PDF abaixo.'],
  audio: ['Autor ou narrador', 'Link do audiolivro', 'Audible, Spotify, YouTube, Skeelo ou outra plataforma.'],
  video: ['Canal ou palestrante', 'Link do vídeo no YouTube', 'A miniatura do vídeo vira a capa automaticamente.'],
  podcast: ['Programa ou apresentador', 'Link do episódio', 'Spotify, Apple Podcasts, YouTube, Deezer ou outra plataforma.'],
  filme: ['Diretor ou ano', 'Link do filme', 'Link do Google Drive ou da plataforma onde o filme está.']
};

function recTipo(k) {
  RC.tipo = k;
  $$('#rtp button').forEach(b => b.classList.toggle('on', b.dataset.k == k));
  const d = RDICA[k];
  $('#rla').textContent = d[0];
  $('#rll').textContent = d[1];
  $('#rlh').textContent = d[2];
  $('#rpdf').style.display = k == 'livro' || k == 'audio' ? '' : 'none';
  recPrev();
}

/* Pré-visualização ao vivo do cartão, como o mentorado vai ver. */
function recPrev() {
  const el = $('#rprev');
  if (el)
    el.innerHTML = recCapa({ tipo: RC.tipo, t: val('r1') || 'Título da recomendação', autor: val('r2'), url: val('r3'), capa: RC.capa });
}

function recCapaUp(f) {
  if (!f)
    return;
  if (!/^image\//.test(f.type))
    return toast('A capa precisa ser uma imagem');
  const img = new Image(), u = URL.createObjectURL(f);
  img.onload = () => {
    const k = Math.min(1, 640 / Math.max(img.width, img.height)), c = document.createElement('canvas');
    c.width = Math.round(img.width * k);
    c.height = Math.round(img.height * k);
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    RC.capa = c.toDataURL('image/jpeg', .82);
    URL.revokeObjectURL(u);
    $('#rcx').style.display = '';
    recPrev();
  };
  img.onerror = () => toast('Não foi possível ler a imagem');
  img.src = u;
}

function recPdfUp(f) {
  if (!f)
    return;
  if (fext(f.name) != 'pdf')
    return toast('Anexe um arquivo PDF');
  if (f.size > FMAX * 1048576)
    return toast('O PDF passa de ' + FMAX + ' MB');
  RC.novo = f;
  RC.file = { name: f.name, size: f.size };
  recPdfList();
}

function recPdfList() {
  $('#rpl').innerHTML = RC.file ? fileChip(RC.file, 'RC.file=null;RC.novo=null;recPdfList()') : '';
}

function recForm(id) {
  const r = id ? S.recs.find(x => x.id == id) : { tipo: 'livro', turmas: ctx() ? [ctx()] : [] };
  RC = { tipo: r.tipo, capa: r.capa || '', file: r.file || null, novo: null };
  modal(id ? 'Editar recomendação' : 'Nova recomendação', `<div class="rform"><div>
<div class="f"><span>Tipo de conteúdo</span><div class="rtp" id="rtp">${Object.keys(RTIPOS).map(k => `<button type="button" data-k="${k}" class="${k == r.tipo ? 'on' : ''}" onclick="recTipo('${k}')">${ic(RTIPOS[k][2])}${RTIPOS[k][0]}</button>`).join('')}</div></div>
${F('Título', `<input id="r1" value="${E(r.t || '')}" oninput="recPrev()" placeholder="Ex.: Hábitos Atômicos">`)}
<label class="f"><span id="rla"></span><input id="r2" value="${E(r.autor || '')}" oninput="recPrev()"></label>
<label class="f"><span id="rll"></span><input id="r3" value="${E(r.url || '')}" oninput="recPrev()" placeholder="https://"><small id="rlh"></small></label>
<div class="f" id="rpdf"><span>Arquivo PDF (opcional)</span><label class="drop sm"><input type="file" accept=".pdf" onchange="recPdfUp(this.files[0]);this.value=''">${ic('upload')}<b>Anexar PDF</b><small>até ${FMAX} MB</small></label><div class="fchips" id="rpl" style="margin-top:8px"></div></div>
${F('Por que você recomenda', `<textarea id="r4" rows="3" placeholder="Uma ou duas frases para o mentorado saber o que vai encontrar">${E(r.desc || '')}</textarea>`)}
<div class="g2">${F('Competência relacionada (opcional)', `<select id="r5"><option value="">Nenhuma</option>${CK().map(c => `<option ${c == r.comp ? 'selected' : ''}>${E(c)}</option>`).join('')}</select>`)}<div class="f"><span>Capa (opcional)</span><div class="row" style="flex-wrap:nowrap"><label class="btn s sm" style="position:relative;overflow:hidden">${ic('image')}Enviar imagem<input type="file" accept="image/*" style="position:absolute;inset:0;opacity:0;cursor:pointer" onchange="recCapaUp(this.files[0]);this.value=''"></label><button type="button" class="btn q sm" id="rcx" style="${r.capa ? '' : 'display:none'}" onclick="RC.capa='';this.style.display='none';recPrev()">Remover</button></div><small>Sem imagem, o portal monta uma capa com o título.</small></div></div>
${F('Turma(s)', tpick(r.turmas || []), 'Deixe tudo desmarcado para mostrar a todas as turmas.')}
<label class="chk"><input type="checkbox" id="r6" ${r.pin ? 'checked' : ''}> Colocar em destaque no topo da vitrine</label>${id ? '' : `<label class="chk" style="margin-top:10px"><input type="checkbox" id="r7" checked> Avisar os mentorados</label>`}
</div><aside class="rpv"><span class="sm-t">Como o mentorado vê</span><div id="rprev"></div></aside></div>`, { wide: true, label: id ? 'Salvar recomendação' : 'Publicar recomendação', ok: () => {
      if (!val('r1')) {
        toast('Informe o título');
        return false;
      }
      if (val('r3') && !safeUrl(val('r3'))) {
        toast('O link precisa começar com https://');
        return false;
      }
      recSalvar(id);
      return false;
    } });
  $('#mbox').classList.add('cw');
  recTipo(r.tipo);
  recPdfList();
}

async function recSalvar(id) {
  const r = id ? S.recs.find(x => x.id == id) : null, b = $('#mok');
  const d = {
    tipo: RC.tipo, t: val('r1'), autor: val('r2'), url: val('r3'), desc: val('r4'), comp: val('r5'), capa: RC.capa || '', turmas: tpicked(), pin: $('#r6').checked
  };
  const avisar = !id && $('#r7').checked;
  b.disabled = true;
  let file = RC.tipo == 'livro' || RC.tipo == 'audio' ? RC.file : null;
  if (file && RC.novo) {
    file = { id: 'r' + uid(), name: RC.novo.name, size: RC.novo.size };
    if (!await fput(file.id, RC.novo)) {
      b.disabled = false;
      return toast(FILES.erro + ': ' + RC.novo.name);
    }
  }
  if (r && r.file && (!file || file.id != r.file.id))
    fdel(r.file.id);
  d.file = file;
  if (d.pin)
    S.recs.forEach(x => x.pin = false);
  if (r)
    Object.assign(r, d);
  else {
    const nova = { id: uid(), ...d, at: stamp(), por: S.mentor };
    S.recs.unshift(nova);
    if (avisar)
      notify('Nova recomendação: ' + d.t, 'Push + e-mail', RTIPOS[d.tipo][0] + ' indicado pelo mentor' + (d.autor ? ', de ' + d.autor : '') + '.', alvoDe(nova), 'recs');
  }
  closeM();
  done(id ? 'Recomendação atualizada' : 'Recomendação publicada', (id ? 'Editou' : 'Publicou') + ' a recomendação "' + d.t + '"');
}

function recDel(id) {
  const r = S.recs.find(x => x.id == id);
  modal('Excluir recomendação', `<p>Excluir <b>${E(r.t)}</b>? Ela deixa de aparecer para os mentorados.</p>`, { label: 'Excluir', danger: true, ok: () => {
      if (r.file)
        fdel(r.file.id);
      S.recs = S.recs.filter(x => x.id != id);
      Object.keys(S.recSt).forEach(k => {
        if (k.endsWith('-' + id))
          delete S.recSt[k];
      });
      done('Recomendação excluída', 'Excluiu a recomendação "' + r.t + '"');
    } });
}
