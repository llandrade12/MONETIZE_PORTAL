/**
 * mentor/app.js
 * Painel do mentor (mentor.html): menu, selos de pendência, mapa de páginas, "ver como aluno" e inicialização.
 * Para adicionar uma página: crie o arquivo em js/mentor/, registre em PAGINAS e no menu ANAV, e inclua no mentor.html.
 */
'use strict';

const ANAV = [['Geral', [['visao', 'Visão geral', 'grid'], ['comps', 'Competências', 'sliders']]], ['Mentoria', [['turmas', 'Turmas', 'layers'], ['alunos', 'Alunos', 'users'], ['aulas', 'Aulas e calendário', 'cal'], ['freq', 'Frequência', 'roll'], ['tarefas', 'Tarefas', 'check'], ['recs', 'Recomendações', 'bookmark']]], ['Avaliação', [['avaliacoes', 'Notas e avaliações', 'star'], ['metas', 'Metas e planos de ação', 'target']]], ['Comunicação', [['mural', 'Mural de avisos', 'mega'], ['comunicacao', 'Notificações', 'bell'], ['suporte', 'Suporte', 'help']]], ['Resultados', [['certificados', 'Certificados', 'award'], ['relatorios', 'Relatórios', 'file']]], ['Sistema', [['config', 'Configurações', 'gear']]]];

function badgeA(k) {
  if (k == 'avaliacoes')
    return pendC();
  if (k == 'metas')
    return pendM();
  if (k == 'freq')
    return justPend().length + aulasCtx().filter(a => a.status == 'agendada' && a.date <= hoje()).length;
  if (k == 'suporte')
    return chAbertos();
  if (k == 'comunicacao')
    return unreadM();
  if (k == 'alunos')
    return alunosCtx().filter(a => a.status == 'pendente').length;
  return 0;
}

/* Entra na área do aluno como o mentorado escolhido (o banner "Voltar ao painel" traz de volta). */
function abrirComoAluno(id) {
  save();
  try {
    sessionStorage.removeItem('sop-rota-aluno');
  }
  catch (e) {
  }
  verComo(id);
  irPara('aluno');
}

/* Aluno de teste: existe só para o mentor navegar pela área do aluno. Não tem e-mail nem senha, então ninguém entra com ele pelo login. */
function alunoTeste() {
  let a = S.alunos.find(x => x.teste && x.status != 'removido');
  if (!a) {
    a = { id: nid(), nome: 'Aluno de teste', email: '', tel: '', nasc: '1990-01-01', cargo: 'Outro', civil: 'Solteiro', formacao: '', mat: hoje(), turma: (S.turmas[0] || {}).id || 0, status: 'ativo', canais: { email: false, whats: false }, teste: true };
    S.alunos.push(a);
    S.roda[a.id] = { ini: Array(8).fill(5), fin: Array(8).fill(5), iniSent: false, finSent: false };
  }
  a.status = 'ativo';
  return a;
}

function previewAs() {
  const L = S.alunos.filter(a => a.status == 'ativo');
  if (!L.length)
    return modal('Ver o portal como aluno', `<p class="mu" style="margin:0">Ainda não há aluno ativo. O portal cria um <b>Aluno de teste</b> para você navegar pela área do aluno. Ele aparece na lista de alunos e pode ser removido quando quiser.</p>`, { label: 'Criar aluno de teste e abrir', ok: () => {
        abrirComoAluno(alunoTeste().id);
        return false;
      } });
  modal('Ver o portal como aluno', F('Mentorado', `<select id="pva">${L.map(a => `<option value="${a.id}">${E(a.nome)}</option>`).join('')}</select>`), { label: 'Abrir visão do aluno', sub: 'Útil para conferir o que cada aluno está vendo.', ok: () => {
      abrirComoAluno(+val('pva'));
      return false;
    } });
}

const APP = {
  role: 'admin', inicio: 'visao',
  view() {
    const PAGINAS = {
      visao: A_visao, recs: A_recs, turmas: A_turmas, alunos: A_alunos, alunoD: A_aluno, aulas: A_aulas, tarefas: A_tarefas, avaliacoes: A_aval, metas: A_metas, comps: A_comps, mural: A_mural, comunicacao: A_com, freq: A_freq, suporte: A_sup, certificados: A_cert, relatorios: A_rel, config: A_config
    };
    if (R.p == 'alunoD' && !aluno(R.a))
      R = { p: 'alunos', a: null };
    const html = (PAGINAS[R.p] || A_visao)();
    let title = { aulas: 'Aulas e calendário', tarefas: 'Tarefas', mural: 'Mural de avisos' }[R.p] || TITLES[R.p] || 'Visão geral', crumb = '';
    if (R.p == 'alunoD') {
      title = E(nm(R.a));
      crumb = `<button onclick="nav('alunos')">Alunos</button> / Ficha`;
    }
    return { html, title, crumb };
  }
};

boot(iniciar);
