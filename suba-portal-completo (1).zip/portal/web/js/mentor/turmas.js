/**
 * mentor/turmas.js
 * Página do admin: turmas. Cadastro de turmas e vínculo de cada aluno à turma desejada.
 */
'use strict';

function A_turmas() {
  const sem = S.alunos.filter(a => !turmaById(a.turma) && a.status != 'removido');
  return `<div class="row sp" style="margin-bottom:16px"><p class="mu" style="margin:0;max-width:620px">Cadastre quantas turmas quiser e escolha os alunos de cada uma. A cor da turma aparece no calendário, nas aulas e nas tarefas.</p><button class="btn" onclick="novaTurma()">${ic('plus')}Nova turma</button></div>
${sem.length ? `<div class="card alert" style="margin-bottom:14px"><div class="row sp"><div><b>${sem.length} aluno(s) sem turma</b><p class="mu" style="margin:2px 0 0">${sem.map(a => E(a.nome)).join(', ')}</p></div><span class="sm-t">Use "Alunos da turma" em uma das turmas abaixo.</span></div></div>` : ''}
<div class="g2">${S.turmas.map(t => {
    const al = S.alunos.filter(a => a.turma == t.id && a.status != 'removido'), T = aulasDe(t.id).length, r = realizadas(t.id).length;
    return `<div class="card tcard" style="--c:${E(t.cor)}"><div class="row sp" style="align-items:flex-start;flex-wrap:nowrap"><div><div class="row" style="gap:8px;margin-bottom:6px">${tchip(t, true)}${ttag(t)}</div><h2>${E(t.nome)}</h2><p class="mu" style="margin:2px 0 0">${E(t.edicao)}${t.publico ? ', público ' + E(t.publico).toLowerCase() : ''}</p></div><button class="btn q sm" aria-label="Editar turma" onclick="editTurma(${t.id})">${ic('edit')}</button></div>
<dl class="meta" style="margin:16px 0"><dt>Período</dt><dd>${t.inicio ? DFY(t.inicio) + (t.fim ? ' a ' + DFY(t.fim) : '') : 'A definir'}</dd><dt>Encontros</dt><dd>${T ? r + ' de ' + T + ' realizados' : 'Nenhuma aula cadastrada'}</dd><dt>Carga horária</dt><dd>${t.carga ? E(t.carga) + ' horas' : 'A definir'}</dd><dt>Frequência mínima</dt><dd>${freqMin(t.id)}%${has(t.freqMin) ? '' : ' <span class="sm-t">(padrão)</span>'}</dd></dl>
${unResumo(t)}
${rodaResumo(t, al)}
<div class="tal"><div class="row sp" style="margin-bottom:8px"><b style="font-size:13px">${al.length} aluno(s)</b><button class="btn s sm" onclick="turmaAlunos(${t.id})">${ic('users')}Alunos da turma</button></div>${al.length ? `<div class="avs">${al.slice(0, 8).map(a => `<button class="av" title="${E(a.nome)}" onclick="nav('alunoD',${a.id})">${ini(a.nome)}</button>`).join('')}${al.length > 8 ? `<span class="sm-t">+${al.length - 8}</span>` : ''}</div>` : `<p class="sm-t" style="margin:0">Nenhum aluno vinculado ainda.</p>`}</div>
<div class="row" style="margin-top:16px"><button class="btn s sm" onclick="setCtx(${t.id});nav('aulas')">${ic('cal')}Calendário</button><button class="btn s sm" onclick="turmaUnid(${t.id})">${ic('layers')}Unidades e aulas</button><button class="btn s sm" onclick="shift(${t.id})">Adiantar ou prorrogar</button><button class="btn ${t.status == 'Concluída' ? 's' : 'd'} sm" onclick="concl(${t.id})">${t.status == 'Concluída' ? 'Reabrir turma' : 'Concluir turma'}</button><button class="btn q sm" aria-label="Excluir turma" title="Excluir turma" onclick="delTurma(${t.id})">${ic('trash')}</button></div></div>`;
  }).join('')}</div>${S.turmas.length ? '' : empty('Nenhuma turma cadastrada', 'Crie a primeira turma para vincular alunos e aulas.', `<button class="btn" onclick="novaTurma()">${ic('plus')}Nova turma</button>`)}
<p class="sm-t" style="margin-top:14px">Ao concluir uma turma, os alunos mantêm acesso somente leitura e o certificado fica disponível no perfil.</p>`;
}

function turmaForm(t = {}) {
  const usadas = S.turmas.map(x => x.cor), cor = t.cor || TCORES.find(c => !usadas.includes(c)) || TCORES[S.turmas.length % TCORES.length];
  return F('Nome da mentoria', `<input id="tn" value="${E(t.nome || '')}" placeholder="Ex.: Suba o Padrão">`) + `<div class="g2">${F('Edição', `<input id="te" value="${E(t.edicao || 'Turma ' + p2(S.turmas.length + 1))}">`) + F('Sigla (aparece no calendário)', `<input id="tsg" maxlength="8" value="${E(t.sigla || '')}" placeholder="Automática">`)}</div>` +
    F('Cor da turma', `<div class="swp" role="radiogroup" aria-label="Cor da turma">${TCORES.map(c => `<label title="${c}"><input type="radio" name="tcor" value="${c}" ${c == cor ? 'checked' : ''}><i style="background:${c}"></i></label>`).join('')}</div>`, 'É por esta cor que você identifica a turma no calendário.') +
    `<div class="g2">${F('Público', `<select id="tp">${['Masculino', 'Feminino', 'Misto'].map(x => `<option ${x == t.publico ? 'selected' : ''}>${x}</option>`).join('')}</select>`) + F('Situação', `<select id="tst">${['Planejada', 'Ativa', 'Concluída'].map(x => `<option ${x == (t.status || 'Ativa') ? 'selected' : ''}>${x}</option>`).join('')}</select>`)}${F('Início', `<input id="ti" type="date" value="${t.inicio || ''}">`)}${F('Término', `<input id="tf" type="date" value="${t.fim || ''}">`)}${F('Carga horária (horas)', `<input id="tch" type="number" min="0" value="${E(t.carga || '')}">`, 'Sai impressa no certificado.')}${F('Cidade', `<input id="tci" value="${E(t.cidade || '')}">`, 'Usada em "Local e data" do certificado.')}${F('Frequência mínima (%)', `<input id="tfm" type="number" min="0" max="100" value="${E(t.freqMin ?? '')}" placeholder="${S.cfg.freqMin} (padrão)">`, 'Deixe vazio para usar a regra geral de Configurações.')}</div>`;
}

function turmaVal() {
  if (!val('tn')) {
    toast('Informe o nome');
    return null;
  }
  if (val('ti') && val('tf') && val('tf') < val('ti')) {
    toast('O término não pode ser antes do início');
    return null;
  }
  const d = {
    nome: val('tn'), edicao: val('te'), sigla: val('tsg'), cor: ($('#mbox input[name=tcor]:checked') || {}).value || TCORES[0], publico: val('tp'), status: val('tst'), inicio: val('ti'), fim: val('tf'), carga: val('tch'), cidade: val('tci'), freqMin: val('tfm') === '' ? '' : Math.max(0, Math.min(100, +val('tfm') || 0))
  };
  if (!d.sigla)
    d.sigla = tsig(d);
  return d;
}

function novaTurma() {
  modal('Nova turma', turmaForm(), { wide: true, label: 'Criar turma', ok: () => {
      const d = turmaVal();
      if (!d)
        return false;
      const id = nid();
      S.turmas.push({ id, ...d, unidades: [], rodaIni: '', rodaFin: '' });
      done('Turma criada. Agora vincule os alunos.', 'Criou a turma ' + tnome(d));
      setTimeout(() => turmaAlunos(id), 60);
    } });
}

function editTurma(id) {
  const t = turmaById(id);
  modal('Editar turma', turmaForm(t), { wide: true, label: 'Salvar alterações', ok: () => {
      const d = turmaVal();
      if (!d)
        return false;
      Object.assign(t, d);
      done('Turma atualizada');
    } });
}

/* Vincular alunos à turma: marque quem faz parte. */
function turmaAlunos(id) {
  const t = turmaById(id), L = S.alunos.filter(a => a.status != 'removido');
  modal('Alunos da turma', `<div class="row sp" style="margin-bottom:8px"><span class="sm-t">Marque quem faz parte desta turma. Quem estiver em outra turma é movido para esta.</span><span class="row"><button class="btn q sm" onclick="$$('.tac').forEach(c=>c.checked=true)">Todos</button><button class="btn q sm" onclick="$$('.tac').forEach(c=>c.checked=false)">Nenhum</button></span></div><div class="card flat" style="padding:4px 14px">${L.map(a => {
    const o = turmaById(a.turma);
    return `<label class="chk tal-r"><input type="checkbox" class="tac" value="${a.id}" ${a.turma == id ? 'checked' : ''}><span class="grow"><b>${E(a.nome)}</b><small>${E(a.email)}</small></span>${a.turma == id ? '' : o ? tchip(o, true) : tchip(null)}</label>`;
  }).join('') || '<p class="mu">Nenhum aluno cadastrado.</p>'}</div>`, { wide: true, sub: tchip(t), label: 'Salvar alunos da turma', ok: () => {
      let n = 0;
      $$('.tac').forEach(c => {
        const a = aluno(+c.value);
        if (c.checked && a.turma != id) {
          a.turma = id;
          n++;
        }
        else if (!c.checked && a.turma == id) {
          a.turma = 0;
          n++;
        }
      });
      done(n ? n + ' vínculo(s) atualizado(s) em ' + tnome(t) : 'Nada foi alterado');
    } });
}

function shift(id) {
  const t = turmaById(id), fut = aulasDe(id).filter(a => a.status == 'agendada' && a.date >= hoje());
  if (!fut.length)
    return toast('Esta turma não tem aulas futuras agendadas');
  modal('Adiantar ou prorrogar a turma', F('Mover as próximas ' + fut.length + ' aula(s) em quantos dias?', '<input id="sh" type="number" value="7">', 'Use número negativo para adiantar. Aulas compartilhadas com outra turma também mudam de data. Os alunos são notificados.'), { sub: tchip(t), label: 'Recalcular calendário', ok: () => {
      const d = parseInt(val('sh')) || 0;
      if (!d) {
        toast('Informe os dias');
        return false;
      }
      fut.forEach(a => a.date = addD(a.date, d));
      if (t.fim)
        t.fim = addD(t.fim, d);
      notify('Calendário atualizado', 'E-mail + push', 'As próximas aulas foram ' + (d > 0 ? 'prorrogadas' : 'adiantadas') + ' em ' + Math.abs(d) + ' dia(s). Confira a agenda.', S.alunos.filter(a => a.status == 'ativo' && a.turma == id), 'agenda');
      done('Calendário recalculado e turma notificada');
    } });
}

function concl(id) {
  const t = turmaById(id);
  if (t.status == 'Concluída') {
    t.status = 'Ativa';
    return done('Turma reaberta: ' + tnome(t));
  }
  modal('Concluir turma', `<p>${tchip(t)}</p><p>A turma passa para "Concluída". Os alunos ficam com acesso somente leitura. O histórico é arquivado e nunca apagado.</p>`, { label: 'Concluir turma', danger: true, ok: () => {
      t.status = 'Concluída';
      if (!t.fim)
        t.fim = hoje();
      done('Turma concluída: ' + tnome(t));
    } });
}

function delTurma(id) {
  const t = turmaById(id), al = S.alunos.filter(a => a.turma == id).length, uso = [...S.aulas, ...S.tarefas, ...S.eventos].filter(x => (x.turmas || []).includes(id)).length;
  if (al || uso)
    return modal('Não é possível excluir agora', `<p>${tchip(t)}</p><p>Esta turma ainda tem ${al} aluno(s) e ${uso} aula(s), tarefa(s) ou evento(s) ligados a ela.</p><p class="mu">Mova os alunos para outra turma e ajuste as aulas antes de excluir. Se a turma terminou, use "Concluir turma": o histórico fica guardado.</p>`, { cancel: 'Entendi' });
  modal('Excluir turma', `<p>Excluir ${tchip(t)}? Esta ação fica registrada no histórico.</p>`, { label: 'Excluir turma', danger: true, ok: () => {
      S.turmas = S.turmas.filter(x => x.id != id);
      delete S.certs[id];
      if (S.turmaAtual == id)
        S.turmaAtual = 0;
      done('Turma excluída', 'Excluiu a turma ' + tnome(t));
    } });
}

/* ---------- Unidades da turma e quantidade de aulas ---------- */

/* Resumo das unidades no cartão da turma. */
function unResumo(t) {
  const U = t.unidades || [];
  if (!U.length)
    return `<div class="un-b un-e"><span class="sm-t">Sem unidades. Divida a mentoria em unidades (ou módulos) e diga quantas aulas cada uma tem.</span></div>`;
  const prev = U.reduce((s, u) => s + (+u.qtd || 0), 0);
  return `<div class="un-b"><div class="row sp" style="margin-bottom:8px"><b style="font-size:13px">${U.length} unidade(s) · ${prev} aula(s) previstas</b></div>${U.map((u, i) => {
    const A = aulasUn(t.id, u.id), r = A.filter(aulaLib).length, q = Math.max(+u.qtd || 0, A.length);
    return `<div class="un-r"><span class="un-n">${i + 1}</span><span class="grow"><span class="row sp" style="font-size:13px;margin-bottom:4px;flex-wrap:nowrap"><b>${E(u.nome)}</b><span class="sm-t">${r} de ${q} realizada(s)${A.length < q ? ' · ' + (q - A.length) + ' sem data' : ''}</span></span>${bar(pct(r, q))}</span></div>`;
  }).join('')}</div>`;
}

/* Unidades em edição. */
let UNE = [];

const unRow = (u, i, tid) => `<div class="une"><span class="un-n">${i + 1}</span><input class="une-n" placeholder="Nome da unidade (ex.: Fundamentos)" value="${E(u.nome)}" oninput="UNE[${i}].nome=this.value"><label class="une-q"><input type="number" min="0" max="60" value="${E(u.qtd)}" aria-label="Quantidade de aulas" oninput="UNE[${i}].qtd=this.value"><small>aulas</small></label><span class="sm-t une-c">${u.novo ? 'nova' : aulasUn(tid, u.id).length + ' cadastrada(s)'}</span><span class="row" style="gap:2px;flex-wrap:nowrap"><button type="button" class="btn q sm" aria-label="Subir" ${i ? '' : 'disabled'} onclick="unMove(${i},-1,${tid})">${ic('up')}</button><button type="button" class="btn q sm" aria-label="Remover unidade" onclick="UNE.splice(${i},1);unList(${tid})">${ic('x')}</button></span></div>`;

function unList(tid) {
  const el = $('#unl');
  if (!el)
    return;
  el.innerHTML = UNE.map((u, i) => unRow(u, i, tid)).join('') || '<p class="mu" style="margin:0 0 6px">Nenhuma unidade. Adicione a primeira.</p>';
  $('#unt').textContent = UNE.length + ' unidade(s) · ' + UNE.reduce((s, u) => s + (+u.qtd || 0), 0) + ' aula(s) previstas';
}

function unMove(i, d, tid) {
  const x = UNE.splice(i, 1)[0];
  UNE.splice(i + d, 0, x);
  unList(tid);
}

function turmaUnid(id) {
  const t = turmaById(id), ult = aulasDe(id).slice(-1)[0];
  UNE = (t.unidades || []).map(u => ({ ...u }));
  modal('Unidades e aulas', `<p class="sm-t" style="margin:0 0 12px">Divida a mentoria em unidades e informe quantas aulas cada uma tem. O aluno vê as aulas agrupadas por unidade, e o total previsto entra no cálculo de "faltas que ainda cabem".</p>
<div id="unl"></div><div class="row sp" style="margin-top:10px"><button type="button" class="btn s sm" onclick="UNE.push({id:'u'+uid(),nome:'',qtd:4,novo:1});unList(${id});$('#unl .une:last-child .une-n').focus()">${ic('plus')}Adicionar unidade</button><b class="sm-t" id="unt"></b></div>
<div class="card flat" style="margin-top:16px;padding:14px"><label class="chk"><input type="checkbox" id="ung" onchange="$('#ungb').hidden=!this.checked"> <span><b>Criar no calendário as aulas que faltam</b><br><span class="sm-t">O portal cria as aulas de cada unidade em sequência, já com data. Depois é só ajustar o tema e a competência de cada uma.</span></span></label>
<div id="ungb" hidden><div class="g2" style="margin-top:12px">${F('Primeira data', `<input id="ung1" type="date" value="${ult ? addD(ult.date, 7) : t.inicio && t.inicio >= hoje() ? t.inicio : addD(hoje(), 7)}">`)}${F('Horário', `<input id="ung2" type="time" value="${ult ? ult.hora : '20:00'}">`)}${F('Intervalo entre aulas (dias)', `<input id="ung3" type="number" min="1" value="7">`, '7 = toda semana, no mesmo dia.')}</div><p class="sm-t" style="margin:10px 0 0">A competência de cada aula você escolhe depois, ao editar a aula.</p></div></div>`, { wide: true, sub: tchip(t), label: 'Salvar unidades', ok: () => {
      if (UNE.some(u => !String(u.nome).trim())) {
        toast('Dê um nome a cada unidade');
        return false;
      }
      const fora = (t.unidades || []).filter(o => !UNE.some(u => u.id == o.id)).map(o => o.id);
      t.unidades = UNE.map(u => ({ id: u.id, nome: String(u.nome).trim(), qtd: Math.max(0, Math.min(60, parseInt(u.qtd) || 0)) }));
      /* Aulas de uma unidade removida ficam sem unidade (não são apagadas). */
      S.aulas.forEach(a => {
        if (a.un && fora.includes(a.un[id]))
          delete a.un[id];
      });
      let n = 0;
      if ($('#ung').checked) {
        if (!val('ung1')) {
          toast('Informe a primeira data');
          return false;
        }
        let d = val('ung1');
        const passo = Math.max(1, parseInt(val('ung3')) || 7);
        t.unidades.forEach(u => {
          const tem = aulasUn(id, u.id).length;
          for (let k = tem; k < u.qtd; k++) {
            S.aulas.push({ n: nid(), nome: u.nome + ' · Aula ' + (k + 1), date: d, hora: val('ung2') || '20:00', dur: 120, turmas: [id], un: { [id]: u.id }, comp: '', mentor: S.mentor, link: '', obj: '', topicos: [], aberta: false, status: 'agendada', video: '', mats: [], motivo: '', hist: [{ at: stamp(), m: 'Aula criada pela unidade "' + u.nome + '"' }] });
            d = addD(d, passo);
            n++;
          }
        });
        if (n)
          notify('Calendário atualizado', 'E-mail + push', n + ' novo(s) encontro(s) na agenda da turma.', S.alunos.filter(a => a.status == 'ativo' && a.turma == id), 'agenda');
      }
      done('Unidades salvas' + (n ? ' e ' + n + ' aula(s) criada(s)' : ''), 'Atualizou as unidades de ' + tnome(t));
    } });
  unList(id);
}

/* ---------- Roda da Vida: o mentor libera a inicial e a final para a turma toda ---------- */

function rodaResumo(t, al) {
  const at = al.filter(a => a.status == 'ativo'), n = k => at.filter(a => (S.roda[a.id] || {})[k + 'Sent']).length;
  const linha = (k, nome, campo) => `<div class="rd-r"><span class="grow"><b>${nome}</b><span class="sm-t">${t[campo] ? 'Liberada em ' + DF(t[campo]) + ' · ' + n(k) + ' de ' + at.length + ' enviada(s)' : 'Ainda não liberada para a turma'}</span></span>${t[campo] ? `<button class="btn q sm" onclick="rodaLib(${t.id},'${campo}')">Fechar</button>` : `<button class="btn s sm" onclick="rodaLib(${t.id},'${campo}')">${ic('wheel')}Liberar</button>`}</div>`;
  return `<div class="un-b"><b style="font-size:13px;display:block;margin-bottom:4px">Roda da Vida</b>${linha('ini', 'Roda inicial', 'rodaIni')}${linha('fin', 'Roda final', 'rodaFin')}</div>`;
}

function rodaLib(tid, campo) {
  const t = turmaById(tid), fin = campo == 'rodaFin', nome = fin ? 'Roda da Vida final' : 'Roda da Vida inicial', al = S.alunos.filter(a => a.turma == tid && a.status == 'ativo');
  if (t[campo]) {
    t[campo] = '';
    keep();
    return done(nome + ' fechada para ' + tnome(t), 'Fechou a ' + nome + ' de ' + tnome(t));
  }
  modal('Liberar a ' + nome, `<p>${tchip(t)}</p><p>Os ${al.length} aluno(s) ativo(s) da turma passam a poder preencher e enviar a ${nome}. Cada um é avisado. Depois de enviada, o aluno não altera mais os valores.</p>${fin ? '<p class="mu">Com a final enviada, o aluno e você veem a comparação antes e depois.</p>' : ''}${fin && !t.rodaIni ? '<p class="sm-t" style="color:var(--wn)">A Roda inicial desta turma ainda não foi liberada.</p>' : ''}`, { label: 'Liberar para a turma', ok: () => {
      t[campo] = hoje();
      notify(nome + ' liberada', 'E-mail + WhatsApp', fin ? 'Preencha a Roda da Vida final para comparar o antes e o depois da mentoria.' : 'Preencha a sua Roda da Vida inicial: ela é o ponto de partida para medir a sua evolução.', al, 'evolucao');
      keep();
      done(nome + ' liberada para ' + tnome(t), 'Liberou a ' + nome + ' para ' + tnome(t));
    } });
}
