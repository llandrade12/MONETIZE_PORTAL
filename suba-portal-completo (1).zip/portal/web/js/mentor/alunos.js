/**
 * mentor/alunos.js
 * Página do admin: alunos.
 */
'use strict';

function A_alunos() {
  const q = (ST.q || '').toLowerCase(), f = ST.fa || 'todos';
  const AL = alunosCtx(), L = AL.filter(a => (f == 'todos' || a.status == f) && (!q || (a.nome + a.email + a.cargo).toLowerCase().includes(q)));
  const c = s => AL.filter(a => a.status == s).length;
  return `<div class="toolbar"><input class="search" id="qa" placeholder="Buscar por nome, e-mail ou cargo" value="${E(ST.q || '')}" oninput="ST.q=this.value;clearTimeout(window._q);window._q=setTimeout(()=>{render();const i=$('#qa');i.focus();i.setSelectionRange(i.value.length,i.value.length)},250)">
<div class="seg">${[['todos', 'Todos', AL.length], ['ativo', 'Ativos', c('ativo')], ['pendente', 'Pendentes', c('pendente')], ['bloqueado', 'Bloqueados', c('bloqueado') + c('removido')]].map(([k, l, n]) => `<button class="${f == k ? 'on' : ''}" onclick="ST.fa='${k}';render()">${l} ${n}</button>`).join('')}</div>
<button class="btn" onclick="novoAluno()">${ic('plus')}Cadastrar aluno</button></div>
<div class="tw"><table><thead><tr><th>Aluno</th><th>Turma</th><th class="hide-m">Cargo</th><th>Status</th><th class="hide-m">Nota final</th><th class="hide-m">Presença</th><th class="hide-m">Entregas</th><th></th></tr></thead><tbody>
${L.map(a => `<tr class="hov" onclick="nav('alunoD',${a.id})"><td>${who(a)}</td><td onclick="event.stopPropagation()"><span class="tsel" style="--c:${E(turmaDe(a.id).cor)}"><i></i><select aria-label="Turma de ${E(a.nome)}" onchange="setTurmaAluno(${a.id},this.value)"><option value="0">Sem turma</option>${S.turmas.map(t => `<option value="${t.id}" ${t.id == a.turma ? 'selected' : ''}>${E(tnome(t))}</option>`).join('')}</select></span></td><td class="hide-m">${E(a.cargo)}</td><td>${tag(...stTag(a.status))}${a.saida && a.status == 'ativo' ? ' ' + tag('Pediu saída', 'er') : ''}</td><td class="hide-m"><b class="gold">${f1(fin(a.id))}</b></td><td class="hide-m">${a.status == 'ativo' ? presPct(a.id) + '%' : '—'}</td><td class="hide-m">${a.status == 'ativo' ? entPct(a.id) + '%' : '—'}</td><td style="text-align:right">${ic('right')}</td></tr>`).join('') || `<tr><td colspan="8">${empty('Nenhum aluno encontrado', ctx() ? 'Nenhum aluno em ' + E(ctxNome()) + ' com este filtro.' : 'Ajuste a busca ou o filtro.')}</td></tr>`}</tbody></table></div>
<p class="sm-t" style="margin-top:12px">Troque a turma de qualquer aluno direto na coluna Turma. Pagamento e matrícula ficam na plataforma de vendas (Hotmart, Eduzz ou Kiwify). Aqui o portal controla apenas o status: pendente, ativo ou bloqueado. Nenhum histórico é apagado.</p>`;
}

function alunoForm(a = {}) {
  return F('Nome completo', `<input id="n1" value="${E(a.nome || '')}" autocomplete="off">`) + `<div class="g2">${F('E-mail de login', `<input id="n7" type="email" value="${E(a.email || '')}">`)}${F('Telefone (WhatsApp)', `<input id="n8" value="${E(a.tel || '')}" placeholder="(71) 99999-9999">`)}${F('Data de nascimento', `<input id="n2" type="date" value="${E(a.nasc || '')}">`, 'Idade mínima: 18 anos.')}${F('Função/cargo', `<select id="n3">${['Dono', 'Sócio', 'Gestor', 'Diretor', 'Outro'].map(x => `<option ${x == a.cargo ? 'selected' : ''}>${x}</option>`).join('')}</select>`)}${F('Estado civil', `<select id="n4">${['Solteiro', 'Casado', 'União estável', 'Divorciado', 'Viúvo'].map(x => `<option ${x == a.civil ? 'selected' : ''}>${x}</option>`).join('')}</select>`, '')}${F('Formação', `<input id="n5" value="${E(a.formacao || '')}">`)}${F('Matrícula na mentoria', `<input id="n6" type="date" value="${E(a.mat || hoje())}">`)}${F('Turma', `<select id="n9"><option value="0">Sem turma</option>${S.turmas.map(t => `<option value="${t.id}" ${t.id == (a.id ? a.turma : ctx() || (S.turmas[0] || {}).id) ? 'selected' : ''}>${E(tnome(t))}</option>`).join('')}</select>`)}</div>`;
}

function alunoVal() {
  if (!val('n1') || !val('n2') || !val('n7')) {
    toast('Preencha nome, e-mail e nascimento');
    return null;
  }
  if (!/\S+@\S+\.\S+/.test(val('n7'))) {
    toast('E-mail inválido');
    return null;
  }
  if (age(val('n2')) < 18) {
    toast('Idade mínima de 18 anos não atingida');
    return null;
  }
  return {
    nome: val('n1'), email: val('n7'), tel: val('n8'), nasc: val('n2'), cargo: val('n3'), civil: val('n4'), formacao: val('n5'), mat: val('n6'), turma: +val('n9')
  };
}

/* Campo de senha do aluno, com botão para sugerir uma senha. */
const senhaCampo = (rotulo, dica) => F(rotulo, `<span class="row" style="flex-wrap:nowrap;gap:8px"><input id="nsn" type="text" autocomplete="off" spellcheck="false" placeholder="Mínimo de 8 caracteres, com letras e números"><button type="button" class="btn s sm" style="white-space:nowrap" onclick="$('#nsn').value=senhaNova()">${ic('refresh')}Sugerir</button></span>`, dica);

/* Senha fácil de ditar e digitar: sem letras e números que se confundem (0/O, 1/l/I). */
function senhaNova() {
  const L = 'abcdefghjkmnpqrstuvwxyz', N = '23456789', r = new Uint32Array(10);
  crypto.getRandomValues(r);
  const p = (set, i) => set[r[i] % set.length];
  return p(L, 0).toUpperCase() + p(L, 1) + p(L, 2) + p(L, 3) + '-' + p(N, 4) + p(N, 5) + p(N, 6) + p(N, 7) + '-' + p(L, 8) + p(L, 9);
}

/* Mostra ao mentor o acesso recém-criado, para ele repassar ao aluno. A senha aparece só aqui: não fica guardada. */
function acessoAluno(a, senha, titulo) {
  const link = location.origin + location.pathname.replace(/[^/]*$/, ''), txt = 'Olá, ' + a.nome.split(' ')[0] + '. Seu acesso à Área de Membros da mentoria:\nEndereço: ' + link + '\nE-mail: ' + a.email + '\nSenha: ' + senha + '\n\nVocê pode trocar a senha depois, em Perfil.';
  ST.acTxt = txt;
  modal(titulo, `<p class="mu" style="margin:0 0 12px">Repasse estes dados ao aluno. <b>A senha só aparece agora</b>: o portal não guarda a senha, só o resumo dela.</p>
<div class="card flat" style="padding:14px"><dl class="meta"><dt>E-mail</dt><dd>${E(a.email)}</dd><dt>Senha</dt><dd style="font:600 17px ui-monospace,Menlo,Consolas,monospace;letter-spacing:.04em">${E(senha)}</dd></dl></div>
<div class="row" style="margin-top:14px">${a.tel && digits(a.tel).length >= 10 ? `<a class="btn sm" href="${E(waLink(a.tel, txt))}" target="_blank" rel="noopener">${ic('whats')}Enviar por WhatsApp</a>` : ''}<a class="btn s sm" href="${E(mailLink(a.email, 'Seu acesso à Área de Membros', txt))}" target="_blank" rel="noopener">${ic('mail')}Enviar por e-mail</a><button class="btn s sm" onclick="navigator.clipboard&&navigator.clipboard.writeText(ST.acTxt).then(()=>toast('Dados de acesso copiados'),()=>toast('Copie manualmente'))">${ic('copy')}Copiar</button></div>`, { cancel: 'Concluir', sub: E(a.nome) });
  $('#modal').dataset.re = '1';
}

function novoAluno() {
  modal('Cadastrar aluno', alunoForm() + senhaCampo('Senha de acesso do aluno', 'Você define a senha e repassa ao aluno. Ele pode trocar depois, no perfil.') + `<label class="chk"><input type="checkbox" id="nl" checked> Liberar o acesso agora</label>`, { wide: true, label: 'Cadastrar aluno', ok: () => {
      const d = alunoVal(), sn = $('#nsn').value.trim();
      if (!d)
        return false;
      if (S.alunos.some(a => a.email && a.email.toLowerCase() == d.email.toLowerCase())) {
        toast('Já existe um aluno com este e-mail');
        return false;
      }
      if (d.email.toLowerCase() == String(U.email).toLowerCase()) {
        toast('Este e-mail é o seu login de mentor. Use outro para o aluno.');
        return false;
      }
      if (!senhaForte(sn)) {
        toast('Defina a senha do aluno: 8+ caracteres, com letras e números');
        return false;
      }
      const id = nid(), lib = $('#nl').checked;
      /* senhaNova viaja uma única vez até o servidor, que guarda só o resumo dela e devolve o cadastro sem a senha. */
      const a = { id, ...d, senhaNova: sn, status: lib ? 'ativo' : 'pendente', canais: { email: true, whats: true } };
      S.alunos.push(a);
      S.roda[id] = { ini: Array(8).fill(5), fin: Array(8).fill(5), iniSent: false, finSent: false };
      closeM();
      done(lib ? 'Aluno cadastrado e acesso liberado' : 'Aluno cadastrado como pendente', 'Cadastrou o aluno ' + d.nome);
      acessoAluno(a, sn, 'Acesso criado');
      return false;
    } });
}

function editAluno(id) {
  const a = aluno(id);
  modal('Editar cadastro', alunoForm(a) + senhaCampo('Nova senha (opcional)', 'Deixe vazio para manter a senha atual.'), { wide: true, label: 'Salvar alterações', ok: () => {
      const d = alunoVal(), sn = $('#nsn').value.trim();
      if (!d)
        return false;
      if (S.alunos.some(x => x.id != id && x.email && x.email.toLowerCase() == d.email.toLowerCase())) {
        toast('Já existe um aluno com este e-mail');
        return false;
      }
      if (d.email.toLowerCase() == String(U.email).toLowerCase()) {
        toast('Este e-mail é o seu login de mentor. Use outro para o aluno.');
        return false;
      }
      if (sn && !senhaForte(sn)) {
        toast('Senha: 8+ caracteres, com letras e números');
        return false;
      }
      if (!sn) {
        Object.assign(a, d);
        return done('Cadastro atualizado');
      }
      Object.assign(a, d, { senhaNova: sn });
      closeM();
      done('Cadastro e senha atualizados', 'Atualizou o cadastro e a senha de ' + a.nome);
      acessoAluno(a, sn, 'Nova senha definida');
      return false;
    } });
}

function togA(id) {
  const a = aluno(id);
  if (a.status == 'ativo') {
    modal('Bloquear acesso de ' + E(a.nome), F('Motivo', `<select id="bm"><option>Inadimplência</option><option>Falta grave</option><option>Solicitação do aluno</option><option>Outro</option></select>`), { label: 'Bloquear acesso', danger: true, ok: () => {
        a.status = 'bloqueado';
        a.motivo = val('bm') + ', ' + stamp();
        done('Acesso bloqueado: ' + a.nome);
      } });
    return;
  }
  a.status = 'ativo';
  a.motivo = '';
  notify('Acesso liberado', 'E-mail + WhatsApp', 'Seu acesso à Área de Membros está liberado. Entre com este e-mail e a senha que o mentor te passou.', id);
  done('Acesso liberado: ' + a.nome);
}

function remov(id) {
  const a = aluno(id);
  modal('Remover ' + E(a.nome), F('Motivo', `<select id="rm1"><option>Falta grave</option><option>Inadimplência</option></select>`, 'O acesso é bloqueado imediatamente. O histórico é arquivado para auditoria, nunca apagado.'), { label: 'Remover da turma', danger: true, ok: () => {
      a.status = 'removido';
      a.motivo = val('rm1') + ', ' + stamp();
      done('Aluno removido e histórico arquivado');
    } });
}

function confSaida(id) {
  const a = aluno(id);
  modal('Confirmar saída de ' + E(a.nome), `<p>Motivo informado: ${E(a.saida.motivo)}</p><p class="mu">O acesso será bloqueado e o registro arquivado com motivo e data.</p>`, { label: 'Confirmar saída', danger: true, ok: () => {
      a.status = 'bloqueado';
      a.motivo = 'Saída voluntária: ' + a.saida.motivo + ', ' + stamp();
      done('Saída confirmada: ' + a.nome);
    } });
}

/* O mentor define uma senha nova para o aluno (quando ele esquece, por exemplo). */
function reenviarAcesso(id) {
  const a = aluno(id);
  modal('Redefinir senha de ' + E(a.nome.split(' ')[0]), senhaCampo('Nova senha', 'A senha atual deixa de valer. Você repassa a nova ao aluno.'), { label: 'Definir nova senha', sub: E(a.email), ok: () => {
      const sn = $('#nsn').value.trim();
      if (!senhaForte(sn)) {
        toast('Senha: 8+ caracteres, com letras e números');
        return false;
      }
      a.senhaNova = sn;
      closeM();
      done('Senha redefinida: ' + a.nome, 'Redefiniu a senha de ' + a.nome);
      acessoAluno(a, sn, 'Nova senha definida');
      return false;
    } });
  $('#nsn').value = senhaNova();
}

/* Troca rápida de turma direto na lista de alunos. */
function setTurmaAluno(id, tid) {
  const a = aluno(id);
  a.turma = +tid || 0;
  keep();
  done(a.nome + (a.turma ? ' agora está em ' + tnome(turmaById(a.turma)) : ' ficou sem turma'));
}
