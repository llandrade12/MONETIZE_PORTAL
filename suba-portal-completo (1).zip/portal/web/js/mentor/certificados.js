/**
 * mentor/certificados.js
 * Página do admin: certificados. A arte oficial fica em assets/img/certificado.jpg;
 * o portal preenche nome do aluno, período, carga horária, mentor, local e data.
 */
'use strict';

function A_cert() {
  const T = S.turmas.filter(t => !ctx() || t.id == ctx()), at = ativos();
  return `<p class="mu" style="max-width:680px">O certificado usa a arte oficial da mentoria. O portal preenche o nome do aluno, o período, a carga horária, o mentor responsável e o local e data. Emita por turma quando ela terminar. ${S.cfg.certFreq ? 'Só recebe quem atingiu a <b>frequência mínima</b>; você pode liberar um aluno por exceção.' : 'A frequência mínima não está bloqueando o certificado (mude em Configurações).'}</p>
<div class="g2">${T.map(t => {
    const c = S.certs[t.id] || {}, n = S.alunos.filter(a => a.turma == t.id && a.status == 'ativo').length;
    return `<div class="card tcard ${c.on ? '' : 'gold'}" style="--c:${E(t.cor)}"><div class="row sp" style="align-items:flex-start"><div><div style="margin-bottom:6px">${tchip(t)}</div><p class="mu" style="margin:0">${n} aluno(s) ativo(s) · ${t.carga ? E(t.carga) + ' h' : 'carga horária a definir'} · ${E(t.cidade || 'cidade a definir')}</p></div>${c.on ? tag('Emitidos em ' + c.at, 'ok') : tag('Não emitidos', '')}</div><div class="row" style="margin-top:14px">${c.on ? `<button class="btn s sm" onclick="revogar(${t.id})">Recolher certificados</button>` : `<button class="btn sm" ${n ? '' : 'disabled'} onclick="emitir(${t.id})">${ic('award')}Emitir certificados</button>`}<button class="btn q sm" onclick="editTurma(${t.id})">${ic('edit')}Carga horária e cidade</button></div></div>`;
  }).join('')}</div>
${at.length ? `<div class="tw sec" style="margin-top:16px"><table><thead><tr><th>Aluno</th><th>Turma</th><th>Frequência</th><th class="hide-m">Entregas</th><th>Situação</th><th></th></tr></thead><tbody>${at.map(a => {
    const f = freq(a.id), el = certElig(a.id), ex = S.certLib[a.id];
    return `<tr><td>${who(a)}</td><td>${tchip(turmaDe(a.id), true)}</td><td><b class="${f.abaixo ? 'er' : ''}">${f.n ? f.pct + '%' : '—'}</b> <span class="sm-t">mín. ${f.min}%</span></td><td class="hide-m">${entPct(a.id)}%</td><td>${!el ? tag('Bloqueado pela frequência', 'er') : certOpen(a.id) ? tag(ex && f.abaixo ? 'Disponível (exceção)' : 'Disponível para o aluno', 'ok') : tag(ex && f.abaixo ? 'Liberado por exceção' : 'Aguardando emissão', '')}</td><td style="text-align:right;white-space:nowrap">${S.cfg.certFreq && f.abaixo ? `<button class="btn q sm" onclick="certExc(${a.id})">${ex ? 'Desfazer exceção' : 'Liberar por exceção'}</button> ` : ''}<button class="btn s sm" onclick="verCert(${a.id})">${ic('eye')}<span class="hide-m">Ver certificado</span></button></td></tr>`;
  }).join('')}</tbody></table></div>` : `<div style="margin-top:16px">${empty('Nenhum aluno ativo', 'Vincule alunos às turmas para gerar os certificados.')}</div>`}
<p class="sm-t" style="margin-top:12px">O nome do mentor responsável vem de Configurações. Para trocar a arte, substitua o arquivo assets/img/certificado.jpg mantendo o mesmo tamanho.</p>`;
}

function emitir(tid) {
  const t = turmaById(tid), todos = S.alunos.filter(a => a.turma == tid && a.status == 'ativo'), al = todos.filter(a => certElig(a.id)), fora = todos.filter(a => !certElig(a.id));
  modal('Emitir certificados', `<p>${tchip(t)}</p><p>O certificado fica disponível no perfil de ${al.length} aluno(s) desta turma, e cada um recebe e-mail e notificação.</p>${fora.length ? `<div class="card flat" style="margin-bottom:14px;border-color:var(--er)"><b>${fora.length} aluno(s) abaixo de ${freqMin(tid)}% de frequência não recebem:</b><p class="mu" style="margin:4px 0 0">${fora.map(a => E(a.nome) + ' (' + freq(a.id).pct + '%)').join(', ')}. Eles são avisados do motivo. Para incluir alguém, use "Liberar por exceção" antes de emitir.</p></div>` : ''}` + F('Data que sai no certificado', `<input id="cdt" type="date" value="${t.fim && t.fim <= hoje() ? t.fim : hoje()}">`) + (t.carga ? '' : '<p class="sm-t" style="color:var(--wn)">Esta turma está sem carga horária. O certificado sai sem essa informação.</p>') + (t.status == 'Concluída' || (t.fim && t.fim <= hoje()) ? '' : '<p class="sm-t" style="color:var(--wn)">A turma ainda não terminou. Emita antes apenas se tiver certeza.</p>'), { label: 'Emitir e notificar', ok: () => {
      const d = val('cdt') || hoje();
      S.certs[tid] = { on: true, at: DFY(d), iso: d };
      notify('Certificado disponível', 'E-mail + WhatsApp', 'Seu certificado de conclusão está no seu perfil.', al, 'perfil');
      if (fora.length)
        notify('Certificado pendente por frequência', 'E-mail + WhatsApp', 'Os certificados da turma foram emitidos, mas sua frequência ficou abaixo do mínimo de ' + freqMin(tid) + '%.' + (S.cfg.compensa ? ' Assista às gravações dos encontros que perdeu: ao atingir o mínimo, o certificado é liberado.' : ' Fale com o mentor.'), fora, 'frequencia');
      done('Certificados emitidos: ' + tnome(t));
    } });
}

function revogar(tid) {
  const t = turmaById(tid);
  modal('Recolher certificados', `<p>${tchip(t)}</p><p>Os alunos deixam de ver o certificado no perfil até você emitir de novo. Use para corrigir data, carga horária ou cidade.</p>`, { label: 'Recolher', danger: true, ok: () => {
      delete S.certs[tid];
      done('Certificados recolhidos: ' + tnome(t));
    } });
}

/* Libera (ou volta a bloquear) o certificado de um aluno que ficou abaixo da frequência mínima. */
function certExc(aid) {
  if (S.certLib[aid]) {
    delete S.certLib[aid];
    keep();
    return done('Exceção desfeita: ' + nm(aid));
  }
  const f = freq(aid);
  modal('Liberar certificado por exceção', `<p><b>${E(nm(aid))}</b> está com ${f.pct}% de frequência, abaixo do mínimo de ${f.min}%.</p>` + F('Motivo da exceção', `<input id="cex" placeholder="Ex.: reposição feita presencialmente">`, 'Fica registrado no histórico de ações.'), { label: 'Liberar certificado', ok: () => {
      if (val('cex').length < 4) {
        toast('Informe o motivo');
        return false;
      }
      S.certLib[aid] = { at: stamp(), motivo: val('cex') };
      if (certDe(aid).on)
        notify('Certificado disponível', 'E-mail + WhatsApp', 'Seu certificado de conclusão foi liberado e está no seu perfil.', aid, 'perfil');
      keep();
      done('Certificado liberado por exceção', 'Liberou o certificado de ' + nm(aid) + ' por exceção: ' + val('cex'));
    } });
}
