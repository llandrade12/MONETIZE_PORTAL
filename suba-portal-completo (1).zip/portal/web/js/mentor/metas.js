/**
 * mentor/metas.js
 * Página do admin: metas e planos de ação. O aluno propõe a meta e monta o plano (etapas com prazo);
 * o mentor aprova ou pede ajuste e acompanha o progresso.
 */
'use strict';

function A_metas() {
  const M = S.metas.filter(m => inCtx(m.aid)), c = k => M.filter(m => k == 'feita' ? m.feita : k == 'aprovada' ? m.st == 'aprovada' && !m.feita : m.st == k).length;
  const f = sub('metas', c('proposta') ? 'proposta' : 'aprovada'), L = M.filter(m => f == 'todas' || (f == 'feita' ? m.feita : f == 'aprovada' ? m.st == 'aprovada' && !m.feita : m.st == f));
  const late = M.filter(m => m.st == 'aprovada' && !m.feita && m.etapas.some(etapaAtrasada)).length;
  return `<p class="mu" style="max-width:680px">O aluno propõe a meta e transforma em plano, com etapas e prazos. Você aprova ou pede ajuste, acompanha o avanço e comenta. O aluno recebe lembrete automático das etapas.${late ? ` <b style="color:var(--er)">${late} plano(s) com etapa em atraso.</b>` : ''}</p>` + tabs('metas', [['proposta', 'Aguardando', c('proposta')], ['aprovada', 'Em andamento', c('aprovada')], ['ajustar', 'Em ajuste', c('ajustar')], ['feita', 'Concluídas', c('feita')], ['todas', 'Todas', M.length]], f) + (L.length ? `<div class="stack">${L.map(m => metaCard(m, false, true)).join('')}</div>` : empty('Nada por aqui', 'Nenhuma meta nesta situação.'));
}

function metaAval(id) {
  const m = S.metas.find(x => x.id == id);
  modal('Avaliar meta', `<div class="card flat"><b>${E(m.t)}</b>${m.prazo ? `<div class="sm-t">Prazo final: ${DFY(m.prazo)}</div>` : ''}${m.etapas.length ? `<ul class="topics" style="margin-top:8px">${m.etapas.map(e => `<li>${E(e.t)}${e.prazo ? ' <span class="sm-t">até ' + DF(e.prazo) + '</span>' : ''}</li>`).join('')}</ul>` : '<p class="sm-t" style="margin:6px 0 0">O aluno ainda não definiu etapas.</p>'}</div><div style="height:14px"></div>` + F('Observação para o aluno (obrigatória para ajuste)', `<textarea id="mo" rows="3"></textarea>`), {
    sub: E(nm(m.aid)), label: 'Aprovar meta', cancel: '', wide: true, ok: () => {
      m.st = 'aprovada';
      m.obs = val('mo');
      notify('Meta aprovada', 'Notificação + e-mail', 'Sua meta "' + m.t + '" foi aprovada. Agora é executar o plano, etapa por etapa.', m.aid, 'evolucao');
      done('Meta aprovada');
    }
  });
  const f = $('.mf');
  f.insertAdjacentHTML('afterbegin', `<button class="btn s" onclick="metaAjuste('${id}')">Pedir ajuste</button><span style="flex:1"></span>`);
}

function metaAjuste(id) {
  const m = S.metas.find(x => x.id == id);
  if (!val('mo')) {
    toast('Escreva o que precisa ser ajustado');
    return;
  }
  m.st = 'ajustar';
  m.obs = val('mo');
  notify('Ajuste solicitado na sua meta', 'Notificação + e-mail', m.obs, m.aid, 'evolucao');
  closeM();
  done('Ajuste solicitado ao aluno');
}
