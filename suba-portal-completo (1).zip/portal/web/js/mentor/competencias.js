/**
 * mentor/competencias.js
 * Página do admin: competências.
 * Aba "Competências da mentoria": o mentor cria, edita, ordena e exclui competências (cada aula e tarefa usa uma).
 * Aba "Por aluno": análise individual, com ajuste de nota e peso só para aquele aluno.
 */
'use strict';

function A_comps() {
  const t = sub('comps', 'cad');
  return tabs('comps', [['cad', 'Competências da mentoria', S.compL.length], ['aluno', 'Análise por aluno']], 'cad') + (t == 'aluno' ? compsAluno() : compsCad());
}

/* ---------- Cadastro ---------- */

function compsCad() {
  const soma = S.compL.reduce((s, c) => s + (+c.peso || 0), 0), at = ativos();
  return `<div class="row sp" style="margin-bottom:16px"><p class="mu" style="margin:0;max-width:620px">Crie as competências que a mentoria desenvolve. Cada aula e cada tarefa é ligada a uma delas, e o peso define quanto ela vale na nota final.</p><span class="row">${S.compL.length ? tag('Pesos somam ' + soma + '%', soma == 100 ? 'ok' : 'wn') : ''}<button class="btn" onclick="compForm()">${ic('plus')}Nova competência</button></span></div>` +
    (S.compL.length ? `<div class="g2">${S.compL.map((c, i) => {
      const A = S.aulas.filter(a => a.comp == c.nome).length, T = S.tarefas.filter(x => x.comp == c.nome).length, m = avg(at.map(a => compAvg(a.id, c.nome)).filter(x => x != null));
      return `<div class="card"><div class="row sp" style="align-items:flex-start;flex-wrap:nowrap"><div class="row" style="gap:14px;flex-wrap:nowrap;align-items:flex-start"><span class="hexn">${i + 1}</span><div><h3 style="font-size:16.5px">${E(c.nome)}</h3><p class="mu" style="margin:4px 0 0">${E(c.desc || 'Sem descrição.')}</p></div></div><div class="row" style="flex-wrap:nowrap;gap:2px"><button class="btn q sm" aria-label="Subir na ordem" title="Subir na ordem" ${i ? '' : 'disabled'} onclick="compMove(${i},-1)">${ic('up')}</button><button class="btn q sm" aria-label="Editar competência" title="Editar" onclick="compForm(${i})">${ic('edit')}</button><button class="btn q sm" aria-label="Excluir competência" title="Excluir" onclick="compDel(${i})">${ic('trash')}</button></div></div>
<div class="row sp" style="margin-top:16px"><div class="row">${tag('Peso ' + (+c.peso || 0) + '%', 'gd')}${tag(A + (A == 1 ? ' aula' : ' aulas'), '')}${tag(T + (T == 1 ? ' tarefa' : ' tarefas'), '')}</div><span class="sm-t">Média da turma <b class="gold" style="font:700 17px var(--dp)">${f1(m)}</b></span></div></div>`;
    }).join('')}</div>${soma != 100 ? `<p class="sm-t" style="margin-top:12px;color:var(--wn)">Os pesos somam ${soma}%. A nota final continua sendo calculada na proporção, mas o ideal é fechar em 100%.</p>` : ''}` : empty('Nenhuma competência criada', 'Crie a primeira competência para poder cadastrar aulas e tarefas.', `<button class="btn" onclick="compForm()">${ic('plus')}Criar competência</button>`));
}

function compForm(i) {
  const c = i != null ? S.compL[i] : {};
  modal(i != null ? 'Editar competência' : 'Nova competência', F('Nome da competência', `<input id="c1" value="${E(c.nome || '')}" placeholder="Ex.: Liderança">`) + F('Descrição (opcional)', `<textarea id="c2" rows="3" placeholder="O que o mentorado desenvolve nesta competência">${E(c.desc || '')}</textarea>`) + F('Peso na nota final (%)', `<input id="c3" type="number" min="0" max="100" value="${E(c.peso ?? '')}">`, 'O ideal é que os pesos de todas as competências somem 100%.'), { label: i != null ? 'Salvar competência' : 'Criar competência', ok: () => {
      const nome = val('c1'), peso = Math.max(0, Math.min(100, Math.round(+val('c3') || 0)));
      if (!nome) {
        toast('Informe o nome da competência');
        return false;
      }
      if (S.compL.some((x, j) => j != i && x.nome.toLowerCase() == nome.toLowerCase())) {
        toast('Já existe uma competência com este nome');
        return false;
      }
      if (i != null) {
        compRename(c.nome, nome);
        Object.assign(c, { nome, desc: val('c2'), peso });
      }
      else
        S.compL.push({ nome, desc: val('c2'), peso });
      done(i != null ? 'Competência atualizada' : 'Competência criada', (i != null ? 'Editou' : 'Criou') + ' a competência ' + nome);
    } });
}

/* Renomear leva junto aulas, tarefas e ajustes individuais. */
function compRename(de, para) {
  if (de == para)
    return;
  [...S.aulas, ...S.tarefas].forEach(x => {
    if (x.comp == de)
      x.comp = para;
  });
  Object.values(S.compA).forEach(o => {
    if (o[de]) {
      o[para] = o[de];
      delete o[de];
    }
  });
}

function compMove(i, d) {
  const j = i + d;
  if (j < 0 || j >= S.compL.length)
    return;
  [S.compL[i], S.compL[j]] = [S.compL[j], S.compL[i]];
  save();
  keep();
  render();
}

function compDel(i) {
  const c = S.compL[i], uso = [...S.aulas, ...S.tarefas].filter(x => x.comp == c.nome).length, outras = S.compL.filter((_, j) => j != i);
  if (uso && !outras.length)
    return modal('Não é possível excluir agora', `<p><b>${E(c.nome)}</b> é a única competência e está em uso por ${uso} aula(s) ou tarefa(s). Crie outra competência antes de excluir esta.</p>`, { cancel: 'Entendi' });
  modal('Excluir competência', `<p>Excluir <b>${E(c.nome)}</b>?</p>` + (uso ? F(uso + ' aula(s) e tarefa(s) usam esta competência. Mover para', `<select id="cmv">${outras.map(o => `<option>${E(o.nome)}</option>`).join('')}</select>`, 'As notas já lançadas passam a contar na competência escolhida.') : '<p class="mu">Nenhuma aula ou tarefa usa esta competência.</p>'), { label: 'Excluir competência', danger: true, ok: () => {
      if (uso)
        compRename(c.nome, val('cmv'));
      Object.values(S.compA).forEach(o => delete o[c.nome]);
      S.compL.splice(i, 1);
      done('Competência excluída', 'Excluiu a competência ' + c.nome);
    } });
}

/* ---------- Análise por aluno ---------- */

function compsAluno() {
  const at = ativos(), K = CK();
  if (!at.length)
    return empty('Nenhum aluno ativo', 'Não há alunos ativos em ' + E(ctxNome()) + ' para analisar.');
  if (!K.length)
    return empty('Nenhuma competência criada', 'Crie as competências na aba ao lado.');
  if (!at.some(a => a.id == ST.csel))
    ST.csel = at[0].id;
  const id = ST.csel, a = aluno(id), soma = K.reduce((s, c) => s + pesoDe(id, c), 0), aj = K.filter(c => has(compA(id, c).nota) || has(compA(id, c).peso)).length;
  return `<p class="mu" style="max-width:680px">Escolha o aluno para analisar as competências dele. A nota vem das tarefas avaliadas, e você pode ajustar a nota e o peso de cada competência só para esse aluno.</p>
<div class="cp"><div class="card cp-l"><div class="ch" style="margin-bottom:8px"><h3>Alunos</h3><span class="sm-t">${at.length}</span></div>${at.map(x => `<button class="cp-a ${x.id == id ? 'on' : ''}" onclick="ST.csel=${x.id};keep();render()"><span class="av">${ini(x.nome)}</span><span class="grow"><b>${E(x.nome)}</b><small>${E(tsig(turmaDe(x.id)))}${K.some(c => has(compA(x.id, c).nota) || has(compA(x.id, c).peso)) ? ', ajustado' : ''}</small></span><b class="gold">${f1(fin(x.id))}</b></button>`).join('')}</div>
<div class="stack"><div class="card"><div class="row sp" style="gap:14px"><div class="row" style="gap:14px;flex-wrap:nowrap"><div class="av big">${ini(a.nome)}</div><div><h2>${E(a.nome)}</h2><div class="row" style="gap:8px;margin-top:6px">${tchip(turmaDe(id))}${aj ? tag(aj + ' ajuste(s) individual(is)', 'gd') : tag('Cálculo automático', '')}</div></div></div><div style="text-align:right"><span class="sm-t">Nota final</span><div class="num gold" style="font-size:40px;line-height:1.1">${f1(fin(id))}</div></div></div></div>
<div class="card"><div class="ch"><h3>Competências de ${E(a.nome.split(' ')[0])}</h3>${tag('Pesos somam ' + soma + '%', soma == 100 ? 'ok' : 'wn')}</div>
${K.map((c, i) => {
    const o = compA(id, c), auto = compAuto(id, c), v = compAvg(id, c), n = (mediaC(id)[c] || []).length;
    return `<div class="cp-c"><div class="row sp" style="margin-bottom:8px"><div><b style="font-size:15px">${E(c)}</b><span class="sm-t" style="display:block">${n ? 'Média das tarefas: ' + f1(auto) + ' (' + n + ' nota' + (n > 1 ? 's' : '') + ')' : 'Sem tarefas avaliadas ainda'}</span></div><span class="num ${has(o.nota) ? 'gold' : ''}" style="font-size:26px">${f1(v)}</span></div>${bar((v || 0) * 10)}
<div class="cp-f">${F('Nota definida por você (0 a 10)', `<input type="number" min="0" max="10" step="0.5" placeholder="${auto != null ? 'Automática: ' + f1(auto) : 'Sem nota'}" value="${has(o.nota) ? o.nota : ''}" aria-label="Nota de ${E(c)}" onchange="setCompA(${id},${i},'nota',this.value)">`)}${F('Peso para este aluno (%)', `<input type="number" min="0" max="100" placeholder="Padrão: ${cpeso(c)}" value="${has(o.peso) ? o.peso : ''}" aria-label="Peso de ${E(c)}" onchange="setCompA(${id},${i},'peso',this.value)">`)}${F('Observação da análise', `<input placeholder="Ex.: evoluiu muito na delegação" value="${E(o.obs || '')}" aria-label="Observação de ${E(c)}" onchange="setCompA(${id},${i},'obs',this.value)">`)}</div></div>`;
  }).join('')}
<div class="row sp" style="margin-top:16px"><span class="sm-t">Deixe o campo vazio para usar o cálculo automático. As alterações são salvas ao sair do campo.</span><span class="row">${aj ? `<button class="btn s sm" onclick="resetCompA(${id})">${ic('refresh')}Voltar ao automático</button>` : ''}<button class="btn sm" onclick="avisarComp(${id})">${ic('bell')}Avisar o aluno</button></span></div></div></div></div>`;
}

function setCompA(id, i, campo, v) {
  const c = CK()[i], A = S.compA[id] || (S.compA[id] = {}), o = A[c] || (A[c] = {});
  v = String(v).trim();
  if (campo == 'obs')
    o.obs = v;
  else if (v === '')
    delete o[campo];
  else {
    const n = parseFloat(v.replace(',', '.')), max = campo == 'nota' ? 10 : 100;
    if (isNaN(n) || n < 0 || n > max) {
      toast(campo == 'nota' ? 'A nota deve ser de 0 a 10' : 'O peso deve ser de 0 a 100');
      keep();
      return render();
    }
    o[campo] = campo == 'nota' ? Math.round(n * 2) / 2 : Math.round(n);
  }
  if (campo != 'obs')
    logA((campo == 'nota' ? 'Nota' : 'Peso') + ' de ' + c + ' de ' + nm(id) + (has(o[campo]) ? ' ajustado para ' + o[campo] : ' voltou ao automático'));
  save();
  keep();
  render();
  toast('Competência de ' + nm(id).split(' ')[0] + ' atualizada');
}

function resetCompA(id) {
  modal('Voltar ao cálculo automático', `<p>As notas e os pesos ajustados para <b>${E(nm(id))}</b> voltam a ser calculados pelas tarefas e pelos pesos padrão. As observações também são apagadas.</p>`, { label: 'Voltar ao automático', ok: () => {
      delete S.compA[id];
      keep();
      done('Competências de ' + nm(id) + ' no cálculo automático');
    } });
}

function avisarComp(id) {
  notify('Competências atualizadas', 'Notificação + e-mail', 'O mentor revisou suas competências. Veja como você está em Minha evolução.', id, 'evolucao');
  S.nlog[id + '|comp'] = stamp();
  keep();
  done(nm(id).split(' ')[0] + ' foi avisado da revisão');
}
