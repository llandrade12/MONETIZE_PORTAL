/**
 * mentor/notificacoes.js
 * Página do admin: notificações por aluno.
 * O mentor não vê nem edita script: cada situação do aluno tem um botão "Notificar" que já envia a mensagem certa.
 */
'use strict';

/* Situações que geram um botão de notificar. Cada uma: [chave, ícone, rótulo, detalhe, mensagem enviada, destino no portal, cor]. */
function situacoes(a) {
  const id = a.id, r = [], t = turmaDe(id), at = atrasos(id), re = realDe(id), px = nextAula(a.turma || -1);
  if (at.length)
    r.push(['atraso', 'clock', at.length + ' tarefa(s) em atraso', at.map(x => x.t).slice(0, 2).join(', ') + (at.length > 2 ? ' e mais ' + (at.length - 2) : ''), ['Tarefas em atraso', 'Você tem ' + at.length + ' tarefa(s) em atraso: ' + at.map(x => x.t).join(', ') + '. Entregue assim que puder para não perder o ritmo.'], 'tarefas', 'er']);
  const venc = tarefasDe(id).filter(x => tLib(x) && !S.ent[id + '-' + x.id] && diff(due(id, x), hoje()) >= 0 && diff(due(id, x), hoje()) <= 2);
  if (venc.length)
    r.push(['prazo', 'check', venc.length + ' tarefa(s) vencendo', 'Prazo até ' + DF(due(id, venc[0])), ['Prazo chegando', 'A tarefa "' + venc[0].t + '" vence em ' + DL(due(id, venc[0])) + '. Não deixe para a última hora.'], 'tarefas', 'wn']);
  const fq = freq(id), fal = fq.B.filter((x, i) => fq.st[i] == 'F');
  if (fq.abaixo)
    r.push(['freq', 'roll', 'Frequência abaixo do mínimo', fq.pct + '% (mínimo ' + fq.min + '%), ' + fq.ok + ' de ' + fq.n + ' encontros', ['Sua frequência precisa de atenção', 'Você está com ' + fq.pct + '% de frequência e o mínimo para o certificado é ' + fq.min + '%.' + (S.cfg.compensa ? ' Assista às gravações dos encontros que perdeu para compensar.' : '')], 'frequencia', 'er']);
  if (fal.length)
    r.push(['falta', 'user', fal.length + ' falta(s)', 'Frequência de ' + fq.pct + '%', ['Sentimos sua falta', 'Você faltou a ' + fal.length + ' encontro(s). As gravações estão no portal: assista para acompanhar a turma.'], 'frequencia', fal.length >= 2 ? 'er' : 'wn']);
  const nv = fq.B.filter(x => x.video && !S.vis[id + '-' + x.n]);
  if (nv.length)
    r.push(['grav', 'play', nv.length + ' gravação(ões) não assistida(s)', nv.map(x => x.nome).slice(0, 2).join(', '), ['Gravações esperando por você', 'Há ' + nv.length + ' gravação(ões) que você ainda não assistiu. Reserve um horário esta semana.'], 'aulas', 'wn']);
  if (rodaIniOpen(id) && (!S.roda[id] || !S.roda[id].iniSent))
    r.push(['roda', 'wheel', 'Roda da Vida inicial pendente', 'Liberada por você, ainda não enviada', ['Preencha sua Roda da Vida', 'Sua Roda da Vida inicial ainda não foi enviada. Ela é o ponto de partida para medir sua evolução.'], 'evolucao', 'wn']);
  else if (finOpen(id) && S.roda[id] && !S.roda[id].finSent)
    r.push(['rodaf', 'wheel', 'Roda da Vida final pendente', 'Liberada por você, ainda não enviada', ['Preencha sua Roda da Vida final', 'A Roda da Vida final está liberada. Preencha para comparar o antes e o depois da mentoria.'], 'evolucao', 'wn']);
  if (S.metas.some(m => m.aid == id && m.st == 'ajustar'))
    r.push(['meta', 'target', 'Meta aguardando ajuste', 'Você pediu ajuste e ele ainda não reenviou', ['Ajuste sua meta', 'Uma das suas metas pessoais precisa de ajuste. Revise e reenvie para aprovação.'], 'evolucao', 'wn']);
  if (!S.termos[id])
    r.push(['acesso', 'lock', 'Nunca acessou o portal', 'Termos ainda não aceitos', ['Seu acesso está liberado', 'Seu acesso à Área de Membros está pronto. Entre e aceite os termos para começar.'], 'inicio', 'wn']);
  if (px && diff(px.date, hoje()) <= 3)
    r.push(['aula', 'cal', 'Encontro ' + (diff(px.date, hoje()) == 0 ? 'hoje' : diff(px.date, hoje()) == 1 ? 'amanhã' : 'em ' + diff(px.date, hoje()) + ' dias'), px.nome + ', ' + px.hora, ['Lembrete de encontro', 'Nosso encontro "' + px.nome + '" é ' + DL(px.date) + ' às ' + px.hora + '. Conto com você.'], 'agenda', 'in']);
  return r;
}

const SITS = {};

function A_com() {
  const at = ativos(), f = sub('comunicacao', 'alunos');
  let tot = 0;
  const rows = at.map(a => {
    const s = situacoes(a);
    SITS[a.id] = s;
    tot += s.length;
    return [a, s];
  }).sort((x, y) => y[1].length - x[1].length);
  const comAtraso = rows.filter(([, s]) => s.some(x => x[0] == 'atraso')).length, man = S.fila.filter(x => x.st == 'manual').length;
  const body = f == 'fila' ? comFila() : f == 'auto' ? comAuto() : f == 'mentor' ? comMentor() : f == 'hist'
    ? `<div class="card">${S.notif.slice(0, 60).map(n => `<div class="li"><span class="ico ${n.auto ? '' : 'gd'}">${ic(n.auto ? 'bolt' : 'send')}</span><div class="grow"><b style="font-weight:600">${E(n.ev)}</b><span class="sm-t">${n.auto ? 'Automático · ' : ''}${E(n.canal)} · para ${E(n.dest)}</span></div><span class="sm-t">${E(n.at)}</span></div>`).join('') || '<p class="mu" style="margin:0">Nenhum envio ainda.</p>'}</div>`
    : (at.length ? `<div class="toolbar">${tfilter()}<span style="flex:1"></span>${comAtraso > 1 ? `<button class="btn s" onclick="notifLote('atraso')">${ic('bell')}Notificar os ${comAtraso} com tarefas em atraso</button>` : ''}</div>
<div class="stack">${rows.map(([a, s]) => `<div class="card nt ${s.some(x => x[6] == 'er') ? 'hot' : ''}"><div class="row sp nt-h"><div class="row" style="gap:12px;flex-wrap:nowrap;min-width:0">${who(a)}${tchip(turmaDe(a.id), true)}</div><div class="row">${s.length ? tag(s.length + (s.length == 1 ? ' ponto de atenção' : ' pontos de atenção'), s.some(x => x[6] == 'er') ? 'er' : 'wn') : tag('Em dia', 'ok')}<button class="btn q sm" onclick="notifCustom(${a.id})">${ic('msg')}Mensagem pessoal</button></div></div>
${s.length ? `<div class="nt-l">${s.map((x, i) => {
        const env = S.nlog[a.id + '|' + x[0]];
        return `<div class="nt-i"><span class="ico ${x[6] == 'er' ? 'er' : x[6] == 'in' ? '' : 'gd'}">${ic(x[1])}</span><div class="grow"><b>${E(x[2])}</b><span class="sm-t">${E(x[3])}${env ? ' · último aviso em ' + E(env) : ''}</span></div><button class="btn ${env || x[6] != 'er' ? 's' : ''} sm" onclick="notifSit(${a.id},${i})">${ic('bell')}${env ? 'Notificar de novo' : 'Notificar'}</button></div>`;
      }).join('')}</div>` : `<p class="sm-t" style="margin:12px 0 0">Nada pendente com este aluno. Se quiser, mande um reconhecimento.</p><div style="margin-top:10px"><button class="btn s sm" onclick="notifElogio(${a.id})">${ic('star')}Parabenizar pelo ritmo</button></div>`}</div>`).join('')}</div>` : empty('Nenhum aluno ativo', 'Não há alunos ativos em ' + E(ctxNome()) + '.'));
  return `<div class="au-st ${S.cfg.autoOn ? 'on' : ''}"><span class="ico ${S.cfg.autoOn ? 'gd' : ''}">${ic('bolt')}</span><div class="grow"><b>Lembretes automáticos ${S.cfg.autoOn ? 'ligados' : 'desligados'}</b><span class="sm-t">${S.cfg.autoOn ? 'Aula, prazo, tarefa em atraso e frequência saem sozinhos, por e-mail e WhatsApp. O botão "Notificar" continua aqui para um reforço pessoal.' : 'Hoje os avisos só saem quando você clica em "Notificar".'}</span></div><button class="btn s sm" onclick="ST.comunicacao='auto';render()">${ic('gear')}Configurar</button></div>` +
    tabs('comunicacao', [['alunos', 'Por aluno', tot || ''], ['fila', 'E-mail e WhatsApp', man || ''], ['auto', 'Automação'], ['mentor', 'Alertas para mim', unreadM() || ''], ['hist', 'Histórico', S.notif.length || '']], 'alunos') + body;
}

/* ---------- Fila de e-mail e WhatsApp ---------- */

const FILA_ST = { manual: ['Pronta para enviar', 'wn'], enviando: ['Enviando', 'in'], enviado: ['Enviada', 'ok'], erro: ['Falhou', 'er'] };

function comFila() {
  const fc = ST.filaC || 'todos', L = S.fila.filter(x => (fc == 'todos' || x.c == fc) && (!ST.filaP || x.st == 'manual')), man = S.fila.filter(x => x.st == 'manual').length;
  const eAuto = API.srv.email || S.cfg.webhook, wAuto = S.cfg.webhook;
  return `${eAuto && wAuto ? `<div class="card flat fl-i"><span class="ico ok">${ic('ok')}</span><div class="grow"><b>Envio automático ativo</b><span class="sm-t">${API.srv.email ? 'Os e-mails saem pelo servidor do portal' : 'Os e-mails são entregues ao seu serviço de automação'} e o WhatsApp é entregue ao seu serviço de automação.</span></div></div>` : eAuto ? `<div class="card flat fl-i"><span class="ico ok">${ic('ok')}</span><div class="grow"><b>E-mails saem sozinhos</b><span class="sm-t">O servidor envia cada e-mail na hora. As mensagens de WhatsApp ficam prontas aqui: clique em "Enviar" para abrir o WhatsApp com tudo preenchido, ou conecte um serviço de envio em Automação.</span></div><button class="btn s sm" onclick="ST.comunicacao='auto';render()">Conectar</button></div>` : `<div class="card flat fl-i"><span class="ico gd">${ic('alert')}</span><div class="grow"><b>Envio com um clique</b><span class="sm-t">As mensagens já ficam prontas aqui, com texto e destinatário. Clique em "Enviar" para abrir o WhatsApp ou o e-mail com tudo preenchido. Para sair sozinho, configure o e-mail no servidor e conecte um serviço de envio em Automação.</span></div><button class="btn s sm" onclick="ST.comunicacao='auto';render()">Conectar</button></div>`}
<div class="toolbar"><div class="seg">${[['todos', 'Todos'], ['whats', 'WhatsApp'], ['email', 'E-mail']].map(([k, l]) => `<button class="${fc == k ? 'on' : ''}" onclick="ST.filaC='${k}';render()">${l}</button>`).join('')}</div><label class="chk" style="font-size:13px;align-items:center"><input type="checkbox" ${ST.filaP ? 'checked' : ''} onchange="ST.filaP=this.checked;render()"> Só as que faltam enviar (${man})</label><span style="flex:1"></span>${S.fila.length ? `<button class="btn q sm" onclick="S.fila=S.fila.filter(x=>x.st=='manual');done('Fila limpa')">Limpar enviadas</button>` : ''}</div>
${L.length ? `<div class="card">${L.slice(0, 80).map(x => `<div class="li fl"><span class="ico ${x.c == 'whats' ? 'ok' : ''}">${ic(x.c == 'whats' ? 'whats' : 'mail')}</span><div class="grow"><b>${E(x.ev)} <span class="sm-t" style="font-weight:500">· ${E(x.nome)}</span></b><span class="sm-t">${x.auto ? 'Automático · ' : ''}${E(x.to)} · ${E(x.at)}</span><span class="sm-t fl-m">${E(x.txt.split('\n')[0])}</span>${x.erro ? `<span class="sm-t" style="color:var(--er)">Motivo: ${E(x.erro)}</span>` : ''}</div>${tag(...FILA_ST[x.st])}${x.st == 'enviado' ? '' : `<a class="btn ${x.st == 'manual' ? '' : 's'} sm" href="${E(x.c == 'whats' ? waLink(x.to, x.txt) : mailLink(x.to, x.ev, x.txt))}" target="_blank" rel="noopener" onclick="filaOk('${x.id}')">${ic('send')}Enviar</a>`}</div>`).join('')}</div>${L.length > 80 ? `<p class="sm-t" style="margin-top:8px">Mostrando as 80 mais recentes de ${L.length}.</p>` : ''}` : empty('Nenhuma mensagem na fila', 'Toda notificação do portal gera aqui a versão de e-mail e a de WhatsApp para o aluno.')}`;
}

function filaOk(id) {
  const x = S.fila.find(f => f.id == id);
  if (x)
    x.st = 'enviado';
  save();
  setTimeout(() => {
    keep();
    render();
  }, 400);
}

/* ---------- Automação: regras dos lembretes e conexão com e-mail/WhatsApp ---------- */

function comAuto() {
  const c = S.cfg, num = (id, v, min, max) => `<input id="${id}" type="number" min="${min}" max="${max}" value="${v}" style="width:72px;padding:7px 9px">`;
  const regra = (i, t, d, campo = '') => `<div class="li au-r"><span class="ico gd">${ic(i)}</span><div class="grow"><b>${t}</b><span class="sm-t">${d}</span></div>${campo}</div>`;
  return `<div class="main2"><div class="stack"><div class="card"><div class="ch"><h3>Lembretes automáticos</h3><label class="sw" style="padding:0;border:0"><input type="checkbox" id="au0" ${c.autoOn ? 'checked' : ''}><i></i></label></div>
<p class="mu" style="margin:0 0 6px">O servidor confere tudo sozinho, várias vezes ao dia, e avisa o aluno no portal, por notificação no celular, por e-mail e por WhatsApp. Cada lembrete sai uma única vez.</p>
${regra('cal', 'Aula chegando', 'Antes do encontro e de novo no dia, com o link da reunião.', `<span class="au-n">${num('au1', c.lembAula, 0, 7)}<small>dia(s) antes</small></span>`)}
${regra('check', 'Prazo de tarefa', 'Para quem ainda não entregou, antes do prazo e no dia.', `<span class="au-n">${num('au2', c.lembPrazo, 0, 7)}<small>dia(s) antes</small></span>`)}
${regra('clock', 'Tarefa em atraso', 'No dia seguinte ao prazo e depois repete até a entrega.', `<span class="au-n">${num('au3', c.atrasoCada, 1, 15)}<small>dia(s) entre avisos</small></span>`)}
${regra('user', 'Atraso prolongado', 'Você recebe um alerta para fazer contato pessoal.', `<span class="au-n">${num('au4', c.escala, 2, 30)}<small>dias de atraso</small></span>`)}
${regra('play', 'Gravação não assistida', '3 dias depois do encontro, para quem ainda não assistiu.')}
${regra('roll', 'Frequência', 'Falta registrada, limite de faltas e frequência abaixo do mínimo: o aluno é avisado e você também.')}
${regra('target', 'Plano de ação', 'Etapa vencendo e etapa em atraso.')}
<div class="row" style="margin-top:14px"><button class="btn" onclick="autoSalvar()">Salvar regras</button><button class="btn s" onclick="autoAgora()">${ic('bolt')}Conferir agora</button></div></div></div>
<div class="stack"><div class="card"><h3 style="margin-bottom:4px">Canais</h3><p class="mu" style="margin:0 0 6px">O aluno também escolhe, no perfil dele, por onde quer ser avisado.</p>
<label class="sw"><span class="grow"><b>E-mail</b><small>Para o e-mail de login do aluno</small></span><input type="checkbox" id="auE" ${c.canais.email ? 'checked' : ''}><i></i></label>
<label class="sw"><span class="grow"><b>WhatsApp</b><small>Para o telefone do cadastro</small></span><input type="checkbox" id="auW" ${c.canais.whats ? 'checked' : ''}><i></i></label>${pushSwitch()}<p class="sm-t" style="margin:10px 0 0">Com as notificações ligadas neste aparelho, os alertas do painel (justificativas, chamados, frequência baixa) chegam na tela, mesmo com o portal fechado.</p></div>
<div class="card"><div class="ch" style="margin-bottom:4px"><h3>Envio sem clique</h3>${API.srv.email || c.webhook ? tag(API.srv.email && c.webhook ? 'E-mail e WhatsApp' : API.srv.email ? 'E-mail ligado' : 'Conectado', 'ok') : tag('Não conectado', 'wn')}</div>
<p class="mu" style="margin:0 0 12px">${API.srv.email ? '<b>E-mail:</b> o servidor do portal já envia sozinho.' : '<b>E-mail:</b> ainda não configurado no servidor; as mensagens ficam prontas para envio com um clique.'} <b>WhatsApp:</b> cole abaixo o endereço (webhook) do seu serviço de automação, como n8n, Make ou Zapier. O portal entrega a ele cada mensagem pronta, e ele dispara pela sua API de WhatsApp.</p>
${F('Endereço do webhook', `<input id="auH" value="${E(c.webhook)}" placeholder="https://">`, 'Recebe: canal (whatsapp ou email), para, nome, assunto e mensagem.')}
<div class="g2">${F('Seu e-mail (alertas do mentor)', `<input id="auME" type="email" value="${E(c.mentorEmail)}">`)}${F('Seu WhatsApp', `<input id="auMT" value="${E(c.mentorTel)}" placeholder="(71) 99999-9999">`)}</div>
<div class="row"><button class="btn s sm" onclick="autoSalvar()">Salvar conexão</button>${API.srv.email || c.webhook ? `<button class="btn q sm" onclick="autoTeste()">Enviar teste</button>` : ''}</div></div></div></div></div>`;
}

function autoSalvar() {
  const c = S.cfg, n = (id, min, max, d) => Math.max(min, Math.min(max, parseInt(val(id)) || d));
  if (val('auH') && !safeUrl(val('auH')))
    return toast('O webhook precisa começar com https://');
  c.autoOn = $('#au0').checked;
  c.lembAula = Math.max(0, Math.min(7, parseInt(val('au1')) || 0));
  c.lembPrazo = Math.max(0, Math.min(7, parseInt(val('au2')) || 0));
  c.atrasoCada = n('au3', 1, 15, 3);
  c.escala = n('au4', 2, 30, 7);
  c.canais = { email: $('#auE').checked, whats: $('#auW').checked };
  c.webhook = val('auH');
  c.mentorEmail = val('auME');
  c.mentorTel = val('auMT');
  keep();
  done('Automação salva', 'Alterou as regras de lembretes automáticos');
}

/* Pede ao servidor uma conferência dos lembretes agora. */
async function autoAgora() {
  await salvarAgora();
  let n;
  try {
    n = (await chamar('POST', '/api/lembretes/rodar')).n;
  }
  catch (e) {
    return toast(e.msg);
  }
  await conferir();
  keep();
  render();
  toast(n ? n + ' lembrete(s) enviado(s) agora' : 'Tudo em dia: nenhum lembrete novo para enviar');
}

/* Teste dos canais do mentor: um alerta de teste percorre o mesmo caminho dos alertas de verdade. */
async function autoTeste() {
  if (!S.cfg.mentorEmail && !S.cfg.mentorTel)
    return toast('Informe seu e-mail ou WhatsApp e salve para receber o teste');
  notifyM('Teste de envio', 'Se você recebeu esta mensagem, o envio automático do portal está funcionando.', 'comunicacao');
  save();
  await salvarAgora();
  await conferir();
  ST.comunicacao = 'fila';
  render();
  toast('Teste enviado. Acompanhe a situação nesta lista.');
}

/* ---------- Alertas para o mentor ---------- */

function comMentor() {
  const L = S.inboxM.slice(0, 60);
  const html = `<div class="card">${L.map(i => `<button class="li cht" onclick="${i.arg != null ? `nav('${i.go}',${JSON.stringify(i.arg).replace(/"/g, '&quot;')})` : `nav('${i.go}')`}"><span class="ico ${i.lido ? '' : 'gd'}">${ic(i.auto ? 'bolt' : 'bell')}</span><span class="grow"><b>${E(i.t)}</b><span class="sm-t">${E(i.m)}</span></span><span class="sm-t">${E(i.at)}</span></button>`).join('') || '<p class="mu" style="margin:0">Nenhum alerta. Aqui chegam frequência baixa, justificativas, chamados, anotações compartilhadas e atrasos prolongados.</p>'}</div>`;
  if (S.inboxM.some(i => !i.lido)) {
    S.inboxM.forEach(i => i.lido = true);
    save();
  }
  return html;
}

/* Envia a notificação de uma situação específica do aluno. */
function notifSit(aid, i) {
  const x = (SITS[aid] || situacoes(aluno(aid)))[i];
  if (!x)
    return;
  notify(x[4][0], 'e-mail + WhatsApp', x[4][1], aid, x[5]);
  S.nlog[aid + '|' + x[0]] = stamp();
  keep();
  done(nm(aid).split(' ')[0] + ' notificado: ' + x[2].toLowerCase(), 'Notificou ' + nm(aid) + ' (' + x[2].toLowerCase() + ')');
}

/* Notifica de uma vez todos os alunos da lista que estão na mesma situação. */
function notifLote(chave) {
  let n = 0;
  ativos().forEach(a => {
    const x = situacoes(a).find(s => s[0] == chave);
    if (!x)
      return;
    notify(x[4][0], 'Push + e-mail + WhatsApp', x[4][1], a.id, x[5]);
    S.nlog[a.id + '|' + chave] = stamp();
    n++;
  });
  keep();
  done(n + ' aluno(s) notificado(s)');
}

function notifElogio(aid) {
  notify('Parabéns pelo ritmo', 'Push + e-mail', 'Você está em dia com tudo na mentoria. Continue assim: é a constância que sobe o padrão.', aid, 'evolucao');
  S.nlog[aid + '|elogio'] = stamp();
  keep();
  done(nm(aid).split(' ')[0] + ' recebeu o reconhecimento');
}

/* Mensagem escrita pelo mentor para um aluno específico. */
function notifCustom(aid) {
  modal('Mensagem para ' + E(nm(aid).split(' ')[0]), F('Assunto', `<input id="nc1" placeholder="Ex.: Sobre a sua última entrega">`) + F('Mensagem', `<textarea id="nc2" rows="4" placeholder="Escreva direto para o aluno"></textarea>`) + F('Enviar por', `<select id="nc3"><option>Push + e-mail + WhatsApp</option><option>Push + e-mail</option><option>Somente notificação no portal</option></select>`), { sub: E(nm(aid)) + ' · ' + E(tnome(turmaDe(aid))), label: 'Enviar notificação', ok: () => {
      if (!val('nc1') || !val('nc2')) {
        toast('Preencha assunto e mensagem');
        return false;
      }
      notify(val('nc1'), val('nc3'), val('nc2'), aid, 'notificacoes');
      keep();
      done('Mensagem enviada para ' + nm(aid).split(' ')[0], 'Enviou mensagem pessoal para ' + nm(aid));
    } });
}
