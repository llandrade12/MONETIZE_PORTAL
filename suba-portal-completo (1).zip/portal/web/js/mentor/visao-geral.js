/**
 * mentor/visao-geral.js
 * Página do admin: visão geral. Resumo do dia, pendências, próximos encontros e turmas.
 */
'use strict';

function A_visao() {
  const at = ativos(), med = at.map(a => fin(a.id)).filter(x => x != null), L = aulasCtx(), re = realizadas(), n = nextAula();
  const prox = L.filter(a => a.status == 'agendada' && a.date >= hoje()).slice(0, 4);
  const atras = at.filter(a => atrasos(a.id).length);
  const pend = [];
  semRegistro().forEach(a => pend.push(['er', 'alert', `Aula "${a.nome}" passou sem chamada`, `Era em ${DF(a.date)}. Faça a chamada e registre a gravação.`, `chamada(${a.n})`, 'Chamada']));
  S.alunos.filter(a => a.saida && a.status == 'ativo' && inCtx(a.id)).forEach(a => pend.push(['er', 'logout', `${a.nome} pediu saída`, a.saida.motivo, `confSaida(${a.id})`, 'Confirmar']));
  S.lgpd.filter(x => x.st == 'pendente' && inCtx(x.aid)).forEach(x => pend.push(['er', 'shield', `${nm(x.aid)} pediu a exclusão dos dados`, 'LGPD: confirme e apague os dados.', `ST.alunoD='dados';nav('alunoD',${x.aid})`, 'Abrir']));
  justPend().forEach(j => pend.push(['gd', 'roll', `Justificativa de falta de ${nm(j.aid)}`, (aulaN(j.n) || {}).nome || '', `justAval('${j.id}')`, 'Avaliar']));
  const baixa = at.filter(a => freq(a.id).abaixo);
  if (baixa.length)
    pend.push(['wn', 'roll', `${baixa.length} aluno(s) abaixo da frequência mínima`, baixa.slice(0, 3).map(a => a.nome.split(' ')[0] + ' (' + freq(a.id).pct + '%)').join(', '), `nav('freq')`, 'Ver frequência']);
  if (chAbertos())
    pend.push(['gd', 'help', `${chAbertos()} chamado(s) de suporte aguardando resposta`, 'Acesso, pagamento ou problema técnico.', `nav('suporte')`, 'Responder']);
  const dn = S.diario.filter(d => d.share && !d.resp && inCtx(d.aid));
  if (dn.length)
    pend.push(['gd', 'note', `${dn.length} anotação(ões) compartilhada(s) sem resposta`, [...new Set(dn.map(d => nm(d.aid).split(' ')[0]))].slice(0, 3).join(', '), `ST.alunoD='diario';nav('alunoD',${dn[0].aid})`, 'Ler']);
  if (atras.length)
    pend.push(['wn', 'clock', `${atras.length} aluno(s) com tarefas em atraso`, atras.slice(0, 3).map(a => a.nome.split(' ')[0]).join(', ') + (atras.length > 3 ? ' e mais ' + (atras.length - 3) : ''), `nav('comunicacao')`, 'Notificar']);
  S.contest.filter(c => !c.resp && inCtx(c.aid)).forEach(c => pend.push(['gd', 'star', `Contestação de ${nm(c.aid)}`, `Tarefa "${(S.tarefas.find(t => t.id == c.tid) || {}).t || ''}"`, `respC('${c.id}')`, 'Responder']));
  S.metas.filter(m => m.st == 'proposta' && inCtx(m.aid)).forEach(m => pend.push(['gd', 'target', `Meta proposta por ${nm(m.aid)}`, m.t, `metaAval('${m.id}')`, 'Avaliar']));
  alunosCtx().filter(a => a.status == 'pendente').forEach(a => pend.push(['gd', 'user', `${a.nome} aguarda liberação`, 'Matrícula sem acesso liberado.', `togA(${a.id})`, 'Liberar acesso']));
  const ung = tarefasLib().reduce((s, t) => s + at.filter(a => S.ent[a.id + '-' + t.id] && S.notas[a.id + '-' + t.id] == null).length, 0);
  if (ung)
    pend.push(['gd', 'check', `${ung} entrega(s) aguardando nota`, 'Lance as notas para atualizar as competências.', `nav('avaliacoes')`, 'Avaliar']);
  const kpi = (i, lb, num, sm, extra = '') => `<div class="kpi k2"><span class="ico gd">${ic(i)}</span><div class="kb"><span class="lb">${lb}</span><span class="num">${num}</span><small>${sm}</small>${extra}</div></div>`;
  return `<section class="ov-top"><div><p class="ov-d">${DL(hoje())} · ${E(ctxNome())}</p><h1>Olá, ${E(S.mentor.split(' ')[0])}.</h1><p class="mu" style="margin:6px 0 0">${pend.length ? `Você tem <b style="color:var(--gd)">${pend.length} ${pend.length == 1 ? 'item' : 'itens'}</b> para resolver.` : 'Tudo em dia na operação.'}${n ? ` Próximo encontro: ${DL(n.date)}, às ${n.hora}.` : ''}</p></div>
<div class="ov-act"><button class="btn" onclick="novaAula()">${ic('plus')}Nova aula</button><button class="btn s" onclick="taskForm()">${ic('check')}Nova tarefa</button><button class="btn s" onclick="novoAluno()">${ic('user')}Cadastrar aluno</button></div></section>
<div class="g4 ov-k">
${kpi('users', 'Alunos ativos', `${at.length}<span class="ks"> de ${alunosCtx().length}</span>`, `${alunosCtx().filter(a => a.status == 'pendente').length} aguardando liberação`)}
${kpi('cal', 'Encontros realizados', `${re.length}<span class="ks"> de ${L.length}</span>`, L.length ? '' : 'nenhuma aula cadastrada', L.length ? bar(pct(re.length, L.length)) : '')}
${kpi('roll', 'Frequência média', mediaPct(presPct) + '%', baixa.length ? baixa.length + ' abaixo do mínimo' : 'todos acima do mínimo', bar(mediaPct(presPct)))}
${kpi('check', 'Entrega de tarefas', mediaPct(entPct) + '%', 'nota média ' + f1(avg(med)), bar(mediaPct(entPct)))}</div>
<div class="ov-g"><div class="stack">
<div class="card ${pend.some(p => p[0] == 'er') ? 'alert' : ''}"><div class="ch"><h3>Precisa da sua atenção</h3>${tag(pend.length ? pend.length + (pend.length == 1 ? ' item' : ' itens') : 'Em dia', pend.length ? 'wn' : 'ok')}</div>${pend.map(p => `<div class="li"><span class="ico ${p[0] == 'wn' ? 'gd' : p[0]}">${ic(p[1])}</span><div class="grow"><b>${E(p[2])}</b><span class="sm-t">${E(p[3])}</span></div><button class="btn ${p[0] == 'er' ? '' : 's'} sm" onclick="${p[4]}">${p[5]}</button></div>`).join('') || `<p class="mu" style="margin:0">Nenhuma pendência. Bom trabalho.</p>`}</div>
<div class="card"><div class="ch"><h3>Próximos encontros</h3><button class="btn q sm" onclick="nav('aulas')">Abrir calendário</button></div>${prox.map(a => `<div class="li"><div class="dbox gd"><b>${D(a.date).getDate()}</b><small>${MES[D(a.date).getMonth()]}</small></div><div class="grow"><b>${E(a.nome)}</b><span class="sm-t">${DOW[D(a.date).getDay()]}, ${a.hora}${a.comp ? ' · ' + E(a.comp) : ''}</span><div class="row" style="gap:6px;margin-top:6px">${tchips(a.turmas, false)}</div></div><button class="btn s sm" onclick="aulaMenu(${a.n})">Abrir</button></div>`).join('') || `<div class="ov-e"><p class="mu" style="margin:0">Nenhuma aula agendada. Adicione as aulas e escolha a turma de cada uma.</p><button class="btn sm" onclick="novaAula()">${ic('plus')}Adicionar aula</button></div>`}</div>
</div><div class="stack">
<div class="card"><div class="ch"><h3>Turmas</h3><button class="btn q sm" onclick="nav('turmas')">Gerenciar</button></div>${S.turmas.map(t => {
    const al = S.alunos.filter(a => a.turma == t.id && a.status != 'removido').length, T = aulasDe(t.id).length, r = realizadas(t.id).length;
    return `<button class="ov-t ${ctx() == t.id ? 'on' : ''}" style="--c:${E(t.cor)}" onclick="setCtx(${ctx() == t.id ? 0 : t.id})" title="Filtrar o painel por esta turma"><i></i><span class="grow"><b>${E(tnome(t))}</b><span class="sm-t">${al} aluno(s) · ${T ? r + ' de ' + T + ' encontros' : 'sem aulas'}</span>${T ? bar(pct(r, T)) : ''}</span>${ttag(t)}</button>`;
  }).join('') || `<p class="mu" style="margin:0">Nenhuma turma cadastrada.</p>`}</div>
<div class="card"><div class="ch"><h3>Engajamento</h3><button class="btn q sm" onclick="nav('relatorios')">Relatório</button></div>${[...at].sort((a, b) => engaj(b.id) - engaj(a.id)).slice(0, 5).map((a, i) => `<button class="ov-r" onclick="nav('alunoD',${a.id})"><span class="rk">${i + 1}</span><span class="grow"><span class="row sp" style="font-size:13px;margin-bottom:5px;flex-wrap:nowrap"><span>${E(a.nome)}</span><b>${engaj(a.id)}%</b></span>${bar(engaj(a.id))}</span></button>`).join('') || `<p class="mu" style="margin:0">Sem alunos ativos nesta seleção.</p>`}</div>
<div class="card"><div class="ch"><h3>Atividade recente</h3><button class="btn q sm" onclick="nav('config')">Histórico</button></div>${S.log.slice(0, 5).map(l => `<div class="ov-l"><b>${E(l.m)}</b><span class="sm-t">${E(l.who)} · ${E(l.at)}</span></div>`).join('') || `<p class="mu" style="margin:0">Nada registrado ainda.</p>`}</div>
</div></div>`;
}
