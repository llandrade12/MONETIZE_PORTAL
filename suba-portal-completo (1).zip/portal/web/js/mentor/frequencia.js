/**
 * mentor/frequencia.js
 * Página do admin: Frequência. Chamada rápida, justificativas para aprovar e o mapa aluno x encontro
 * com percentual, faltas que ainda cabem e situação em relação ao mínimo do certificado.
 */
'use strict';

function A_freq() {
  const jp = justPend(), T = S.turmas.filter(t => !ctx() || t.id == ctx());
  /* Encontros pedindo chamada: os de hoje e os que passaram sem registro. */
  const cham = aulasCtx().filter(a => a.status == 'agendada' && a.date <= hoje());
  const feitas = aulasCtx().filter(aulaLib).slice(-3).reverse();
  return `<div class="toolbar">${tfilter()}<span style="flex:1"></span><button class="btn s" onclick="nav('config')">${ic('gear')}Regras de frequência</button></div>
<div class="main2"><div class="card ${cham.length ? 'gold' : ''}"><div class="ch"><h3>Fazer chamada</h3>${cham.length ? tag(cham.length + ' aguardando', 'wn') : tag('Em dia', 'ok')}</div>
${cham.map(a => `<div class="li"><div class="dbox gd"><b>${D(a.date).getDate()}</b><small>${MES[D(a.date).getMonth()]}</small></div><div class="grow"><b>${E(a.nome)}</b><span class="sm-t">${a.date == hoje() ? 'Hoje' : DL(a.date)}, ${a.hora} · ${alvoDe(a).length} aluno(s)</span><div class="row" style="gap:6px;margin-top:6px">${tchips(a.turmas)}</div></div><button class="btn sm" onclick="chamada(${a.n})">${ic('roll')}Chamada</button></div>`).join('') || `<p class="mu" style="margin:0">Nenhum encontro esperando chamada.</p>`}
${feitas.length ? `<p class="sm-t" style="margin:14px 0 4px">Últimas chamadas (toque para corrigir)</p>${feitas.map(a => `<button class="fq-last" onclick="chamada(${a.n})"><span class="grow"><b>${E(a.nome)}</b><span class="sm-t">${DF(a.date)}</span></span><span class="sm-t">${alvoDe(a).filter(x => presOk(x.id, a.n)).length}/${alvoDe(a).length} presentes</span>${ic('edit')}</button>`).join('')}` : ''}</div>
<div class="card ${jp.length ? 'alert' : ''}"><div class="ch"><h3>Justificativas de falta</h3>${jp.length ? tag(jp.length + ' para avaliar', 'er') : tag('Nenhuma pendente', 'ok')}</div>
${jp.map(j => `<div class="li">${avatar(aluno(j.aid))}<div class="grow"><b>${E(nm(j.aid))}</b><span class="sm-t">${E((aulaN(j.n) || {}).nome || 'Aula')} · ${E(j.motivo)}</span></div><button class="btn sm" onclick="justAval('${j.id}')">Avaliar</button></div>`).join('') || `<p class="mu" style="margin:0">Quando um aluno justificar uma falta pelo portal, o pedido aparece aqui para você aprovar ou recusar.</p>`}</div></div>
${T.map(t => freqTurma(t)).join('') || empty('Nenhuma turma', 'Cadastre uma turma para acompanhar a frequência.')}
<div class="legend fq-lg">${['P', 'A', 'J', 'C', 'F'].map(k => `<span><i class="fqd k-${k}">${k}</i>${PST[k][0]}</span>`).join('')}<span><i class="fqd k-x">·</i>Antes da matrícula</span></div>`;
}

function freqTurma(t) {
  const al = S.alunos.filter(a => a.turma == t.id && a.status == 'ativo'), L = realizadas(t.id), min = freqMin(t.id);
  if (!al.length)
    return '';
  const rows = al.map(a => [a, freq(a.id)]).sort((x, y) => x[1].pct - y[1].pct), risco = rows.filter(r => r[1].abaixo).length;
  return `<div class="card sec fq-t" style="margin-top:16px;--c:${E(t.cor)}"><div class="ch"><div class="row" style="gap:10px">${tchip(t)}<span class="sm-t">mínimo de ${min}% · ${L.length} encontro(s) realizado(s)</span></div>${risco ? tag(risco + ' abaixo do mínimo', 'er') : L.length ? tag('Todos acima do mínimo', 'ok') : ''}</div>
${L.length ? `<div class="fq-w"><table class="fq-m"><thead><tr><th>Aluno</th>${L.map((a, i) => `<th><button title="${E(a.nome)} · ${DF(a.date)} · abrir chamada" onclick="chamada(${a.n})"><b>${i + 1}</b><small>${DF(a.date)}</small></button></th>`).join('')}<th>Frequência</th><th class="hide-m">Faltas que cabem</th><th></th></tr></thead><tbody>
${rows.map(([a, f]) => `<tr class="${f.abaixo ? 'bad' : ''}"><td><button class="fq-n" onclick="nav('alunoD',${a.id})">${avatar(a)}<span>${E(a.nome)}</span></button></td>${L.map(x => {
    const s = f.B.includes(x) ? freqSt(a.id, x) : 'x', o = S.presObs[a.id + '-' + x.n];
    return `<td><i class="fqd k-${s}" title="${s == 'x' ? 'Antes da matrícula' : PST[s][0]}${o ? ': ' + E(o) : ''}">${s == 'x' ? '·' : s}</i></td>`;
  }).join('')}<td><div class="fq-p"><b class="${f.abaixo ? 'er' : ''}">${f.n ? f.pct + '%' : '—'}</b><span class="sm-t">${f.ok}/${f.n}</span></div></td><td class="hide-m">${f.n ? Math.max(0, f.restam) + ' de ' + f.maxF : '—'}</td><td style="text-align:right">${f.abaixo ? `<button class="btn s sm" onclick="notifFreq(${a.id})">${ic('bell')}Avisar</button>` : ''}</td></tr>`).join('')}</tbody></table></div>` : `<p class="mu" style="margin:0">Nenhum encontro realizado nesta turma ainda. A frequência começa a contar na primeira chamada.</p>`}</div>`;
}

function notifFreq(aid) {
  const f = freq(aid);
  notify('Sua frequência precisa de atenção', 'e-mail + whatsapp', 'Você está com ' + f.pct + '% de frequência e o mínimo para o certificado é ' + f.min + '%.' + (S.cfg.compensa ? ' Assista às gravações dos encontros que perdeu para compensar.' : ''), aid, 'frequencia');
  keep();
  done(nm(aid).split(' ')[0] + ' avisado sobre a frequência', 'Avisou ' + nm(aid) + ' sobre a frequência');
}
