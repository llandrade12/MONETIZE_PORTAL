/**
 * mentor/_helpers.js
 * Utilitários visuais usados só pelo painel administrativo.
 */
'use strict';

const stTag = s => ({
  ativo: ['Ativo', 'ok'], pendente: ['Pendente', 'wn'], bloqueado: ['Bloqueado', 'er'], removido: ['Removido', 'er']
}[s] || [s, '']);

const aTag = a => ({
  agendada: semRegistro().includes(a) ? ['Sem registro', 'er'] : ['Agendada', 'in'], realizada: ['Realizada', 'ok'], parcial: ['Parcial', 'wn'], cancelada: ['Cancelada', 'er']
}[a.status]);

const who = a => `<div class="who">${avatar(a)}<div><b>${E(a.nome)}</b><small>${E(a.email)}</small></div></div>`;

/* O aluno pertence à turma em contexto? */
const inCtx = aid => !ctx() || (aluno(aid) || {}).turma == ctx();

const ttag = t => tag(t.status, t.status == 'Ativa' ? 'ok' : t.status == 'Concluída' ? 'in' : 'wn');
