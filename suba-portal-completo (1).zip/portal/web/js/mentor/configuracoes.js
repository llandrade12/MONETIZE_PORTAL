/**
 * mentor/configuracoes.js
 * Página do admin: configurações.
 */
'use strict';

function A_config() {
  if (!ST.mentores && !ST.mentoresPed) {
    ST.mentoresPed = true;
    mentoresCarregar();
  }
  return `<div class="main2"><div class="stack"><div class="card"><div class="ch"><h3>Histórico de ações</h3><span class="sm-t">Registro permanente para auditoria</span></div>${S.log.slice(0, 40).map(l => `<div class="li"><span class="ico">${ic('clock')}</span><div class="grow"><b style="font-weight:600">${E(l.m)}</b><span class="sm-t">${E(l.who)}, ${E(l.at)}</span></div></div>`).join('') || '<p class="mu" style="margin:0">Nada registrado ainda.</p>'}</div></div>
<div class="stack"><div class="card"><h3>Mentor responsável</h3><p class="mu">Nome que aparece no painel, nos avisos e na assinatura do certificado.</p>${F('Nome', `<input id="mnm" value="${E(S.mentor)}">`)}<button class="btn sm" onclick="nomeMentor()">Salvar nome</button></div>
<div class="card"><div class="ch"><h3>Acessos ao painel</h3><button class="btn s sm" onclick="mentorNovo()">${ic('plus')}Novo acesso</button></div><p class="mu" style="margin:0 0 6px">Quem entra no painel do mentor. Não existe tela de cadastro: só quem está nesta lista tem acesso.</p>
${ST.mentores ? ST.mentores.map(m => `<div class="li"><div class="av">${ini(m.nome)}</div><div class="grow"><b>${E(m.nome)}${m.id == U.mid ? ' <span class="sm-t">(você)</span>' : ''}</b><span class="sm-t">${E(m.email)}${m.ultimo ? ' · último acesso em ' + E(m.ultimo) : ' · ainda não entrou'}</span></div>${m.id == U.mid ? `<button class="btn s sm" onclick="senha()">${ic('lock')}Alterar minha senha</button>` : `<button class="btn q sm" onclick="mentorSenha(${m.id})">Nova senha</button><button class="btn q sm" aria-label="Remover o acesso de ${E(m.nome)}" onclick="mentorRemover(${m.id})">${ic('trash')}</button>`}</div>`).join('') : '<p class="mu" style="margin:0">Carregando…</p>'}</div>
<div class="card"><h3>Regras de frequência</h3><p class="mu">Valem para todas as turmas. Uma turma pode ter o seu próprio mínimo (em Turmas, editar).</p>
<div class="g2">${F('Frequência mínima (%)', `<input id="cf1" type="number" min="0" max="100" value="${S.cfg.freqMin}">`)}${F('Aula assistida a partir de (%)', `<input id="cf2" type="number" min="50" max="100" value="${S.cfg.pctVisto}">`, 'Quanto do vídeo marca como assistida.')}</div>
<label class="sw"><span class="grow"><b>Certificado depende da frequência mínima</b><small>Abaixo do mínimo, o aluno não recebe o certificado (você pode liberar por exceção).</small></span><input type="checkbox" id="cf3" ${S.cfg.certFreq ? 'checked' : ''}><i></i></label>
<label class="sw"><span class="grow"><b>Gravação assistida compensa a falta</b><small>Quem faltou e assistiu à gravação até o fim fica como "Compensada".</small></span><input type="checkbox" id="cf4" ${S.cfg.compensa ? 'checked' : ''}><i></i></label>
<label class="sw"><span class="grow"><b>Falta justificada não reduz a frequência</b><small>Desligado, a falta justificada fica registrada com o motivo, mas conta como falta.</small></span><input type="checkbox" id="cf5" ${S.cfg.justAbona ? 'checked' : ''}><i></i></label>
<p class="sm-t" style="margin:10px 0 12px">A frequência de cada aluno conta só os encontros realizados desde a matrícula dele.</p>
<button class="btn sm" onclick="freqCfg()">Salvar regras</button></div>
<div class="card"><h3>Integrações</h3><div class="li"><div class="grow"><b>Pagamento e matrícula</b><span class="sm-t">Hotmart, Eduzz ou Kiwify</span></div>${tag('Externo', '')}</div>
<div class="li"><div class="grow"><b>Dados e arquivos</b><span class="sm-t">Guardados no servidor do portal. Cada pessoa acessa de qualquer aparelho.</span></div>${tag('Servidor', 'ok')}</div>
<div class="li"><div class="grow"><b>Gravações</b><span class="sm-t">YouTube não listado, Vimeo, Google Drive ou arquivo MP4, dentro da página da aula</span></div>${tag('Ativo', 'ok')}</div>
<div class="li"><div class="grow"><b>E-mail</b><span class="sm-t">${API.srv.email ? 'Os avisos e o "Esqueci minha senha" saem pelo e-mail configurado no servidor.' : 'O envio de e-mails ainda não foi configurado no servidor (veja o tutorial de instalação).'}</span></div>${API.srv.email ? `<button class="btn q sm" onclick="emailTeste()">Enviar teste</button>` : tag('Não configurado', 'wn')}</div>
<div class="li"><div class="grow"><b>WhatsApp</b><span class="sm-t">${S.cfg.webhook ? 'Envio automático pelo seu serviço de automação' : 'Mensagem pronta para enviar com um clique. Conecte um serviço para sair sozinho.'}</span></div><button class="btn q sm" onclick="ST.comunicacao='auto';nav('comunicacao')">${S.cfg.webhook ? tag('Conectado', 'ok') : tag('Configurar', 'wn')}</button></div>
<div class="li"><div class="grow"><b>Notificações no celular</b><span class="sm-t">Com o aplicativo instalado, os avisos chegam na tela do aparelho (push).</span></div>${tag('Ativo', 'ok')}</div>
<div class="li"><div class="grow"><b>Agenda</b><span class="sm-t">Assinatura no Google Agenda, iPhone e Outlook, e arquivo .ics de cada encontro</span></div><button class="btn q sm" onclick="assinarAgenda()">Assinar</button></div></div>
<div class="card"><h3>Cópia dos dados</h3><p class="mu">Baixe um arquivo com turmas, alunos, aulas, tarefas, notas e frequência, para guardar ou levar para outra instalação do portal.</p><div class="row"><button class="btn s sm" onclick="bkpBaixar()">${ic('download')}Baixar cópia dos dados</button><label class="btn s sm" style="position:relative;overflow:hidden">${ic('upload')}Restaurar de uma cópia<input type="file" accept=".json,application/json" style="position:absolute;inset:0;opacity:0;cursor:pointer" onchange="bkpLer(this.files[0]);this.value=''"></label></div><p class="sm-t" style="margin:10px 0 0">A cópia não leva os arquivos anexados nem as anotações que os alunos mantêm privadas. A cópia completa do sistema é o backup do banco de dados, feito no servidor (veja o tutorial de instalação).</p></div>
<div class="card"><h3>Zerar o portal</h3><p class="mu">Apaga turmas, alunos, aulas, tarefas, notas e arquivos. Os acessos ao painel continuam. Baixe uma cópia antes.</p><button class="btn d sm" onclick="zerar()">${ic('trash')}Apagar todos os dados</button></div></div></div>`;
}

function freqCfg() {
  const c = S.cfg;
  c.freqMin = Math.max(0, Math.min(100, parseInt(val('cf1')) || 0));
  c.pctVisto = Math.max(50, Math.min(100, parseInt(val('cf2')) || 90));
  c.certFreq = $('#cf3').checked;
  c.compensa = $('#cf4').checked;
  c.justAbona = $('#cf5').checked;
  autoRun(true);
  keep();
  done('Regras de frequência salvas', 'Alterou as regras de frequência (mínimo ' + c.freqMin + '%)');
}

function nomeMentor() {
  if (!val('mnm'))
    return toast('Informe o nome');
  S.mentores = S.mentores.filter(m => m != S.mentor);
  S.mentor = val('mnm');
  S.mentores.unshift(S.mentor);
  done('Nome do mentor atualizado');
}

/* ---------- Acessos ao painel (contas de mentor) ---------- */

async function mentoresCarregar() {
  try {
    ST.mentores = (await chamar('GET', '/api/mentores')).mentores;
  }
  catch (e) {
    ST.mentores = [];
    toast(e.msg);
  }
  ST.mentoresPed = false;
  if (R.p == 'config' && !ocupado()) {
    keep();
    render();
  }
}

function mentorNovo() {
  modal('Novo acesso ao painel', F('Nome', '<input id="mn1" autocomplete="off">') + F('E-mail de login', '<input id="mn2" type="email" autocomplete="off">') + senhaCampo('Senha', 'Repasse a senha à pessoa. Ela pode trocar depois, em Configurações.'), { label: 'Criar acesso', ok: () => {
      mentorCriar();
      return false;
    } });
  $('#nsn').value = senhaNova();
}

async function mentorCriar() {
  const d = { nome: val('mn1'), email: val('mn2'), senha: $('#nsn').value.trim() };
  if (d.nome.length < 3 || !/\S+@\S+\.\S+/.test(d.email))
    return toast('Informe nome e e-mail');
  if (!senhaForte(d.senha))
    return toast('Senha: 8+ caracteres, com letras e números');
  try {
    await chamar('POST', '/api/mentores', d);
  }
  catch (e) {
    return toast(e.msg);
  }
  closeM();
  logA('Criou o acesso de mentor de ' + d.nome);
  save();
  await mentoresCarregar();
  modal('Acesso criado', `<p class="mu" style="margin:0 0 12px">Repasse estes dados. <b>A senha só aparece agora.</b></p><div class="card flat" style="padding:14px"><dl class="meta"><dt>E-mail</dt><dd>${E(d.email)}</dd><dt>Senha</dt><dd style="font:600 17px ui-monospace,Menlo,Consolas,monospace;letter-spacing:.04em">${E(d.senha)}</dd></dl></div>`, { cancel: 'Concluir', sub: E(d.nome) });
}

function mentorSenha(id) {
  const m = ST.mentores.find(x => x.id == id);
  modal('Nova senha para ' + E(m.nome.split(' ')[0]), senhaCampo('Nova senha', 'A senha atual deixa de valer e a pessoa é desconectada.'), { sub: E(m.email), label: 'Definir nova senha', ok: () => {
      const sn = $('#nsn').value.trim();
      if (!senhaForte(sn)) {
        toast('Senha: 8+ caracteres, com letras e números');
        return false;
      }
      chamar('POST', '/api/mentores/senha', { id, senha: sn }).then(() => {
        closeM();
        logA('Redefiniu a senha do mentor ' + m.nome);
        save();
        modal('Nova senha definida', `<div class="card flat" style="padding:14px"><dl class="meta"><dt>E-mail</dt><dd>${E(m.email)}</dd><dt>Senha</dt><dd style="font:600 17px ui-monospace,Menlo,Consolas,monospace;letter-spacing:.04em">${E(sn)}</dd></dl></div>`, { cancel: 'Concluir', sub: E(m.nome) });
      }, e => toast(e.msg));
      return false;
    } });
  $('#nsn').value = senhaNova();
}

function mentorRemover(id) {
  const m = ST.mentores.find(x => x.id == id);
  modal('Remover acesso', `<p><b>${E(m.nome)}</b> (${E(m.email)}) deixa de entrar no painel na hora.</p>`, { label: 'Remover acesso', danger: true, ok: () => {
      chamar('POST', '/api/mentores/remover', { id }).then(() => {
        closeM();
        logA('Removeu o acesso de mentor de ' + m.nome);
        save();
        mentoresCarregar();
        toast('Acesso removido');
      }, e => toast(e.msg));
      return false;
    } });
}

async function emailTeste() {
  toast('Enviando o e-mail de teste…');
  try {
    const r = await chamar('POST', '/api/admin/teste-email', { para: S.cfg.mentorEmail || U.email });
    modal(r.ok ? 'E-mail de teste enviado' : 'O e-mail não saiu', r.ok ? `<p>Enviado para <b>${E(r.para)}</b>. Se não chegar em alguns minutos, veja a caixa de spam.</p>` : `<p>O servidor de e-mail respondeu:</p><div class="card flat" style="padding:12px 14px;font:500 13px ui-monospace,Menlo,Consolas,monospace;word-break:break-word">${E(r.erro)}</div><p class="mu" style="margin:12px 0 0">Confira os dados de e-mail (SMTP) na configuração do servidor.</p>`, { cancel: 'Fechar' });
  }
  catch (e) {
    toast(e.msg);
  }
}

/* ---------- Zerar e cópia dos dados (operações feitas no servidor, com a senha de quem pediu) ---------- */

function zerar() {
  modal('Apagar todos os dados', `<p>Turmas, alunos, aulas, tarefas, notas e arquivos enviados são apagados do servidor, para todos. Os acessos ao painel continuam valendo. <b>Não dá para desfazer.</b></p>` + F('Para confirmar, digite ZERAR', '<input id="zz" autocomplete="off">') + F('Sua senha', '<input id="zs" type="password" autocomplete="current-password">'), { label: 'Apagar tudo', danger: true, ok: () => {
      if (val('zz').toUpperCase() != 'ZERAR') {
        toast('Digite ZERAR para confirmar');
        return false;
      }
      const b = $('#mok');
      b.disabled = true;
      salvarAgora().then(() => chamar('POST', '/api/admin/zerar', { senha: $('#zs').value })).then(async () => {
        await carregarEstado();
        definirUsuario();
        closeM();
        nav('visao');
        toast('O portal foi zerado');
      }, e => {
        b.disabled = false;
        toast(e.msg);
      });
      return false;
    } });
}

async function bkpBaixar() {
  await salvarAgora();
  try {
    const r = await fetch('api/admin/copia', { credentials: 'same-origin', cache: 'no-store' });
    if (!r.ok)
      throw 0;
    baixar('portal-dados-' + hoje() + '.json', await r.blob());
    logA('Baixou a cópia dos dados');
    save();
    toast('Cópia dos dados baixada');
  }
  catch (e) {
    toast('Não foi possível baixar a cópia agora');
  }
}

function bkpLer(file) {
  if (!file)
    return;
  const r = new FileReader();
  r.onload = () => {
    let o;
    try {
      o = JSON.parse(r.result);
    }
    catch (e) {
      o = null;
    }
    if (!o || !Array.isArray(o.alunos) || !Array.isArray(o.turmas) || !Array.isArray(o.aulas) || (o.v !== 5 && o.v !== 6))
      return toast('Este arquivo não é uma cópia dos dados do portal');
    modal('Restaurar cópia dos dados', `<p>A cópia tem <b>${o.turmas.length} turma(s)</b>, <b>${o.alunos.length} aluno(s)</b> e <b>${o.aulas.length} aula(s)</b>.</p><p class="mu">Ela <b>substitui tudo</b> o que está no portal agora, para todos os alunos. O que não está na cópia (inclusive as anotações privadas dos alunos) é apagado. Se quiser guardar o que está aqui, baixe uma cópia antes.</p>` + F('Para confirmar, digite RESTAURAR', '<input id="rz" autocomplete="off">') + F('Sua senha', '<input id="rs2" type="password" autocomplete="current-password">'), { label: 'Substituir pelos dados da cópia', danger: true, ok: () => {
        if (val('rz').toUpperCase() != 'RESTAURAR') {
          toast('Digite RESTAURAR para confirmar');
          return false;
        }
        const b = $('#mok');
        b.disabled = true;
        b.textContent = 'Restaurando…';
        chamar('POST', '/api/admin/restaurar', { senha: $('#rs2').value, copia: o }).then(async res => {
          await carregarEstado();
          definirUsuario();
          closeM();
          nav('visao');
          toast('Dados restaurados: ' + res.alunos + ' aluno(s)' + (res.avisos.length ? '. ' + res.avisos.length + ' aviso(s): ' + res.avisos[0] : ''));
        }, e => {
          b.disabled = false;
          b.textContent = 'Substituir pelos dados da cópia';
          toast(e.msg);
        });
        return false;
      } });
  };
  r.readAsText(file);
}
