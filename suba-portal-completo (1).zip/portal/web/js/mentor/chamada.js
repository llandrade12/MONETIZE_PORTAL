/**
 * mentor/chamada.js
 * Chamada: lista de alunos com um toque por aluno e quatro estados
 * (Presente, Atrasado, Falta, Falta justificada com motivo), mais o atalho "Marcar todos presentes".
 * Usada na página Frequência, no cronograma e no registro da sessão.
 */
'use strict';

/* Chamada em edição: { [id do aluno]: { s: 'P'|'A'|'F'|'J'|'', m: motivo } } */
let CH = {};

function chInit(a) {
  CH = {};
  alvoDe(a).forEach(x => CH[x.id] = { s: pst(x.id, a.n), m: S.presObs[x.id + '-' + a.n] || '' });
}

const chCount = () => {
  const v = Object.values(CH), c = k => v.filter(x => x.s == k).length;
  return `<b>${c('P')}</b> presentes · <b>${c('A')}</b> atrasados · <b>${c('F')}</b> faltas · <b>${c('J')}</b> justificadas${c('') ? ` · <b class="er">${c('')}</b> sem marcar` : ''}`;
};

/* Lista da chamada (o HTML entra em um modal). */
function chBlock(a) {
  const al = alvoDe(a);
  return `<div class="chh"><span class="sm-t" id="chc">${chCount()}</span><button type="button" class="btn s sm" onclick="chAll()">${ic('ok')}Marcar todos presentes</button></div>
<div class="chl">${al.map(x => {
    const tarde = x.mat && x.mat > a.date;
    return `<div class="chr" id="chr-${x.id}">${avatar(x)}<div class="chn"><b>${E(x.nome)}</b>${tarde ? '<small>matriculado depois desta aula (não conta na frequência)</small>' : a.turmas.length > 1 ? `<small>${E(tnome(turmaDe(x.id)))}</small>` : ''}</div>
<div class="chs" role="radiogroup" aria-label="Presença de ${E(x.nome)}">${['P', 'A', 'F', 'J'].map(k => `<button type="button" role="radio" aria-checked="${CH[x.id].s == k}" class="k-${k} ${CH[x.id].s == k ? 'on' : ''}" title="${PST[k][0]}" onclick="chSet(${x.id},'${k}')">${PST[k][2]}</button>`).join('')}</div>
<input class="chm" id="chm-${x.id}" placeholder="Motivo da falta justificada" value="${E(CH[x.id].m)}" ${CH[x.id].s == 'J' ? '' : 'hidden'} oninput="CH[${x.id}].m=this.value"></div>`;
  }).join('') || '<p class="mu" style="margin:8px 0">Nenhum aluno ativo nas turmas desta aula.</p>'}</div>`;
}

/* Um toque: marca o estado. Tocar de novo no mesmo estado desmarca. */
function chSet(aid, k) {
  const c = CH[aid];
  c.s = c.s == k ? '' : k;
  const r = document.getElementById('chr-' + aid);
  r.querySelectorAll('.chs button').forEach(b => {
    const on = b.classList.contains('k-' + c.s);
    b.classList.toggle('on', on);
    b.setAttribute('aria-checked', on);
  });
  const m = document.getElementById('chm-' + aid);
  m.hidden = c.s != 'J';
  if (c.s == 'J')
    m.focus();
  document.getElementById('chc').innerHTML = chCount();
}

function chAll() {
  Object.keys(CH).forEach(id => {
    if (CH[id].s != 'P')
      chSet(+id, 'P');
  });
  toast('Todos marcados como presentes. Ajuste só as exceções.');
}

/* Valida e grava a chamada. Devolve false se faltar algo. */
function chSave(a) {
  const ids = Object.keys(CH);
  if (ids.some(id => !CH[id].s)) {
    toast('Marque a presença de todos (ou use "Marcar todos presentes")');
    return false;
  }
  const semMotivo = ids.find(id => CH[id].s == 'J' && CH[id].m.trim().length < 3);
  if (semMotivo) {
    toast('Informe o motivo da falta justificada de ' + nm(+semMotivo).split(' ')[0]);
    document.getElementById('chm-' + semMotivo)?.focus();
    return false;
  }
  const novas = [];
  ids.forEach(id => {
    const k = id + '-' + a.n, antes = S.pres[k];
    S.pres[k] = CH[id].s;
    if (CH[id].s == 'J')
      S.presObs[k] = CH[id].m.trim();
    else
      delete S.presObs[k];
    if (CH[id].s == 'F' && antes != 'F')
      novas.push(+id);
    /* Uma justificativa pendente do aluno deixa de fazer sentido se o mentor já resolveu na chamada. */
    if (CH[id].s != 'F')
      S.just.filter(j => j.aid == id && j.n == a.n && j.st == 'pendente').forEach(j => {
        j.st = CH[id].s == 'J' ? 'aprovada' : 'encerrada';
        j.respAt = stamp();
      });
  });
  if (novas.length)
    notify('Falta registrada', 'e-mail + whatsapp', 'Registramos sua falta em "' + a.nome + '" (' + DF(a.date) + ').' + (S.cfg.compensa ? ' Assista à gravação até o fim para compensar,' : ' Se houve um imprevisto,') + ' ou justifique em Minha frequência.', novas, 'frequencia');
  return true;
}

/* Modal só da chamada (o caminho mais curto: abrir, tocar, salvar). */
function chamada(n) {
  const a = aulaN(n);
  if (!a)
    return;
  chInit(a);
  const fut = a.status == 'agendada' && a.date > hoje();
  modal('Chamada', (fut ? `<div class="card flat" style="margin-bottom:12px;padding:10px 14px"><span class="sm-t">Esta aula está marcada para ${DL(a.date)}. Ao salvar a chamada ela passa a constar como realizada.</span></div>` : '') + chBlock(a), { wide: true, sub: E(a.nome) + ' · ' + DL(a.date) + ', ' + a.hora, label: 'Salvar chamada', ok: () => {
      if (!chSave(a))
        return false;
      if (a.status == 'agendada') {
        a.status = 'realizada';
        a.hist.unshift({ at: stamp(), m: 'Sessão registrada como realizada (pela chamada)' });
      }
      a.hist.unshift({ at: stamp(), m: 'Chamada registrada' });
      autoRun(true);
      keep();
      done('Chamada salva: ' + a.nome);
    } });
}

/* ---------- Justificativa de falta: o mentor aprova ou recusa ---------- */

/* Mentor aprova ou recusa. */
function justAval(jid) {
  const j = S.just.find(x => x.id == jid), a = aulaN(j.n) || { nome: 'Aula excluída', date: hoje() };
  modal('Justificativa de falta', `<div class="card flat"><span class="sm-t">${E(nm(j.aid))} · enviada em ${E(j.at)}</span><p style="margin:6px 0 0;white-space:pre-line">${E(j.motivo)}</p></div><div style="height:14px"></div>` + F('Resposta para o aluno (obrigatória para recusar)', `<textarea id="jr" rows="2"></textarea>`) + `<p class="sm-t" style="margin:0">Aprovada, a falta vira "Falta justificada"${S.cfg.justAbona ? ' e deixa de reduzir a frequência' : ' (continua contando como falta, conforme a regra em Configurações)'}.</p>`, { sub: E(a.nome) + ' · ' + DL(a.date), label: 'Aprovar justificativa', cancel: '', ok: () => justFim(jid, true) });
  $('.mf').insertAdjacentHTML('afterbegin', `<button class="btn s" onclick="if(justFim('${jid}',false)!==false)closeM()">Recusar</button><span style="flex:1"></span>`);
}

function justFim(jid, ok) {
  const j = S.just.find(x => x.id == jid), r = val('jr'), a = aulaN(j.n);
  if (!ok && r.length < 3) {
    toast('Escreva o motivo da recusa');
    return false;
  }
  j.st = ok ? 'aprovada' : 'recusada';
  j.resp = r;
  j.respAt = stamp();
  if (ok && a) {
    S.pres[j.aid + '-' + j.n] = 'J';
    S.presObs[j.aid + '-' + j.n] = j.motivo;
  }
  notify(ok ? 'Justificativa aprovada' : 'Justificativa recusada', 'e-mail + whatsapp', (a ? '"' + a.nome + '": ' : '') + (ok ? 'sua falta foi justificada.' : 'a falta foi mantida.') + (r ? ' Mentor: ' + r : ''), j.aid, 'frequencia');
  keep();
  done(ok ? 'Justificativa aprovada' : 'Justificativa recusada', (ok ? 'Aprovou' : 'Recusou') + ' a justificativa de ' + nm(j.aid));
}
