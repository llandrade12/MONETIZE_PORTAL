/**
 * mentor/aluno-ficha.js
 * Página do admin: aluno ficha.
 */
'use strict';

function A_aluno() {
  const id = R.a, a = aluno(id), t = sub('alunoD', 'resumo'), f = fin(id), fq = freq(id), dsh = S.diario.filter(d => d.aid == id && d.share), lg = S.lgpd.find(x => x.aid == id && x.st == 'pendente');
  const head = `<div class="card"><div class="row sp" style="gap:16px"><div class="row" style="gap:16px">${avatar(a, 'big')}<div><h2>${E(a.nome)}</h2><p class="mu" style="margin:2px 0 6px">${E(a.cargo)}, ${age(a.nasc)} anos, ${E(a.civil).toLowerCase()}, ${E(a.formacao)}</p>${tchip(turmaDe(id))} ${tag(...stTag(a.status))}${a.motivo ? ` <span class="sm-t">${E(a.motivo)}</span>` : ''}</div></div>
<div class="row"><button class="btn sm" onclick="notifCustom(${id})">${ic('bell')}Notificar</button><button class="btn s sm" onclick="editAluno(${id})">${ic('edit')}Editar</button>${a.status == 'pendente' || a.status == 'bloqueado' ? `<button class="btn sm" onclick="togA(${id})">Liberar acesso</button>` : a.status == 'ativo' ? `<button class="btn s sm" onclick="reenviarAcesso(${id})">Redefinir senha</button><button class="btn s sm" onclick="togA(${id})">Bloquear</button>` : ''}${a.status != 'removido' ? `<button class="btn d sm" onclick="remov(${id})">Remover</button>` : ''}</div></div></div>
<div class="g4" style="margin-top:14px"><div class="kpi"><span class="lb">Nota final</span><span class="num gold">${f1(f)}</span></div><div class="kpi"><span class="lb">Frequência</span><span class="num ${fq.abaixo ? 'er' : ''}">${fq.n ? fq.pct + '%' : '—'}</span><small>${fq.ok} de ${fq.n} · mínimo ${fq.min}%</small></div><div class="kpi"><span class="lb">Entregas</span><span class="num">${entPct(id)}%</span></div><div class="kpi"><span class="lb">Engajamento</span><span class="num">${engaj(id)}%</span></div></div><div style="height:20px"></div>`;
  const tb = tabs('alunoD', [['resumo', 'Resumo'], ['freq', 'Frequência e aulas'], ['tarefas', 'Tarefas e notas'], ['diario', 'Anotações do aluno', dsh.filter(d => !d.resp).length || ''], ['roda', 'Roda da Vida'], ['rotina', 'Rotina'], ['aval', 'Avaliação semanal'], ['notas', 'Anotações privadas'], ['dados', 'Dados e acesso']]);
  let body;
  if (t == 'freq')
    body = `<div class="main2"><div class="card"><div class="ch"><h3>Aula a aula</h3><span class="sm-t">desde a matrícula, em ${DFY(a.mat)}</span></div>${fq.B.map((x, i) => {
      const s = fq.st[i], p = progDe(id, x.n), o = S.presObs[id + '-' + x.n];
      return `<div class="li"><div class="dbox ${s == 'F' ? '' : 'gd'}"><b>${D(x.date).getDate()}</b><small>${MES[D(x.date).getMonth()]}</small></div><div class="grow"><b>${E(x.nome)}</b><span class="sm-t">${x.video ? (S.vis[id + '-' + x.n] ? 'Gravação assistida' + (p.auto ? ' em ' + E(p.auto) : '') : p.p ? 'Gravação: ' + p.p + '% assistido, parou em ' + fmtT(p.t) : 'Gravação não iniciada') : 'Sem gravação'}${o ? ' · motivo: ' + E(o) : ''}</span></div>${tag(PST[s][0], PST[s][1])}<button class="btn q sm" aria-label="Corrigir chamada" title="Abrir chamada desta aula" onclick="chamada(${x.n})">${ic('edit')}</button></div>`;
    }).join('') || '<p class="mu" style="margin:0">Nenhum encontro realizado desde a matrícula.</p>'}</div>
<div class="stack"><div class="card ${fq.abaixo ? 'alert' : ''}"><h3 style="margin-bottom:10px">Frequência</h3><div class="bar ${fq.abaixo ? '' : 'ok'}"><i style="width:${fq.n ? fq.pct : 0}%"></i><u style="left:${fq.min}%"></u></div><dl class="meta" style="margin-top:14px"><dt>Percentual</dt><dd>${fq.n ? fq.pct + '%' : '—'} (mínimo ${fq.min}%)</dd><dt>Encontros</dt><dd>${fq.ok} de ${fq.n}</dd><dt>Faltas que cabem</dt><dd>${Math.max(0, fq.restam)} de ${fq.maxF}, em ${fq.tot} previstos</dd><dt>Certificado</dt><dd>${S.certLib[id] ? 'Liberado por exceção' : fq.abaixo && S.cfg.certFreq ? 'Bloqueado pela frequência' : 'Dentro da regra'}</dd></dl>${fq.abaixo ? `<div class="row" style="margin-top:14px"><button class="btn sm" onclick="notifFreq(${id})">${ic('bell')}Avisar o aluno</button>${S.cfg.certFreq ? `<button class="btn s sm" onclick="certExc(${id})">${S.certLib[id] ? 'Desfazer exceção' : 'Liberar certificado'}</button>` : ''}</div>` : ''}</div>
<div class="card"><h3 style="margin-bottom:6px">Justificativas</h3>${S.just.filter(j => j.aid == id).map(j => `<div class="li"><div class="grow"><b style="font-weight:600">${E((aulaN(j.n) || {}).nome || 'Aula')}</b><span class="sm-t">${E(j.motivo)}</span></div>${j.st == 'pendente' ? `<button class="btn sm" onclick="justAval('${j.id}')">Avaliar</button>` : tag(j.st == 'aprovada' ? 'Aprovada' : j.st == 'recusada' ? 'Recusada' : 'Resolvida', j.st == 'aprovada' ? 'ok' : j.st == 'recusada' ? 'er' : '')}</div>`).join('') || '<p class="mu" style="margin:0">Nenhuma justificativa enviada.</p>'}</div></div></div>`;
  else if (t == 'diario')
    body = `<p class="mu" style="max-width:640px">Só aparecem aqui as anotações que o aluno escolheu compartilhar com você. O restante do diário é privado.</p>` + (dsh.length ? `<div class="stack">${dsh.map(d => {
      const x = d.n && aulaN(d.n);
      return `<article class="card dn sh"><div class="row sp" style="align-items:flex-start"><div><b>${E(x ? x.nome : d.tit || 'Anotação livre')}</b><div class="sm-t">${x ? 'Aula de ' + DF(x.date) + ' · ' : ''}${E(d.upd)}</div></div>${d.resp ? tag('Respondida', 'ok') : tag('Sem resposta', 'wn')}</div><p style="white-space:pre-line;margin:12px 0 0">${E(d.txt)}</p>${d.resp ? `<div class="card flat" style="margin-top:12px;padding:12px 14px"><span class="sm-t">Sua resposta · ${E(d.respAt || '')}</span><p style="margin:4px 0 0;white-space:pre-line">${E(d.resp)}</p></div>` : ''}<div class="row" style="margin-top:12px;flex-wrap:nowrap"><input id="dr-${d.id}" placeholder="${d.resp ? 'Escrever outra resposta' : 'Responder a esta anotação'}" onkeydown="if(event.key=='Enter')dResp('${d.id}')"><button class="btn s sm" onclick="dResp('${d.id}')">${ic('send')}Responder</button></div></article>`;
    }).join('')}</div>` : empty('Nenhuma anotação compartilhada', 'Quando o aluno compartilhar uma anotação de aula ou do diário, ela aparece aqui para você responder.'));
  else if (t == 'tarefas')
    body = `<div class="tw"><table><thead><tr><th>Tarefa</th><th>Prazo</th><th>Status</th><th>Nota</th><th></th></tr></thead><tbody>${tarefasDe(id).map(x => {
      const [s, c] = tStatus(id, x), k = id + '-' + x.id;
      return `<tr><td><b>${E(x.t)}</b><div class="sm-t">${E(x.comp)}</div></td><td>${DF(due(id, x))}${S.prazo[k] ? ' <span class="sm-t">(reaberto)</span>' : ''}</td><td>${tag(s, c)}</td><td><input type="number" min="0" max="10" step="0.5" style="width:84px;padding:7px 9px" value="${S.notas[k] ?? ''}" ${S.ent[k] ? '' : 'disabled'} aria-label="Nota" onchange="setNota(${id},${x.id},this.value)"></td><td style="text-align:right">${S.ent[k] ? `<button class="btn q sm" onclick="verEnt(${id},${x.id})">Ver entrega</button>` : tLib(x) ? `<button class="btn q sm" onclick="reabre(${x.id},${id})">Reabrir prazo</button>` : ''}</td></tr>`;
    }).join('')}</tbody></table></div>`;
  else if (t == 'roda') {
    const r = S.roda[id];
    body = `<div class="main2"><div class="card printable">${radar(r)}</div><div class="card"><h3 style="margin-bottom:12px">Comparação por área</h3>${AREAS.map((x, i) => `<div class="row sp" style="padding:8px 0;border-top:1px solid var(--ln)"><span>${x}</span><span><span class="mu">${r.ini[i]}</span> → <b class="gold">${r.fin[i]}</b></span></div>`).join('')}<p class="sm-t" style="margin-top:10px">Inicial ${r.iniSent ? 'enviada' : 'pendente'}, final ${r.finSent ? 'enviada' : 'pendente'}.</p><button class="btn s sm" onclick="print()">${ic('print')}Exportar PDF</button></div></div>`;
  }
  else if (t == 'rotina')
    body = S_rotina(id, true);
  else if (t == 'aval')
    body = avalSemanal(id);
  else if (t == 'notas')
    body = `<div class="card" style="max-width:760px"><h3>Anotações privadas do mentor</h3><p class="mu">O aluno não vê este conteúdo.</p><textarea id="pv" rows="8" placeholder="Percepções, combinados, pontos de atenção">${E(S.priv[id] || '')}</textarea><div style="margin-top:12px"><button class="btn" onclick="S.priv[${id}]=val('pv');done('Anotação salva')">Salvar anotação</button></div></div>`;
  else if (t == 'dados')
    body = `<div class="card" style="max-width:760px"><dl class="meta"><dt>E-mail de login</dt><dd>${E(a.email)}</dd><dt>Telefone</dt><dd>${E(a.tel || '—')}</dd><dt>Nascimento</dt><dd>${DFY(a.nasc)}</dd><dt>Matrícula</dt><dd>${DFY(a.mat)}</dd><dt>Turma</dt><dd><span class="tsel" style="--c:${E(turmaDe(id).cor)}"><i></i><select aria-label="Turma" onchange="setTurmaAluno(${id},this.value)"><option value="0">Sem turma</option>${S.turmas.map(x => `<option value="${x.id}" ${x.id == a.turma ? 'selected' : ''}>${E(tnome(x))}</option>`).join('')}</select></span></dd><dt>Termos aceitos</dt><dd>${E(S.termos[id] || 'Ainda não acessou')}</dd><dt>Status</dt><dd>${E(stTag(a.status)[0])}</dd><dt>Avisos</dt><dd>${[(a.canais || {}).email !== false ? 'E-mail' : '', (a.canais || {}).whats !== false && a.tel ? 'WhatsApp' : ''].filter(Boolean).join(' e ') || 'Só no portal'}</dd></dl></div>
<div class="card ${lg ? 'alert' : ''}" style="max-width:760px"><div class="ch" style="margin-bottom:4px"><h3>Privacidade (LGPD)</h3>${lg ? tag('Exclusão pedida em ' + lg.at, 'er') : ''}</div><p class="mu" style="margin:0 0 12px">${lg ? 'O aluno pediu a exclusão dos dados' + (lg.motivo ? ' (' + E(lg.motivo) + ')' : '') + '. Exporte uma cópia se precisar e confirme a exclusão.' : 'Entregue ao aluno uma cópia de tudo o que o portal guarda sobre ele, ou apague os dados quando ele pedir.'}</p><div class="row"><button class="btn s sm" onclick="lgpdExport(${id})">${ic('download')}Exportar dados do aluno</button><button class="btn d sm" onclick="lgpdApagar(${id})">${ic('trash')}Excluir dados</button></div></div>`;
  else {
    const m = S.metas.filter(x => x.aid == id);
    body = `<div class="main2"><div class="card"><div class="ch"><h3>Competências</h3><button class="btn s sm" onclick="ST.csel=${id};ST.comps='aluno';nav('comps')">${ic('sliders')}Analisar e ajustar</button></div>${CK().map(c => {
      const v = compAvg(id, c);
      return `<div style="margin-bottom:14px"><div class="row sp" style="font-size:13px;margin-bottom:5px"><span>${c}${has(compA(id, c).nota) ? ' <span class="sm-t">(ajustada)</span>' : ''}</span><b>${f1(v)}</b></div>${bar((v || 0) * 10)}</div>`;
    }).join('')}</div><div class="stack"><div class="card"><h3 style="margin-bottom:6px">Plano de ação</h3>${m.map(x => `<div class="li"><div class="grow"><b style="font-weight:600">${E(x.t)}</b><span class="sm-t">${x.etapas.filter(e => e.feito).length} de ${x.etapas.length} etapa(s)${x.etapas.some(etapaAtrasada) ? ' · com atraso' : ''}</span>${x.etapas.length ? bar(metaPct(x), x.feita ? 'ok' : '') : ''}</div>${x.st == 'proposta' ? `<button class="btn sm" onclick="metaAval('${x.id}')">Avaliar</button>` : tag(...metaSt(x))}</div>`).join('') || '<p class="mu" style="margin:0">Nenhuma meta proposta.</p>'}</div><div class="card"><h3 style="margin-bottom:6px">Aulas</h3><p class="mu" style="margin:0">${fq.B.filter(x => presOk(id, x.n)).length} presenças e ${fq.B.filter(x => S.vis[id + '-' + x.n]).length} gravações assistidas de ${fq.n} encontros desde a matrícula.</p><button class="btn q sm" style="margin:8px 0 0 -10px" onclick="ST.alunoD='freq';render()">Ver aula a aula${ic('right')}</button></div></div></div>`;
  }
  return head + tb + body;
}

function setNota(aid, tid, v) {
  if (v === '') {
    delete S.notas[aid + '-' + tid];
    save();
    return;
  }
  const n = parseFloat(String(v).replace(',', '.'));
  if (isNaN(n) || n < 0 || n > 10) {
    toast('A nota deve ser de 0 a 10');
    keep();
    render();
    return;
  }
  S.notas[aid + '-' + tid] = Math.round(n * 2) / 2;
  const t = S.tarefas.find(x => x.id == tid);
  notify('Nota lançada', 'Notificação + e-mail', 'Você recebeu nota ' + f1(n) + ' na tarefa "' + t.t + '".', aid, 'tarefas');
  logA('Nota ' + f1(n) + ' lançada para ' + nm(aid) + ' em "' + t.t + '"');
  save();
  keep();
  render();
  toast('Nota lançada e aluno notificado');
}

function verEnt(aid, tid) {
  const e = S.ent[aid + '-' + tid], t = S.tarefas.find(x => x.id == tid), k = aid + '-' + tid;
  modal(E(t.t), `<p class="sm-t">Entregue por ${E(nm(aid))} em ${E(e.at)}</p><div class="card flat">${e.txt ? `<p style="margin:0;white-space:pre-line">${E(e.txt)}</p>` : '<p class="mu" style="margin:0">Entrega feita por arquivo, sem texto.</p>'}${(e.files || []).length ? `<div class="fchips" style="margin-top:12px">${e.files.map(f => fileChip(f)).join('')}</div>` : ''}${e.link ? `<p style="margin:10px 0 0"><a href="${E(safeUrl(e.link))}" target="_blank" rel="noopener">${E(e.link)}</a></p>` : ''}</div><div style="height:14px"></div>${F('Nota (0 a 10)', `<input id="vn" type="number" min="0" max="10" step="0.5" value="${S.notas[k] ?? ''}">`, 'Competência avaliada: ' + E(t.comp))}`, { label: 'Lançar nota', ok: () => {
      const v = val('vn');
      if (v === '') {
        toast('Informe a nota');
        return false;
      }
      setNota(aid, tid, v);
    } });
}

function reabre(tid, aid) {
  const t = S.tarefas.find(x => x.id == tid);
  modal('Reabrir prazo', (aid ? '' : F('Aluno', `<select id="ra">${alvoDe(t).filter(a => inCtx(a.id)).map(a => `<option value="${a.id}">${E(a.nome)}</option>`).join('')}</select>`)) + F('Novo prazo', `<input id="rp" type="date" value="${addD(hoje(), 3)}">`), { sub: E(t.t), label: 'Reabrir prazo', ok: () => {
      const a = aid || +val('ra');
      if (!a) {
        toast('Nenhum aluno nesta tarefa');
        return false;
      }
      if (!val('rp')) {
        toast('Escolha a data');
        return false;
      }
      S.prazo[a + '-' + tid] = val('rp');
      notify('Prazo reaberto', 'Push + e-mail', 'Novo prazo para "' + t.t + '": ' + DF(val('rp')), a, 'tarefas');
      done('Prazo reaberto para ' + nm(a));
    } });
}

function avalSemanal(id) {
  const w = ST.aw ?? week(), av = S.aval[id] || (S.aval[id] = {}), wa = av[w] || {}, m = i => {
    const v = Object.values(av[i] || {}).map(Number).filter(Boolean);
    return v.length ? avg(v) : null;
  };
  return `<p class="mu">Avaliação privada do mentor, de 1 a 5, em 10 critérios. O aluno não vê.</p>` + wkSel('aw', i => m(i) ? 'Média ' + f1(m(i)) : 'Pendente') + `<div class="card"><div class="ch"><h3>Semana ${w + 1}</h3>${tag('Média ' + f1(m(w)), m(w) ? 'gd' : '')}</div><div class="g2">${Object.keys(CRIT).map(c => `<div class="slot" style="margin:0"><b>${c}</b><p class="sm-t" style="margin:2px 0 10px">${CRIT[c]}</p><div class="seg" role="radiogroup" aria-label="${c}">${[1, 2, 3, 4, 5].map(n => `<button role="radio" aria-checked="${wa[c] == n}" class="${wa[c] == n ? 'on' : ''}" style="${wa[c] == n ? 'background:var(--gd);color:var(--gdi)' : ''}" onclick="setAv(${id},${w},'${c}',${n})">${n}</button>`).join('')}</div></div>`).join('')}</div></div>`;
}

function setAv(id, w, c, n) {
  const a = S.aval[id] || (S.aval[id] = {});
  (a[w] = a[w] || {})[c] = n;
  save();
  keep();
  render();
}

/* Mentor responde a uma anotação que o aluno compartilhou. */
function dResp(did) {
  const d = S.diario.find(x => x.id == did), t = val('dr-' + did);
  if (t.length < 2)
    return toast('Escreva a resposta');
  d.resp = t;
  d.respAt = stamp();
  notify('O mentor respondeu sua anotação', 'E-mail + WhatsApp', t, d.aid, 'diario');
  keep();
  done('Resposta enviada ao aluno', 'Respondeu uma anotação de ' + nm(d.aid));
}

async function lgpdExecutar(aid) {
  const b = $('#mok');
  b.disabled = true;
  b.textContent = 'Excluindo…';
  try {
    await salvarAgora();
    await chamar('POST', '/api/admin/lgpd-apagar', { id: aid });
    await carregarEstado();
    definirUsuario();
  }
  catch (e) {
    b.disabled = false;
    b.textContent = 'Excluir dados';
    return toast(e.msg);
  }
  closeM();
  nav('alunos');
  toast('Dados excluídos');
}

/* Mentor confirma: apaga tudo o que é do aluno e deixa só um registro anônimo para a auditoria. */
function lgpdApagar(aid) {
  const a = aluno(aid);
  modal('Excluir dados de ' + E(a.nome), `<p>Serão apagados de vez: cadastro, foto, entregas e arquivos, notas, frequência, metas, rotina, Roda da Vida, anotações, chamados e notificações.</p><p class="mu">Fica apenas um registro sem identificação ("Aluno excluído"), para o histórico da turma continuar fazendo sentido.</p>` + F('Para confirmar, digite EXCLUIR', `<input id="lg3" autocomplete="off">`), { label: 'Excluir definitivamente', danger: true, ok: () => {
      if (val('lg3').toUpperCase() != 'EXCLUIR') {
        toast('Digite EXCLUIR para confirmar');
        return false;
      }
      /* O servidor apaga tudo o que é do aluno, inclusive o que o mentor não enxerga (anotações privadas do diário e arquivos). */
      lgpdExecutar(aid);
      return false;
    } });
}
