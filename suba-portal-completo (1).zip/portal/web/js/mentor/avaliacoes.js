/**
 * mentor/avaliacoes.js
 * Página do admin: avaliacoes.
 */
'use strict';

function A_aval() {
  const t = sub('avaliacoes', 'lancar');
  return tabs('avaliacoes', [['lancar', 'Lançar notas'], ['matriz', 'Boletim da turma'], ['contest', 'Contestações', pendC() || ''], ['semanal', 'Avaliação semanal']]) + (t == 'matriz' ? matriz() : t == 'contest' ? contestList() : t == 'semanal' ? semanalTab() : lancar());
}

function lancar() {
  const L = tarefasLib(), tid = ST.tsel && L.find(t => t.id == ST.tsel) ? ST.tsel : (L[L.length - 1] || {}).id, t = S.tarefas.find(x => x.id == tid);
  if (!t)
    return empty('Nenhuma tarefa liberada', 'As entregas aparecem aqui quando as tarefas forem liberadas.');
  return `<div class="toolbar"><select style="max-width:420px" onchange="ST.tsel=+this.value;render()">${L.map(x => `<option value="${x.id}" ${x.id == tid ? 'selected' : ''}>${E(x.t)} (${E(x.comp)})</option>`).join('')}</select><span class="sm-t">Prazo ${DF(t.due)}. A nota vai direto para a competência ${E(t.comp)}.</span></div>
<div class="tw"><table><thead><tr><th>Aluno</th><th>Entrega</th><th class="hide-m">Resposta</th><th>Nota</th></tr></thead><tbody>${ativos().filter(a => inT(t, a.turma)).map(a => {
    const k = a.id + '-' + t.id, e = S.ent[k], [s, c] = tStatus(a.id, t);
    return `<tr><td>${who(a)}</td><td>${e ? `<button class="btn q sm" style="padding-left:0" onclick="verEnt(${a.id},${t.id})">${tag(s, c)}</button>` : tag(s, c)}</td><td class="hide-m" style="max-width:340px"><span class="sm-t">${e ? E((e.txt || '').slice(0, 90)) + ((e.txt || '').length > 90 ? '…' : '') + ((e.files || []).length ? ` <span class="lk">${ic('clip')}${e.files.length} arquivo(s)</span>` : '') : '—'}</span></td><td><input type="number" min="0" max="10" step="0.5" style="width:88px;padding:7px 9px" aria-label="Nota de ${E(a.nome)}" value="${S.notas[k] ?? ''}" ${e ? '' : 'disabled'} onchange="setNota(${a.id},${t.id},this.value)"></td></tr>`;
  }).join('')}</tbody></table></div><p class="sm-t" style="margin-top:10px">A nota é salva ao sair do campo. O aluno recebe notificação na hora.</p>`;
}

function matriz() {
  const at = ativos(), L = tarefasLib();
  return `<div class="tw"><table><thead><tr><th>Aluno</th>${L.map(t => `<th title="${E(t.t)}">T${t.id}</th>`).join('')}${CK().map(c => `<th class="hide-m" title="${c}">${c.slice(0, 4)}.</th>`).join('')}<th>Final</th></tr></thead><tbody>${at.map(a => `<tr class="hov" onclick="nav('alunoD',${a.id})"><td><b>${E(a.nome)}</b></td>${L.map(t => {
    const n = S.notas[a.id + '-' + t.id], e = S.ent[a.id + '-' + t.id];
    return `<td>${n != null ? f1(n) : e ? '<span class="tag in">E</span>' : atrasada(a.id, t) ? '<span class="tag er">×</span>' : '<span class="sm-t">·</span>'}</td>`;
  }).join('')}${CK().map(c => `<td class="hide-m">${f1(compAvg(a.id, c))}</td>`).join('')}<td><b class="gold" style="font:600 18px var(--dp)">${f1(fin(a.id))}</b></td></tr>`).join('')}</tbody></table></div><p class="sm-t" style="margin-top:10px">E = entregue aguardando nota. × = não entregue. Pesos padrão das competências: ${CK().map(c => c + ' ' + cpeso(c) + '%').join(', ')}.</p>`;
}

function contestList() {
  const CL = S.contest.filter(c => inCtx(c.aid) && S.tarefas.some(x => x.id == c.tid));
  return CL.length ? `<div class="stack">${[...CL].reverse().map(c => {
    const t = S.tarefas.find(x => x.id == c.tid);
    return `<div class="card ${c.resp ? '' : 'gold'}"><div class="row sp"><div class="row">${who(aluno(c.aid))}</div>${c.resp ? tag('Respondida', 'ok') : tag('Aguardando resposta', 'wn')}</div><p style="margin:14px 0 4px"><b>${E(t.t)}</b>, nota atual <b class="gold">${f1(S.notas[c.aid + '-' + c.tid])}</b></p><p class="mu" style="margin:0">"${E(c.msg)}"</p><p class="sm-t" style="margin:6px 0 0">${E(c.at)}</p>${c.resp ? `<div class="card flat" style="margin-top:12px;padding:12px"><span class="sm-t">Sua resposta</span><p style="margin:4px 0 0">${E(c.resp)}</p></div>` : `<div style="margin-top:12px"><button class="btn sm" onclick="respC('${c.id}')">Responder</button></div>`}</div>`;
  }).join('')}</div>` : empty('Nenhuma contestação', 'Quando um aluno contestar uma nota, ela aparece aqui.');
}

function respC(id) {
  const c = S.contest.find(x => x.id == id), k = c.aid + '-' + c.tid;
  modal('Responder contestação', `<p class="mu">"${E(c.msg)}"</p>` + F('Nova nota', `<input id="rn" type="number" min="0" max="10" step="0.5" value="${S.notas[k] ?? ''}">`, 'Mantenha a nota ou ajuste.') + F('Resposta ao aluno', `<textarea id="rc" rows="3"></textarea>`), { sub: E(nm(c.aid)), label: 'Enviar resposta', ok: () => {
      if (!val('rc')) {
        toast('Escreva a resposta');
        return false;
      }
      const n = parseFloat(val('rn'));
      if (!isNaN(n) && n >= 0 && n <= 10)
        S.notas[k] = Math.round(n * 2) / 2;
      c.resp = val('rc');
      notify('Contestação respondida', 'Notificação + e-mail', c.resp, c.aid, 'tarefas');
      done('Resposta enviada ao aluno');
    } });
}

function semanalTab() {
  const at = ativos();
  if (!at.length)
    return empty('Nenhum aluno ativo', 'Não há alunos ativos nesta turma.');
  if (!at.some(a => a.id == ST.asel))
    ST.asel = at[0].id;
  return `<div class="toolbar">${F('Mentorado', `<select onchange="ST.asel=+this.value;render()">${at.map(a => `<option value="${a.id}" ${a.id == ST.asel ? 'selected' : ''}>${E(a.nome)}</option>`).join('')}</select>`)}</div>` + avalSemanal(ST.asel);
}
