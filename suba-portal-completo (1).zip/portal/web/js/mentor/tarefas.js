/**
 * mentor/tarefas.js
 * Página do admin: tarefas. O mentor pode anexar links de apoio; o aluno entrega por escrito ou com arquivo.
 */
'use strict';

function A_tarefas() {
  const L = tarefasCtx();
  return `<div class="row sp" style="margin-bottom:16px"><p class="mu" style="margin:0;max-width:620px">Crie a tarefa, anexe links se precisar e escolha as turmas. O aluno responde por escrito na plataforma ou anexa um arquivo (PDF, PPTX, XLSX, DOCX e outros).</p><button class="btn" onclick="taskForm()">${ic('plus')}Nova tarefa</button></div>` +
    (L.length ? `<div class="tw"><table><thead><tr><th>Tarefa</th><th>Turma</th><th class="hide-m">Competência</th><th>Prazo</th><th>Entregas</th><th class="hide-m">Avaliadas</th><th></th></tr></thead><tbody>${L.map(t => {
      const at = ativos().filter(a => inT(t, a.turma)), e = at.filter(a => S.ent[a.id + '-' + t.id]).length, n = at.filter(a => S.notas[a.id + '-' + t.id] != null).length, au = t.aula && aulaN(t.aula);
      return `<tr><td><b>${E(t.t)}</b><div class="sm-t">${E(t.freq)}${au ? ' · aula: ' + E(au.nome) : ''}${tLib(t) ? '' : ' · libera em ' + DF(t.lib || addD(t.due, -7))}${(t.links || []).length ? ` · <span class="lk">${ic('link')}${t.links.length} link(s)</span>` : ''}</div></td><td><div class="row" style="gap:5px">${tchips(t.turmas)}</div></td><td class="hide-m">${tag(t.comp, 'gd')}</td><td>${DF(t.due)}</td><td><div style="min-width:90px"><span class="sm-t">${e}/${at.length}</span>${bar(pct(e, at.length))}</div></td><td class="hide-m">${n}/${e}</td><td style="text-align:right;white-space:nowrap"><button class="btn s sm" onclick="ST.avaliacoes='lancar';ST.tsel=${t.id};nav('avaliacoes')">Avaliar</button> <button class="btn q sm" aria-label="Editar" title="Editar" onclick="taskForm(${t.id})">${ic('edit')}</button> <button class="btn q sm" aria-label="Reabrir prazo" title="Reabrir prazo individual" onclick="reabre(${t.id})">${ic('refresh')}</button> <button class="btn q sm" aria-label="Excluir" title="Excluir" onclick="delTask(${t.id})">${ic('trash')}</button></td></tr>`;
    }).join('')}</tbody></table></div>` : empty('Nenhuma tarefa', 'Crie a primeira tarefa para a turma.', `<button class="btn" onclick="taskForm()">${ic('plus')}Nova tarefa</button>`));
}

/* Linha de link de apoio dentro do formulário. */
const linkRow = (l = {}) => `<div class="lrow"><input class="lt" placeholder="Nome do link (ex.: Planilha modelo)" value="${E(l.t || '')}"><input class="lu" placeholder="https://" value="${E(l.u || '')}"><button type="button" class="btn q sm" aria-label="Remover link" onclick="this.parentNode.remove()">${ic('x')}</button></div>`;

function taskForm(id) {
  const t = id ? S.tarefas.find(x => x.id == id) : { turmas: ctx() ? [ctx()] : [], links: [], lib: hoje() };
  modal(id ? 'Editar tarefa' : 'Nova tarefa', F('Título', `<input id="t1" value="${E(t.t || '')}">`) + F('Instruções para o aluno', `<textarea id="t5" rows="3">${E(t.desc || '')}</textarea>`) +
    `<div class="f"><span>Links de apoio (opcional)</span><div id="tlinks">${(t.links || []).map(linkRow).join('')}</div><button type="button" class="btn s sm" onclick="$('#tlinks').insertAdjacentHTML('beforeend',linkRow());$('#tlinks .lrow:last-child .lt').focus()">${ic('link')}Anexar link</button><small>Vídeo, planilha modelo, artigo, pasta do Drive. O aluno abre direto da tarefa.</small></div>` +
    F('Turma(s)', tpick(t.turmas || []), 'Deixe tudo desmarcado para enviar a todas as turmas.') +
    `<div class="g2">${F('Competência', `<select id="t2">${CK().map(c => `<option ${c == t.comp ? 'selected' : ''}>${E(c)}</option>`).join('')}</select>`)}${F('Frequência', `<select id="t3">${['Semanal', 'Diária', 'Pontual'].map(x => `<option ${x == t.freq ? 'selected' : ''}>${x}</option>`).join('')}</select>`)}${F('Disponível a partir de', `<input id="t7" type="date" value="${t.lib || addD(t.due || hoje(), -7)}">`)}${F('Prazo de entrega', `<input id="t4" type="date" value="${t.due || addD(hoje(), 7)}">`, 'Padrão: 7 dias.')}</div>` +
    F('Aula relacionada (opcional)', `<select id="t6"><option value="">Nenhuma</option>${aulasDe(0).map(a => `<option value="${a.n}" ${a.n == t.aula ? 'selected' : ''}>${DF(a.date)} · ${E(a.nome)}</option>`).join('')}</select>`), { wide: true, label: id ? 'Salvar tarefa' : 'Publicar tarefa', ok: () => {
      if (!val('t1') || !val('t4')) {
        toast('Informe título e prazo');
        return false;
      }
      const links = $$('#tlinks .lrow').map(r => ({ t: r.querySelector('.lt').value.trim(), u: r.querySelector('.lu').value.trim() })).filter(l => l.t || l.u);
      if (links.some(l => !safeUrl(l.u))) {
        toast('Cada link precisa começar com https://');
        return false;
      }
      links.forEach(l => l.t = l.t || l.u.replace(/^https:\/\//, '').split('/')[0]);
      const d = {
        t: val('t1'), desc: val('t5') || 'Execute a prática proposta e registre o resultado.', comp: val('t2'), freq: val('t3'), lib: val('t7') || hoje(), due: val('t4'), aula: +val('t6') || null, turmas: tpicked(), links
      };
      if (d.lib > d.due)
        d.lib = d.due;
      if (id)
        Object.assign(t, d);
      else {
        const nova = { id: nid(), ...d };
        S.tarefas.push(nova);
        notify('Nova tarefa: ' + d.t, 'Push + e-mail', 'Prazo: ' + DL(d.due), alvoDe(nova), 'tarefas');
      }
      done(id ? 'Tarefa atualizada' : 'Tarefa publicada e alunos notificados');
    } });
}

function delTask(id) {
  const t = S.tarefas.find(x => x.id == id), e = Object.keys(S.ent).filter(k => k.endsWith('-' + id)).length;
  modal('Excluir tarefa', `<p>Excluir <b>${E(t.t)}</b>?</p>${e ? `<p class="mu">${e} entrega(s) e as notas desta tarefa também serão removidas das competências.</p>` : ''}`, { label: 'Excluir tarefa', danger: true, ok: () => {
      S.tarefas = S.tarefas.filter(x => x.id != id);
      [S.ent, S.notas, S.prazo].forEach(o => Object.keys(o).forEach(k => {
        if (k.endsWith('-' + id)) {
          ((o[k] || {}).files || []).forEach(f => fdel(f.id));
          delete o[k];
        }
      }));
      S.contest = S.contest.filter(c => c.tid != id);
      done('Tarefa excluída', 'Excluiu a tarefa "' + t.t + '"');
    } });
}
