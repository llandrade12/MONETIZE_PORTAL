/**
 * mentor/aulas.js
 * Página do admin: aulas e calendário.
 * O calendário começa vazio. O mentor adiciona cada aula e escolhe a(s) turma(s) que participam.
 */
'use strict';

function A_aulas() {
  const v = sub('aulasA', 'cal'), L = aulasCtx();
  return `<div class="toolbar"><div class="seg"><button class="${v == 'cal' ? 'on' : ''}" onclick="ST.aulasA='cal';render()">Calendário</button><button class="${v == 'lista' ? 'on' : ''}" onclick="ST.aulasA='lista';render()">Cronograma</button></div>${tfilter()}<span style="flex:1"></span><button class="btn q" title="Ver os encontros no seu Google Agenda, iPhone ou Outlook" onclick="assinarAgenda()">${ic('calplus')}Assinar agenda</button><button class="btn q" title="Baixar a agenda em .ics" onclick="icsAll()">${ic('download')}.ics</button><button class="btn s" onclick="novoEv()">${ic('plus')}Evento</button><button class="btn" onclick="novaAula()">${ic('plus')}Nova aula</button></div>` +
    (v == 'cal' ? calendar(0) : L.length ? `<div class="tw"><table><thead><tr><th style="width:44px">Nº</th><th>Data</th><th>Tema</th><th>Turma</th><th class="hide-m">Mentor</th><th>Status</th><th class="hide-m">Presença</th><th></th></tr></thead><tbody>${L.map(a => {
      const al = alvoDe(a), p = aulaLib(a) ? al.filter(x => presOk(x.id, a.n)).length + '/' + al.length : '—', un = a.turmas.map(i => unDe(a, i)).filter(Boolean).map(u => u.nome).filter((x, i, v) => v.indexOf(x) == i).join(' / ');
      return `<tr><td><b class="gold" style="font:600 20px var(--dp)">${ord(a)}</b></td><td style="white-space:nowrap"><b>${DF(a.date)}</b><div class="sm-t">${DOW[D(a.date).getDay()]}, ${a.hora}</div></td><td><b>${E(a.nome)}</b><div class="sm-t">${[un, a.comp].filter(Boolean).map(E).join(' · ')}${(a.mats || []).length ? ' · ' + a.mats.length + ' material(is)' : ''}${a.aberta ? ' · aberta a convidados' : ''}${a.motivo ? ' · reagendada: ' + E(a.motivo) : ''}</div></td><td><div class="row" style="gap:5px">${tchips(a.turmas)}</div></td><td class="hide-m">${E(a.mentor)}</td><td>${tag(...aTag(a))}</td><td class="hide-m">${p}</td><td style="text-align:right;white-space:nowrap"><button class="btn ${aTag(a)[1] == 'er' ? '' : 's'} sm" onclick="chamada(${a.n})">${ic('roll')}Chamada</button> <button class="btn s sm hide-m" onclick="regAula(${a.n})">${aulaLib(a) ? 'Gravação' : 'Registrar'}</button> <button class="btn q sm" aria-label="Mais ações da aula" onclick="aulaMenu(${a.n})">${ic('dots')}</button></td></tr>`;
    }).join('')}</tbody></table></div>` : empty('Nenhuma aula cadastrada', ctx() ? 'Ainda não há aulas para ' + E(ctxNome()) + '.' : 'O cronograma começa vazio. Adicione cada aula e escolha a turma que participa.', `<button class="btn" onclick="novaAula()">${ic('plus')}Adicionar primeira aula</button>`));
}

function aulaMenu(n) {
  const a = aulaN(n);
  modal(E(a.nome), `<div class="row" style="gap:6px;margin-bottom:14px">${tchips(a.turmas, false)}</div><div style="display:grid;gap:8px">${[['Fazer chamada (presença)', 'roll', `chamada(${n})`], [aulaLib(a) ? 'Gravação e registro da sessão' : 'Registrar sessão e gravação', 'play', `regAula(${n})`], ['Materiais de apoio (PDF, slides)' + ((a.mats || []).length ? ' · ' + a.mats.length : ''), 'clip', `matsAula(${n})`], ['Editar aula, turmas e pauta', 'edit', `aulaForm(${n})`], ['Reagendar aula', 'cal', `reag(${n})`], ['Substituir mentor', 'user', `subst(${n})`], ['Reenviar link da reunião', 'link', `relink(${n})`], ['Adicionar à minha agenda', 'calplus', `calAdd('a',${n})`], ['Ver histórico da aula', 'clock', `histAula(${n})`]].map(([l, i, f]) => `<button class="btn s" style="justify-content:flex-start" onclick="closeM();setTimeout(()=>${f},30)">${ic(i)}${l}</button>`).join('')}<button class="btn d" style="justify-content:flex-start" onclick="closeM();setTimeout(()=>delAula(${n}),30)">${ic('trash')}Excluir aula</button></div>`, { cancel: 'Fechar', sub: DL(a.date) + ', ' + a.hora + (a.comp ? ' · ' + E(a.comp) : '') });
}

/* Formulário de aula. n = editar; date = data sugerida ao clicar em um dia do calendário. */
function aulaForm(n, date) {
  const a = n ? aulaN(n) : { date: date || hoje(), hora: '20:00', dur: 120, un: {}, turmas: ctx() ? [ctx()] : S.turmas.length == 1 ? [S.turmas[0].id] : [], mentor: S.mentor, comp: CK()[0] || '', topicos: [] };
  if (!S.turmas.length)
    return modal('Cadastre uma turma primeiro', '<p>Toda aula precisa de pelo menos uma turma. Cadastre a turma e volte aqui.</p>', { label: 'Ir para Turmas', ok: () => nav('turmas') });
  modal(n ? 'Editar aula' : 'Nova aula', F('Tema da aula', `<input id="an" value="${E(a.nome || '')}" placeholder="Ex.: Mentalidade de dono">`) +
    F('Turma(s) que participam', tpick(a.turmas), 'Marque uma ou mais turmas. A cor de cada uma aparece no calendário.') +
    `<div id="aunw">${S.turmas.filter(t => t.unidades.length).map(t => `<label class="f aunr" data-t="${t.id}" ${a.turmas.includes(t.id) ? '' : 'hidden'}><span>Unidade em ${E(tnome(t))}</span><select class="aun" data-t="${t.id}"><option value="">Sem unidade</option>${t.unidades.map(u => `<option value="${u.id}" ${(a.un || {})[t.id] == u.id ? 'selected' : ''}>${E(u.nome)} (${aulasUn(t.id, u.id).length}/${u.qtd || '?'} aulas)</option>`).join('')}</select></label>`).join('')}</div>` +
    `<div class="g2">${F('Data', `<input id="ad" type="date" value="${a.date}">`)}${F('Horário', `<input id="ah" type="time" value="${a.hora}">`)}${F('Duração (minutos)', `<input id="adu" type="number" min="15" step="15" value="${a.dur || 120}">`, 'Usada no convite da agenda.')}${F('Competência', `<select id="ac">${a.comp ? '' : n ? '<option value="">Definir depois</option>' : ''}${CK().map(c => `<option ${c == a.comp ? 'selected' : ''}>${E(c)}</option>`).join('')}</select>`, 'Crie novas no menu Competências.')}${F('Mentor', `<input id="amt" list="mlist" value="${E(a.mentor || '')}"><datalist id="mlist">${S.mentores.map(m => `<option value="${E(m)}">`).join('')}</datalist>`)}${F('Link da reunião', `<input id="al" value="${E(a.link || '')}" placeholder="https://">`)}</div>` +
    F('Objetivo (pauta visível para o aluno na véspera)', `<textarea id="ao" rows="2">${E(a.obj || '')}</textarea>`) + F('Tópicos (um por linha)', `<textarea id="at" rows="3">${E((a.topicos || []).join('\n'))}</textarea>`) +
    `<label class="chk"><input type="checkbox" id="aa" ${a.aberta ? 'checked' : ''}> Aula aberta a convidados</label>${n ? '' : `<label class="chk" style="margin-top:10px"><input type="checkbox" id="anf" checked> Avisar os alunos das turmas escolhidas</label>`}`, { wide: true, label: n ? 'Salvar aula' : 'Adicionar ao calendário', ok: () => {
      const tur = tpicked();
      if (!val('an') || !val('ad')) {
        toast('Informe tema e data');
        return false;
      }
      if (!tur.length) {
        toast('Escolha pelo menos uma turma');
        return false;
      }
      if (val('al') && !safeUrl(val('al'))) {
        toast('O link precisa começar com https://');
        return false;
      }
      const d = {
        nome: val('an'), date: val('ad'), hora: val('ah') || '20:00', turmas: tur, comp: val('ac'), mentor: val('amt') || S.mentor, link: val('al'), dur: Math.max(15, +val('adu') || 120), un: Object.fromEntries($$('#mbox .aun').filter(s => tur.includes(+s.dataset.t) && s.value).map(s => [s.dataset.t, s.value])), obj: val('ao'), topicos: val('at').split('\n').map(x => x.trim()).filter(Boolean), aberta: $('#aa').checked
      };
      if (!S.mentores.includes(d.mentor))
        S.mentores.push(d.mentor);
      if (n) {
        Object.assign(a, d);
        a.hist.unshift({ at: stamp(), m: 'Aula editada' });
        return done('Aula atualizada: ' + d.nome);
      }
      const nova = { n: nid(), ...d, status: 'agendada', video: '', mats: [], motivo: '', hist: [{ at: stamp(), m: 'Aula criada' }] };
      S.aulas.push(nova);
      ST.cal = d.date.slice(0, 7);
      if ($('#anf').checked)
        notify('Nova aula na agenda', 'E-mail + push', d.nome + ', ' + DL(d.date) + ' às ' + d.hora + '.', alvoDe(nova), 'agenda');
      done('Aula adicionada ao calendário', 'Criou a aula "' + d.nome + '" para ' + tur.map(i => tnome(turmaById(i))).join(' + '));
    } });
  /* Mostra o campo de unidade só das turmas marcadas. */
  $$('#mbox .tkc').forEach(c => c.addEventListener('change', () => $$('#mbox .aunr').forEach(r => r.hidden = !tpicked().includes(+r.dataset.t))));
}

const novaAula = date => aulaForm(0, date);

const editAula = n => aulaForm(n);

function delAula(n) {
  const a = aulaN(n);
  modal('Excluir aula', `<p>Excluir <b>${E(a.nome)}</b> de ${DL(a.date)}?</p><p class="mu">A aula sai do calendário das turmas. Presenças e gravação registradas para ela também são removidas.</p>`, { label: 'Excluir aula', danger: true, ok: () => {
      S.aulas = S.aulas.filter(x => x.n != n);
      [S.pres, S.vis, S.prog, S.presObs].forEach(o => Object.keys(o).forEach(k => {
        if (k.endsWith('-' + n))
          delete o[k];
      }));
      (a.mats || []).forEach(m => m.file && fdel(m.file.id));
      S.just = S.just.filter(j => j.n != n);
      /* As anotações dos alunos são deles: ficam no diário como anotação livre. */
      S.diario.forEach(d => {
        if (d.n == n) {
          d.n = null;
          d.tit = d.tit || a.nome;
        }
      });
      S.tarefas.forEach(t => {
        if (t.aula == n)
          t.aula = null;
      });
      done('Aula excluída', 'Excluiu a aula "' + a.nome + '"');
    } });
}

function regAula(n) {
  const a = aulaN(n), al = alvoDe(a), src = vsrc(a.video);
  chInit(a);
  /* Aula ainda sem chamada: já abre com todos presentes, para o mentor só ajustar as exceções. */
  if (!aulaLib(a))
    Object.values(CH).forEach(c => c.s = c.s || 'P');
  modal('Registrar sessão', `<div class="g2">${F('Situação', `<select id="rs"><option value="realizada" ${a.status == 'realizada' ? 'selected' : ''}>Realizada</option><option value="parcial" ${a.status == 'parcial' ? 'selected' : ''}>Parcial (sessão interrompida)</option></select>`)}${F('Mentor', `<input id="rme" value="${E(a.mentor)}">`)}</div>` +
    F('Gravação', `<input id="rl" placeholder="Cole o link do YouTube, Vimeo, Google Drive ou do arquivo .mp4" value="${E(a.video)}" oninput="vHint(this.value)">`, `<span id="rlh">${vHintTxt(a.video)}</span>`) +
    `<div class="card flat mt-box"><div class="grow"><b>Material de apoio</b><span class="sm-t">${(a.mats || []).length ? a.mats.length + ' item(ns): ' + a.mats.map(m => E(m.t)).slice(0, 3).join(', ') : 'PDF, slides, planilhas e links aparecem ao lado do vídeo.'}</span></div><button type="button" class="btn s sm" onclick="closeM();setTimeout(()=>matsAula(${n}),30)">${ic('clip')}${(a.mats || []).length ? 'Gerenciar' : 'Adicionar'}</button></div>` +
    `<p style="font-size:12.5px;font-weight:600;color:var(--t2);margin:16px 0 8px">Presença (${al.length} aluno(s) das turmas desta aula)</p>` + chBlock(a), { wide: true, sub: E(a.nome) + ', ' + DL(a.date), label: 'Salvar registro', ok: () => {
      const v = val('rl'), novo = v && v != a.video;
      if (v && !safeUrl(v)) {
        toast('O link precisa começar com https://');
        return false;
      }
      if (!chSave(a))
        return false;
      a.status = val('rs');
      a.video = v;
      a.mentor = val('rme') || a.mentor;
      a.hist.unshift({ at: stamp(), m: 'Sessão registrada como ' + a.status });
      if (novo)
        notify('Gravação disponível', 'e-mail + whatsapp', 'A gravação de "' + a.nome + '" já está no portal.' + (S.cfg.compensa ? ' Quem faltou compensa a falta assistindo até o fim.' : ''), al, 'aulas');
      autoRun(true);
      done('Sessão registrada: ' + a.nome);
    } });
}

const vHintTxt = u => {
  const s = vsrc(u);
  const arq = s && s.k == 'yt' && !/^http/.test(location.protocol) ? ' Atenção: você abriu o portal direto do arquivo, e assim o YouTube não toca. Use o "abrir-portal" da pasta ou o endereço publicado.' : '';
  return !u ? 'O vídeo abre dentro da página da aula. Use YouTube "não listado" ou Vimeo privado para proteger o conteúdo.' : !s ? 'O link precisa começar com https://' : s.auto ? s.nome + ' reconhecido: o portal lembra onde o aluno parou e marca como assistida aos ' + S.cfg.pctVisto + '%.' + arq : s.nome + ': o vídeo abre na página, mas sem medir o progresso (o aluno marca como assistida).';
};

function vHint(u) {
  const el = document.getElementById('rlh');
  if (el)
    el.textContent = vHintTxt(u.trim());
}

/* ---------- Materiais de apoio da aula ---------- */

/* Lista em edição: itens já salvos e novos (com o arquivo em .blob até salvar). */
let MT = [];

const matEd = (m, i) => `<div class="mtr"><span class="mtp fx-${mtipo(m)[1]}">${mtipo(m)[0].toUpperCase().slice(0, 6)}</span><div class="mtf"><input placeholder="Nome do material (ex.: Slides da aula)" value="${E(m.t)}" oninput="MT[${i}].t=this.value">${m.file ? `<span class="sm-t">${E(m.file.name)} · ${fsize(m.file.size)}</span>` : `<input placeholder="https://" value="${E(m.u || '')}" oninput="MT[${i}].u=this.value.trim()">`}<label class="chk" style="font-size:12.5px;align-items:center"><input type="checkbox" ${m.antes ? 'checked' : ''} onchange="MT[${i}].antes=this.checked"> Liberar antes do encontro (junto com a pauta)</label></div><button type="button" class="btn q sm" aria-label="Remover material" onclick="MT.splice(${i},1);matList()">${ic('x')}</button></div>`;

function matList() {
  const el = $('#mtl');
  if (el)
    el.innerHTML = MT.map(matEd).join('') || '<p class="mu" style="margin:0 0 4px">Nenhum material ainda.</p>';
}

function matAddFiles(files) {
  for (const f of files) {
    if (!MEXT.includes(fext(f.name))) {
      toast('Formato não aceito: ' + f.name);
      continue;
    }
    if (f.size > FMAX * 1048576) {
      toast(f.name + ' passa de ' + FMAX + ' MB');
      continue;
    }
    MT.push({ id: 'm' + uid(), t: f.name.replace(/\.\w+$/, ''), file: { name: f.name, size: f.size, type: f.type }, blob: f, antes: false });
  }
  matList();
}

function matsAula(n) {
  const a = aulaN(n);
  MT = (a.mats || []).map(m => ({ ...m }));
  modal('Material de apoio', `<p class="sm-t" style="margin:0 0 12px">O aluno encontra estes materiais na página da aula, ao lado do vídeo. PDF e imagens abrem dentro do portal; links do Google Drive, Slides e Docs também.</p><div id="mtl"></div>
<div class="row" style="margin-top:10px"><label class="btn s sm" style="position:relative;overflow:hidden">${ic('upload')}Enviar arquivo<input type="file" multiple accept="${MEXT.map(x => '.' + x).join(',')}" style="position:absolute;inset:0;opacity:0;cursor:pointer" onchange="matAddFiles(this.files);this.value=''"></label><button type="button" class="btn s sm" onclick="MT.push({id:'m'+uid(),t:'',u:'',antes:false});matList();$('#mtl .mtr:last-child input').focus()">${ic('link')}Adicionar link</button></div>
<label class="chk" style="margin-top:16px"><input type="checkbox" id="mtn" checked> Avisar os alunos quando houver material novo</label>`, { wide: true, sub: E(a.nome) + ' · ' + DL(a.date), label: 'Salvar materiais', ok: () => {
      if (MT.some(m => !m.file && !safeUrl(m.u))) {
        toast('Cada link precisa começar com https://');
        return false;
      }
      matSalvar(a);
      return false;
    } });
  matList();
}

async function matSalvar(a) {
  const b = $('#mok'), antes = a.mats || [], avisar = $('#mtn').checked;
  b.disabled = true;
  b.textContent = 'Salvando…';
  const novos = [];
  for (const m of MT) {
    m.t = (m.t || '').trim() || (m.file ? m.file.name : m.u.replace(/^https:\/\//, '').split('/')[0]);
    if (m.blob) {
      /* O arquivo precisa chegar ao servidor antes de o material aparecer para os alunos. */
      const id = 'mf' + uid();
      if (!await fput(id, m.blob)) {
        b.disabled = false;
        b.textContent = 'Salvar materiais';
        return toast(FILES.erro + ': ' + m.file.name);
      }
      m.file.id = id;
      delete m.blob;
    }
    if (!antes.some(o => o.id == m.id))
      novos.push(m);
  }
  antes.filter(o => o.file && !MT.some(m => m.id == o.id)).forEach(o => fdel(o.file.id));
  a.mats = MT.map(m => ({ ...m }));
  a.hist.unshift({ at: stamp(), m: 'Materiais atualizados (' + a.mats.length + ')' });
  /* Só avisa do que o aluno já consegue abrir. */
  const vis = novos.filter(m => aulaLib(a) || (m.antes && pautaLib(a)));
  if (avisar && vis.length)
    notify('Material novo na aula', 'e-mail + whatsapp', vis.map(m => m.t).join(', ') + ' em "' + a.nome + '".', alvoDe(a), 'aulas');
  closeM();
  done('Materiais salvos', 'Atualizou os materiais de "' + a.nome + '"');
}

function reag(n) {
  const a = aulaN(n);
  modal('Reagendar aula', `<div class="g2">${F('Nova data', `<input id="rd1" type="date" value="${a.date}">`)}${F('Horário', `<input id="rh" type="time" value="${a.hora}">`)}</div>` + F('Motivo (obrigatório)', `<select id="rmo"><option>Mentor indisponível</option><option>Feriado ou evento</option><option>Pedido da turma</option><option>Outro</option></select>`) + F('Detalhes', `<input id="rm" placeholder="Explique para a turma">`), { sub: E(a.nome), label: 'Reagendar e notificar', ok: () => {
      if (!val('rd1')) {
        toast('Informe a nova data');
        return false;
      }
      const old = a.date;
      a.date = val('rd1');
      a.hora = val('rh') || a.hora;
      a.motivo = val('rmo') + (val('rm') ? ': ' + val('rm') : '');
      a.status = 'agendada';
      ST.cal = a.date.slice(0, 7);
      a.hist.unshift({ at: stamp(), m: 'Reagendada de ' + DF(old) + ' para ' + DF(a.date) + '. ' + a.motivo });
      notify('Aula reagendada: ' + a.nome, 'E-mail + push + WhatsApp', 'Nova data: ' + DL(a.date) + ', ' + a.hora + '. Motivo: ' + a.motivo, alvoDe(a), 'agenda');
      done('Aula reagendada e turma notificada');
    } });
}

function subst(n) {
  const a = aulaN(n);
  modal('Substituir mentor', F('Mentor substituto', `<input id="sm" list="mlist2" placeholder="Nome"><datalist id="mlist2">${S.mentores.map(m => `<option value="${E(m)}">`).join('')}</datalist>`, 'A data é mantida. A turma é notificada.'), { sub: E(a.nome) + ', ' + DL(a.date), label: 'Confirmar substituição', ok: () => {
      if (!val('sm')) {
        toast('Informe o nome');
        return false;
      }
      a.mentor = val('sm');
      if (!S.mentores.includes(a.mentor))
        S.mentores.push(a.mentor);
      a.hist.unshift({ at: stamp(), m: 'Mentor substituído por ' + a.mentor });
      notify('Mentor substituto: ' + a.nome, 'E-mail + push', a.mentor + ' vai conduzir a aula, data mantida.', alvoDe(a), 'agenda');
      done('Mentor substituído e turma notificada');
    } });
}

function relink(n) {
  const a = aulaN(n);
  modal('Reenviar link da reunião', F('Link da reunião', `<input id="nlk" value="${E(a.link)}" placeholder="https://">`), { sub: E(a.nome), label: 'Enviar para a turma', ok: () => {
      if (!safeUrl(val('nlk'))) {
        toast('O link precisa começar com https://');
        return false;
      }
      a.link = val('nlk');
      a.hist.unshift({ at: stamp(), m: 'Novo link enviado' });
      notify('Link da aula: ' + a.nome, 'E-mail + push + WhatsApp', 'Use este link: ' + a.link, alvoDe(a), 'aulas');
      done('Link enviado à turma');
    } });
}

function histAula(n) {
  const a = aulaN(n);
  modal('Histórico da aula', a.hist.map(h => `<div class="li"><span class="ico">${ic('clock')}</span><div class="grow"><b style="font-weight:600">${E(h.m)}</b><span class="sm-t">${E(h.at)}</span></div></div>`).join('') || '<p class="mu">Sem alterações registradas.</p>', { cancel: 'Fechar', sub: E(a.nome) });
}

/* ---------- Eventos (confraternização, imersão, encontro extra) ---------- */

function novoEv(id) {
  const e = id ? S.eventos.find(x => x.id == id) : { turmas: ctx() ? [ctx()] : [] };
  modal(id ? 'Editar evento' : 'Novo evento no calendário', F('Título', `<input id="e1" value="${E(e.t || '')}" placeholder="Ex.: Confraternização">`) + F('Data', `<input id="e2" type="date" value="${e.d || ''}">`) + F('Turma(s)', tpick(e.turmas || []), 'Deixe tudo desmarcado para valer para todas as turmas.'), { label: id ? 'Salvar evento' : 'Adicionar e notificar', ok: () => {
      if (!val('e1') || !val('e2')) {
        toast('Informe título e data');
        return false;
      }
      const d = { t: val('e1'), d: val('e2'), turmas: tpicked() };
      if (id)
        Object.assign(e, d);
      else {
        S.eventos.push({ id: uid(), ...d });
        notify('Novo evento: ' + d.t, 'E-mail + push', DL(d.d), alvoDe(d), 'agenda');
      }
      ST.cal = d.d.slice(0, 7);
      done(id ? 'Evento atualizado' : 'Evento adicionado');
    } });
}

function evMenu(id) {
  const e = S.eventos.find(x => x.id == id);
  modal(E(e.t), `<div class="row" style="gap:6px;margin-bottom:14px">${tchips(e.turmas, false)}</div><div style="display:grid;gap:8px"><button class="btn s" style="justify-content:flex-start" onclick="closeM();setTimeout(()=>novoEv('${id}'),30)">${ic('edit')}Editar evento</button><button class="btn d" style="justify-content:flex-start" onclick="S.eventos=S.eventos.filter(x=>x.id!='${id}');closeM();done('Evento excluído')">${ic('trash')}Excluir evento</button></div>`, { cancel: 'Fechar', sub: DL(e.d) });
}
