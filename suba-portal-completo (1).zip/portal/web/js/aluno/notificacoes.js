/**
 * aluno/notificacoes.js
 * Página do aluno: notificacoes.
 */
'use strict';

function S_notif() {
  const id = ME().id, L = S.inbox.filter(i => i.aid == id);
  const html = `<div style="max-width:760px"><div class="row sp" style="margin-bottom:14px"><p class="mu" style="margin:0">Tudo o que o sistema enviou para você, por e-mail, push ou WhatsApp.</p></div><div class="card">${L.map(i => `<button class="li" style="width:100%;background:none;border-left:0;border-right:0;border-bottom:0;text-align:left;cursor:pointer" onclick="nav('${i.go || 'inicio'}')"><span class="ico ${i.lido ? '' : 'gd'}">${ic('bell')}</span><span class="grow"><b>${E(i.t)}</b><span class="sm-t">${E(i.m)}</span></span><span class="sm-t">${E(i.at.slice(0, 5))}</span></button>`).join('') || '<p class="mu">Nenhuma notificação.</p>'}</div></div>`;
  L.forEach(i => i.lido = true);
  save();
  return html;
}
