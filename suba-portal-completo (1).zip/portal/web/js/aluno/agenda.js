/**
 * aluno/agenda.js
 * Página do aluno: agenda. Mostra só as aulas, eventos e prazos da turma do aluno,
 * com a assinatura da agenda (Google Agenda, iPhone, Outlook) e o arquivo .ics de cada encontro.
 */
'use strict';

function S_agenda() {
  return `<div class="row sp" style="margin-bottom:6px"><p class="mu" style="max-width:600px;margin:0">Encontros, eventos e prazos da sua turma, ${E(tnome(turmaDe(ME().id)))}. Assine a agenda para os encontros aparecerem sozinhos no seu Google Agenda ou no celular.</p><span class="row"><button class="btn" onclick="assinarAgenda()">${ic('calplus')}Assinar a agenda</button><button class="btn s" onclick="icsAll()">${ic('download')}Baixar (.ics)</button></span></div>` + calendar(ME().id);
}
