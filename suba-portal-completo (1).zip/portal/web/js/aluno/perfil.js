/**
 * aluno/perfil.js
 * Página do aluno: perfil completo. Foto, edição dos próprios dados, canais de aviso,
 * privacidade (exportar ou excluir os dados, LGPD) e certificado.
 */
'use strict';

function S_perfil() {
  const me = ME(), t = turmaDe(me.id), co = certOpen(me.id), emit = !!certDe(me.id).on, f = freq(me.id), c = me.canais || {}, lg = S.lgpd.find(x => x.aid == me.id && x.st == 'pendente');
  const sw = (k, on, l, s, dis = '') => `<label class="sw"><span class="grow"><b>${l}</b><small>${s}</small></span><input type="checkbox" ${on ? 'checked' : ''} ${dis} onchange="setCanal('${k}',this.checked)"><i></i></label>`;
  return `<div class="main2"><div class="stack">
<div class="card"><div class="row" style="gap:16px;flex-wrap:nowrap"><label class="pf-ph" title="${me.foto ? 'Trocar foto' : 'Adicionar foto'}">${avatar(me, 'big')}<span class="pf-cam">${ic('camera')}</span><input id="pf-file" type="file" accept="image/png,image/jpeg,image/webp" ${ro() ? 'disabled' : ''} onchange="fotoSet(this.files[0]);this.value=''"></label><div style="min-width:0"><h2>${E(me.nome)}</h2><p class="mu" style="margin:2px 0 0">${E(me.cargo)}${me.empresa ? ' · ' + E(me.empresa) : ''}, ${E(tnome(t))}</p>${ro() ? '' : `<div class="row" style="margin-top:10px;gap:8px"><label class="btn ${me.foto ? 's' : ''} sm" for="pf-file">${ic('camera')}${me.foto ? 'Trocar foto' : 'Adicionar foto'}</label>${me.foto ? `<button class="btn q sm" onclick="fotoSet(null)">Remover</button>` : ''}</div>`}</div></div>
${me.bio ? `<p style="margin:16px 0 0;white-space:pre-line">${E(me.bio)}</p>` : ''}
<dl class="meta" style="margin-top:20px"><dt>E-mail</dt><dd>${E(me.email)}</dd><dt>WhatsApp</dt><dd>${E(me.tel || '—')}</dd><dt>Nascimento</dt><dd>${DFY(me.nasc)} (${age(me.nasc)} anos)</dd><dt>Cidade</dt><dd>${E(me.cidade || '—')}</dd><dt>Estado civil</dt><dd>${E(me.civil)}</dd><dt>Formação</dt><dd>${E(me.formacao || '—')}</dd><dt>Matrícula</dt><dd>${DFY(me.mat)}</dd><dt>Termos aceitos</dt><dd>${E(S.termos[me.id] || '—')}</dd></dl>
<div class="row" style="margin-top:20px"><button class="btn sm" ${ro() ? 'disabled' : ''} onclick="perfilEdit()">${ic('edit')}Editar meus dados</button><button class="btn s sm" onclick="senha()">${ic('lock')}Alterar senha</button></div></div>
<div class="card"><h3 style="margin-bottom:4px">Como quero ser avisado</h3><p class="mu" style="margin:0 0 6px">Lembretes de aula, prazos e respostas do mentor. No portal você sempre recebe.</p>
${pushSwitch()}${sw('email', c.email !== false, 'E-mail', E(me.email))}${sw('whats', c.whats !== false, 'WhatsApp', me.tel ? E(me.tel) : 'Cadastre seu número em "Editar meus dados"', me.tel ? '' : 'disabled')}</div>
<div class="card"><div class="ch" style="margin-bottom:4px"><h3>Privacidade e meus dados</h3>${tag('LGPD', '')}</div><p class="mu" style="margin:0 0 12px">Você pode levar uma cópia de tudo o que o portal guarda sobre você ou pedir a exclusão.</p>
<div class="li" style="border-top:0;padding-top:0"><span class="ico gd">${ic('download')}</span><div class="grow"><b>Exportar meus dados</b><span class="sm-t">Cadastro, frequência, entregas, notas, metas, rotina e anotações em um arquivo.</span></div><button class="btn s sm" onclick="lgpdExport(${me.id})">Baixar</button></div>
<div class="li"><span class="ico er">${ic('trash')}</span><div class="grow"><b>Excluir meus dados</b><span class="sm-t">${lg ? 'Pedido enviado em ' + E(lg.at) + '. A equipe confirma e apaga.' : 'Apaga seu cadastro e seu histórico. Não dá para desfazer.'}</span></div>${lg ? `<button class="btn s sm" onclick="lgpdCancel()">Cancelar pedido</button>` : `<button class="btn q sm" onclick="lgpdPedir()">Solicitar</button>`}</div>
<div class="li"><span class="ico">${ic('logout')}</span><div class="grow"><b>Sair da mentoria</b><span class="sm-t">${me.saida ? 'Solicitação enviada em ' + E(me.saida.at) + '.' : 'Bloqueia o acesso, mas mantém o histórico arquivado.'}</span></div>${me.saida ? '' : `<button class="btn q sm" onclick="saida()">Solicitar</button>`}</div></div>
</div>
<div class="stack"><div class="card ${co ? 'gold' : ''}"><div class="ch"><h3>Certificado</h3>${co ? tag('Disponível', 'ok') : emit ? tag('Bloqueado pela frequência', 'er') : tag('No encerramento', '')}</div>
${co ? `<button class="certthumb" aria-label="Abrir certificado" onclick="verCert(${me.id})">${certHtml(me.id)}</button><p class="mu">Seu certificado de conclusão está pronto.</p><button class="btn full" onclick="verCert(${me.id})">${ic('award')}Ver e baixar certificado</button>` : emit ? `<p class="mu" style="margin:0 0 12px">Os certificados da turma foram emitidos, mas sua frequência (${f.pct}%) ficou abaixo do mínimo de ${f.min}%.${S.cfg.compensa ? ' Assista às gravações dos encontros que perdeu para compensar.' : ' Fale com o mentor.'}</p><button class="btn full" onclick="nav('frequencia')">${ic('roll')}Ver minha frequência</button>` : `<p class="mu" style="margin:0">Disponível no encerramento da mentoria${t.fim ? ', em ' + DFY(t.fim) : ''}. Fica no seu perfil para sempre.</p>`}
${S.cfg.certFreq ? `<div class="pf-req"><div class="row sp" style="font-size:13px;margin-bottom:6px"><span>Frequência mínima de ${f.min}%</span><b class="${f.abaixo ? 'er' : ''}">${f.n ? f.pct + '%' : '—'}</b></div><div class="bar ${f.abaixo ? '' : 'ok'}"><i style="width:${f.n ? f.pct : 0}%"></i><u style="left:${f.min}%"></u></div><button class="btn q sm" style="margin:8px 0 0 -10px" onclick="nav('frequencia')">Minha frequência${ic('right')}</button></div>` : ''}</div>
<div class="card"><h3 style="margin-bottom:6px">Precisa de ajuda?</h3><p class="mu" style="margin:0 0 12px">Acesso, pagamento ou problema técnico: veja as perguntas frequentes ou abra um chamado.</p><button class="btn s full" onclick="nav('ajuda')">${ic('help')}Ajuda e suporte</button></div></div></div>`;
}

/* Foto: reduz e recorta antes de enviar, para ficar leve. */
function fotoSet(file) {
  const me = ME();
  if (!file) {
    delete me.foto;
    return done('Foto removida');
  }
  if (!/^image\//.test(file.type))
    return toast('Escolha uma imagem (JPG ou PNG)');
  const img = new Image(), u = URL.createObjectURL(file);
  img.onload = () => {
    const s = 320, cv = document.createElement('canvas'), g = cv.getContext('2d'), m = Math.min(img.width, img.height);
    cv.width = cv.height = s;
    g.drawImage(img, (img.width - m) / 2, (img.height - m) / 2, m, m, 0, 0, s, s);
    URL.revokeObjectURL(u);
    me.foto = cv.toDataURL('image/jpeg', .82);
    done('Foto atualizada', 'Atualizou a foto do perfil');
  };
  img.onerror = () => toast('Não foi possível ler esta imagem');
  img.src = u;
}

function perfilEdit() {
  const me = ME();
  modal('Editar meus dados', F('Nome completo', `<input id="p1" value="${E(me.nome)}" autocomplete="name">`) +
    `<div class="g2">${F('WhatsApp', `<input id="p2" value="${E(me.tel || '')}" placeholder="(71) 99999-9999" inputmode="tel" autocomplete="tel">`)}${F('Data de nascimento', `<input id="p3" type="date" value="${me.nasc || ''}">`)}${F('Função/cargo', `<select id="p4">${['Dono', 'Sócio', 'Gestor', 'Diretor', 'Outro'].map(x => `<option ${x == me.cargo ? 'selected' : ''}>${x}</option>`).join('')}</select>`)}${F('Empresa', `<input id="p8" value="${E(me.empresa || '')}">`)}${F('Estado civil', `<select id="p5">${['Solteiro', 'Casado', 'União estável', 'Divorciado', 'Viúvo'].map(x => `<option ${x == me.civil ? 'selected' : ''}>${x}</option>`).join('')}</select>`)}${F('Formação', `<input id="p6" value="${E(me.formacao || '')}">`)}${F('Cidade', `<input id="p7" value="${E(me.cidade || '')}">`)}</div>` +
    F('Sobre mim', `<textarea id="p9" rows="3" maxlength="400" placeholder="O que você faz e o que busca na mentoria">${E(me.bio || '')}</textarea>`) +
    `<p class="sm-t" style="margin:0">O e-mail (${E(me.email)}) é o seu login. Para trocar, abra um chamado em Ajuda e suporte.</p>`, { wide: true, label: 'Salvar meus dados', ok: () => {
      if (val('p1').length < 3 || !val('p3')) {
        toast('Informe nome e data de nascimento');
        return false;
      }
      if (age(val('p3')) < 18) {
        toast('Idade mínima de 18 anos');
        return false;
      }
      if (val('p2') && digits(val('p2')).length < 10) {
        toast('WhatsApp incompleto: use DDD e número');
        return false;
      }
      Object.assign(me, { nome: val('p1'), tel: val('p2'), nasc: val('p3'), cargo: val('p4'), civil: val('p5'), formacao: val('p6'), cidade: val('p7'), empresa: val('p8'), bio: val('p9') });
      done('Dados atualizados', 'Atualizou os próprios dados cadastrais');
    } });
}

function setCanal(k, on) {
  const me = ME();
  me.canais = Object.assign({ email: true, whats: true }, me.canais, { [k]: on });
  save();
  toast((k == 'email' ? 'Avisos por e-mail ' : 'Avisos por WhatsApp ') + (on ? 'ligados' : 'desligados'));
}

function saida() {
  modal('Solicitar saída', F('Motivo', `<textarea id="sv" rows="3"></textarea>`, 'Seu acesso é bloqueado após a confirmação da equipe. O histórico fica arquivado.'), { label: 'Enviar solicitação', danger: true, ok: () => {
      if (val('sv').length < 4) {
        toast('Informe o motivo');
        return false;
      }
      const me = ME();
      me.saida = { motivo: val('sv'), at: stamp() };
      notify('Solicitação de saída', 'E-mail', 'Recebemos sua solicitação. A equipe vai confirmar em breve.', me.id);
      notifyM('Pedido de saída: ' + me.nome, val('sv'), 'visao');
      done('Solicitação enviada para a equipe', 'Solicitou saída da mentoria');
    } });
}

/* ---------- LGPD: exportar e excluir os dados ---------- */

function lgpdPedir() {
  const me = ME();
  modal('Excluir meus dados', `<p>Ao confirmar, a equipe apaga seu cadastro, sua foto, entregas, notas, frequência, metas, rotina e anotações. <b>Seu acesso ao portal termina e não dá para desfazer.</b></p><p class="mu">Se quiser guardar uma cópia, use "Exportar meus dados" antes.</p>` + F('Para confirmar, digite EXCLUIR', `<input id="lg1" autocomplete="off">`) + F('Motivo (opcional)', `<input id="lg2">`), { label: 'Solicitar exclusão', danger: true, ok: () => {
      if (val('lg1').toUpperCase() != 'EXCLUIR') {
        toast('Digite EXCLUIR para confirmar');
        return false;
      }
      S.lgpd.unshift({ id: uid(), aid: me.id, nome: me.nome, tipo: 'exclusao', motivo: val('lg2'), at: stamp(), st: 'pendente' });
      notifyM('Pedido de exclusão de dados (LGPD)', me.nome + ' pediu a exclusão dos dados.' + (val('lg2') ? ' Motivo: ' + val('lg2') : ''), 'alunoD', me.id);
      done('Pedido enviado. A equipe confirma a exclusão.', 'Pediu a exclusão dos próprios dados (LGPD)');
    } });
}

function lgpdCancel() {
  const me = ME();
  S.lgpd.filter(x => x.aid == me.id && x.st == 'pendente').forEach(x => x.st = 'cancelado');
  done('Pedido de exclusão cancelado');
}

