/**
 * aluno/ajuda.js
 * Ajuda e suporte: perguntas frequentes e chamados (acesso, pagamento, problema técnico).
 * É um canal separado das dúvidas de conteúdo, que seguem no mural e nas anotações compartilhadas com o mentor.
 * Cada chamado em S.chamados: { id, aid, cat, t, st: 'aberto'|'respondido'|'resolvido', at, upd, msgs: [{ adm, txt, at }] }.
 */
'use strict';

function S_ajuda() {
  const id = ME().id, f = sub('ajuda', 'faq'), L = S.chamados.filter(c => c.aid == id), q = (ST.fq || '').toLowerCase();
  const novo = L.filter(c => c.st == 'respondido').length;
  let body;
  if (f == 'cham')
    body = `<div class="row sp" style="margin-bottom:14px"><p class="mu" style="margin:0;max-width:560px">Problema de acesso, pagamento ou algo que não funciona no portal. A equipe responde por aqui e você é avisado.</p><button class="btn" onclick="chNovo()">${ic('plus')}Abrir chamado</button></div>` +
      (L.length ? `<div class="card">${L.map(c => `<button class="li cht" onclick="chVer('${c.id}')"><span class="ico ${c.st == 'respondido' ? 'gd' : ''}">${ic('msg')}</span><span class="grow"><b>${E(c.t)}</b><span class="sm-t">${E(c.cat)} · aberto em ${E(c.at)} · ${c.msgs.length} mensagem(ns)</span></span>${tag(...CH_ST[c.st])}</button>`).join('')}</div>` : empty('Nenhum chamado', 'Quando precisar da equipe, abra um chamado. Antes, vale conferir as perguntas frequentes.'));
  else {
    const F2 = S.faq.filter(x => !q || (x.q + x.a + x.cat).toLowerCase().includes(q)), cats = [...new Set(F2.map(x => x.cat))];
    body = `<div class="toolbar"><input class="search" id="fqq" placeholder="Buscar nas perguntas frequentes" value="${E(ST.fq || '')}" oninput="ST.fq=this.value;clearTimeout(window._fq);window._fq=setTimeout(()=>{keep();render();const i=$('#fqq');i.focus();i.setSelectionRange(i.value.length,i.value.length)},250)"></div>` +
      (cats.map(c => `<h4 class="faq-c">${E(c)}</h4>${F2.filter(x => x.cat == c).map(x => `<details class="faq"><summary>${E(x.q)}<span class="chev">${ic('down')}</span></summary><p>${E(x.a)}</p></details>`).join('')}`).join('') || empty('Nada encontrado', 'Tente outras palavras ou abra um chamado.')) +
      `<div class="card flat faq-f"><div class="grow"><b>Não achou a resposta?</b><span class="sm-t">Acesso, pagamento e problemas técnicos: abra um chamado. Dúvida sobre o conteúdo da aula: use o mural ou compartilhe uma anotação com o mentor.</span></div><button class="btn sm" onclick="chNovo()">${ic('plus')}Abrir chamado</button></div>`;
  }
  return tabs('ajuda', [['faq', 'Perguntas frequentes'], ['cham', 'Meus chamados', novo || L.length || '']], 'faq') + body;
}

function chNovo() {
  modal('Abrir chamado', F('Assunto', `<select id="c1">${CHCAT.map(c => `<option>${c}</option>`).join('')}</select>`) + F('Resumo', `<input id="c2" placeholder="Ex.: Não consigo abrir a gravação da aula 3" maxlength="90">`) + F('O que está acontecendo?', `<textarea id="c3" rows="5" placeholder="Conte o que você tentou fazer, o que apareceu e em qual aparelho (celular ou computador)."></textarea>`), { wide: true, label: 'Enviar chamado', ok: () => {
      if (val('c2').length < 5 || val('c3').length < 10) {
        toast('Preencha o resumo e descreva o problema');
        return false;
      }
      const me = ME(), c = { id: uid(), aid: me.id, cat: val('c1'), t: val('c2'), st: 'aberto', at: stamp(), upd: stamp(), msgs: [{ adm: false, txt: val('c3'), at: stamp() }] };
      S.chamados.unshift(c);
      notifyM('Chamado de ' + me.nome + ' (' + c.cat + ')', c.t, 'suporte');
      ST.ajuda = 'cham';
      done('Chamado aberto. A equipe responde por aqui.', 'Abriu um chamado: ' + c.t);
    } });
}

