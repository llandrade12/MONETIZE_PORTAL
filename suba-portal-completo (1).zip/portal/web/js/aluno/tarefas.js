/**
 * aluno/tarefas.js
 * Página do aluno: tarefas. A entrega pode ser por escrito na plataforma, com arquivo anexado, ou os dois.
 */
'use strict';

function S_tarefas() {
  const id = ME().id, f = sub('tarefas', 'pend'), T = tarefasDe(id);
  const L = T.filter(tLib), P = L.filter(t => !S.ent[id + '-' + t.id]), En = L.filter(t => S.ent[id + '-' + t.id]);
  const list = f == 'pend' ? P : f == 'ent' ? En : T;
  return `<p class="mu" style="max-width:640px">Responda por escrito aqui mesmo ou anexe um arquivo (PDF, PowerPoint, Excel, Word e outros). Cada entrega é avaliada pelo mentor e alimenta uma competência.</p>` +
    tabs('tarefas', [['pend', 'Pendentes', P.length], ['ent', 'Entregues', En.length], ['todas', 'Todas', T.length]]) +
    (list.length ? `<div class="stack">${list.map(t => {
      const k = id + '-' + t.id, [s, c] = tStatus(id, t), e = S.ent[k], n = S.notas[k], rs = S.rasc[k], ct = S.contest.find(x => x.aid == id && x.tid == t.id), au = t.aula && aulaN(t.aula);
      return `<div class="card"><div class="row sp" style="align-items:flex-start"><div style="flex:1;min-width:220px"><div class="row" style="margin-bottom:6px">${tag(t.comp, 'gd')}<span class="sm-t">${E(t.freq)}${au ? ', aula: ' + E(au.nome) : ''}</span></div><h3>${E(t.t)}</h3><p class="mu" style="margin:6px 0 0;white-space:pre-line">${E(t.desc)}</p></div><div style="text-align:right">${tag(s, c)}<div class="sm-t" style="margin-top:8px">Prazo ${DL(due(id, t))}</div></div></div>
  ${(t.links || []).length ? `<div class="tlk"><span class="sm-t">Material do mentor</span><div class="row" style="gap:8px;margin-top:6px">${t.links.map(l => `<a class="btn s sm" href="${E(safeUrl(l.u))}" target="_blank" rel="noopener">${ic('link')}${E(l.t)}</a>`).join('')}</div></div>` : ''}
  ${e ? `<div class="card flat" style="margin-top:14px;padding:14px"><div class="sm-t">Sua entrega em ${E(e.at)}</div>${e.txt ? `<p style="margin:6px 0 0;white-space:pre-line">${E(e.txt)}</p>` : ''}${(e.files || []).length ? `<div class="fchips" style="margin-top:10px">${e.files.map(x => fileChip(x)).join('')}</div>` : ''}${e.link ? `<a href="${E(safeUrl(e.link))}" target="_blank" rel="noopener" style="font-size:13px;display:inline-block;margin-top:8px">${E(e.link)}</a>` : ''}</div>` : ''}
  ${n != null ? `<div class="row sp" style="margin-top:14px"><div class="row"><span class="num gold" style="font-size:30px">${f1(n)}</span><span class="sm-t">nota do mentor</span></div>${ct ? (ct.resp ? tag('Contestação respondida', 'ok') : tag('Contestação em análise', 'in')) : `<button class="btn q sm" onclick="contestar(${t.id})">Contestar nota</button>`}</div>${ct && ct.resp ? `<p class="mu" style="margin:8px 0 0">Resposta do mentor: ${E(ct.resp)}</p>` : ''}` : ''}
  ${!e && tLib(t) ? `<div class="row" style="margin-top:14px"><button class="btn" ${ro() ? 'disabled' : ''} onclick="entregar(${t.id})">${ic(rs ? 'edit' : 'upload')}${rs ? 'Continuar entrega' : 'Entregar tarefa'}</button>${rs ? `<span class="rsc">${ic('note')}Rascunho salvo em ${E(rs.at)}</span>` : ''}</div>` : ''}
  ${e && n == null && !ro() ? `<div class="row" style="margin-top:12px"><button class="btn q sm" onclick="entregar(${t.id})">Editar entrega</button>${rs ? `<span class="rsc">${ic('note')}Edição em rascunho, ainda não enviada</span>` : ''}</div>` : ''}</div>`;
    }).join('')}</div>` : empty(f == 'pend' ? 'Nenhuma tarefa pendente' : 'Nada por aqui', 'Novas tarefas aparecem quando são liberadas pelo mentor.'));
}

/* Arquivos da entrega em edição: os já enviados que ficam (keep) e os novos (add). */
let UP = { keep: [], add: [] };

function upList() {
  const el = $('#eflist');
  if (el)
    el.innerHTML = UP.keep.map((f, i) => fileChip(f, `UP.keep.splice(${i},1);upList()`)).join('') + UP.add.map((f, i) => fileChip(f, `UP.add.splice(${i},1);upList()`)).join('');
}

function upAdd(files) {
  for (const f of files) {
    if (UP.keep.length + UP.add.length >= 5) {
      toast('Máximo de 5 arquivos por entrega');
      break;
    }
    if (!FEXT.includes(fext(f.name))) {
      toast('Formato não aceito: ' + f.name);
      continue;
    }
    if (f.size > FMAX * 1048576) {
      toast(f.name + ' passa de ' + FMAX + ' MB');
      continue;
    }
    UP.add.push(f);
  }
  upList();
}

/* Rascunho automático: o que o aluno digita fica guardado no servidor, mesmo se ele fechar a janela ou trocar de aparelho. */
let rT;

function rascIn(k) {
  const txt = $('#et').value, link = $('#el').value.trim(), e = S.ent[k] || {};
  if (!txt.trim() && !link)
    delete S.rasc[k];
  else if (txt == (e.txt || '') && link == (e.link || ''))
    delete S.rasc[k];
  else
    S.rasc[k] = { txt, link, at: stamp() };
  const el = $('#rst');
  if (el)
    el.textContent = S.rasc[k] ? 'Salvando rascunho…' : '';
  clearTimeout(rT);
  rT = setTimeout(() => {
    save();
    const x = $('#rst');
    if (x && S.rasc[k])
      x.textContent = 'Rascunho salvo às ' + S.rasc[k].at.slice(11);
  }, 500);
}

function rascDel(tid) {
  delete S.rasc[ME().id + '-' + tid];
  save();
  closeM();
  render();
  setTimeout(() => entregar(tid), 30);
}

function entregar(tid) {
  const t = S.tarefas.find(x => x.id == tid), k = ME().id + '-' + tid, env = S.ent[k] || {}, rs = S.rasc[k], e = rs ? { ...env, txt: rs.txt, link: rs.link } : env;
  UP = { keep: (e.files || []).slice(), add: [] };
  modal('Entregar tarefa', `<p class="sm-t" style="margin:0 0 14px">Você pode responder por escrito, anexar arquivo, ou os dois. O texto fica salvo como rascunho enquanto você escreve.</p>` +
    (rs ? `<div class="card flat rsb"><span>${ic('note')}Continuando do rascunho de ${E(rs.at)}.</span><button type="button" class="btn q sm" onclick="rascDel(${tid})">Descartar rascunho</button></div>` : '') +
    `<label class="f"><span class="row sp"><span>Resposta por escrito</span><small id="rst" class="rst"></small></span><textarea id="et" rows="6" placeholder="Descreva o que você fez e o principal aprendizado" oninput="rascIn('${k}')">${E(e.txt || '')}</textarea></label>` +
    `<div class="f"><span>Anexar arquivos</span><label class="drop" id="edrop" ondragover="event.preventDefault();this.classList.add('on')" ondragleave="this.classList.remove('on')" ondrop="event.preventDefault();this.classList.remove('on');upAdd(event.dataTransfer.files)"><input type="file" id="ef" multiple accept="${FEXT.map(x => '.' + x).join(',')}" onchange="upAdd(this.files);this.value=''">${ic('upload')}<b>Escolher arquivos</b><small>ou arraste para cá · PDF, PPTX, XLSX, DOCX, imagens · até ${FMAX} MB cada</small></label><div class="fchips" id="eflist" style="margin-top:10px"></div></div>` +
    F('Link (opcional)', `<input id="el" placeholder="https://" value="${E(e.link || '')}" oninput="rascIn('${k}')">`, 'Google Drive, Docs, vídeo ou outro link https. Os arquivos anexados não entram no rascunho: anexe na hora de enviar.'), { sub: E(t.t), label: 'Enviar entrega', cancel: 'Fechar e continuar depois', ok: () => {
      const txt = val('et'), l = val('el');
      if (txt.length < 10 && !UP.keep.length && !UP.add.length) {
        toast('Escreva sua resposta ou anexe um arquivo');
        return false;
      }
      if (l && !safeUrl(l)) {
        toast('O link precisa começar com https://');
        return false;
      }
      enviarEntrega(t, k, txt, l);
      return false;
    } });
  $('#modal').dataset.re = '1';
  upList();
}

async function enviarEntrega(t, k, txt, link) {
  const b = $('#mok'), antigos = (S.ent[k] || {}).files || [];
  if (b) {
    b.disabled = true;
    b.textContent = 'Enviando…';
  }
  const files = UP.keep.slice();
  for (const f of UP.add.slice()) {
    /* Cada arquivo sobe para o servidor antes de a entrega ser registrada. Se um falhar, nada é enviado pela metade. */
    const id = 'f' + uid();
    if (!await fput(id, f)) {
      if (b) {
        b.disabled = false;
        b.textContent = 'Enviar entrega';
      }
      UP.keep = files;
      UP.add = UP.add.slice(UP.add.indexOf(f));
      upList();
      return toast(FILES.erro + ': ' + f.name);
    }
    files.push({ id, name: f.name, size: f.size, type: f.type });
  }
  antigos.filter(o => !files.some(f => f.id == o.id)).forEach(o => fdel(o.id));
  S.ent[k] = { at: stamp(), txt, link, files };
  clearTimeout(rT);
  delete S.rasc[k];
  closeM();
  done('Tarefa entregue', 'Entregou a tarefa: ' + t.t + (files.length ? ' (' + files.length + ' arquivo(s))' : ''));
}

function contestar(tid) {
  modal('Contestar nota', F('Motivo', `<textarea id="ct" rows="4" placeholder="Explique por que a nota deve ser revista"></textarea>`, 'O mentor recebe uma notificação e a contestação fica registrada no histórico.'), { label: 'Enviar contestação', ok: () => {
      if (val('ct').length < 10) {
        toast('Explique o motivo com mais detalhes');
        return false;
      }
      S.contest.push({ id: uid(), aid: ME().id, tid, msg: val('ct'), at: stamp(), resp: '' });
      done('Contestação enviada ao mentor', 'Contestou a nota da tarefa ' + tid);
    } });
}
