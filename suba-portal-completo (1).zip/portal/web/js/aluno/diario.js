/**
 * aluno/diario.js
 * Diário e anotações do aluno: espaço privado, com uma anotação por aula e anotações livres.
 * O aluno escolhe, nota a nota, se compartilha com o mentor (que pode responder).
 * Cada item de S.diario: { id, aid, n (aula ou null), tit, txt, at, upd, share, resp, respAt }.
 */
'use strict';

const dAula = (aid, n) => S.diario.find(d => d.aid == aid && d.n == n);

let dT;

/* Digitação na anotação da aula: guarda na hora e grava sem redesenhar a tela (o vídeo continua tocando). */
function dAulaIn(n, txt) {
  const id = ME().id;
  let d = dAula(id, n);
  if (!d) {
    if (!txt.trim())
      return;
    d = { id: uid(), aid: id, n, tit: '', txt: '', at: stamp(), upd: stamp(), share: false, resp: '' };
    S.diario.unshift(d);
  }
  d.txt = txt;
  d.upd = stamp();
  clearTimeout(dT);
  dT = setTimeout(() => {
    save();
    const el = document.getElementById('nast');
    if (el)
      el.textContent = 'Salvo às ' + d.upd.slice(11);
  }, 500);
}

function dShare(n, on) {
  const id = ME().id;
  let d = dAula(id, n);
  if (!d || !d.txt.trim()) {
    const c = document.getElementById('nash');
    if (c)
      c.checked = false;
    return toast('Escreva a anotação antes de compartilhar');
  }
  dSetShare(d, on);
  save();
  toast(on ? 'Anotação compartilhada com o mentor' : 'Anotação voltou a ser privada');
}

function dSetShare(d, on) {
  d.share = on;
  if (on && !d.avisou) {
    d.avisou = 1;
    notifyM('Anotação compartilhada por ' + nm(d.aid), (d.n && aulaN(d.n) ? 'Sobre a aula "' + aulaN(d.n).nome + '": ' : '') + d.txt.slice(0, 140), 'alunoD', d.aid);
  }
}

function S_diario() {
  const id = ME().id, f = sub('diario', 'todas'), all = S.diario.filter(d => d.aid == id && (d.txt || '').trim());
  const L = all.filter(d => f == 'todas' || (f == 'aulas' ? d.n : f == 'livres' ? !d.n : d.share));
  return `<div class="row sp" style="margin-bottom:16px"><p class="mu" style="margin:0;max-width:600px">Seu espaço privado. Anote por aula ou escreva livremente. Só o que você marcar como compartilhado chega ao mentor.</p><button class="btn" ${ro() ? 'disabled' : ''} onclick="dForm()">${ic('plus')}Nova anotação</button></div>` +
    tabs('diario', [['todas', 'Todas', all.length], ['aulas', 'Por aula', all.filter(d => d.n).length], ['livres', 'Livres', all.filter(d => !d.n).length], ['comp', 'Compartilhadas', all.filter(d => d.share).length]], 'todas') +
    (L.length ? `<div class="stack">${L.map(d => {
      const a = d.n && aulaN(d.n);
      return `<article class="card dn ${d.share ? 'sh' : ''}"><div class="row sp" style="align-items:flex-start;gap:10px"><div style="min-width:0"><b>${E(a ? a.nome : d.tit || 'Anotação livre')}</b><div class="sm-t">${a ? 'Aula de ' + DF(a.date) + ' · ' : ''}atualizada em ${E(d.upd)}</div></div><div class="row" style="gap:6px">${d.share ? tag('Compartilhada', 'gd') : tag('Privada', '')}</div></div>
<p style="white-space:pre-line;margin:12px 0 0">${E(d.txt)}</p>
${d.resp ? `<div class="card flat" style="margin-top:12px;padding:12px 14px"><span class="sm-t">Resposta do mentor · ${E(d.respAt || '')}</span><p style="margin:4px 0 0;white-space:pre-line">${E(d.resp)}</p></div>` : ''}
<div class="row" style="margin-top:14px">${a ? `<button class="btn s sm" onclick="nav('aula',${a.n})">${ic('play')}Abrir aula</button>` : ''}<button class="btn s sm" ${ro() ? 'disabled' : ''} onclick="dForm('${d.id}')">${ic('edit')}Editar</button><button class="btn q sm" ${ro() ? 'disabled' : ''} onclick="dTog('${d.id}')">${d.share ? 'Tornar privada' : 'Compartilhar com o mentor'}</button><button class="btn q sm" aria-label="Excluir anotação" ${ro() ? 'disabled' : ''} onclick="dDel('${d.id}')">${ic('trash')}</button></div></article>`;
    }).join('')}</div>` : empty('Nada anotado aqui', f == 'todas' ? 'Abra uma aula e use "Minhas anotações", ou crie uma anotação livre.' : 'Nenhuma anotação neste filtro.'));
}

function dForm(did) {
  const id = ME().id, d = did ? S.diario.find(x => x.id == did) : {}, L = aulasCtx().filter(a => !dAula(id, a.n) || a.n == d.n);
  modal(did ? 'Editar anotação' : 'Nova anotação', F('Sobre', `<select id="d1" ${did ? 'disabled' : ''}><option value="">Anotação livre (sem aula)</option>${L.map(a => `<option value="${a.n}" ${a.n == d.n ? 'selected' : ''}>${DF(a.date)} · ${E(a.nome)}</option>`).join('')}</select>`) +
    F('Título (opcional)', `<input id="d2" value="${E(d.tit || '')}" placeholder="Ex.: Ideias para a reunião de segunda">`) +
    F('Anotação', `<textarea id="d3" rows="7">${E(d.txt || '')}</textarea>`) +
    `<label class="chk"><input type="checkbox" id="d4" ${d.share ? 'checked' : ''}> Compartilhar com o mentor</label>`, { wide: true, label: 'Salvar anotação', ok: () => {
      if (val('d3').length < 2) {
        toast('Escreva a anotação');
        return false;
      }
      const o = did ? d : { id: uid(), aid: id, n: +val('d1') || null, at: stamp(), share: false, resp: '' };
      o.tit = val('d2');
      o.txt = val('d3');
      o.upd = stamp();
      if (!did)
        S.diario.unshift(o);
      dSetShare(o, $('#d4').checked);
      done('Anotação salva', 'Salvou uma anotação no diário');
    } });
}

function dTog(did) {
  const d = S.diario.find(x => x.id == did);
  dSetShare(d, !d.share);
  keep();
  done(d.share ? 'Anotação compartilhada com o mentor' : 'Anotação voltou a ser privada', d.share ? 'Compartilhou uma anotação com o mentor' : 'Tornou uma anotação privada');
}

function dDel(did) {
  modal('Excluir anotação', '<p>Esta anotação será apagada de vez, inclusive para o mentor se estava compartilhada.</p>', { label: 'Excluir', danger: true, ok: () => {
      S.diario = S.diario.filter(x => x.id != did);
      done('Anotação excluída');
    } });
}
