/**
 * aluno/inicio.js
 * Página do aluno: inicio.
 */
'use strict';

function S_inicio() {
  const me = ME(), id = me.id, n = nextAula(), f = fin(id), done = realizadas().length, tot = aulasCtx().length;
  const pend = tarefasDe(id).filter(t => tLib(t) && !S.ent[id + '-' + t.id]).sort((a, b) => due(id, a) < due(id, b) ? -1 : 1).slice(0, 3);
  const cont = aulasCtx().find(a => aulaLib(a) && !S.vis[id + '-' + a.n]);
  const pin = avisosFor(id).filter(a => a.pin)[0];
  const ultimos = avisosFor(id).slice(0, 2);
  const dd = n ? diff(n.date, hoje()) : 0, fq = freq(id), pc = cont ? progDe(id, cont.n) : null;
  return `<section class="hero"><p class="mu" style="margin-bottom:6px">${DL(hoje())}</p><h1>Olá, ${E(me.nome.split(' ')[0])}. ${tot ? `Você está no degrau ${Math.min(done + 1, tot)} de ${tot}.` : 'Bem-vindo à mentoria.'}</h1>
<p class="mu" style="margin:10px 0 18px;max-width:520px">${tot ? `${done} encontro(s) realizado(s). ${n ? `Próximo encontro ${dd == 0 ? 'hoje' : dd == 1 ? 'amanhã' : 'em ' + dd + ' dias'}.` : 'Todos os encontros agendados foram realizados.'}` : 'Os encontros da sua turma aparecem aqui assim que o mentor agendar.'}</p>
${climb()}
<div class="row" style="margin-top:20px">${cont ? `<button class="btn" onclick="nav('aula',${cont.n})">${ic('play')}${pc.t > 15 ? 'Continuar de ' + fmtT(pc.t) : 'Assistir'}: ${E(cont.nome)}</button>` : ''}<button class="btn s" onclick="nav('agenda')">${ic('cal')}Ver agenda</button></div></section>
${fq.abaixo ? `<div class="card alert fq-al" style="margin-top:16px"><span class="ico er">${ic('alert')}</span><div class="grow"><b>Sua frequência está em ${fq.pct}%, abaixo do mínimo de ${fq.min}%.</b><p class="mu" style="margin:4px 0 0">Sem o mínimo você fica sem o certificado. Veja o que dá para compensar ou justificar.</p></div><button class="btn sm" onclick="nav('frequencia')">Ver minha frequência</button></div>` : ''}
${pin ? `<div class="card gold" style="margin-top:16px"><div class="row" style="gap:12px;align-items:flex-start"><span class="ico gd">${ic('pin')}</span><div style="flex:1;min-width:0"><b>${E(pin.t)}</b><p class="mu" style="margin:4px 0 0">${E(pin.m)}</p></div></div></div>` : ''}
<div class="g4 sec" style="margin-top:16px">
<div class="kpi"><span class="lb">Nota final</span><span class="num gold">${f1(f)}</span><small>média ponderada das competências</small></div>
<div class="kpi"><span class="lb">Tarefas entregues</span><span class="num">${entPct(id)}%</span>${bar(entPct(id))}</div>
<button class="kpi" onclick="nav('frequencia')"><span class="lb">Frequência</span><span class="num ${fq.abaixo ? 'er' : ''}">${fq.n ? fq.pct + '%' : '—'}</span><div class="bar ${fq.abaixo ? '' : 'ok'}"><i style="width:${fq.n ? fq.pct : 0}%"></i><u style="left:${fq.min}%"></u></div><small>${fq.n ? fq.ok + ' de ' + fq.n + ' encontros · mínimo ' + fq.min + '%' : 'mínimo de ' + fq.min + '%'}</small></button>
<div class="kpi"><span class="lb">Aulas assistidas</span><span class="num">${realizadas().filter(a => S.vis[id + '-' + a.n]).length}/${done}</span>${bar(visPct(id))}</div></div>
<div class="main2 sec">
<div class="stack">
${n ? `<div class="card"><div class="ch"><h3>Próximo encontro</h3>${n.aberta ? tag('Aberta a convidados', 'gd') : ''}</div>
<div class="li" style="padding:0;border:0"><div class="dbox gd"><b>${D(n.date).getDate()}</b><small>${MES[D(n.date).getMonth()]}</small></div><div class="grow"><b>${E(n.nome)}</b><span class="sm-t">${DL(n.date)}, ${n.hora}, com ${E(n.mentor)}</span></div></div>
<p class="mu" style="margin:14px 0">${pautaLib(n) ? E(n.obj || 'Pauta ainda não publicada.') : 'A pauta desta aula é liberada na véspera do encontro.'}</p>
<div class="row"><button class="btn sm" onclick="nav('aula',${n.n})">Ver detalhes</button><button class="btn s sm" onclick="calAdd('a',${n.n})">${ic('calplus')}Adicionar à agenda</button>${pautaLib(n) && safeUrl(n.link) ? `<a class="btn s sm" href="${E(safeUrl(n.link))}" target="_blank" rel="noopener">${ic('link')}Link da reunião</a>` : ''}</div></div>` : ''}
<div class="card"><div class="ch"><h3>Tarefas da semana</h3><button class="btn q sm" onclick="nav('tarefas')">Ver todas</button></div>
${pend.length ? pend.map(t => {
    const [s, c] = tStatus(id, t);
    return `<div class="li"><span class="ico ${c == 'er' ? 'er' : 'gd'}">${ic('check')}</span><div class="grow"><b>${E(t.t)}</b><span class="sm-t">Prazo ${DL(due(id, t))}, ${E(t.comp)}</span></div>${tag(s, c)}</div>`;
  }).join('') : empty('Tudo entregue', 'Nenhuma tarefa pendente agora.')}</div>
</div>
<div class="stack">
<div class="card"><div class="ch"><h3>Competências</h3><button class="btn q sm" onclick="nav('evolucao')">Detalhes</button></div>
${CK().map(c => {
    const v = compAvg(id, c);
    return `<div style="margin-bottom:12px"><div class="row sp" style="font-size:13px;margin-bottom:5px"><span>${c}</span><b>${f1(v)}</b></div>${bar((v || 0) * 10)}</div>`;
  }).join('')}</div>
<div class="card"><div class="ch"><h3>Mural</h3><button class="btn q sm" onclick="nav('mural')">Abrir</button></div>
${ultimos.map(a => `<div class="li"><div class="grow"><b>${E(a.t)}</b><span class="sm-t">${E(a.at.slice(0, 5))}, ${E(a.autor)}</span></div></div>`).join('') || '<p class="mu">Sem avisos.</p>'}</div>
</div></div>`;
}
