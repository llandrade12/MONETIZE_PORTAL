/**
 * aluno/aulas.js
 * Página do aluno: aulas da turma dele, organizadas por unidade (quando a turma tem unidades) ou por competência.
 * A página da aula traz o player incorporado, os materiais de apoio e as anotações do aluno.
 */
'use strict';

function S_aulas() {
  const me = ME(), id = me.id, L = aulasCtx(), nx = nextAula(), t = turmaDe(id), UN = t.unidades || [];
  if (!L.length && !UN.length)
    return empty('Nenhuma aula por enquanto', 'Assim que o mentor agendar os encontros da sua turma, eles aparecem aqui e na agenda.');
  /* grupo = [nome, aulas, quantidade prevista] */
  const grupos = (UN.length
    ? UN.map(u => [u.nome, L.filter(a => (a.un || {})[t.id] == u.id), +u.qtd || 0]).concat([['Outros encontros', L.filter(a => !UN.some(u => u.id == (a.un || {})[t.id])), 0]])
    : CK().map(c => [c, L.filter(a => a.comp == c), 0]).concat([['Outros encontros', L.filter(a => !CK().includes(a.comp)), 0]])).filter(g => g[1].length || g[2]);
  const tot = grupos.reduce((s, g) => s + Math.max(g[1].length, g[2]), 0);
  return `<p class="mu" style="margin-bottom:18px;max-width:640px">${tot} encontro(s) em ${grupos.length} ${UN.length ? (grupos.length == 1 ? 'unidade' : 'unidades') : (grupos.length == 1 ? 'competência' : 'competências')}. Cada aula mostra a pauta na véspera e, depois do encontro, a gravação, os materiais e as suas anotações.</p>` +
    grupos.map(([nome, A, q], i) => {
      const lib = A.filter(aulaLib), v = lib.filter(a => S.vis[id + '-' + a.n]).length, n = Math.max(A.length, q), falta = n - A.length;
      const open = grupos.length == 1 || A.some(a => nx && a.n == nx.n) || (!nx && i == 0);
      return `<details class="mod" ${open ? 'open' : ''}><summary><span class="mn">${i + 1}</span><span class="grow"><b style="font-size:15.5px">${E(nome)}</b><span class="sm-t" style="display:block;margin:2px 0 8px">${n} aula(s)${falta > 0 ? ', ' + falta + ' ainda sem data' : ''} · ${v} de ${lib.length} gravações assistidas</span>${bar(pct(v, n))}</span><span class="chev">${ic('down')}</span></summary>${A.map(a => aulaRow(a, id)).join('')}${falta > 0 ? `<div class="al ghost"><span class="n">+${falta}</span><span class="grow"><b>${falta} aula(s) desta unidade a agendar</b><span class="sm-t">As datas aparecem aqui e na agenda assim que forem definidas.</span></span></div>` : ''}</details>`;
    }).join('');
}

function S_aula() {
  const a = aulaN(R.a), me = ME(), id = me.id, L = aulasCtx(), i = L.indexOf(a), lib = aulaLib(a), pl = pautaLib(a), k = id + '-' + a.n, v = S.vis[k], pr = L[i - 1], nx = L[i + 1];
  const tk = tarefasDe(id).filter(t => t.aula == a.n), src = lib && vsrc(a.video), mats = matsVis(a), un = unDe(a, me.turma), d = dAula(id, a.n);
  const conta = freqBase(id).includes(a), st = lib && conta ? freqSt(id, a) : '', j = S.just.find(x => x.aid == id && x.n == a.n && x.st == 'pendente');
  const manual = src && (!src.auto || ST.plManual == a.n);
  return `<div class="main2"><div class="stack">
<div>${playerBox(a, id)}</div>
<div><h1 style="font-size:clamp(28px,3.6vw,36px)">${E(a.nome)}</h1><div class="row" style="margin-top:10px">${un ? tag(un.nome, '') : ''}${a.comp ? tag(a.comp, 'gd') : ''}${lib ? (a.status == 'parcial' ? tag('Sessão parcial', 'wn') : tag('Realizada', 'ok')) : tag('Agendada', 'in')}${a.aberta ? tag('Aberta a convidados', 'gd') : ''}<span id="vistag">${v ? tag('Assistida', 'ok') : ''}</span></div></div>
${a.status == 'parcial' ? `<div class="card" style="border-color:var(--wn)"><b>Esta sessão foi interrompida.</b><p class="mu" style="margin:4px 0 0">A gravação completa de reposição está disponível no player acima.</p></div>` : ''}
${a.motivo ? `<div class="card flat"><b>Aula reagendada</b><p class="mu" style="margin:4px 0 0">Motivo informado: ${E(a.motivo)}</p></div>` : ''}
<div class="card"><h3 style="margin-bottom:10px">${lib ? 'Sobre esta aula' : 'Pauta do encontro'}</h3>
${pl ? (a.obj || a.topicos.length ? `<p>${E(a.obj)}</p><ul class="topics">${a.topicos.map(t => `<li>${E(t)}</li>`).join('')}</ul>` : '<p class="mu" style="margin:0">O mentor ainda não publicou a pauta deste encontro.</p>') : `<p class="mu" style="margin:0">A pauta, com objetivo e tópicos, é liberada na véspera do encontro (${DF(addD(a.date, -1))}).</p>`}</div>
${lib || mats.length ? `<div class="card"><div class="ch" style="margin-bottom:6px"><h3>Material de apoio</h3>${mats.length ? `<span class="sm-t">${mats.length} arquivo(s)</span>` : ''}</div>${mats.map((m, x) => matRow(a, m, x)).join('') || '<p class="mu" style="margin:0">Nenhum material anexado a esta aula.</p>'}</div>` : ''}
<div class="card"><div class="ch" style="margin-bottom:8px"><h3>Minhas anotações</h3><span class="sm-t" id="nast">${d ? 'Salvo em ' + E(d.upd) : 'Só você vê'}</span></div>
<textarea id="natx" rows="5" placeholder="O que ficou desta aula? Ideias, decisões, o que você vai aplicar. Salva sozinho enquanto você escreve." ${ro() ? 'disabled' : ''} oninput="dAulaIn(${a.n},this.value)">${E(d ? d.txt : '')}</textarea>
<div class="row sp" style="margin-top:10px"><label class="chk" style="font-size:13px;align-items:center"><input type="checkbox" id="nash" ${d && d.share ? 'checked' : ''} ${ro() ? 'disabled' : ''} onchange="dShare(${a.n},this.checked)"> Compartilhar esta anotação com o mentor</label><button class="btn q sm" onclick="nav('diario')">${ic('note')}Abrir diário</button></div>
${d && d.resp ? `<div class="card flat" style="margin-top:12px;padding:12px 14px"><span class="sm-t">Resposta do mentor · ${E(d.respAt || '')}</span><p style="margin:4px 0 0;white-space:pre-line">${E(d.resp)}</p></div>` : ''}</div>
${tk.length ? `<div class="card"><h3 style="margin-bottom:6px">Tarefa ligada a esta aula</h3>${tk.map(t => {
    const [s, c] = tStatus(id, t);
    return `<div class="li"><span class="ico gd">${ic('check')}</span><div class="grow"><b>${E(t.t)}</b><span class="sm-t">Prazo ${DF(due(id, t))}</span></div>${tag(s, c)}<button class="btn s sm" onclick="nav('tarefas')">Abrir</button></div>`;
  }).join('')}</div>` : ''}
</div>
<div class="stack">
<div class="card"><dl class="meta"><dt>Data</dt><dd>${DL(a.date)}</dd><dt>Horário</dt><dd>${a.hora}${a.dur ? ' · ' + (a.dur >= 60 ? Math.floor(a.dur / 60) + 'h' + (a.dur % 60 ? p2(a.dur % 60) : '') : a.dur + ' min') : ''}</dd><dt>Mentor</dt><dd>${E(a.mentor)}</dd>${un ? `<dt>Unidade</dt><dd>${E(un.nome)}</dd>` : ''}${a.comp ? `<dt>Competência</dt><dd>${E(a.comp)}</dd>` : ''}<dt>Presença</dt><dd>${st ? tag(PST[st][0], PST[st][1]) : lib ? 'Antes da sua matrícula' : '—'}</dd></dl>
${st == 'F' ? `<p class="sm-t" style="margin:12px 0 0">${j ? 'Sua justificativa está em análise pelo mentor.' : src && S.cfg.compensa ? 'Assista à gravação até o fim para compensar esta falta.' : 'Você pode justificar esta falta.'}</p>` : ''}
<div style="margin-top:16px;display:grid;gap:8px">
${lib && src ? `<button class="btn ${v ? 's' : ''} full" id="plman" ${manual ? '' : 'hidden'} onclick="toggleVis(${a.n})">${ic('ok')}${v ? 'Assistida (desmarcar)' : 'Marcar como assistida'}</button>` : ''}
${!lib && pl && safeUrl(a.link) ? `<a class="btn full" href="${E(safeUrl(a.link))}" target="_blank" rel="noopener">${ic('link')}Entrar na reunião</a>` : ''}
${!lib ? `<button class="btn s full" onclick="calAdd('a',${a.n})">${ic('calplus')}Adicionar à minha agenda</button>` : ''}
${st == 'F' && !j && !ro() ? `<button class="btn s full" onclick="justificar(${a.n})">${ic('msg')}Justificar falta</button>` : ''}
<button class="btn q full" onclick="nav('frequencia')">${ic('roll')}Minha frequência</button></div></div>
<div class="row sp">${pr ? `<button class="btn s sm" onclick="nav('aula',${pr.n})">${ic('left')}Anterior</button>` : '<span></span>'}${nx ? `<button class="btn s sm" onclick="nav('aula',${nx.n})">Próxima${ic('right')}</button>` : ''}</div>
</div></div>`;
}

/* Marcação manual: só para vídeos que não informam o progresso (Drive, outros links). */
function toggleVis(n) {
  const k = ME().id + '-' + n;
  if (S.vis[k])
    delete S.vis[k];
  else
    S.vis[k] = 1;
  done(S.vis[k] ? 'Aula marcada como assistida' : 'Marcação removida');
}

/* Linha de uma aula na lista. */
function aulaRow(a, aid) {
  const v = S.vis[aid + '-' + a.n], lib = aulaLib(a), nx = nextAula(), p = progDe(aid, a.n);
  return `<button class="al" onclick="nav('aula',${a.n})"><span class="n ${v ? 'd' : lib ? 'w' : ''}">${v ? ic('ok') : ord(a)}</span><span class="grow"><b>${E(a.nome)}${a.aberta ? ' <span class="tag gd" style="margin-left:6px">Aberta a convidados</span>' : ''}</b><span class="sm-t">${DL(a.date)}, ${a.hora}</span></span>${lib ? (a.status == 'parcial' ? tag('Parcial, com reposição', 'wn') : v ? tag('Assistida', 'ok') : p.p ? tag(p.p + '% assistido', 'in') : tag('Disponível', 'gd')) : nx && nx.n == a.n ? tag('Próxima', 'in') : `<span class="hide-m">${ic('lock')}</span>`}</button>`;
}
