/**
 * aluno/frequencia.js
 * Página do aluno: Minha frequência. Percentual, "X de Y encontros", a situação aula a aula,
 * quantas faltas ainda cabem antes de perder o certificado e o pedido de justificativa.
 */
'use strict';

function S_freq() {
  const me = ME(), id = me.id, f = freq(id), t = turmaDe(id), c = S.cfg;
  const cls = !f.n ? '' : f.abaixo ? 'er' : f.restam == 0 && f.faltas ? 'wn' : 'ok';
  const pend = S.just.filter(j => j.aid == id), rest = Math.max(0, f.tot - f.n);
  /* Quantos dos encontros que faltam ele precisa frequentar para fechar no mínimo. */
  const precisa = Math.max(0, Math.ceil(f.tot * f.min / 100 - 1e-9) - f.ok);
  const aviso = !f.n ? '' : f.abaixo && precisa > rest
    ? `<div class="card alert fq-al"><span class="ico er">${ic('alert')}</span><div><b>Sua frequência está abaixo do mínimo e não fecha mais só com presença.</b><p class="mu" style="margin:4px 0 0">${c.compensa ? 'Assista às gravações dos encontros que você perdeu: cada uma compensa uma falta.' : 'Fale com o mentor.'} Faltas com motivo podem ser justificadas na lista abaixo.</p></div></div>`
    : f.abaixo
      ? `<div class="card alert fq-al"><span class="ico er">${ic('alert')}</span><div><b>Sua frequência está abaixo do mínimo de ${f.min}%.</b><p class="mu" style="margin:4px 0 0">Você precisa estar em ${precisa} dos ${rest} encontro(s) que faltam${c.compensa ? ', ou compensar faltas assistindo às gravações' : ''}. O mentor já foi avisado.</p></div></div>`
      : f.restam == 0 && f.faltas
        ? `<div class="card fq-al" style="border-color:var(--wn)"><span class="ico gd">${ic('alert')}</span><div><b>Você está no limite de faltas.</b><p class="mu" style="margin:4px 0 0">Mais uma falta e a frequência fica abaixo de ${f.min}%.</p></div></div>` : '';
  return `${aviso}<div class="fq-top"><div class="card fq-ring ${cls}"><div class="ring" style="--p:${f.n ? f.pct : 0}" role="img" aria-label="Frequência de ${f.pct}%"><span><b>${f.n ? f.pct + '%' : '—'}</b><small>frequência</small></span></div>
<div class="fq-min"><div class="bar ${cls == 'ok' ? 'ok' : ''}"><i style="width:${f.n ? f.pct : 0}%"></i><u style="left:${f.min}%"></u></div><div class="row sp sm-t" style="margin-top:6px"><span>0%</span><span>mínimo ${f.min}%</span><span>100%</span></div></div></div>
<div class="g3 fq-k"><div class="kpi"><span class="lb">Encontros</span><span class="num">${f.ok}<span class="ks"> de ${f.n}</span></span><small>${f.n ? 'você esteve em ' + f.ok + ' de ' + f.n + ' encontros' : 'nenhum encontro realizado ainda'}</small></div>
<div class="kpi"><span class="lb">Faltas que ainda cabem</span><span class="num ${f.restam <= 0 && f.n ? 'er' : ''}">${Math.max(0, f.restam)}</span><small>${f.faltas} de ${f.maxF} permitidas já usadas, em ${f.tot} encontros previstos</small></div>
<div class="kpi"><span class="lb">Certificado</span><span class="num" style="font-size:22px;line-height:1.5">${!c.certFreq ? 'Sem exigência' : S.certLib[id] ? 'Liberado' : f.abaixo ? 'Em risco' : 'Garantido até aqui'}</span><small>${c.certFreq ? 'exige frequência mínima de ' + f.min + '%' : 'a frequência não bloqueia o certificado'}</small></div></div></div>
<div class="main2 sec" style="margin-top:16px"><div class="card"><div class="ch"><h3>Aula a aula</h3><span class="sm-t">desde a sua matrícula, em ${DFY(me.mat)}</span></div>
${f.B.map((a, i) => {
    const s = f.st[i], j = pend.find(x => x.n == a.n && x.st == 'pendente'), rec = pend.find(x => x.n == a.n && x.st == 'recusada'), temV = !!vsrc(a.video), obs = S.presObs[id + '-' + a.n];
    return `<div class="li fq-r"><div class="dbox ${s == 'F' ? '' : 'gd'}"><b>${D(a.date).getDate()}</b><small>${MES[D(a.date).getMonth()]}</small></div><div class="grow"><b>${E(a.nome)}</b><span class="sm-t">${DOW[D(a.date).getDay()]}, ${a.hora}${s == 'J' && obs ? ' · motivo: ' + E(obs) : ''}${j ? ' · justificativa em análise' : ''}${s == 'F' && rec ? ' · justificativa recusada' + (rec.resp ? ': ' + E(rec.resp) : '') : ''}</span></div>
<div class="row fq-a">${tag(PST[s][0], PST[s][1])}${s == 'F' && !ro() ? (temV && c.compensa ? `<button class="btn sm" onclick="nav('aula',${a.n})">${ic('play')}Assistir e compensar</button>` : '') + (j ? '' : `<button class="btn s sm" onclick="justificar(${a.n})">Justificar</button>`) : `<button class="btn q sm" aria-label="Abrir aula" onclick="nav('aula',${a.n})">${ic('right')}</button>`}</div></div>`;
  }).join('') || `<p class="mu" style="margin:0">Os encontros aparecem aqui depois de realizados${t.id ? '' : '. Você ainda não está em uma turma'}.</p>`}</div>
<div class="stack"><div class="card"><h3 style="margin-bottom:8px">Como a frequência é calculada</h3><ul class="topics">
<li>Contam só os encontros realizados <b>desde a sua matrícula</b>.</li>
<li>Presente e Atrasado contam como presença.</li>
<li>${c.justAbona ? 'Falta justificada, quando aprovada pelo mentor, <b>não reduz</b> a frequência.' : 'Falta justificada fica registrada com o motivo, mas conta como falta.'}</li>
<li>${c.compensa ? 'Assistir à gravação até o fim <b>compensa</b> a falta daquele encontro.' : 'Assistir à gravação não substitui a presença no encontro.'}</li>
<li>${c.certFreq ? 'Mínimo de <b>' + f.min + '%</b> para receber o certificado.' : 'A frequência não bloqueia o certificado nesta turma.'}</li></ul></div>
${pend.length ? `<div class="card"><h3 style="margin-bottom:6px">Minhas justificativas</h3>${pend.slice(0, 8).map(j => `<div class="li"><div class="grow"><b style="font-weight:600">${E((aulaN(j.n) || {}).nome || 'Aula')}</b><span class="sm-t">${E(j.motivo)}${j.resp ? ' · Mentor: ' + E(j.resp) : ''}</span></div>${tag(...({ pendente: ['Em análise', 'in'], aprovada: ['Aprovada', 'ok'], recusada: ['Recusada', 'er'], encerrada: ['Resolvida', ''] }[j.st]))}</div>`).join('')}</div>` : ''}</div></div>`;
}

/* Aluno pede para justificar uma falta. */
function justificar(n) {
  const a = aulaN(n);
  modal('Justificar falta', F('Motivo', `<textarea id="jm" rows="4" placeholder="Conte o que aconteceu"></textarea>`, 'O mentor recebe o pedido e aprova ou recusa. Você é avisado da resposta.'), { sub: E(a.nome) + ' · ' + DL(a.date), label: 'Enviar justificativa', ok: () => {
      if (val('jm').length < 8) {
        toast('Explique o motivo com um pouco mais de detalhe');
        return false;
      }
      const id = ME().id;
      S.just.unshift({ id: uid(), aid: id, n, motivo: val('jm'), at: stamp(), st: 'pendente', resp: '' });
      notifyM('Justificativa de falta: ' + nm(id), '"' + a.nome + '" (' + DF(a.date) + '): ' + val('jm').slice(0, 140), 'freq');
      keep();
      done('Justificativa enviada ao mentor', 'Justificou a falta em "' + a.nome + '"');
    } });
}
