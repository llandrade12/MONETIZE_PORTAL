/**
 * aluno/evolucao.js
 * Página do aluno: evolucao.
 */
'use strict';

function S_evo() {
  const id = ME().id, t = sub('evolucao', 'desemp');
  return tabs('evolucao', [['desemp', 'Desempenho'], ['roda', 'Roda da Vida'], ['metas', 'Plano de ação', S.metas.filter(m => m.aid == id).length]]) + (t == 'roda' ? rodaView(id) : t == 'metas' ? metasAluno(id) : desemp(id));
}

function desemp(id) {
  const f = fin(id);
  return `<div class="main2"><div class="stack"><div class="card gold"><div class="row sp"><div><span class="lb mu" style="font-weight:600;font-size:13px">Nota final</span><div class="num gold" style="font-size:56px;margin-top:4px">${f1(f)}</div><p class="mu" style="margin:6px 0 0;max-width:360px">Média ponderada das competências ao longo dos módulos. Atualiza a cada nota lançada.</p></div></div></div>
  <div class="card"><h3 style="margin-bottom:14px">Competências</h3>${CK().map(c => {
    const v = compAvg(id, c);
    return `<div style="margin-bottom:16px"><div class="row sp" style="margin-bottom:6px"><b>${c}</b><span><b>${f1(v)}</b> <span class="sm-t">peso ${pesoDe(id, c)}%</span></span></div>${bar((v || 0) * 10)}${compA(id, c).obs ? `<div class="sm-t" style="margin-top:5px">Mentor: ${E(compA(id, c).obs)}</div>` : ''}</div>`;
  }).join('')}</div></div>
  <div class="card"><h3 style="margin-bottom:6px">Histórico de notas</h3>${tarefasDe(id).filter(t => S.notas[id + '-' + t.id] != null).map(t => `<div class="li"><div class="grow"><b>${E(t.t)}</b><span class="sm-t">${E(t.comp)}</span></div><b class="gold" style="font:600 22px var(--dp)">${f1(S.notas[id + '-' + t.id])}</b></div>`).join('') || '<p class="mu">Nenhuma nota lançada ainda.</p>'}</div></div>`;
}

function rodaView(id) {
  const r = S.roda[id], iO = rodaIniOpen(id), fO = finOpen(id), canI = iO && !r.iniSent && !ro(), canF = fO && !r.finSent && !ro();
  const col = (k, en) => AREAS.map((a, i) => `<label class="f" style="margin-bottom:10px"><span class="row sp"><span>${a}</span><b class="gold" id="rv-${k}-${i}">${r[k][i]}</b></span><input type="range" min="1" max="10" value="${r[k][i]}" ${en ? '' : 'disabled'} oninput="document.getElementById('rv-${k}-${i}').textContent=this.value" onchange="S.roda[${id}].${k}[${i}]=+this.value;save();keep();render()" style="padding:0;accent-color:#fdb621"></label>`).join('');
  const bloco = (k, nome, aberto, pode, enviada) => `<div class="card"><div class="ch"><h3>${nome}</h3>${enviada ? tag('Enviada', 'ok') : aberto ? tag('Liberada', 'gd') : tag('Aguardando o mentor', '')}</div>${aberto || enviada ? col(k, pode) + (pode ? `<button class="btn full" onclick="S.roda[${id}].${k}Sent=true;notifyM('${nome} enviada por '+nm(${id}),'Veja na ficha do aluno, aba Roda da Vida.','alunoD',${id});done('${nome} enviada')">Enviar ${nome}</button><p class="sm-t" style="margin-top:8px">Após o envio os valores ficam travados.</p>` : '') : `<p class="mu" style="margin:0">${k == 'ini' ? 'O mentor libera a Roda inicial para a turma. Você é avisado quando puder preencher.' : 'O mentor libera a Roda final para a turma, para você comparar a sua evolução.'}</p>`}</div>`;
  return `<div class="main2"><div class="card printable"><div class="ch"><h3>Roda da Vida, ${E(nm(id))}</h3><button class="btn s sm" onclick="print()">${ic('print')}Exportar PDF</button></div>${r.iniSent ? radar(r) : `<p class="mu" style="margin:24px 0;text-align:center">O gráfico aparece depois que você enviar a Roda inicial.</p>`}
  <p class="mu" style="text-align:center;margin-top:10px">${r.finSent ? 'Comparação antes e depois da mentoria.' : r.iniSent ? 'A comparação aparece quando você enviar a Roda final.' : ''}</p></div>
  <div class="stack">${bloco('ini', 'Roda inicial', iO, canI, r.iniSent)}${bloco('fin', 'Roda final', fO, canF, r.finSent)}</div></div>`;
}

/* ---------- Plano de ação: cada meta vira um plano com etapas, prazos e acompanhamento ---------- */

function metasAluno(id) {
  const L = S.metas.filter(m => m.aid == id), and = L.filter(m => m.st == 'aprovada' && !m.feita), prox = and.flatMap(m => m.etapas.filter(e => !e.feito && e.prazo).map(e => [e, m])).sort((a, b) => a[0].prazo < b[0].prazo ? -1 : 1).slice(0, 4);
  return `<div class="row sp" style="margin-bottom:16px"><p class="mu" style="margin:0;max-width:580px">Cada meta vira um plano: etapas com prazo, que você marca conforme avança. O mentor aprova a meta e acompanha o progresso.</p><button class="btn" ${ro() ? 'disabled' : ''} onclick="proporMeta()">${ic('plus')}Nova meta</button></div>
${prox.length ? `<div class="card flat" style="margin-bottom:14px"><b style="font-size:13px">Próximas etapas</b>${prox.map(([e, m]) => `<div class="row sp" style="padding:8px 0 0;font-size:13.5px;flex-wrap:nowrap;gap:10px"><span>${E(e.t)} <span class="sm-t">· ${E(m.t)}</span></span>${tag(etapaAtrasada(e) ? 'Atrasada, ' + DF(e.prazo) : DF(e.prazo), etapaAtrasada(e) ? 'er' : diff(e.prazo, hoje()) <= 2 ? 'wn' : '')}</div>`).join('')}</div>` : ''}` +
    (L.length ? `<div class="stack">${L.map(m => metaCard(m, !ro(), false)).join('')}</div>` : empty('Nenhuma meta ainda', 'Comece com uma meta concreta e mensurável para o período da mentoria e quebre em etapas.'));
}

function proporMeta(mid) {
  const m = mid && S.metas.find(x => x.id == mid);
  modal(m ? 'Ajustar meta' : 'Nova meta', F('Meta', `<textarea id="mt" rows="2" placeholder="Ex.: Dobrar o faturamento da empresa em 12 meses">${E(m ? m.t : '')}</textarea>`, 'Seja específico: o quê, quanto e até quando.') + F('Prazo final', `<input id="mpz" type="date" value="${m && m.prazo || ''}">`) +
    (m ? '' : F('Etapas do plano (uma por linha)', `<textarea id="me" rows="4" placeholder="Mapear os indicadores atuais&#10;Contratar gerente comercial&#10;Implantar rotina semanal de metas"></textarea>`, 'Você define o prazo de cada etapa depois, e pode acrescentar outras quando quiser.')), { wide: true, label: 'Enviar para aprovação', ok: () => {
      if (val('mt').length < 6) {
        toast('Descreva a meta');
        return false;
      }
      if (m) {
        m.t = val('mt');
        m.prazo = val('mpz');
        m.st = 'proposta';
        m.obs = '';
      }
      else
        S.metas.push({ id: uid(), aid: ME().id, t: val('mt'), prazo: val('mpz'), st: 'proposta', obs: '', checkins: [], etapas: val('me').split('\n').map(x => x.trim()).filter(Boolean).map(t => ({ id: 'e' + uid(), t, prazo: '', feito: false })) });
      notifyM('Meta para avaliar: ' + nm(ME().id), val('mt'), 'metas');
      done('Meta enviada para aprovação');
    } });
}

function etapaAdd(mid) {
  const m = metaDe(mid), t = val('pe-' + mid);
  if (t.length < 3)
    return toast('Descreva a etapa');
  m.etapas.push({ id: 'e' + uid(), t, prazo: val('pd-' + mid), feito: false });
  keep();
  done('Etapa adicionada ao plano', 'Adicionou uma etapa ao plano de ação');
}

function etapaTog(mid, eid) {
  const m = metaDe(mid), e = m.etapas.find(x => x.id == eid);
  e.feito = !e.feito;
  e.at = e.feito ? stamp() : '';
  keep();
  const tudo = m.etapas.every(x => x.feito);
  done(e.feito ? (tudo ? 'Todas as etapas feitas. Conclua a meta.' : 'Etapa concluída') : 'Etapa reaberta', (e.feito ? 'Concluiu' : 'Reabriu') + ' a etapa "' + e.t + '"');
}

function etapaPrazo(mid, eid, v) {
  metaDe(mid).etapas.find(x => x.id == eid).prazo = v;
  save();
  keep();
  render();
}

function etapaDel(mid, eid) {
  const m = metaDe(mid);
  m.etapas = m.etapas.filter(x => x.id != eid);
  keep();
  done('Etapa removida');
}

function metaFim(mid) {
  const m = metaDe(mid);
  m.feita = stamp();
  notifyM('Meta concluída por ' + nm(m.aid), m.t, 'metas');
  keep();
  done('Meta concluída. Parabéns!', 'Concluiu a meta "' + m.t + '"');
}
