/**
 * aluno/mural.js
 * Página do aluno: mural.
 */
'use strict';

function S_mural() {
  const L = avisosFor(ME().id);
  return `<div style="max-width:760px"><p class="mu">Avisos oficiais da mentoria. Você pode comentar em cada publicação.</p><div class="stack">${L.map(a => avisoCard(a, false)).join('') || empty('Nenhum aviso publicado', 'Os avisos da equipe aparecem aqui.')}</div></div>`;
}
