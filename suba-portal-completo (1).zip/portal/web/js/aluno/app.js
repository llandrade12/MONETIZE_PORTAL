/**
 * aluno/app.js
 * Área do mentorado (aluno.html): menu, mapa de páginas e inicialização.
 * Para adicionar uma página: crie o arquivo em js/aluno/, registre em PAGINAS e no menu SNAV, e inclua no aluno.html.
 */
'use strict';

const SNAV = [['inicio', 'Início', 'home'], ['aulas', 'Aulas', 'play'], ['agenda', 'Agenda', 'cal'], ['frequencia', 'Minha frequência', 'roll'], ['tarefas', 'Tarefas', 'check'], ['diario', 'Diário e anotações', 'note'], ['recs', 'Recomendações', 'bookmark'], ['evolucao', 'Evolução e plano de ação', 'chart'], ['rotina', 'Rotina e hábitos', 'flame'], ['mural', 'Mural', 'mega'], ['perfil', 'Perfil e certificado', 'user'], ['ajuda', 'Ajuda e suporte', 'help']];

/* Itens do menu "Mais" no celular. */
const SMORE = ['agenda', 'frequencia', 'diario', 'recs', 'rotina', 'mural', 'notificacoes', 'perfil', 'ajuda'];

const APP = {
  role: 'aluno', inicio: 'inicio',
  /* O vídeo para quando o aluno sai da aula. */
  antes() {
    if (PL.n && !(R.p == 'aula' && R.a == PL.n))
      plStop();
  },
  view() {
    const PAGINAS = {
      inicio: S_inicio, aulas: S_aulas, aula: S_aula, agenda: S_agenda, tarefas: S_tarefas, recs: S_recs, evolucao: S_evo, rotina: S_rotina, mural: S_mural, perfil: S_perfil, notificacoes: S_notif, frequencia: S_freq, diario: S_diario, ajuda: S_ajuda
    };
    if (R.p == 'aula' && !aulaN(R.a))
      R = { p: 'aulas', a: null };
    const html = (PAGINAS[R.p] || S_inicio)();
    let title = TITLES[R.p] || '', crumb = '';
    if (R.p == 'aula') {
      const a = aulaN(R.a);
      title = 'Aula ' + ord(a);
      crumb = `<button onclick="nav('aulas')">Aulas</button> / ${E(a.comp || (unDe(a, ME().turma) || {}).nome || 'Aula')}`;
    }
    return { html, title, crumb };
  }
};

/* Mentor que estava vendo o portal como aluno volta para o painel. */
function exitPreview() {
  verComo(0);
  irPara('admin');
}

boot(iniciar);
