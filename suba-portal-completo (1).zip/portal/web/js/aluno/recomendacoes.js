/**
 * aluno/recomendacoes.js
 * Página do mentorado: vitrine das recomendações do mentor.
 */
'use strict';

function S_recs() {
  const id = ME().id, L = recsDe(id), feitos = L.filter(r => S.recSt[id + '-' + r.id] == 'feito').length;
  if (!L.length)
    return empty('Nenhuma recomendação ainda', 'Os livros, vídeos, podcasts e filmes indicados pelo mentor aparecem aqui.');
  return `<div class="row sp" style="margin-bottom:18px"><p class="mu" style="margin:0;max-width:600px">O que o mentor indica para você ler, ouvir e assistir fora dos encontros. Salve para depois e marque o que já concluiu.</p><span class="rprog"><b>${feitos}</b> de ${L.length} concluídos${bar(pct(feitos, L.length))}</span></div>` + recVitrine(id);
}
