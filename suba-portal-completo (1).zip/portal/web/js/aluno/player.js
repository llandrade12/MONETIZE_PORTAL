/**
 * aluno/player.js
 * Player da aula incorporado na página: YouTube (não listado), Vimeo, arquivo de vídeo (MP4) e Google Drive.
 * Lembra onde o aluno parou (S.prog), retoma do mesmo ponto e marca a aula como assistida sozinho
 * quando ele passa do percentual configurado (padrão 90%). Também abre os materiais de apoio (PDF, slides).
 */
'use strict';

const PL = { n: 0, k: '', obj: null, timer: null, last: null, saved: 0 };

/* Bloco do player na página da aula (capa com botão; o vídeo entra ao tocar). */
function playerBox(a, aid) {
  const lib = aulaLib(a), src = lib && vsrc(a.video), p = progDe(aid, a.n), v = S.vis[aid + '-' + a.n];
  if (!src)
    return `<div class="player lock"><div style="text-align:center;color:#a49d8f"><button class="pb" aria-hidden="true" tabindex="-1">${ic('lock')}</button><p style="margin-top:12px">${lib ? 'Gravação em processamento' : 'Gravação liberada após o encontro'}</p></div></div>`;
  const cont = p.t > 15 && p.d && p.t < p.d - 15;
  return `<div class="player" id="pl" data-n="${a.n}"><button class="pb" aria-label="${cont ? 'Continuar de ' + fmtT(p.t) : 'Assistir gravação'}" onclick="plMount(${a.n})">${ic('play')}</button><span class="cap">${cont ? 'Continuar de ' + fmtT(p.t) : v ? 'Assistir de novo' : 'Assistir gravação'}${p.d ? ' · ' + fmtT(p.d) : ''}</span></div>
${src.auto ? `<div class="plb"><div class="plb-t"><span id="plpct">${plTxt(p, v)}</span><span class="sm-t">Marca como assistida sozinha ao passar de ${S.cfg.pctVisto}%</span></div><div class="bar ${v ? 'ok' : ''}" id="plbar"><i style="width:${v ? 100 : p.p || 0}%"></i><u style="left:${S.cfg.pctVisto}%"></u></div></div>` : `<p class="sm-t" style="margin:8px 2px 0">Este vídeo (${E(src.nome)}) não informa o progresso ao portal. Depois de assistir, toque em "Marcar como assistida".</p>`}`;
}

const plTxt = (p, v) => v ? 'Aula assistida' : p.p ? p.p + '% assistido' + (p.t ? ' · parou em ' + fmtT(p.t) : '') : 'Ainda não começou';

function loadScript(src) {
  return new Promise((res, rej) => {
    if (document.querySelector('script[data-s="' + src + '"]'))
      return res();
    const s = document.createElement('script');
    s.src = src;
    s.dataset.s = src;
    s.onload = res;
    s.onerror = () => {
      s.remove();
      rej(new Error('script'));
    };
    document.head.appendChild(s);
  });
}

function plStop() {
  clearInterval(PL.timer);
  PL.timer = null;
  if (PL.obj && PL.obj.destroy)
    try {
      PL.obj.destroy();
    }
    catch (e) {
    }
  PL.obj = null;
  PL.last = null;
  if (PL.n)
    save();
  PL.n = 0;
}

/* Aviso no lugar do vídeo quando o YouTube não pode ser incorporado, com a saída para assistir assim mesmo. */
const plAviso = (id, t, s) => `<div class="plw"><b>${t}</b><p>${s}</p><a class="btn" href="https://www.youtube.com/watch?v=${E(id)}" target="_blank" rel="noopener">${ic('ext')}Assistir no YouTube</a><small>Depois de assistir, toque em "Marcar como assistida".</small></div>`;

/* Sem a API do player não dá para medir o progresso: mostra o vídeo e libera a marcação manual. */
function plManual(box, html) {
  if (html)
    box.innerHTML = html;
  ST.plManual = PL.n;
  const b = document.getElementById('plman');
  if (b)
    b.hidden = false;
}

function plMount(n) {
  const a = aulaN(n), box = document.getElementById('pl'), src = a && vsrc(a.video);
  if (!box || !src)
    return;
  plStop();
  PL.n = n;
  PL.k = ME().id + '-' + n;
  const p = progDe(ME().id, n), t0 = p.d && p.t < p.d - 15 ? Math.floor(p.t) : 0;
  box.classList.add('on');
  const http = /^http/.test(location.protocol), fr = (u, id = 'plf') => `<iframe id="${id}" src="${E(u)}" title="${E(a.nome)}" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>`;
  if (src.k == 'file') {
    box.innerHTML = `<video id="plf" controls playsinline autoplay controlsList="nodownload" disablePictureInPicture oncontextmenu="return false" src="${E(src.u)}"></video>`;
    const v = box.querySelector('video');
    v.addEventListener('loadedmetadata', () => {
      if (t0)
        v.currentTime = t0;
    });
    v.addEventListener('timeupdate', () => plTick(v.currentTime, v.duration));
    v.addEventListener('pause', () => save());
    v.addEventListener('error', () => toast('Não foi possível carregar o vídeo'));
    return;
  }
  if (src.k == 'yt' && !http)
    return plManual(box, plAviso(src.id, 'O YouTube não toca com o portal aberto direto do arquivo', 'Abra o portal pelo arquivo "abrir-portal" (que vem na pasta) ou pelo endereço publicado, e o vídeo toca aqui dentro, com o progresso salvo.'));
  if (src.k == 'yt') {
    const u = 'https://www.youtube.com/embed/' + src.id + '?enablejsapi=1&rel=0&modestbranding=1&playsinline=1&autoplay=1' + (t0 ? '&start=' + t0 : '') + (http ? '&origin=' + encodeURIComponent(location.origin) : '');
    box.innerHTML = fr(u);
    const fail = setTimeout(() => plManual(box), 9000);
    const go = () => {
      if (PL.n != n || !document.getElementById('plf'))
        return;
      PL.obj = new YT.Player('plf', {
        events: {
          onReady: () => {
            clearTimeout(fail);
            PL.timer = setInterval(() => {
              if (!document.getElementById('plf'))
                return plStop();
              try {
                if (PL.obj.getPlayerState() == 1)
                  plTick(PL.obj.getCurrentTime(), PL.obj.getDuration());
              }
              catch (e) {
              }
            }, 2000);
          },
          onError: () => {
            clearTimeout(fail);
            clearInterval(PL.timer);
            plManual(box, plAviso(src.id, 'O YouTube não liberou este vídeo para tocar aqui', 'Confira se o vídeo está como "Não listado" (e não "Privado") e se a incorporação está permitida nas configurações dele.'));
          },
          onStateChange: e => {
            if (e.data == 2 || e.data == 0) {
              try {
                plTick(PL.obj.getCurrentTime(), PL.obj.getDuration(), e.data == 0);
              }
              catch (x) {
              }
              save();
            }
            else
              PL.last = null;
          }
        }
      });
    };
    if (window.YT && YT.Player)
      go();
    else {
      const prev = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        if (prev)
          prev();
        go();
      };
      loadScript('https://www.youtube.com/iframe_api').catch(() => {
        clearTimeout(fail);
        plManual(box);
      });
    }
    return;
  }
  if (src.k == 'vimeo') {
    box.innerHTML = fr('https://player.vimeo.com/video/' + src.id + '?autoplay=1&dnt=1' + (src.h ? '&h=' + src.h : '') + (t0 ? '#t=' + t0 + 's' : ''));
    loadScript('https://player.vimeo.com/api/player.js').then(() => {
      if (PL.n != n || !document.getElementById('plf'))
        return;
      PL.obj = new Vimeo.Player(document.getElementById('plf'));
      PL.obj.on('timeupdate', d => plTick(d.seconds, d.duration));
      PL.obj.on('pause', () => save());
      PL.obj.on('ended', () => save());
    }, () => plManual(box));
    return;
  }
  plManual(box, fr(src.u));
}

/* Recebe a posição do vídeo: guarda onde parou e marca como assistida ao passar do percentual. */
function plTick(t, d, fim) {
  if (!PL.n || !d || !isFinite(d) || U.role != 'aluno')
    return;
  const k = PL.k, p = S.prog[k] || (S.prog[k] = { t: 0, d: 0, w: 0, p: 0 });
  /* w = quanto do vídeo foi de fato tocado (pular para o fim não conta). */
  const dl = PL.last == null ? 0 : t - PL.last;
  if (dl > 0 && dl < 12)
    p.w = Math.min(d, (p.w || 0) + dl);
  PL.last = t;
  p.t = fim ? 0 : t;
  p.d = d;
  p.p = Math.max(p.p || 0, Math.min(100, Math.round(t / d * 100)));
  p.at = stamp();
  const lim = S.cfg.pctVisto / 100;
  if (!S.vis[k] && t / d >= lim && p.w / d >= Math.min(.5, lim)) {
    S.vis[k] = 1;
    p.auto = stamp();
    logA('Assistiu à gravação: ' + aulaN(PL.n).nome);
    save();
    toast('Aula marcada como assistida');
    const tg = document.getElementById('vistag');
    if (tg)
      tg.innerHTML = tag('Assistida', 'ok');
    const bar = document.getElementById('plbar');
    if (bar)
      bar.classList.add('ok');
  }
  const el = document.getElementById('plpct'), bi = document.querySelector('#plbar i');
  if (el)
    el.textContent = plTxt(p, S.vis[k]);
  if (bi)
    bi.style.width = (S.vis[k] ? 100 : p.p) + '%';
  if (Date.now() - PL.saved > 10000) {
    PL.saved = Date.now();
    save();
  }
}

addEventListener('pagehide', () => {
  if (PL.n)
    save();
});

/* ---------- Materiais de apoio (PDF, slides, planilhas, links) ---------- */

/* Materiais que o aluno já pode ver: todos depois do encontro; antes, só os marcados como "liberar antes". */
const matsVis = a => (a.mats || []).filter(m => aulaLib(a) || (m.antes && pautaLib(a)));

const matRow = (a, m, i) => {
  const [t, c] = mtipo(m);
  return `<div class="li"><span class="mtp fx-${c}">${t == 'Documento' ? 'DOC' : t == 'Planilha' ? 'XLS' : t == 'Imagem' ? 'IMG' : t == 'Arquivo' ? 'ARQ' : t.toUpperCase().slice(0, 6)}</span><div class="grow"><b>${E(m.t)}</b><span class="sm-t">${t}${m.file ? ' · ' + fsize(m.file.size) : ''}</span></div><button class="btn s sm" onclick="matOpen(${a.n},'${m.id}')">${ic(m.file && !['pdf', 'img'].includes(c) ? 'download' : 'eye')}${m.file && !['pdf', 'img'].includes(c) ? 'Baixar' : 'Abrir'}</button></div>`;
};

async function matOpen(n, mid) {
  const a = aulaN(n), m = (a.mats || []).find(x => x.id == mid);
  if (!m)
    return;
  const c = mtipo(m)[1];
  if (m.file) {
    if (c != 'pdf' && c != 'img')
      return fopen(m.file.id, m.file.name);
    const b = await fget(m.file.id);
    if (!b)
      return toast('Arquivo não encontrado');
    const u = URL.createObjectURL(b);
    modal(E(m.t), c == 'img' ? `<img src="${u}" alt="${E(m.t)}" style="max-width:100%;border-radius:10px">` : `<iframe class="matv" src="${u}" title="${E(m.t)}"></iframe>`, { wide: true, cancel: 'Fechar', label: 'Baixar', sub: E(a.nome), ok: () => {
        fopen(m.file.id, m.file.name);
        return false;
      } });
    $('#mbox').classList.add('cw');
    return;
  }
  const e = embedU(m.u) || (c == 'pdf' ? safeUrl(m.u) : '');
  if (!e)
    return window.open(safeUrl(m.u), '_blank', 'noopener');
  modal(E(m.t), `<iframe class="matv" src="${E(e)}" title="${E(m.t)}" allowfullscreen></iframe>`, { wide: true, cancel: 'Fechar', label: 'Abrir em nova aba', sub: E(a.nome), ok: () => {
      window.open(safeUrl(m.u), '_blank', 'noopener');
      return false;
    } });
  $('#mbox').classList.add('cw');
}
