/**
 * login/auth.js
 * Página de entrada (index.html): login, "esqueci minha senha", criação de nova senha pelo link do e-mail
 * e aceite dos termos no primeiro acesso. Depois de entrar, a pessoa é levada para aluno.html ou mentor.html.
 * Quem confere e-mail e senha é o servidor; a página só envia o que foi digitado.
 */
'use strict';

/* O que o servidor informa antes do login (ex.: se o envio de e-mails está ligado). */
let PUB = { email: false };

const LG = (art, corpo) => `<div class="lg"><div class="art">${art}</div><div class="fm"><div class="box"><img class="lglogo" src="${BRAND.logo}" alt="Monetize Mentoring and Consulting">${corpo}</div></div></div>`;

const LEMA = `<blockquote>Não delegue o que só você pode fazer!<small>Mentoria Suba o Padrão</small></blockquote>`;

function loginView() {
  return LG(LEMA, `<h2 style="color:#fdfbee;font-size:24px;margin-bottom:6px">Entrar na Área de Membros</h2><p style="color:#958d7c;margin-bottom:22px">Use o e-mail e a senha que você recebeu do mentor.</p>
<form onsubmit="event.preventDefault();login()">${F('E-mail', '<input id="em" type="email" autocomplete="username" placeholder="voce@empresa.com" required>')}
${F('Senha', '<input id="pw" type="password" autocomplete="current-password" placeholder="Sua senha" required>')}
<div class="row sp" style="margin:-4px 0 18px"><label class="chk" style="font-size:13px;color:#958d7c"><input type="checkbox" id="mc" checked> Manter conectado</label><a href="#" onclick="forgot();return false" style="font-size:13px">Esqueci minha senha</a></div>
<button class="btn full" id="lgb" type="submit" style="padding:12px">Entrar</button></form>${pwaConvite()}`);
}

function forgot() {
  if (!PUB.email)
    return modal('Esqueci minha senha', `<p><b>Mentorado:</b> peça ao seu mentor uma senha nova. Depois de entrar, você pode trocá-la no seu perfil.</p><p class="mu" style="margin:0"><b>Mentor:</b> peça a quem cuida do servidor para redefinir a sua senha.</p>`, { cancel: 'Entendi' });
  modal('Esqueci minha senha', `<p class="mu" style="margin:0 0 14px">Informe o e-mail do seu acesso. Enviamos um link para você criar uma senha nova. O link vale por 1 hora.</p>` + F('E-mail', `<input id="fe" type="email" autocomplete="username" value="${E(val('em'))}" placeholder="voce@empresa.com">`), { label: 'Enviar link', ok: () => {
      pedirLink();
      return false;
    } });
}

async function pedirLink() {
  const e = val('fe');
  if (!/\S+@\S+\.\S+/.test(e))
    return toast('Informe um e-mail válido');
  const b = $('#mok');
  b.disabled = true;
  try {
    await chamar('POST', '/api/auth/esqueci', { email: e });
  }
  catch (x) {
    b.disabled = false;
    return toast(x.msg);
  }
  modal('Confira o seu e-mail', `<p>Se <b>${E(e)}</b> for o e-mail de um acesso ativo, o link para criar a nova senha chega em instantes.</p><p class="mu" style="margin:0">Não chegou? Veja a caixa de spam. Se continuar sem receber, peça uma senha nova ao seu mentor.</p>`, { cancel: 'Entendi' });
}

/* Chegou pelo link do e-mail (index.html#redefinir=código): tela para criar a nova senha. */
const tokenRedefinir = () => (/[#&]redefinir=([\w-]+)/.exec(location.hash) || [])[1] || '';

function novaSenhaView() {
  return LG(LEMA, `<h2 style="color:#fdfbee;font-size:24px;margin-bottom:6px">Criar nova senha</h2><p style="color:#958d7c;margin-bottom:22px">Escolha uma senha com 8 ou mais caracteres, com letras e números.</p>
<form onsubmit="event.preventDefault();redefinir()">${F('Nova senha', '<input id="n1" type="password" autocomplete="new-password" required>')}
${F('Confirmar nova senha', '<input id="n2" type="password" autocomplete="new-password" required>')}
<button class="btn full" id="lgb" type="submit" style="padding:12px">Salvar nova senha</button></form>
<button class="btn s full" style="margin-top:10px" onclick="voltarAoLogin()">Voltar para o login</button>`);
}

function voltarAoLogin() {
  history.replaceState(null, '', location.pathname);
  render();
}

async function redefinir() {
  const n = $('#n1').value;
  if (!senhaForte(n))
    return toast('Use 8+ caracteres com letras e números');
  if (n != $('#n2').value)
    return toast('As senhas não coincidem');
  $('#lgb').disabled = true;
  try {
    await chamar('POST', '/api/auth/redefinir', { token: tokenRedefinir(), senha: n });
  }
  catch (e) {
    $('#lgb').disabled = false;
    return toast(e.msg);
  }
  voltarAoLogin();
  toast('Senha criada. Entre com a nova senha.');
}

async function login() {
  const b = $('#lgb');
  b.disabled = true;
  b.textContent = 'Entrando…';
  try {
    await chamar('POST', '/api/auth/entrar', { email: val('em'), senha: $('#pw').value, manter: $('#mc').checked });
    await carregarEstado();
  }
  catch (e) {
    b.disabled = false;
    b.textContent = 'Entrar';
    return toast(e.msg);
  }
  definirUsuario();
  render();
}

function termsView() {
  return `<div class="lg"><div class="art"></div><div class="fm"><div class="box"><div class="brand" style="padding:0 0 26px">${MARK}<div><b>${BRAND.nome}</b><span>Primeiro acesso</span></div></div>
<h2 style="color:#fdfbee;font-size:24px;margin-bottom:8px">Antes de começar</h2><p style="color:#958d7c">Para acessar a Área de Membros é necessário aceitar os termos. O aceite fica registrado com data e hora.</p>
<div style="border:1px solid #262626;border-radius:12px;padding:14px;max-height:180px;overflow:auto;font-size:13px;color:#a49d8f;margin:16px 0;background:#0b0b0b">
<b style="color:#e8e0cf">Termos de Uso.</b> O acesso é pessoal e intransferível. O conteúdo das aulas, gravações e materiais é exclusivo dos mentorados e não pode ser reproduzido ou compartilhado.<br><br><b style="color:#e8e0cf">Política de Privacidade.</b> Seus dados de cadastro são usados apenas para a operação da mentoria: comunicação, acompanhamento, avaliação e emissão de certificado. Você pode solicitar a exclusão dos seus dados ao fim do período de acesso.</div>
<label class="chk" style="color:#d6cebd"><input type="checkbox" id="t1"> Li e aceito os Termos de Uso</label><div style="height:10px"></div>
<label class="chk" style="color:#d6cebd"><input type="checkbox" id="t2"> Li e aceito a Política de Privacidade</label>
<button class="btn full" style="margin-top:22px;padding:12px" onclick="acceptTerms()">Aceitar e entrar</button>
<button class="btn s full" style="margin-top:10px" onclick="sair()">Voltar</button></div></div></div>`;
}

function acceptTerms() {
  if (!$('#t1').checked || !$('#t2').checked)
    return toast('Marque os dois aceites para continuar');
  S.termos[U.aid] = stamp();
  save();
  render();
}

/* Página de login: mostra o formulário, o aceite de termos, ou segue direto para a área de quem já está logado. */
function render() {
  if (U && (U.role == 'admin' || S.termos[U.aid]))
    return irPara(U.role);
  $('#app').innerHTML = U ? termsView() : tokenRedefinir() ? novaSenhaView() : loginView();
  if (!U) {
    let msg = '';
    try {
      msg = sessionStorage.getItem('sop-msg') || '';
      sessionStorage.removeItem('sop-msg');
    }
    catch (e) {
    }
    if (msg)
      toast(msg);
  }
}

document.addEventListener('keydown', e => {
  if (e.key == 'Escape')
    closeM();
});

chamar('GET', '/api/publico').then(p => PUB = p, () => 0);

boot(render);
