#!/bin/sh
# Backup diário: banco de dados + arquivos enviados. Guarda os últimos 14 dias.
# Uso: /opt/suba-portal/backup.sh   (agende no cron; veja docs/INSTALACAO.md)
# Lê usuário, senha e nome do banco do config.properties.
set -e
BASE=/opt/suba-portal
DESTINO=/var/backups/suba-portal
CONFIG="$BASE/config.properties"
valor() { grep -E "^$1=" "$CONFIG" | head -1 | cut -d= -f2- | tr -d '\r'; }

USUARIO=$(valor db.usuario)
SENHA=$(valor db.senha)
BANCO=$(valor db.url | sed -E 's#^jdbc:[a-z]+://[^/]+/([^?]+).*#\1#')
ARQUIVOS=$(valor arquivos.dir)
case "$ARQUIVOS" in /*) ;; *) ARQUIVOS="$BASE/${ARQUIVOS:-arquivos}";; esac
DIA=$(date +%Y-%m-%d_%H%M)

mkdir -p "$DESTINO"
chmod 700 "$DESTINO"
# A senha vai por um arquivo temporário, para não aparecer na lista de processos.
CRED=$(mktemp)
trap 'rm -f "$CRED"' EXIT
printf '[client]\nuser=%s\npassword=%s\n' "$USUARIO" "$SENHA" > "$CRED"
DUMP=mysqldump
command -v mysqldump >/dev/null 2>&1 || DUMP=mariadb-dump
$DUMP --defaults-extra-file="$CRED" --single-transaction --default-character-set=utf8mb4 "$BANCO" | gzip > "$DESTINO/banco-$DIA.sql.gz"
tar -czf "$DESTINO/arquivos-$DIA.tar.gz" -C "$(dirname "$ARQUIVOS")" "$(basename "$ARQUIVOS")"
find "$DESTINO" -type f -mtime +14 -delete
echo "Backup concluído em $DESTINO ($DIA)"
