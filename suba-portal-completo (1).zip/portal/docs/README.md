# Monetize · Área de Membros — notas técnicas

Instalação: veja `INSTALACAO.md`.

## Visão geral

- **Servidor:** Java 17 puro (sem framework), pacote `br.com.monetize.portal`. Única dependência em execução: o driver JDBC (MySQL ou MariaDB).
- **Banco:** MySQL 8 ou MariaDB 10.4+. As tabelas são criadas na subida (`src/main/resources/db/V001__esquema_inicial.sql`). Para mudar o banco em uma versão futura, acrescente `V002__...sql` e registre em `db/Migracoes.java`.
- **Portal:** HTML/CSS/JS sem etapa de build (pasta `web/`), servido pelo próprio servidor Java.

## Como os dados andam

O navegador mantém o estado em `S` (veja `web/js/compartilhado/core/store.js`). Ao abrir, baixa `GET /api/estado` (só o que a pessoa pode ver). Cada alteração vira operações enviadas a `POST /api/sync`; a cada 20 s o portal pergunta `GET /api/mudancas?rev=N` para receber o que os outros mudaram.

No servidor cada registro é uma linha da tabela `registro` (coleção + chave + JSON); alunos ficam na tabela `aluno`. O que cada perfil lê e grava está em:

- `dados/Colecoes.java` — catálogo das coleções. **Tem de ficar igual a `COLECOES` em `web/js/compartilhado/core/store.js`.**
- `dados/Estado.java` — o que cada pessoa enxerga.
- `dados/Permissoes.java` e `dados/Higiene.java` — o que um aluno pode gravar e em que formato.
- `dados/Padroes.java` — valores iniciais. **Tem de ficar igual a `CFG0` em `web/js/compartilhado/data/constants.js`.**

## Pacotes

| Pacote | Conteúdo |
|---|---|
| `http` | servidor HTTP, arquivos estáticos, cabeçalhos de segurança |
| `auth` | login, sessões (cookie HttpOnly), senhas, contas de mentor |
| `dados` | registros, permissões, sincronização, notificações |
| `servicos` | e-mail (SMTP), push (Web Push/VAPID), lembretes, agenda (.ics), arquivos, cópia/restauração, LGPD |
| `api` | as rotas `/api/...` e `/agenda/...` |
| `db` | conexões JDBC e criação das tabelas |

## Rotas

`GET /api/saude` · `GET /api/publico` · `POST /api/auth/entrar|sair|esqueci|redefinir` · `GET /api/estado` · `GET /api/mudancas?rev=` · `POST /api/sync` · `GET /api/ids` · `POST /api/conta/senha` · `PUT|GET|DELETE /api/arquivos/{id}` · `POST /api/push/inscrever|remover|teste` · `POST /api/lembretes/rodar` · `GET|POST /api/mentores` · `POST /api/mentores/remover|senha` · `GET /api/admin/copia` · `POST /api/admin/restaurar|zerar|lgpd-apagar|teste-email` · `GET /agenda/{codigo}.ics`

Toda chamada que grava exige o cabeçalho `X-Portal: 1` (proteção contra requisições vindas de outros sites).

## Segurança

- Senhas: PBKDF2-HMAC-SHA256, 310.000 iterações; o banco guarda só o resumo.
- Sessão: código aleatório em cookie `HttpOnly; SameSite=Lax; Secure`; no banco fica o resumo do código.
- Tentativas de login erradas bloqueiam por tempo crescente (por e-mail e por endereço).
- Tudo o que o aluno grava é conferido no servidor (dono do registro, campos permitidos, formato).
- Arquivos: extensões permitidas, tamanho máximo, fora da pasta pública; só o dono e o mentor baixam.

## Testes

`src/test/java` (JUnit 4): 99 testes. `mvn test` roda todos, com banco H2 em memória no modo MySQL e servidores de e-mail, push e webhook de mentira. Cobrem: JSON, senhas, SMTP (inclusive SSL e STARTTLS), Web Push (exemplo da RFC 8291), agenda, regras de frequência e a API inteira de ponta a ponta.

## Linha de comando

```
java -jar suba-portal.jar [--config=config.properties]
java -jar suba-portal.jar criar-mentor "Nome" email senha
java -jar suba-portal.jar redefinir-senha email novaSenha
java -jar suba-portal.jar versao
```
