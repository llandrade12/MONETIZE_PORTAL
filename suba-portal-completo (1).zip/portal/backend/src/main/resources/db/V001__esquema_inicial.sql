-- Monetize · Área de Membros (Mentoria Suba o Padrão)
-- Esquema inicial do banco de dados. MySQL 8 ou MariaDB 10.4+ (InnoDB, utf8mb4).
-- O servidor aplica este arquivo sozinho na primeira vez que sobe. O banco nasce vazio:
-- nenhuma turma, aluno, aula ou tarefa de exemplo.
-- Os comandos podem ser repetidos sem erro: se a primeira tentativa parar no meio (queda de energia,
-- permissão faltando), basta corrigir a causa e subir o servidor de novo.

-- Quem entra no painel do mentor.
CREATE TABLE IF NOT EXISTS mentor (
  id            BIGINT       NOT NULL AUTO_INCREMENT,
  nome          VARCHAR(160) NOT NULL,
  email         VARCHAR(190) NOT NULL,
  senha_hash    VARCHAR(255) NOT NULL,
  agenda_token  VARCHAR(64)  CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  ativo         TINYINT      NOT NULL DEFAULT 1,
  criado_em     DATETIME     NOT NULL,
  ultimo_acesso DATETIME     NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_mentor_email (email),
  UNIQUE KEY uq_mentor_agenda (agenda_token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Alunos (mentorados). As colunas repetem o que o servidor precisa consultar (login, turma, situação);
-- a ficha completa, como o portal usa, fica em "dados" (JSON).
CREATE TABLE IF NOT EXISTS aluno (
  id            BIGINT       NOT NULL,
  nome          VARCHAR(160) NOT NULL,
  email         VARCHAR(190) NULL,
  telefone      VARCHAR(40)  NULL,
  turma_id      BIGINT       NULL,
  status        VARCHAR(20)  NOT NULL,
  senha_hash    VARCHAR(255) NULL,
  agenda_token  VARCHAR(64)  CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  dados         LONGTEXT     NOT NULL,
  rev           BIGINT       NOT NULL,
  criado_em     DATETIME     NOT NULL,
  atualizado_em DATETIME     NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_aluno_email (email),
  UNIQUE KEY uq_aluno_agenda (agenda_token),
  KEY ix_aluno_rev (rev),
  KEY ix_aluno_turma (turma_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Todos os demais registros do portal, um por linha: turmas, aulas, tarefas, entregas, notas, presenças,
-- metas, avisos, notificações, configurações etc. "colecao" diz o tipo, "chave" identifica o registro
-- dentro do tipo e "dados" guarda o conteúdo em JSON. "aluno_id" marca o dono, quando o registro é de um aluno.
-- "rev" é o número da alteração (cada gravação recebe um número maior), usado para o portal buscar só o que mudou.
-- Registro excluído fica com apagado = 1 por um tempo, para os aparelhos abertos saberem que ele saiu.
CREATE TABLE IF NOT EXISTS registro (
  seq           BIGINT       NOT NULL AUTO_INCREMENT,
  colecao       VARCHAR(30)  CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  chave         VARCHAR(150) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  aluno_id      BIGINT       NULL,
  dados         LONGTEXT     NOT NULL,
  apagado       TINYINT      NOT NULL DEFAULT 0,
  rev           BIGINT       NOT NULL,
  criado_em     DATETIME     NOT NULL,
  atualizado_em DATETIME     NOT NULL,
  PRIMARY KEY (seq),
  UNIQUE KEY uq_registro (colecao, chave),
  KEY ix_registro_rev (rev),
  KEY ix_registro_aluno (aluno_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sessões de login (o navegador guarda só um código aleatório; aqui fica o resumo dele).
CREATE TABLE IF NOT EXISTS sessao (
  id            BIGINT       NOT NULL AUTO_INCREMENT,
  token_hash    CHAR(64)     CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  mentor_id     BIGINT       NULL,
  aluno_id      BIGINT       NULL,
  persistente   TINYINT      NOT NULL DEFAULT 0,
  criado_em     DATETIME     NOT NULL,
  visto_em      DATETIME     NOT NULL,
  expira_em     DATETIME     NOT NULL,
  ip            VARCHAR(64)  NULL,
  agente        VARCHAR(255) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_sessao_token (token_hash),
  KEY ix_sessao_expira (expira_em),
  KEY ix_sessao_aluno (aluno_id),
  KEY ix_sessao_mentor (mentor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Links de "esqueci minha senha" (valem 1 hora e uma única vez).
CREATE TABLE IF NOT EXISTS redefinicao_senha (
  token_hash    CHAR(64)     CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  mentor_id     BIGINT       NULL,
  aluno_id      BIGINT       NULL,
  criado_em     DATETIME     NOT NULL,
  expira_em     DATETIME     NOT NULL,
  usado         TINYINT      NOT NULL DEFAULT 0,
  PRIMARY KEY (token_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Arquivos enviados (entregas dos alunos, materiais de aula, PDFs das recomendações).
-- O conteúdo fica em disco, na pasta de arquivos do servidor; aqui ficam os dados do arquivo.
CREATE TABLE IF NOT EXISTS arquivo (
  id            VARCHAR(60)  CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  aluno_id      BIGINT       NULL,
  mentor_id     BIGINT       NULL,
  nome          VARCHAR(255) NOT NULL,
  tipo          VARCHAR(120) NULL,
  tamanho       BIGINT       NOT NULL,
  caminho       VARCHAR(255) NOT NULL,
  criado_em     DATETIME     NOT NULL,
  PRIMARY KEY (id),
  KEY ix_arquivo_aluno (aluno_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Aparelhos que aceitaram receber notificações (push) do portal.
CREATE TABLE IF NOT EXISTS push_inscricao (
  id            BIGINT       NOT NULL AUTO_INCREMENT,
  mentor_id     BIGINT       NULL,
  aluno_id      BIGINT       NULL,
  endpoint_hash CHAR(64)     CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  endpoint      TEXT         NOT NULL,
  p256dh        VARCHAR(200) NOT NULL,
  auth          VARCHAR(100) NOT NULL,
  falhas        INT          NOT NULL DEFAULT 0,
  criado_em     DATETIME     NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_push_endpoint (endpoint_hash),
  KEY ix_push_aluno (aluno_id),
  KEY ix_push_mentor (mentor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Fila de saída: e-mails e mensagens que o servidor ainda vai enviar (ou já enviou).
CREATE TABLE IF NOT EXISTS envio (
  id            BIGINT       NOT NULL AUTO_INCREMENT,
  fila_chave    VARCHAR(150) CHARACTER SET ascii COLLATE ascii_bin NULL,
  canal         VARCHAR(20)  NOT NULL,
  destino       VARCHAR(600) NOT NULL,
  nome          VARCHAR(160) NULL,
  assunto       VARCHAR(255) NOT NULL,
  corpo         LONGTEXT     NOT NULL,
  status        VARCHAR(20)  NOT NULL,
  tentativas    INT          NOT NULL DEFAULT 0,
  proxima_em    DATETIME     NOT NULL,
  erro          VARCHAR(500) NULL,
  criado_em     DATETIME     NOT NULL,
  enviado_em    DATETIME     NULL,
  PRIMARY KEY (id),
  KEY ix_envio_pendente (status, proxima_em)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Lembretes automáticos que já saíram (cada lembrete sai uma única vez).
CREATE TABLE IF NOT EXISTS lembrete_enviado (
  chave_hash    CHAR(64)     CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  chave         TEXT         NOT NULL,
  enviado_em    DATETIME     NOT NULL,
  PRIMARY KEY (chave_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Contadores: "rev" (número da última alteração) e "id" (próximo código de turma, aluno, aula e tarefa).
CREATE TABLE IF NOT EXISTS sequencia (
  nome          VARCHAR(40)  CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  valor         BIGINT       NOT NULL,
  PRIMARY KEY (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO sequencia (nome, valor) SELECT 'rev', 0 FROM (SELECT 1 AS um) base WHERE NOT EXISTS (SELECT 1 FROM sequencia WHERE nome = 'rev');
INSERT INTO sequencia (nome, valor) SELECT 'id', 0 FROM (SELECT 1 AS um) base WHERE NOT EXISTS (SELECT 1 FROM sequencia WHERE nome = 'id');

-- Valores internos do servidor (chaves do push, marca de instalação).
CREATE TABLE IF NOT EXISTS parametro (
  nome          VARCHAR(60)  CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  valor         LONGTEXT     NOT NULL,
  PRIMARY KEY (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
