package br.com.monetize.portal.dados;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

import br.com.monetize.portal.db.Banco;

/** Todo o SQL das tabelas "registro", "aluno" e "sequencia". */
public final class Repositorio {

    private Repositorio() {
    }

    /** Uma linha da tabela registro. */
    public static final class Reg {
        public long seq;
        public String colecao;
        public String chave;
        public Long alunoId;
        public String dados;
        public boolean apagado;
        public long rev;
    }

    /** Uma linha da tabela aluno. */
    public static final class AlunoLinha {
        public long id;
        public String nome;
        public String email;
        public String telefone;
        public Long turmaId;
        public String status;
        public String senhaHash;
        public String agendaToken;
        public String dados;
        public long rev;

        public long turma() {
            return turmaId == null ? 0 : turmaId;
        }
    }

    /* ---------- contadores ---------- */

    /**
     * Abre uma gravação: reserva o próximo número de alteração. Como todas as gravações atualizam a mesma
     * linha, o banco as coloca em fila, e os números são confirmados sempre em ordem crescente.
     */
    public static long proximaRev(Connection c) throws SQLException {
        Banco.executar(c, "UPDATE sequencia SET valor = valor + 1 WHERE nome = 'rev'");
        return revAtual(c);
    }

    public static long revAtual(Connection c) throws SQLException {
        Long v = Banco.um(c, "SELECT valor FROM sequencia WHERE nome = 'rev'", r -> r.getLong(1));
        if (v == null)
            throw new SQLException("Tabela sequencia sem a linha 'rev'");
        return v;
    }

    /** Reserva n códigos numéricos seguidos (turma, aluno, aula, tarefa). Devolve o primeiro. */
    public static long reservarIds(Connection c, int n) throws SQLException {
        Banco.executar(c, "UPDATE sequencia SET valor = valor + ? WHERE nome = 'id'", n);
        Long fim = Banco.um(c, "SELECT valor FROM sequencia WHERE nome = 'id'", r -> r.getLong(1));
        if (fim == null)
            throw new SQLException("Tabela sequencia sem a linha 'id'");
        return fim - n + 1;
    }

    /** Garante que os próximos códigos fiquem acima de um código já usado (restauração de cópia). */
    public static void garantirIdAcimaDe(Connection c, long usado) throws SQLException {
        Banco.executar(c, "UPDATE sequencia SET valor = ? WHERE nome = 'id' AND valor < ?", usado, usado);
    }

    /* ---------- registro ---------- */

    private static final String COLUNAS = "seq, colecao, chave, aluno_id, dados, apagado, rev";

    private static Reg reg(ResultSet r) throws SQLException {
        Reg x = new Reg();
        x.seq = r.getLong("seq");
        x.colecao = r.getString("colecao");
        x.chave = r.getString("chave");
        x.alunoId = Banco.longOuNulo(r, "aluno_id");
        x.dados = r.getString("dados");
        x.apagado = r.getInt("apagado") != 0;
        x.rev = r.getLong("rev");
        return x;
    }

    /** Registro pela chave (inclui os marcados como apagados), ou null. */
    public static Reg ler(Connection c, String colecao, String chave) throws SQLException {
        return Banco.um(c, "SELECT " + COLUNAS + " FROM registro WHERE colecao = ? AND chave = ?", Repositorio::reg, colecao, chave);
    }

    /** Registro existente e não apagado, ou null. */
    public static Reg vivo(Connection c, String colecao, String chave) throws SQLException {
        Reg r = ler(c, colecao, chave);
        return r == null || r.apagado ? null : r;
    }

    public static void gravar(Connection c, String colecao, String chave, Long alunoId, String json, long rev, LocalDateTime agora) throws SQLException {
        int n = Banco.executar(c, "UPDATE registro SET aluno_id = ?, dados = ?, apagado = 0, rev = ?, atualizado_em = ? WHERE colecao = ? AND chave = ?",
                alunoId, json, rev, agora, colecao, chave);
        if (n == 0)
            Banco.executar(c, "INSERT INTO registro (colecao, chave, aluno_id, dados, apagado, rev, criado_em, atualizado_em) VALUES (?, ?, ?, ?, 0, ?, ?, ?)",
                    colecao, chave, alunoId, json, rev, agora, agora);
    }

    /** Marca como apagado (o conteúdo some na hora; a marca fica para avisar os aparelhos abertos). */
    public static boolean apagar(Connection c, String colecao, String chave, long rev, LocalDateTime agora) throws SQLException {
        return Banco.executar(c, "UPDATE registro SET dados = '', apagado = 1, rev = ?, atualizado_em = ? WHERE colecao = ? AND chave = ? AND apagado = 0",
                rev, agora, colecao, chave) > 0;
    }

    /** Todos os registros existentes, na ordem em que foram criados. */
    public static List<Reg> vivos(Connection c) throws SQLException {
        return Banco.consultar(c, "SELECT " + COLUNAS + " FROM registro WHERE apagado = 0 ORDER BY seq", Repositorio::reg);
    }

    /** Registros sem dono ou do aluno informado. */
    public static List<Reg> vivosParaAluno(Connection c, long alunoId) throws SQLException {
        return Banco.consultar(c, "SELECT " + COLUNAS + " FROM registro WHERE apagado = 0 AND (aluno_id IS NULL OR aluno_id = ?) ORDER BY seq", Repositorio::reg, alunoId);
    }

    public static List<Reg> vivosDe(Connection c, String colecao) throws SQLException {
        return Banco.consultar(c, "SELECT " + COLUNAS + " FROM registro WHERE apagado = 0 AND colecao = ? ORDER BY seq", Repositorio::reg, colecao);
    }

    public static List<Reg> vivosDoAluno(Connection c, long alunoId) throws SQLException {
        return Banco.consultar(c, "SELECT " + COLUNAS + " FROM registro WHERE apagado = 0 AND aluno_id = ? ORDER BY seq", Repositorio::reg, alunoId);
    }

    /** Alterações depois de um número de alteração (inclui apagados). */
    public static List<Reg> desde(Connection c, long rev) throws SQLException {
        return Banco.consultar(c, "SELECT " + COLUNAS + " FROM registro WHERE rev > ? ORDER BY rev, seq", Repositorio::reg, rev);
    }

    public static List<Reg> desdeParaAluno(Connection c, long rev, long alunoId) throws SQLException {
        return Banco.consultar(c, "SELECT " + COLUNAS + " FROM registro WHERE rev > ? AND (aluno_id IS NULL OR aluno_id = ?) ORDER BY rev, seq", Repositorio::reg, rev, alunoId);
    }

    /* ---------- aluno ---------- */

    private static final String COLUNAS_ALUNO = "id, nome, email, telefone, turma_id, status, senha_hash, agenda_token, dados, rev";

    private static AlunoLinha aluno(ResultSet r) throws SQLException {
        AlunoLinha a = new AlunoLinha();
        a.id = r.getLong("id");
        a.nome = r.getString("nome");
        a.email = r.getString("email");
        a.telefone = r.getString("telefone");
        a.turmaId = Banco.longOuNulo(r, "turma_id");
        a.status = r.getString("status");
        a.senhaHash = r.getString("senha_hash");
        a.agendaToken = r.getString("agenda_token");
        a.dados = r.getString("dados");
        a.rev = r.getLong("rev");
        return a;
    }

    public static AlunoLinha lerAluno(Connection c, long id) throws SQLException {
        return Banco.um(c, "SELECT " + COLUNAS_ALUNO + " FROM aluno WHERE id = ?", Repositorio::aluno, id);
    }

    public static AlunoLinha alunoPorEmail(Connection c, String email) throws SQLException {
        return Banco.um(c, "SELECT " + COLUNAS_ALUNO + " FROM aluno WHERE email = ?", Repositorio::aluno, email);
    }

    public static AlunoLinha alunoPorAgenda(Connection c, String token) throws SQLException {
        return Banco.um(c, "SELECT " + COLUNAS_ALUNO + " FROM aluno WHERE agenda_token = ?", Repositorio::aluno, token);
    }

    public static List<AlunoLinha> alunos(Connection c) throws SQLException {
        return Banco.consultar(c, "SELECT " + COLUNAS_ALUNO + " FROM aluno ORDER BY id", Repositorio::aluno);
    }

    public static List<AlunoLinha> alunosDesde(Connection c, long rev) throws SQLException {
        return Banco.consultar(c, "SELECT " + COLUNAS_ALUNO + " FROM aluno WHERE rev > ? ORDER BY rev, id", Repositorio::aluno, rev);
    }

    public static void inserirAluno(Connection c, AlunoLinha a, LocalDateTime agora) throws SQLException {
        Banco.executar(c, "INSERT INTO aluno (id, nome, email, telefone, turma_id, status, senha_hash, agenda_token, dados, rev, criado_em, atualizado_em) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                a.id, a.nome, a.email, a.telefone, a.turmaId, a.status, a.senhaHash, a.agendaToken, a.dados, a.rev, agora, agora);
    }

    public static void atualizarAluno(Connection c, AlunoLinha a, LocalDateTime agora) throws SQLException {
        Banco.executar(c, "UPDATE aluno SET nome = ?, email = ?, telefone = ?, turma_id = ?, status = ?, senha_hash = ?, dados = ?, rev = ?, atualizado_em = ? WHERE id = ?",
                a.nome, a.email, a.telefone, a.turmaId, a.status, a.senhaHash, a.dados, a.rev, agora, a.id);
    }

    public static void senhaDoAluno(Connection c, long id, String hash) throws SQLException {
        Banco.executar(c, "UPDATE aluno SET senha_hash = ? WHERE id = ?", hash, id);
    }
}
