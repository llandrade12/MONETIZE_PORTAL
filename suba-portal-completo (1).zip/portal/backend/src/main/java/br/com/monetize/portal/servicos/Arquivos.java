package br.com.monetize.portal.servicos;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import br.com.monetize.portal.Config;
import br.com.monetize.portal.auth.Usuario;
import br.com.monetize.portal.dados.Repositorio;
import br.com.monetize.portal.dados.Repositorio.Reg;
import br.com.monetize.portal.db.Banco;
import br.com.monetize.portal.http.ErroHttp;
import br.com.monetize.portal.http.Req;
import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Log;
import br.com.monetize.portal.util.Texto;

/**
 * Arquivos enviados pelo portal: anexos das entregas (aluno), materiais de aula e PDFs das recomendações (mentor).
 * O conteúdo fica em disco, na pasta de arquivos; a tabela "arquivo" guarda o nome, o tamanho e de quem é.
 *
 * Quem pode baixar: o mentor, qualquer arquivo; o aluno, os arquivos dele e os que o mentor enviou.
 */
public final class Arquivos {

    /** Extensões aceitas (as mesmas de FEXT e MEXT em web/js/compartilhado/data/constants.js). */
    private static final Set<String> EXTENSOES = new HashSet<>(Arrays.asList("pdf", "ppt", "pptx", "key", "xls", "xlsx", "csv", "doc", "docx", "txt", "png", "jpg", "jpeg", "zip", "mp3"));

    private final Banco banco;
    private final Config config;
    private final Path pasta;

    public Arquivos(Banco banco, Config config) throws IOException {
        this.banco = banco;
        this.config = config;
        this.pasta = config.pastaArquivos();
        Files.createDirectories(pasta);
        if (!Files.isWritable(pasta))
            throw new IOException("A pasta de arquivos não aceita gravação: " + pasta + " (confira o dono e as permissões)");
    }

    private static final class Arquivo {
        String id, nome, tipo, caminho;
        Long alunoId, mentorId;
        long tamanho;
    }

    private static Arquivo ler(Connection c, String id) throws SQLException {
        return Banco.um(c, "SELECT id, aluno_id, mentor_id, nome, tipo, tamanho, caminho FROM arquivo WHERE id = ?", r -> {
            Arquivo a = new Arquivo();
            a.id = r.getString("id");
            a.alunoId = Banco.longOuNulo(r, "aluno_id");
            a.mentorId = Banco.longOuNulo(r, "mentor_id");
            a.nome = r.getString("nome");
            a.tipo = r.getString("tipo");
            a.tamanho = r.getLong("tamanho");
            a.caminho = r.getString("caminho");
            return a;
        }, id);
    }

    private static String idValido(String id) {
        if (id == null || !id.matches("[A-Za-z0-9_-]{4,60}"))
            throw ErroHttp.pedidoInvalido("Identificador de arquivo inválido");
        return id;
    }

    private static String extensao(String nome) {
        int i = nome.lastIndexOf('.');
        return i < 0 ? "" : nome.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    /** Recebe o arquivo no corpo da requisição (PUT /api/arquivos/{id}?nome=...). */
    public void receber(Req r) throws IOException {
        Usuario u = r.usuario;
        String id = idValido(r.parametro);
        String nome = Texto.semEmoji(r.q("nome")).replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (nome.isEmpty() || nome.length() > 200)
            throw ErroHttp.pedidoInvalido("Informe o nome do arquivo");
        if (!EXTENSOES.contains(extensao(nome)))
            throw new ErroHttp(415, "formato", "Formato de arquivo não aceito: " + nome);
        long maximo = config.uploadMaxMb() * 1024L * 1024L;
        Arquivo existente = banco.usar(c -> ler(c, id));
        /* Cada envio tem o seu código. O mentor pode reenviar um arquivo dele; o aluno nunca troca o conteúdo
           de um arquivo já enviado (a entrega avaliada precisa continuar sendo a que o mentor viu). */
        if (existente != null && !(u.mentor() && existente.mentorId != null))
            throw new ErroHttp(409, "ja-existe", "Já existe um arquivo com este identificador");

        String relativo = id.substring(0, 2).toLowerCase(Locale.ROOT) + "/" + id;
        Path destino = pasta.resolve(relativo).normalize();
        if (!destino.startsWith(pasta))
            throw ErroHttp.pedidoInvalido("Identificador de arquivo inválido");
        Files.createDirectories(destino.getParent());
        Path temp = Files.createTempFile(destino.getParent(), "envio-", ".tmp");
        long total = 0;
        try {
            try (InputStream in = r.x.getRequestBody(); OutputStream out = Files.newOutputStream(temp)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) {
                    total += n;
                    if (total > maximo)
                        throw new ErroHttp(413, "grande-demais", "O arquivo passa de " + config.uploadMaxMb() + " MB");
                    out.write(buf, 0, n);
                }
            }
            if (total == 0)
                throw ErroHttp.pedidoInvalido("Arquivo vazio");
            Files.move(temp, destino, StandardCopyOption.REPLACE_EXISTING);
        } finally {
            Files.deleteIfExists(temp);
        }
        final long tamanho = total;
        String tipo = Texto.cortar(r.q("tipo").replaceAll("[^A-Za-z0-9/.+-]", ""), 120);
        banco.transacao(c -> {
            Banco.executar(c, "DELETE FROM arquivo WHERE id = ?", id);
            return Banco.executar(c, "INSERT INTO arquivo (id, aluno_id, mentor_id, nome, tipo, tamanho, caminho, criado_em) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    id, u.aluno() ? u.id : null, u.mentor() ? u.id : null, nome, tipo, tamanho, relativo, java.time.LocalDateTime.now(config.fuso()));
        });
        r.json(200, "{\"ok\":true,\"tamanho\":" + tamanho + "}");
    }

    /** Envia o arquivo para quem tem direito de vê-lo. */
    public void entregar(Req r) throws IOException {
        Usuario u = r.usuario;
        String id = idValido(r.parametro);
        Arquivo a = banco.usar(c -> ler(c, id));
        if (a == null || !(u.mentor() || a.mentorId != null || (a.alunoId != null && a.alunoId == u.id)))
            throw ErroHttp.naoEncontrado();
        Path arq = pasta.resolve(a.caminho).normalize();
        if (!arq.startsWith(pasta) || !Files.isRegularFile(arq))
            throw ErroHttp.naoEncontrado();
        String ext = extensao(a.nome);
        String tipo = ext.equals("pdf") ? "application/pdf" : ext.equals("png") ? "image/png" : ext.equals("jpg") || ext.equals("jpeg") ? "image/jpeg" : "application/octet-stream";
        r.saida().set("Content-Type", tipo);
        r.saida().set("Content-Disposition", "attachment; filename=\"arquivo." + ext + "\"; filename*=UTF-8''" + java.net.URLEncoder.encode(a.nome, java.nio.charset.StandardCharsets.UTF_8).replace("+", "%20"));
        r.saida().set("Cache-Control", "private, max-age=3600");
        long tam = Files.size(arq);
        if (r.metodo.equals("HEAD")) {
            r.saida().set("Content-Length", String.valueOf(tam));
            r.vazio(200);
            return;
        }
        try (OutputStream out = r.corpoDireto(200, tam)) {
            Files.copy(arq, out);
        }
    }

    public void apagar(Req r) throws IOException {
        Usuario u = r.usuario;
        String id = idValido(r.parametro);
        Arquivo a = banco.usar(c -> ler(c, id));
        if (a != null) {
            if (!(u.mentor() || (a.alunoId != null && a.alunoId == u.id)))
                throw ErroHttp.proibido();
            if (u.aluno() && banco.usar(c -> emEntregaAvaliada(c, u.id, id)))
                throw new ErroHttp(409, "ja-avaliada", "A entrega já foi avaliada: o arquivo não pode mais ser removido");
            banco.usar(c -> Banco.executar(c, "DELETE FROM arquivo WHERE id = ?", id));
            remover(a.caminho);
        }
        r.ok();
    }

    /** O arquivo faz parte de uma entrega do aluno que já recebeu nota? */
    private static boolean emEntregaAvaliada(Connection c, long alunoId, String arquivoId) throws SQLException {
        for (Reg r : Repositorio.vivosDoAluno(c, alunoId)) {
            if (!r.colecao.equals("ent") || Repositorio.vivo(c, "notas", r.chave) == null)
                continue;
            for (Object f : Json.lista(Json.obj(Json.ler(r.dados)), "files"))
                if (arquivoId.equals(Json.str(Json.obj(f), "id")))
                    return true;
        }
        return false;
    }

    /** Apaga do disco e da tabela todos os arquivos de um aluno (exclusão de dados, LGPD). Devolve os caminhos. */
    public static List<String> apagarDoAluno(Connection c, long alunoId) throws SQLException {
        List<String> caminhos = Banco.consultar(c, "SELECT caminho FROM arquivo WHERE aluno_id = ?", r -> r.getString(1), alunoId);
        Banco.executar(c, "DELETE FROM arquivo WHERE aluno_id = ?", alunoId);
        return caminhos;
    }

    /** Remove o arquivo do disco (depois que a exclusão foi confirmada no banco). */
    public void remover(String relativo) {
        try {
            Path arq = pasta.resolve(relativo).normalize();
            if (arq.startsWith(pasta))
                Files.deleteIfExists(arq);
        } catch (IOException e) {
            Log.aviso("Não foi possível apagar o arquivo " + relativo + ": " + e.getMessage());
        }
    }
}
