package br.com.monetize.portal.dados;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import br.com.monetize.portal.dados.Colecao.Escrita;
import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Texto;

/**
 * O que um aluno pode gravar. O mentor grava tudo; estas regras valem só para sessões de aluno.
 *
 * Princípios: o aluno só mexe no que é dele; campos que pertencem ao mentor (nota, resposta, aprovação,
 * situação do cadastro, turma) nunca são aceitos de um aluno; nos registros que ele só pode criar
 * (justificativa, contestação, alerta ao mentor), o que já foi gravado não muda mais.
 */
final class Permissoes {

    private Permissoes() {
    }

    private static final int TEXTO_MAX = 20_000;

    /** Valor que deve ser gravado (pode vir ajustado), ou null quando é exclusão. Lança {@link Recusa}. */
    static Object aluno(Gravador g, Colecao col, String k, Object antigo, Object pedido, boolean rm) throws SQLException {
        long eu = g.u.id;
        if (col.escrita == Escrita.NADA)
            throw new Recusa("sem-permissao");

        /* O registro existente precisa ser do próprio aluno (nas coleções que têm dono). */
        if (col.dono != Colecao.Dono.NINGUEM) {
            if (antigo != null && !ehDe(col, k, antigo, eu))
                throw new Recusa("nao-e-seu");
            if (!rm && !ehDe(col, k, pedido, eu))
                throw new Recusa("nao-e-seu");
        }

        if (rm) {
            if (!col.alunoApaga || antigo == null)
                throw new Recusa("sem-permissao");
            return null;
        }

        switch (col.escrita) {
            case SO_CRIAR:
                return criar(g, col, antigo, pedido);
            case PROPRIO:
                return proprio(g, col, antigo, pedido);
            default:
                return especial(g, col, k, antigo, pedido);
        }
    }

    private static boolean ehDe(Colecao col, String k, Object valor, long aluno) {
        Long dono = col.donoDe(k, valor);
        return dono != null && dono == aluno;
    }

    private static Map<String, Object> objeto(Object o) {
        return Higiene.objeto(o);
    }

    /* ---------- só criar ---------- */

    private static Object criar(Gravador g, Colecao col, Object antigo, Object pedido) {
        if (antigo != null) {
            /* Reenvio do mesmo registro (a resposta anterior se perdeu no caminho): não muda nada. */
            return antigo;
        }
        Map<String, Object> p = objeto(pedido), n;
        switch (col.nome) {
            case "contest":
                n = Higiene.so(p, "id", "aid", "tid", "msg");
                n.put("tid", Higiene.codigo(p.get("tid")));
                n.put("msg", Higiene.texto(p.get("msg"), TEXTO_MAX));
                n.put("at", g.carimbo);
                n.put("resp", "");
                return n;
            case "just":
                n = Higiene.so(p, "id", "aid", "n", "motivo");
                n.put("n", Higiene.codigo(p.get("n")));
                n.put("motivo", Higiene.texto(p.get("motivo"), TEXTO_MAX));
                n.put("at", g.carimbo);
                n.put("st", "pendente");
                n.put("resp", "");
                return n;
            case "inboxM":
                Limites.conferir(g.u.id, "inboxM", 80);
                n = Higiene.so(p, "id");
                n.put("t", Higiene.texto(p.get("t"), 300));
                n.put("m", Higiene.texto(p.get("m"), 2000));
                n.put("at", g.carimbo);
                n.put("lido", false);
                n.put("go", Higiene.pagina(p.get("go"), "visao"));
                n.put("arg", Higiene.codigoOuNulo(p.get("arg")));
                n.put("auto", false);
                return n;
            case "notif":
                Limites.conferir(g.u.id, "notif", 80);
                n = Higiene.so(p, "id");
                n.put("at", g.carimbo);
                n.put("ev", Higiene.texto(p.get("ev"), 300));
                n.put("canal", Higiene.texto(p.get("canal"), 80));
                n.put("dest", Higiene.texto(p.get("dest"), 300));
                n.put("auto", false);
                return n;
            case "log":
                Limites.conferir(g.u.id, "log", 900);
                n = Higiene.so(p, "id");
                n.put("at", g.carimbo);
                n.put("who", g.u.nome);
                n.put("m", Higiene.texto(p.get("m"), 500));
                return n;
            default:
                throw new Recusa("sem-permissao");
        }
    }

    /* ---------- registros do próprio aluno ---------- */

    private static Object proprio(Gravador g, Colecao col, Object antigo, Object pedido) {
        switch (col.nome) {
            case "vis":
                /* Aula assistida: uma marca, sem conteúdo. */
                if (!Json.verdadeiro(pedido))
                    throw new Recusa("formato");
                return 1L;
            case "prog":
                return Higiene.progresso(pedido);
            case "rasc":
                return Higiene.rascunho(pedido);
            case "recSt":
                if (!"quero".equals(pedido) && !"feito".equals(pedido))
                    throw new Recusa("formato");
                return pedido;
            case "rot":
                return Higiene.rotina(pedido);
            case "diario":
                return anotacao(col, antigo, pedido);
            default:
                throw new Recusa("sem-permissao");
        }
    }

    /** Anotação do diário: o aluno escreve e escolhe compartilhar; a resposta é do mentor. */
    private static Object anotacao(Colecao col, Object antigo, Object pedido) {
        Map<String, Object> novo = objeto(pedido);
        Map<String, Object> res = antigo == null ? Gravador.novoMapa() : objeto(Json.copia(antigo));
        for (String campo : col.camposAluno) {
            if (novo.containsKey(campo))
                res.put(campo, novo.get(campo));
            else
                res.remove(campo);
        }
        res.put("n", Higiene.codigoOuNulo(res.get("n")));
        res.put("tit", Higiene.texto(res.get("tit"), 200));
        res.put("txt", Higiene.texto(res.get("txt"), TEXTO_MAX));
        /* As datas vêm do aparelho do aluno: o texto é gravado enquanto ele digita, e trocar a data aqui
           faria o portal recarregar a anotação no meio da digitação. */
        res.put("at", Higiene.texto(antigo == null ? res.get("at") : objeto(antigo).get("at"), 20));
        res.put("upd", Higiene.texto(res.get("upd"), 20));
        res.put("share", Json.verdadeiro(res.get("share")));
        if (res.containsKey("avisou"))
            res.put("avisou", Json.verdadeiro(res.get("avisou")));
        if (antigo == null)
            res.put("resp", "");
        return res;
    }

    /* ---------- casos com regra própria ---------- */

    private static Object especial(Gravador g, Colecao col, String k, Object antigo, Object pedido) throws SQLException {
        long eu = g.u.id;
        switch (col.nome) {
            case "avisos":
                return comentar(g, antigo, pedido);

            case "inbox": {
                /* Notificação: o aluno marca como lida; criar, só para ele mesmo (confirmações das próprias ações). */
                Map<String, Object> p = objeto(pedido);
                if (antigo == null) {
                    Limites.conferir(eu, "inbox", 40);
                    Map<String, Object> n = Higiene.so(p, "id", "aid");
                    n.put("t", Higiene.texto(p.get("t"), 300));
                    n.put("m", Higiene.texto(p.get("m"), 2000));
                    n.put("at", g.carimbo);
                    n.put("lido", false);
                    n.put("go", Higiene.pagina(p.get("go"), "inicio"));
                    if (p.containsKey("canal"))
                        n.put("canal", Higiene.texto(p.get("canal"), 80));
                    n.put("auto", false);
                    return n;
                }
                Map<String, Object> res = objeto(Json.copia(antigo));
                res.put("lido", Json.bool(p, "lido"));
                return res;
            }

            case "ent": {
                /* Entrega: pode enviar e corrigir enquanto o mentor não lançou a nota. */
                if (g.ler("notas", k) != null)
                    throw new Recusa("ja-avaliada");
                Map<String, Object> p = objeto(pedido);
                List<Object> arquivos = new ArrayList<>();
                /* Só entram os arquivos que este aluno enviou de fato. */
                for (Object f : Higiene.arquivos(p.get("files")))
                    if (g.arquivoDoAluno(Json.str(Json.obj(f), "id"), eu))
                        arquivos.add(f);
                return Json.mapa("at", g.carimbo, "txt", Higiene.texto(p.get("txt"), TEXTO_MAX), "link", Higiene.link(p.get("link")), "files", arquivos);
            }

            case "termos":
                /* Aceite dos termos: registrado uma vez, com a data e a hora do servidor. */
                return antigo != null ? antigo : g.carimbo;

            case "roda":
                return roda(g, antigo, pedido);

            case "metas":
                return meta(g, antigo, pedido);

            case "chamados":
                return chamado(g, antigo, pedido);

            case "lgpd": {
                Map<String, Object> n = objeto(pedido);
                if (antigo == null) {
                    Map<String, Object> novo = Higiene.so(n, "id", "aid");
                    novo.put("nome", g.u.nome);
                    novo.put("tipo", "exclusao");
                    novo.put("motivo", Higiene.texto(n.get("motivo"), 2000));
                    novo.put("at", g.carimbo);
                    novo.put("st", "pendente");
                    return novo;
                }
                Map<String, Object> res = objeto(Json.copia(antigo));
                if ("pendente".equals(res.get("st")) && "cancelado".equals(n.get("st")))
                    res.put("st", "cancelado");
                return res;
            }

            default:
                throw new Recusa("sem-permissao");
        }
    }

    /** Mural: o aluno só acrescenta comentários dele a um aviso que ele enxerga. */
    private static Object comentar(Gravador g, Object antigo, Object pedido) {
        Map<String, Object> aviso = Json.obj(antigo);
        if (aviso == null || !Estado.avisoPara(aviso, g.u))
            throw new Recusa("sem-permissao");
        Map<String, Object> res = objeto(Json.copia(aviso));
        List<Object> coms = new ArrayList<>(Json.lista(res, "coms"));
        int novos = 0;
        for (Map<String, Object> cm : Gravador.objetos(objeto(pedido), "coms")) {
            if (Json.num(cm, "aid", 0) != g.u.id)
                continue;
            String txt = Json.str(cm, "txt").trim();
            String at = Json.str(cm, "at");
            if (txt.isEmpty() || jaExiste(coms, g.u.id, txt, at))
                continue;
            Limites.conferir(g.u.id, "comentario", 60);
            coms.add(Json.mapa("aid", g.u.id, "txt", Texto.cortar(txt, 2000), "at", at.isEmpty() ? g.carimbo : Texto.cortar(at, 20)));
            novos++;
        }
        if (novos == 0)
            return aviso;
        res.put("coms", coms);
        return res;
    }

    private static boolean jaExiste(List<Object> coms, long aid, String txt, String at) {
        for (Object o : coms) {
            Map<String, Object> c = Json.obj(o);
            if (c != null && Json.num(c, "aid", 0) == aid && txt.equals(Json.str(c, "txt").trim()) && at.equals(Json.str(c, "at")))
                return true;
        }
        return false;
    }

    /**
     * Roda da Vida: o aluno preenche e envia a inicial e a final quando o mentor libera para a turma.
     * Depois de enviada, os valores não mudam mais.
     */
    private static Object roda(Gravador g, Object antigo, Object pedido) throws SQLException {
        Map<String, Object> n = objeto(pedido);
        Map<String, Object> a = Json.obj(antigo);
        Map<String, Object> res = a == null ? Gravador.novoMapa() : objeto(Json.copia(a));
        Map<String, Object> turma = g.u.turmaId > 0 ? Json.obj(g.ler("turmas", String.valueOf(g.u.turmaId))) : null;
        for (String fase : Arrays.asList("ini", "fin")) {
            String enviado = fase + "Sent";
            boolean jaEnviada = a != null && Json.bool(a, enviado);
            boolean liberada = turma != null && Json.bool(turma, fase.equals("ini") ? "rodaIni" : "rodaFin");
            if (!jaEnviada && liberada) {
                List<Object> v = notas(Json.lista(n, fase));
                if (v != null)
                    res.put(fase, v);
                res.put(enviado, Json.bool(n, enviado));
            }
            if (!res.containsKey(fase))
                res.put(fase, Arrays.asList(5L, 5L, 5L, 5L, 5L, 5L, 5L, 5L));
            if (!res.containsKey(enviado))
                res.put(enviado, false);
        }
        return res;
    }

    /** Oito notas de 1 a 10, ou null se o formato não for esse. */
    private static List<Object> notas(List<Object> l) {
        if (l.size() != 8)
            return null;
        List<Object> r = new ArrayList<>();
        for (Object o : l) {
            long v = Json.num(o, -1);
            if (v < 1 || v > 10)
                return null;
            r.add(v);
        }
        return r;
    }

    /** Meta do plano de ação: o aluno propõe e executa; aprovar e pedir ajuste é do mentor. */
    private static Object meta(Gravador g, Object antigo, Object pedido) {
        Map<String, Object> n = objeto(pedido);
        if (antigo == null) {
            Limites.conferir(g.u.id, "meta", 30);
            Map<String, Object> novo = Higiene.so(n, "id", "aid");
            novo.put("t", Higiene.texto(n.get("t"), 300));
            novo.put("prazo", Higiene.data(n.get("prazo")));
            novo.put("st", "proposta");
            novo.put("obs", "");
            novo.put("checkins", new ArrayList<>());
            novo.put("etapas", Higiene.etapas(n.get("etapas")));
            return novo;
        }
        Map<String, Object> a = objeto(antigo);
        Map<String, Object> res = objeto(Json.copia(a));
        if (n.containsKey("t"))
            res.put("t", Higiene.texto(n.get("t"), 300));
        if (n.containsKey("prazo"))
            res.put("prazo", Higiene.data(n.get("prazo")));
        if (n.containsKey("etapas"))
            res.put("etapas", Higiene.etapas(n.get("etapas")));
        if (n.containsKey("checkins"))
            res.put("checkins", acompanhamento(g, Json.lista(a, "checkins"), n.get("checkins")));
        /* Reenviar para aprovação (depois de um pedido de ajuste) volta a meta para "proposta" e limpa a observação. */
        if ("proposta".equals(n.get("st")) && !"proposta".equals(a.get("st"))) {
            res.put("st", "proposta");
            res.put("obs", "");
        }
        /* Concluir: só uma meta aprovada, uma vez, com a data e a hora do servidor. */
        if (Json.verdadeiro(n.get("feita")) && "aprovada".equals(res.get("st")) && !Json.verdadeiro(a.get("feita")))
            res.put("feita", g.carimbo);
        return res;
    }

    /**
     * Acompanhamento de uma meta: o aluno só acrescenta registros dele. O que já estava guardado
     * (inclusive os comentários do mentor) continua como está, na mesma ordem.
     */
    private static List<Object> acompanhamento(Gravador g, List<Object> antes, Object pedido) {
        List<Object> enviados = Json.lista(pedido);
        if (enviados == null)
            throw new Recusa("formato");
        List<Object> novos = new ArrayList<>();
        for (Object o : enviados) {
            Map<String, Object> ck = objeto(o);
            boolean existia = false;
            for (Object x : antes)
                existia = existia || Json.igual(x, ck);
            if (existia)
                continue;
            String txt = Higiene.texto(ck.get("txt"), 2000).trim();
            if (txt.isEmpty())
                continue;
            Limites.conferir(g.u.id, "meta-acompanhamento", 60);
            novos.add(Json.mapa("at", g.carimbo, "txt", txt, "who", ""));
        }
        /* Os registros mais novos ficam no começo da lista, como o portal mostra. */
        List<Object> res = new ArrayList<>(novos);
        res.addAll(antes);
        if (res.size() > 300)
            throw new Recusa("grande-demais");
        return res;
    }

    /** Chamado de suporte: o aluno abre, responde e pode marcar como resolvido. Mensagens da equipe são só da equipe. */
    private static Object chamado(Gravador g, Object antigo, Object pedido) {
        Map<String, Object> n = objeto(pedido);
        List<Map<String, Object>> msgsNovas = Gravador.objetos(n, "msgs");
        if (antigo == null) {
            Limites.conferir(g.u.id, "chamado", 20);
            List<Object> msgs = new ArrayList<>();
            for (Map<String, Object> m : msgsNovas)
                msgs.add(Json.mapa("adm", false, "txt", Texto.cortar(Json.str(m, "txt"), 5000), "at", Json.str(m, "at").isEmpty() ? g.carimbo : Texto.cortar(Json.str(m, "at"), 20)));
            if (msgs.isEmpty() || msgs.size() > 5)
                throw new Recusa("formato");
            Map<String, Object> novo = Higiene.so(n, "id", "aid");
            novo.put("cat", Higiene.texto(n.get("cat"), 40));
            novo.put("t", Higiene.texto(n.get("t"), 200));
            novo.put("st", "aberto");
            novo.put("at", g.carimbo);
            novo.put("upd", g.carimbo);
            novo.put("msgs", msgs);
            return novo;
        }
        Map<String, Object> a = objeto(antigo);
        Map<String, Object> res = objeto(Json.copia(a));
        List<Object> msgs = new ArrayList<>(Json.lista(res, "msgs"));
        boolean mudou = false;
        /* Mensagens novas do aluno: as que ainda não estão guardadas (a equipe pode ter respondido nesse meio-tempo). */
        for (Map<String, Object> m : msgsNovas) {
            String txt = Json.str(m, "txt").trim(), at = Json.str(m, "at");
            if (Json.bool(m, "adm") || txt.isEmpty() || msgExiste(msgs, txt, at))
                continue;
            Limites.conferir(g.u.id, "chamado-msg", 60);
            msgs.add(Json.mapa("adm", false, "txt", Texto.cortar(txt, 5000), "at", at.isEmpty() ? g.carimbo : Texto.cortar(at, 20)));
            mudou = true;
        }
        res.put("msgs", msgs);
        Object st = n.get("st");
        if (("aberto".equals(st) || "resolvido".equals(st)) && !st.equals(a.get("st"))) {
            res.put("st", st);
            mudou = true;
        }
        if (mudou)
            res.put("upd", g.carimbo);
        return res;
    }

    private static boolean msgExiste(List<Object> msgs, String txt, String at) {
        for (Object o : msgs) {
            Map<String, Object> m = Json.obj(o);
            if (m != null && !Json.bool(m, "adm") && txt.equals(Json.str(m, "txt").trim()) && at.equals(Json.str(m, "at")))
                return true;
        }
        return false;
    }

    /* ---------- o próprio cadastro ---------- */

    /** Campos que o aluno pode alterar no cadastro dele. Situação, turma, e-mail de login e matrícula são do mentor. */
    static Map<String, Object> proprioCadastro(Gravador g, long id, Map<String, Object> antigo, Map<String, Object> pedido) {
        if (antigo == null || id != g.u.id)
            throw new Recusa("sem-permissao");
        Colecao col = Colecoes.de(Colecoes.ALUNOS);
        Map<String, Object> res = objeto(Json.copia(antigo));
        for (String campo : col.camposAluno) {
            if (pedido.containsKey(campo))
                res.put(campo, pedido.get(campo));
            else
                res.remove(campo);
        }
        res.put("nome", Higiene.texto(res.get("nome"), 200).trim());
        String nome = Json.str(res, "nome");
        if (nome.length() < 3 || nome.length() > 160)
            throw new Recusa("nome-invalido");
        Higiene.textos(res, 40, "tel");
        Higiene.textos(res, 200, "cargo", "civil", "formacao", "cidade", "empresa");
        Higiene.textos(res, 600, "bio");
        if (res.containsKey("nasc"))
            res.put("nasc", Higiene.data(res.get("nasc")));
        String foto = Higiene.foto(res.get("foto"));
        if (foto == null)
            res.remove("foto");
        else
            res.put("foto", foto);
        /* Preferência de canais: só liga e desliga e-mail e WhatsApp. */
        if (res.containsKey("canais")) {
            Map<String, Object> canais = objeto(res.get("canais"));
            res.put("canais", Json.mapa("email", !Boolean.FALSE.equals(canais.get("email")), "whats", !Boolean.FALSE.equals(canais.get("whats"))));
        }
        /* Pedido de saída: fica registrado com a data do servidor e não é desfeito pelo aluno. */
        Map<String, Object> saidaAntes = Json.obj(antigo, "saida"), saida = Json.obj(res, "saida");
        if (saidaAntes != null)
            res.put("saida", saidaAntes);
        else if (saida != null)
            res.put("saida", Json.mapa("motivo", Higiene.texto(saida.get("motivo"), 1000), "at", g.carimbo));
        else
            res.remove("saida");
        return res;
    }
}
