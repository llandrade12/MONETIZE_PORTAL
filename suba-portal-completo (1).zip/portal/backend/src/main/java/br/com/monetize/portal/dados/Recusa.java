package br.com.monetize.portal.dados;

/** Uma alteração que o servidor não aceita (sem permissão, formato errado, regra do portal). */
public final class Recusa extends RuntimeException {
    private static final long serialVersionUID = 1L;

    /** Código curto, enviado ao portal. */
    public final String motivo;

    public Recusa(String motivo) {
        super(motivo, null, false, false);
        this.motivo = motivo;
    }
}
