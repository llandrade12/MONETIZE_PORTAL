package br.com.monetize.portal.api;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import br.com.monetize.portal.Config;
import br.com.monetize.portal.Principal;
import br.com.monetize.portal.auth.Contas;
import br.com.monetize.portal.auth.Sessoes;
import br.com.monetize.portal.auth.Usuario;
import br.com.monetize.portal.dados.Efeitos;
import br.com.monetize.portal.dados.Estado;
import br.com.monetize.portal.dados.Repositorio;
import br.com.monetize.portal.dados.Repositorio.AlunoLinha;
import br.com.monetize.portal.dados.Sincronizador;
import br.com.monetize.portal.db.Banco;
import br.com.monetize.portal.http.ErroHttp;
import br.com.monetize.portal.http.Req;
import br.com.monetize.portal.http.Servidor;
import br.com.monetize.portal.http.Servidor.Acesso;
import br.com.monetize.portal.servicos.Administracao;
import br.com.monetize.portal.servicos.Agenda;
import br.com.monetize.portal.servicos.Arquivos;
import br.com.monetize.portal.servicos.Envios;
import br.com.monetize.portal.servicos.Lembretes;
import br.com.monetize.portal.servicos.PushServico;
import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Senhas;

/** As rotas da API (/api/...) e da agenda (/agenda/...). Cada método atende uma rota. */
public final class Api {

    private static final int CORPO_PEQUENO = 64 * 1024;
    private static final int CORPO_SYNC = 6 * 1024 * 1024;
    private static final int CORPO_COPIA = 64 * 1024 * 1024;

    private final Config config;
    private final Banco banco;
    private final Sessoes sessoes;
    private final Contas contas;
    private final Sincronizador sinc;
    private final Arquivos arquivos;
    private final PushServico push;
    private final Lembretes lembretes;
    private final Administracao admin;
    private final Agenda agenda;
    private final Envios envios;

    public Api(Config config, Banco banco, Sessoes sessoes, Contas contas, Sincronizador sinc, Arquivos arquivos, PushServico push, Lembretes lembretes,
            Administracao admin, Agenda agenda, Envios envios) {
        this.config = config;
        this.banco = banco;
        this.sessoes = sessoes;
        this.contas = contas;
        this.sinc = sinc;
        this.arquivos = arquivos;
        this.push = push;
        this.lembretes = lembretes;
        this.admin = admin;
        this.agenda = agenda;
        this.envios = envios;
    }

    public void registrar(Servidor s) {
        s.autenticador(sessoes::identificar);

        s.rota("GET", "/api/saude", Acesso.PUBLICO, this::saude);
        s.rota("GET", "/api/publico", Acesso.PUBLICO, this::publico);
        s.rota("POST", "/api/auth/entrar", Acesso.PUBLICO, this::entrar);
        s.rota("POST", "/api/auth/sair", Acesso.PUBLICO, this::sair);
        s.rota("POST", "/api/auth/esqueci", Acesso.PUBLICO, this::esqueci);
        s.rota("POST", "/api/auth/redefinir", Acesso.PUBLICO, this::redefinir);

        s.rota("GET", "/api/estado", Acesso.LOGADO, this::estado);
        s.rota("GET", "/api/mudancas", Acesso.LOGADO, this::mudancas);
        s.rota("POST", "/api/sync", Acesso.LOGADO, this::sync);
        s.rota("GET", "/api/ids", Acesso.MENTOR, this::ids);
        s.rota("POST", "/api/conta/senha", Acesso.LOGADO, this::trocarSenha);

        s.rota("PUT", "/api/arquivos/*", Acesso.LOGADO, arquivos::receber);
        s.rota("GET", "/api/arquivos/*", Acesso.LOGADO, arquivos::entregar);
        s.rota("DELETE", "/api/arquivos/*", Acesso.LOGADO, arquivos::apagar);

        s.rota("POST", "/api/push/inscrever", Acesso.LOGADO, this::pushInscrever);
        s.rota("POST", "/api/push/remover", Acesso.LOGADO, this::pushRemover);
        s.rota("POST", "/api/push/teste", Acesso.LOGADO, this::pushTeste);

        s.rota("POST", "/api/lembretes/rodar", Acesso.MENTOR, this::lembretesRodar);
        s.rota("GET", "/api/mentores", Acesso.MENTOR, this::mentores);
        s.rota("POST", "/api/mentores", Acesso.MENTOR, this::mentorCriar);
        s.rota("POST", "/api/mentores/remover", Acesso.MENTOR, this::mentorRemover);
        s.rota("POST", "/api/mentores/senha", Acesso.MENTOR, this::mentorSenha);

        s.rota("GET", "/api/admin/copia", Acesso.MENTOR, this::copia);
        s.rota("POST", "/api/admin/restaurar", Acesso.MENTOR, this::restaurar);
        s.rota("POST", "/api/admin/zerar", Acesso.MENTOR, this::zerar);
        s.rota("POST", "/api/admin/lgpd-apagar", Acesso.MENTOR, this::lgpdApagar);
        s.rota("POST", "/api/admin/teste-email", Acesso.MENTOR, this::testeEmail);

        s.rota("GET", "/agenda/*", Acesso.PUBLICO, this::agendaIcs);
    }

    /* ---------------------------------------------------------------- público */

    private void saude(Req r) throws IOException {
        long rev = banco.usar(Repositorio::revAtual);
        r.json(Json.mapa("ok", true, "versao", Principal.VERSAO, "rev", rev));
    }

    /** O que a tela de login precisa saber antes de alguém entrar. */
    private void publico(Req r) throws IOException {
        r.json(Json.mapa("nome", config.nomePortal(), "email", config.emailConfigurado(), "versao", Principal.VERSAO));
    }

    private static Map<String, Object> eu(Usuario u) {
        return u.mentor() ? Json.mapa("role", "admin", "id", u.id, "nome", u.nome, "email", u.email) : Json.mapa("role", "aluno", "aid", u.id, "nome", u.nome, "email", u.email);
    }

    private void entrar(Req r) throws IOException {
        Map<String, Object> b = r.json(CORPO_PEQUENO);
        Usuario u = sessoes.entrar(r, Json.str(b, "email"), Json.str(b, "senha"), Json.bool(b, "manter"));
        r.json(Json.mapa("ok", true, "eu", eu(u)));
    }

    private void sair(Req r) throws IOException {
        sessoes.sair(r);
        r.ok();
    }

    private void esqueci(Req r) throws IOException {
        contas.esqueci(Json.str(r.json(CORPO_PEQUENO), "email"), r.ip());
        r.ok();
    }

    private void redefinir(Req r) throws IOException {
        Map<String, Object> b = r.json(CORPO_PEQUENO);
        contas.redefinir(Json.str(b, "token"), Json.str(b, "senha"));
        r.ok();
    }

    /* ---------------------------------------------------------------- estado e sincronização */

    /** Tudo o que a pessoa pode ver, mais quem ela é e as informações do servidor. */
    private void estado(Req r) throws IOException {
        Usuario u = r.usuario;
        String json = banco.transacao(c -> {
            String estado = Estado.completo(c, u);
            String tokenAgenda;
            if (u.mentor()) {
                tokenAgenda = Agenda.tokenDoMentor(c, u.id);
            } else {
                AlunoLinha a = Repositorio.lerAluno(c, u.id);
                tokenAgenda = a == null ? null : a.agendaToken;
            }
            Map<String, Object> srv = Json.mapa("email", config.emailConfigurado(), "push", push.chavePublica(), "agenda", tokenAgenda == null ? "" : agenda.url(tokenAgenda),
                    "uploadMb", (long) config.uploadMaxMb(), "versao", Principal.VERSAO);
            StringBuilder b = new StringBuilder(estado.length() + 512);
            b.append("{\"eu\":").append(Json.texto(eu(u))).append(",\"srv\":").append(Json.texto(srv));
            b.append(',').append(estado, 1, estado.length());
            return b.toString();
        });
        r.json(json);
    }

    /** Quantos códigos numéricos o painel reserva de cada vez. */
    private static final int BLOCO_DE_IDS = 50;

    private void mudancas(Req r) throws IOException {
        long desde = r.qLong("rev", -1);
        if (desde < 0)
            throw ErroHttp.pedidoInvalido("Informe rev");
        Usuario u = r.usuario;
        String json = banco.transacao(c -> Estado.mudancas(c, u, desde));
        r.json(json);
    }

    private void sync(Req r) throws IOException {
        Map<String, Object> b = r.json(CORPO_SYNC);
        List<Object> ops = Json.lista(b, "ops");
        if (ops.size() > Sincronizador.OPERACOES_MAX)
            throw new ErroHttp(413, "grande-demais", "Alterações demais em um único envio");
        Sincronizador.Resultado res = sinc.aplicar(r.usuario, ops);
        StringBuilder s = new StringBuilder(256);
        s.append("{\"ok\":true,\"rev\":").append(res.rev).append(",\"eco\":[");
        for (int i = 0; i < res.eco.size(); i++)
            s.append(i > 0 ? "," : "").append(res.eco.get(i));
        s.append("],\"recusadas\":").append(Json.texto(res.recusadas)).append('}');
        r.json(s.toString());
    }

    /** Reserva um bloco de códigos numéricos para o painel criar turmas, alunos, aulas e tarefas. */
    private void ids(Req r) throws IOException {
        long ini = banco.transacao(c -> Repositorio.reservarIds(c, BLOCO_DE_IDS));
        r.json("{\"ids\":[" + ini + "," + (ini + BLOCO_DE_IDS - 1) + "]}");
    }

    private void trocarSenha(Req r) throws IOException {
        Map<String, Object> b = r.json(CORPO_PEQUENO);
        contas.trocarSenha(r.usuario, Json.str(b, "atual"), Json.str(b, "nova"));
        r.ok();
    }

    /* ---------------------------------------------------------------- push */

    private void pushInscrever(Req r) throws IOException {
        Map<String, Object> b = r.json(CORPO_PEQUENO);
        Map<String, Object> chaves = Json.obj(b, "keys");
        push.inscrever(r.usuario, Json.str(b, "endpoint"), Json.str(chaves, "p256dh"), Json.str(chaves, "auth"));
        r.ok();
    }

    private void pushRemover(Req r) throws IOException {
        push.remover(r.usuario, Json.str(r.json(CORPO_PEQUENO), "endpoint"));
        r.ok();
    }

    private void pushTeste(Req r) throws IOException {
        Usuario u = r.usuario;
        int n = push.enviarAgora(new Efeitos.Push(u.mentor(), u.id, "Notificações ligadas", "É por aqui que chegam os avisos da Área de Membros.", ""));
        r.json(Json.mapa("ok", true, "entregues", (long) n));
    }

    /* ---------------------------------------------------------------- mentor */

    private void lembretesRodar(Req r) throws IOException {
        r.json(Json.mapa("ok", true, "n", (long) lembretes.rodar(true)));
    }

    private void mentores(Req r) throws IOException {
        r.json(Json.mapa("mentores", contas.mentores(), "eu", r.usuario.id));
    }

    private void mentorCriar(Req r) throws IOException {
        Map<String, Object> b = r.json(CORPO_PEQUENO);
        long id = contas.criarMentor(Json.str(b, "nome"), Json.str(b, "email"), Json.str(b, "senha"));
        r.json(Json.mapa("ok", true, "id", id));
    }

    private void mentorRemover(Req r) throws IOException {
        contas.removerMentor(r.usuario, Json.num(r.json(CORPO_PEQUENO), "id", 0));
        r.ok();
    }

    private void mentorSenha(Req r) throws IOException {
        Map<String, Object> b = r.json(CORPO_PEQUENO);
        contas.senhaDoMentor(Json.num(b, "id", 0), Json.str(b, "senha"));
        r.ok();
    }

    private void copia(Req r) throws IOException {
        r.saida().set("Content-Disposition", "attachment; filename=\"portal-dados.json\"");
        r.bytes(200, "application/json; charset=utf-8", admin.copia(r.usuario).getBytes(StandardCharsets.UTF_8), true);
    }

    /** Confere a senha de quem pediu uma operação que apaga dados. */
    private void exigirSenha(Req r, String senha) {
        String guardada = banco.usar(c -> Sessoes.mentorPorId(c, r.usuario.id).senhaHash);
        if (!Senhas.confere(senha, guardada, r.usuario.email))
            throw new ErroHttp(403, "senha-atual", "A senha não confere");
    }

    private void restaurar(Req r) throws IOException {
        Map<String, Object> b = r.json(CORPO_COPIA);
        exigirSenha(r, Json.str(b, "senha"));
        Administracao.Restauracao res = admin.restaurar(Json.obj(b, "copia"));
        r.json(Json.mapa("ok", true, "alunos", (long) res.alunos, "registros", (long) res.registros, "avisos", res.avisos));
    }

    private void zerar(Req r) throws IOException {
        exigirSenha(r, Json.str(r.json(CORPO_PEQUENO), "senha"));
        admin.zerar();
        r.ok();
    }

    private void lgpdApagar(Req r) throws IOException {
        long id = Json.num(r.json(CORPO_PEQUENO), "id", 0);
        if (id <= 0)
            throw ErroHttp.pedidoInvalido("Informe o aluno");
        admin.apagarAluno(id, r.usuario);
        r.ok();
    }

    private void testeEmail(Req r) throws IOException {
        String para = Json.str(r.json(CORPO_PEQUENO), "para").trim();
        if (para.isEmpty())
            para = r.usuario.email;
        String erro = envios.testarEmail(para, r.usuario.nome);
        r.json(erro == null ? Json.mapa("ok", true, "para", para) : Json.mapa("ok", false, "erro", erro));
    }

    /* ---------------------------------------------------------------- agenda */

    private void agendaIcs(Req r) throws IOException {
        String p = r.parametro;
        if (!p.endsWith(".ics"))
            throw ErroHttp.naoEncontrado();
        String ics = agenda.ics(p.substring(0, p.length() - 4));
        if (ics == null)
            throw ErroHttp.naoEncontrado();
        r.saida().set("Cache-Control", "private, max-age=900");
        r.saida().set("Content-Disposition", "inline; filename=\"agenda-mentoria.ics\"");
        r.bytes(200, "text/calendar; charset=utf-8", ics.getBytes(StandardCharsets.UTF_8), true);
    }
}
