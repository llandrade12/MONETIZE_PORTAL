package br.com.monetize.portal;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.DateTimeException;
import java.time.ZoneId;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import br.com.monetize.portal.util.Texto;

/**
 * Configuração do servidor.
 *
 * Ordem de leitura: valores padrão, depois o arquivo config.properties, depois variáveis de ambiente.
 * Cada chave do arquivo tem uma variável de ambiente equivalente: SOP_ + a chave em maiúsculas com
 * pontos trocados por sublinhado. Exemplo: db.senha é SOP_DB_SENHA. No Docker usam-se as variáveis.
 */
public final class Config {

    private final Properties p = new Properties();
    private final Map<String, String> ambiente;

    public Config(Path arquivo, Map<String, String> ambiente) throws IOException {
        this.ambiente = ambiente;
        if (arquivo != null && Files.isRegularFile(arquivo)) {
            try (InputStream in = Files.newInputStream(arquivo)) {
                p.load(new InputStreamReader(in, StandardCharsets.UTF_8));
            }
        }
    }

    public String texto(String chave, String padrao) {
        String env = ambiente.get("SOP_" + chave.toUpperCase(Locale.ROOT).replace('.', '_').replace('-', '_'));
        if (env != null && !env.trim().isEmpty())
            return env.trim();
        String v = p.getProperty(chave);
        return v == null || v.trim().isEmpty() ? padrao : v.trim();
    }

    public int inteiro(String chave, int padrao) {
        String v = texto(chave, null);
        if (v == null)
            return padrao;
        try {
            return Integer.parseInt(v);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Configuração '" + chave + "' precisa ser um número inteiro (valor atual: " + v + ")");
        }
    }

    public boolean logico(String chave, boolean padrao) {
        String v = texto(chave, null);
        if (v == null)
            return padrao;
        String t = v.toLowerCase(Locale.ROOT);
        return t.equals("true") || t.equals("sim") || t.equals("1") || t.equals("s");
    }

    /* ---------- servidor ---------- */

    public int porta() {
        return inteiro("porta", 8080);
    }

    /** Endereço em que o servidor escuta. 127.0.0.1 = só o proxy da própria máquina alcança. */
    public String endereco() {
        return texto("endereco", "127.0.0.1");
    }

    /** Endereço público do portal, sem barra no fim (usado nos e-mails, no push e na agenda). */
    public String urlPublica() {
        String u = texto("url.publica", "http://localhost:" + porta());
        while (u.endsWith("/"))
            u = u.substring(0, u.length() - 1);
        return u;
    }

    public boolean https() {
        return urlPublica().toLowerCase(Locale.ROOT).startsWith("https://");
    }

    /** O servidor está atrás de um proxy (Nginx, Apache, EasyPanel) e pode confiar em X-Forwarded-For? */
    public boolean confiarNoProxy() {
        return logico("proxy.confiar", true);
    }

    public int threads() {
        return Math.max(4, inteiro("threads", 24));
    }

    public Path pastaWeb() {
        return Paths.get(texto("web.dir", "web")).toAbsolutePath().normalize();
    }

    public Path pastaArquivos() {
        return Paths.get(texto("arquivos.dir", "arquivos")).toAbsolutePath().normalize();
    }

    public int uploadMaxMb() {
        return inteiro("arquivos.max-mb", 20);
    }

    public ZoneId fuso() {
        String f = texto("fuso", "America/Bahia");
        try {
            return ZoneId.of(f);
        } catch (DateTimeException e) {
            throw new IllegalArgumentException("Configuração 'fuso' inválida: " + f + " (exemplo válido: America/Sao_Paulo)");
        }
    }

    public String nomePortal() {
        return texto("portal.nome", "Monetize · Área de Membros");
    }

    /* ---------- banco de dados ---------- */

    public String dbUrl() {
        return texto("db.url", "jdbc:mysql://localhost:3306/suba_portal?characterEncoding=UTF-8&connectionCollation=utf8mb4_unicode_ci&useSSL=false&allowPublicKeyRetrieval=true");
    }

    public String dbUsuario() {
        return texto("db.usuario", "suba_portal");
    }

    public String dbSenha() {
        return texto("db.senha", "");
    }

    public int dbConexoes() {
        return Math.max(2, inteiro("db.conexoes", 8));
    }

    /* ---------- primeiro acesso do mentor ---------- */

    public String adminNome() {
        return texto("admin.nome", "");
    }

    public String adminEmail() {
        return texto("admin.email", "").toLowerCase(Locale.ROOT);
    }

    public String adminSenha() {
        return texto("admin.senha", "");
    }

    /* ---------- e-mail (SMTP) ---------- */

    public String smtpHost() {
        return texto("smtp.host", "");
    }

    public int smtpPorta() {
        return inteiro("smtp.porta", 465);
    }

    /** ssl (porta 465), starttls (porta 587) ou nenhuma (só para testes). */
    public String smtpSeguranca() {
        return texto("smtp.seguranca", smtpPorta() == 465 ? "ssl" : smtpPorta() == 587 ? "starttls" : "nenhuma").toLowerCase(Locale.ROOT);
    }

    public String smtpUsuario() {
        return texto("smtp.usuario", "");
    }

    public String smtpSenha() {
        return texto("smtp.senha", "");
    }

    public String smtpRemetente() {
        return texto("smtp.remetente", smtpUsuario());
    }

    public String smtpRemetenteNome() {
        return texto("smtp.remetente.nome", "Monetize Mentoring");
    }

    /** Intervalo mínimo entre dois e-mails, em milissegundos (provedores limitam envios por hora). */
    public int smtpIntervaloMs() {
        return Math.max(0, inteiro("smtp.intervalo-ms", 1500));
    }

    public boolean emailConfigurado() {
        return !Texto.vazio(smtpHost()) && !Texto.vazio(smtpRemetente());
    }

    /* ---------- lembretes automáticos ---------- */

    /** Hora do dia (0 a 23) a partir da qual os lembretes automáticos podem sair. */
    public int lembretesInicio() {
        return Math.max(0, Math.min(23, inteiro("lembretes.hora-inicio", 7)));
    }

    public int lembretesFim() {
        return Math.max(lembretesInicio() + 1, Math.min(24, inteiro("lembretes.hora-fim", 21)));
    }

    /** Contato usado no cabeçalho do push (exigência do padrão Web Push). */
    public String pushContato() {
        String c = texto("push.contato", "");
        if (!c.isEmpty())
            return c.startsWith("mailto:") || c.startsWith("https:") ? c : "mailto:" + c;
        String e = Texto.ou(smtpRemetente(), adminEmail());
        return Texto.vazio(e) ? urlPublica() : "mailto:" + e;
    }

    public boolean logDetalhado() {
        return logico("log.detalhado", false);
    }
}
