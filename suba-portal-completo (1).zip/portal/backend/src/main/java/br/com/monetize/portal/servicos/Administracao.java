package br.com.monetize.portal.servicos;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import br.com.monetize.portal.auth.Usuario;
import br.com.monetize.portal.dados.Colecao;
import br.com.monetize.portal.dados.Colecoes;
import br.com.monetize.portal.dados.Estado;
import br.com.monetize.portal.dados.Gravador;
import br.com.monetize.portal.dados.Padroes;
import br.com.monetize.portal.dados.Recusa;
import br.com.monetize.portal.dados.Repositorio;
import br.com.monetize.portal.dados.Repositorio.AlunoLinha;
import br.com.monetize.portal.dados.Repositorio.Reg;
import br.com.monetize.portal.dados.Sincronizador;
import br.com.monetize.portal.db.Banco;
import br.com.monetize.portal.http.ErroHttp;
import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Log;
import br.com.monetize.portal.util.Texto;

/**
 * Operações do mentor sobre o conjunto dos dados: instalar os valores iniciais, zerar o portal,
 * baixar e restaurar a cópia de segurança e apagar os dados de um aluno (LGPD).
 */
public final class Administracao {

    private final Sincronizador sinc;
    private final Arquivos arquivos;

    public Administracao(Sincronizador sinc, Arquivos arquivos) {
        this.sinc = sinc;
        this.arquivos = arquivos;
    }

    /* ---------------------------------------------------------------- valores iniciais */

    /**
     * Primeira execução: grava as competências e as perguntas frequentes iniciais (as duas listas são
     * editáveis no painel). Nenhuma turma, aluno, aula ou tarefa é criada.
     */
    public void instalarPadroes() {
        sinc.gravar(Usuario.sistema(), g -> {
            if (Banco.um(g.c, "SELECT valor FROM parametro WHERE nome = 'instalado'", r -> r.getString(1)) != null)
                return null;
            semear(g, "");
            Banco.executar(g.c, "INSERT INTO parametro (nome, valor) VALUES ('instalado', ?)", g.carimbo);
            Log.info("Banco de dados: valores iniciais gravados (competências e perguntas frequentes)");
            return null;
        });
    }

    private static void semear(Gravador g, String nomeMentor) throws SQLException {
        g.gravar("compL", Colecoes.CHAVE_VALOR, Padroes.competencias());
        for (Map<String, Object> q : Padroes.faq())
            g.gravar("faq", Json.str(q, "id"), q);
        if (!Texto.vazio(nomeMentor)) {
            g.gravar("mentor", Colecoes.CHAVE_VALOR, nomeMentor);
            List<Object> l = new ArrayList<>();
            l.add(nomeMentor);
            g.gravar("mentores", Colecoes.CHAVE_VALOR, l);
        }
    }

    /* ---------------------------------------------------------------- zerar */

    /** Apaga turmas, alunos, aulas, tarefas, notas e arquivos. Os acessos de mentor continuam. */
    public void zerar() {
        List<String> caminhos = sinc.gravar(Usuario.sistema(), g -> {
            String nome = g.nomeMentor();
            List<String> arq = limpar(g);
            semear(g, "Mentor".equals(nome) ? "" : nome);
            return arq;
        });
        for (String c : caminhos)
            arquivos.remover(c);
        Log.aviso("O portal foi zerado pelo painel do mentor");
    }

    /**
     * Remove todos os registros do portal dentro da gravação e avisa os aparelhos abertos para
     * baixarem tudo de novo. Devolve os arquivos em disco a apagar depois da confirmação.
     */
    private static List<String> limpar(Gravador g) throws SQLException {
        List<String> caminhos = Banco.consultar(g.c, "SELECT caminho FROM arquivo", r -> r.getString(1));
        Banco.executar(g.c, "DELETE FROM arquivo");
        Banco.executar(g.c, "DELETE FROM registro");
        Banco.executar(g.c, "DELETE FROM sessao WHERE aluno_id IS NOT NULL");
        Banco.executar(g.c, "DELETE FROM push_inscricao WHERE aluno_id IS NOT NULL");
        Banco.executar(g.c, "DELETE FROM redefinicao_senha WHERE aluno_id IS NOT NULL");
        Banco.executar(g.c, "DELETE FROM aluno");
        Banco.executar(g.c, "DELETE FROM lembrete_enviado");
        Banco.executar(g.c, "DELETE FROM envio");
        Banco.executar(g.c, "DELETE FROM parametro WHERE nome = ?", Estado.PARAM_PURGA);
        Banco.executar(g.c, "INSERT INTO parametro (nome, valor) VALUES (?, ?)", Estado.PARAM_PURGA, String.valueOf(g.rev));
        g.efeitos.mudou = true;
        return caminhos;
    }

    /* ---------------------------------------------------------------- cópia de segurança */

    /**
     * Cópia dos dados em JSON, no mesmo formato do estado do portal, com o resumo da senha de cada aluno.
     * Não inclui as anotações que os alunos mantêm privadas no diário nem os arquivos enviados:
     * a cópia completa do sistema é o backup do banco e da pasta de arquivos (veja o tutorial de instalação).
     */
    public String copia(Usuario mentor) {
        return sinc.gravar(mentor, g -> {
            Map<String, Object> estado = Json.lerObjeto(Estado.completo(g.c, mentor));
            Map<String, Object> dados = Json.obj(estado, "dados");
            for (Object o : Json.lista(dados, Colecoes.ALUNOS)) {
                Map<String, Object> a = Json.obj(o);
                AlunoLinha l = a == null ? null : Repositorio.lerAluno(g.c, Json.num(a, "id", 0));
                if (l != null && l.senhaHash != null)
                    a.put("senha", l.senhaHash);
                if (a != null)
                    a.remove("temSenha");
            }
            dados.put("v", 6L);
            dados.put("exportado_em", g.carimbo);
            return Json.texto(dados);
        });
    }

    /** Resultado de uma restauração. */
    public static final class Restauracao {
        public int registros;
        public int alunos;
        public final List<String> avisos = new ArrayList<>();
    }

    /** Substitui todos os dados do portal pelos da cópia (do portal antigo, sem servidor, ou desta versão). */
    public Restauracao restaurar(Map<String, Object> copia) {
        if (copia == null || Json.lista(copia.get("alunos")) == null || Json.lista(copia.get("turmas")) == null || Json.lista(copia.get("aulas")) == null)
            throw ErroHttp.pedidoInvalido("Este arquivo não é uma cópia dos dados do portal");
        Restauracao res = new Restauracao();
        List<String> caminhos = sinc.gravar(Usuario.sistema(), g -> {
            g.restaurando = true;
            /* Arquivos enviados continuam em disco: as entregas e materiais da cópia apontam para eles. */
            List<String> antigos = Banco.consultar(g.c, "SELECT id FROM arquivo", r -> r.getString(1));
            List<String[]> linhasArquivo = Banco.consultar(g.c, "SELECT id, aluno_id, mentor_id, nome, tipo, tamanho, caminho FROM arquivo",
                    r -> new String[] { r.getString(1), r.getString(2), r.getString(3), r.getString(4), r.getString(5), r.getString(6), r.getString(7) });
            limpar(g);
            long maiorId = 0;

            for (Object o : Json.lista(copia, Colecoes.ALUNOS)) {
                Map<String, Object> a = Json.obj(o);
                long id = a == null ? 0 : Json.num(a, "id", 0);
                if (id <= 0)
                    continue;
                try {
                    g.gravarAluno(id, null, a);
                    res.alunos++;
                    maiorId = Math.max(maiorId, id);
                } catch (Recusa x) {
                    res.avisos.add("Aluno " + Json.str(a, "nome") + " não foi restaurado (" + x.motivo + ")");
                }
            }
            for (Colecao col : Colecoes.todas()) {
                if (col.nome.equals(Colecoes.ALUNOS) || !copia.containsKey(col.nome))
                    continue;
                Object v = copia.get(col.nome);
                if (col.tipo == Colecao.Tipo.VALOR) {
                    if (v != null) {
                        g.gravar(col.nome, Colecoes.CHAVE_VALOR, v);
                        res.registros++;
                    }
                } else if (col.tipo == Colecao.Tipo.MAPA) {
                    Map<String, Object> m = Json.obj(v);
                    if (m == null)
                        continue;
                    for (Map.Entry<String, Object> e : m.entrySet()) {
                        Object valor = e.getValue();
                        /* A versão antiga guardava presença como verdadeiro/falso. */
                        if (col.nome.equals("pres") && valor instanceof Boolean)
                            valor = ((Boolean) valor) ? "P" : "F";
                        if (valor != null && e.getKey().matches("[A-Za-z0-9_.|:@-]{1,150}")) {
                            g.gravar(col.nome, e.getKey(), valor);
                            res.registros++;
                        }
                    }
                } else {
                    List<Object> lista = new ArrayList<>(Json.lista(v) == null ? new ArrayList<>() : Json.lista(v));
                    /* Listas guardadas do mais novo para o mais antigo entram de trás para frente, para manter a ordem. */
                    if (col.recentePrimeiro)
                        java.util.Collections.reverse(lista);
                    for (Object o : lista) {
                        Map<String, Object> item = Json.obj(o);
                        if (item == null)
                            continue;
                        if (item.get(col.campoChave) == null || "".equals(item.get(col.campoChave)))
                            item.put(col.campoChave, g.novoId());
                        String chave = Gravador.chaveDe(item.get(col.campoChave));
                        if (!chave.matches("[A-Za-z0-9_.|:@-]{1,150}"))
                            continue;
                        if (item.get(col.campoChave) instanceof Number)
                            maiorId = Math.max(maiorId, Json.num(item, col.campoChave, 0));
                        g.gravar(col.nome, chave, item);
                        res.registros++;
                    }
                }
            }
            /* Na versão antiga as competências e as perguntas frequentes podiam não estar no arquivo. */
            if (g.ler("compL", Colecoes.CHAVE_VALOR) == null)
                g.gravar("compL", Colecoes.CHAVE_VALOR, Padroes.competencias());
            /* Lembretes que já tinham saído no portal antigo não saem de novo. */
            Map<String, Object> auto = Json.obj(copia.get("auto"));
            if (auto != null)
                for (String chave : auto.keySet())
                    Banco.executar(g.c, "INSERT INTO lembrete_enviado (chave_hash, chave, enviado_em) VALUES (?, ?, ?)", Texto.sha256Hex(chave), Texto.cortar(chave, 2000), g.agora);
            maiorId = Math.max(maiorId, Json.num(copia, "seqA", 0));
            Repositorio.garantirIdAcimaDe(g.c, maiorId);

            /* Recoloca os dados dos arquivos que continuam em disco e pertencem a alunos que voltaram (ou ao mentor). */
            for (String[] l : linhasArquivo) {
                Long aluno = l[1] == null ? null : Long.valueOf(l[1]);
                if (aluno != null && Repositorio.lerAluno(g.c, aluno) == null)
                    continue;
                Banco.executar(g.c, "INSERT INTO arquivo (id, aluno_id, mentor_id, nome, tipo, tamanho, caminho, criado_em) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                        l[0], aluno, l[2] == null ? null : Long.valueOf(l[2]), l[3], l[4], Long.valueOf(l[5]), l[6], g.agora);
                antigos.remove(l[0]);
            }
            List<String> orfaos = new ArrayList<>();
            for (String[] l : linhasArquivo)
                if (antigos.contains(l[0]))
                    orfaos.add(l[6]);
            return orfaos;
        });
        for (String c : caminhos)
            arquivos.remover(c);
        Log.aviso("Cópia de segurança restaurada pelo painel: " + res.alunos + " aluno(s), " + res.registros + " registro(s)");
        return res;
    }

    /* ---------------------------------------------------------------- LGPD */

    /**
     * Apaga de vez tudo o que é do aluno: cadastro, senha, foto, entregas e arquivos, notas, frequência,
     * metas, rotina, Roda da Vida, diário (inclusive as anotações privadas), chamados, notificações e
     * comentários. Fica só um registro sem identificação ("Aluno excluído"), para o histórico da turma.
     */
    public void apagarAluno(long alunoId, Usuario mentor) {
        List<String> caminhos = sinc.gravar(mentor, g -> {
            AlunoLinha a = Repositorio.lerAluno(g.c, alunoId);
            if (a == null)
                throw ErroHttp.naoEncontrado();
            String nome = a.nome;
            List<String> arq = Arquivos.apagarDoAluno(g.c, alunoId);

            for (Reg r : Repositorio.vivosDoAluno(g.c, alunoId)) {
                if (r.colecao.equals("lgpd")) {
                    Map<String, Object> p = Json.obj(Json.ler(r.dados));
                    if (p != null) {
                        p.put("st", "concluido");
                        p.put("nome", "Aluno excluído");
                        p.put("motivo", "");
                        p.put("fim", g.carimbo);
                        g.gravar("lgpd", r.chave, p);
                    }
                } else
                    g.apagar(r.colecao, r.chave);
            }
            String sid = String.valueOf(alunoId);
            for (Reg r : Repositorio.vivosDe(g.c, "avisos")) {
                Map<String, Object> v = Json.obj(Json.ler(r.dados));
                if (v == null)
                    continue;
                if (sid.equals(Gravador.chaveDe(v.get("alvo")))) {
                    g.apagar("avisos", r.chave);
                    continue;
                }
                List<Object> coms = new ArrayList<>();
                for (Object o : Json.lista(v, "coms"))
                    if (Json.num(Json.obj(o), "aid", 0) != alunoId)
                        coms.add(o);
                if (coms.size() != Json.lista(v, "coms").size()) {
                    v.put("coms", coms);
                    g.gravar("avisos", r.chave, v);
                }
            }
            /* O nome some também do histórico: as ações do próprio aluno saem; nos demais textos, o nome é trocado. */
            for (Reg r : Repositorio.vivosDe(g.c, "log")) {
                Map<String, Object> l = Json.obj(Json.ler(r.dados));
                if (l != null && nome.equals(Json.str(l, "who")))
                    g.apagar("log", r.chave);
            }
            g.trocarNomeNosHistoricos(alunoId, nome, "aluno excluído");

            Banco.executar(g.c, "DELETE FROM sessao WHERE aluno_id = ?", alunoId);
            Banco.executar(g.c, "DELETE FROM push_inscricao WHERE aluno_id = ?", alunoId);
            Banco.executar(g.c, "DELETE FROM redefinicao_senha WHERE aluno_id = ?", alunoId);
            /* Mensagens ainda na fila de saída: as destinadas ao aluno e as que citam o nome dele. */
            Banco.executar(g.c, "DELETE FROM envio WHERE destino = ? OR LOCATE(?, assunto) > 0 OR LOCATE(?, corpo) > 0", a.email == null ? "" : a.email, nome, nome);

            g.gravarAluno(alunoId, a, Json.mapa("id", alunoId, "nome", "Aluno excluído", "email", "", "tel", "", "nasc", "2000-01-01", "cargo", "", "civil", "",
                    "formacao", "", "mat", "", "status", "removido", "turma", 0L, "motivo", "Dados excluídos a pedido (LGPD), " + g.carimbo,
                    "canais", Json.mapa("email", false, "whats", false)));
            String id = g.novoId();
            g.gravar("log", id, Json.mapa("id", id, "at", g.carimbo, "who", mentor.nome, "m", "Excluiu os dados de um aluno a pedido (LGPD)"));
            return arq;
        });
        for (String c : caminhos)
            arquivos.remover(c);
    }
}
