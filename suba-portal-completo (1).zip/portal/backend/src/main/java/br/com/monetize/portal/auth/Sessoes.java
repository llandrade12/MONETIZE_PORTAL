package br.com.monetize.portal.auth;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import br.com.monetize.portal.Config;
import br.com.monetize.portal.dados.Repositorio;
import br.com.monetize.portal.dados.Repositorio.AlunoLinha;
import br.com.monetize.portal.db.Banco;
import br.com.monetize.portal.http.ErroHttp;
import br.com.monetize.portal.http.Req;
import br.com.monetize.portal.util.Log;
import br.com.monetize.portal.util.Senhas;
import br.com.monetize.portal.util.Texto;

/**
 * Login e sessões.
 *
 * O navegador recebe um cookie com um código aleatório (HttpOnly: o JavaScript da página não o lê).
 * O banco guarda só o resumo desse código. "Manter conectado" vale por 30 dias; sem ele, a sessão
 * termina depois de 12 horas sem uso.
 */
public final class Sessoes {

    public static final String COOKIE = "sop_sessao";
    private static final Duration CURTA = Duration.ofHours(12);
    private static final Duration LONGA = Duration.ofDays(30);
    /** Resumo usado para gastar o mesmo tempo quando o e-mail não existe (não revela quais e-mails têm cadastro). */
    private static final String SENHA_FALSA = Senhas.gerar("senha-que-ninguem-usa-" + Texto.segredo(8));

    /** Um mentor cadastrado. */
    public static final class Mentor {
        public long id;
        public String nome;
        public String email;
        public String senhaHash;
        public String agendaToken;
        public boolean ativo;
    }

    private final Banco banco;
    private final Config config;
    private final ZoneId fuso;
    /** Tentativas erradas por e-mail e por endereço: {quantidade, bloqueado até (ms), última falha (ms)}. */
    private final Map<String, long[]> falhas = new ConcurrentHashMap<>();

    public Sessoes(Banco banco, Config config) {
        this.banco = banco;
        this.config = config;
        this.fuso = config.fuso();
    }

    private LocalDateTime agora() {
        return LocalDateTime.now(fuso);
    }

    /* ---------------------------------------------------------------- login */

    /** Confere e-mail e senha, abre a sessão e grava o cookie na resposta. */
    public Usuario entrar(Req r, String email, String senha, boolean manter) {
        String e = email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
        String ip = r.ip();
        conferirBloqueio("e:" + e);
        conferirBloqueio("ip:" + ip);
        if (e.isEmpty() || senha == null || senha.isEmpty() || senha.length() > 200)
            throw falhou(e, ip);

        Mentor m = banco.usar(c -> mentorPorEmail(c, e));
        if (m != null) {
            if (!m.ativo || !Senhas.confere(senha, m.senhaHash, e))
                throw falhou(e, ip);
            if (Senhas.precisaAtualizar(m.senhaHash)) {
                String novo = Senhas.gerar(senha);
                banco.usar(c -> Banco.executar(c, "UPDATE mentor SET senha_hash = ? WHERE id = ?", novo, m.id));
            }
            banco.usar(c -> Banco.executar(c, "UPDATE mentor SET ultimo_acesso = ? WHERE id = ?", agora(), m.id));
            limpar(e, ip);
            abrir(r, m.id, null, manter);
            return new Usuario(Usuario.Tipo.MENTOR, m.id, m.nome, m.email, 0, 0);
        }

        AlunoLinha a = banco.usar(c -> Repositorio.alunoPorEmail(c, e));
        if (a == null || a.senhaHash == null || a.senhaHash.isEmpty() || "removido".equals(a.status)) {
            Senhas.confere(senha, SENHA_FALSA, e);
            throw falhou(e, ip);
        }
        if (!Senhas.confere(senha, a.senhaHash, e))
            throw falhou(e, ip);
        /* A senha está certa: agora sim dá para dizer por que o acesso não abre. */
        if ("bloqueado".equals(a.status))
            throw new ErroHttp(403, "bloqueado", "Acesso bloqueado. Fale com a equipe da mentoria.");
        if (!"ativo".equals(a.status))
            throw new ErroHttp(403, "pendente", "Seu acesso ainda não foi liberado.");
        if (Senhas.precisaAtualizar(a.senhaHash)) {
            String novo = Senhas.gerar(senha);
            banco.usar(c -> {
                Repositorio.senhaDoAluno(c, a.id, novo);
                return null;
            });
        }
        limpar(e, ip);
        abrir(r, null, a.id, manter);
        return new Usuario(Usuario.Tipo.ALUNO, a.id, a.nome, a.email, a.turma(), 0);
    }

    private void abrir(Req r, Long mentorId, Long alunoId, boolean manter) {
        String token = Texto.segredo(32);
        LocalDateTime agora = agora();
        Duration prazo = manter ? LONGA : CURTA;
        banco.usar(c -> Banco.inserir(c,
                "INSERT INTO sessao (token_hash, mentor_id, aluno_id, persistente, criado_em, visto_em, expira_em, ip, agente) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                Texto.sha256Hex(token), mentorId, alunoId, manter, agora, agora, agora.plus(prazo), Texto.cortar(r.ip(), 64), Texto.cortar(Texto.semEmoji(r.cabecalho("User-Agent")), 255)));
        r.saida().add("Set-Cookie", cookie(token, manter ? LONGA.getSeconds() : -1));
    }

    private String cookie(String valor, long maxAge) {
        StringBuilder b = new StringBuilder(COOKIE).append('=').append(valor).append("; Path=/; HttpOnly; SameSite=Lax");
        if (config.https())
            b.append("; Secure");
        if (maxAge >= 0)
            b.append("; Max-Age=").append(maxAge);
        return b.toString();
    }

    public void sair(Req r) {
        String token = r.cookie(COOKIE);
        if (token != null && !token.isEmpty())
            banco.usar(c -> Banco.executar(c, "DELETE FROM sessao WHERE token_hash = ?", Texto.sha256Hex(token)));
        r.saida().add("Set-Cookie", cookie("", 0));
    }

    /* ---------------------------------------------------------------- quem está logado */

    /** Usuário da sessão do cookie, ou null. Renova a validade da sessão conforme o uso. */
    public Usuario identificar(Req r) {
        String token = r.cookie(COOKIE);
        if (token == null || token.length() < 20 || token.length() > 100)
            return null;
        r.tokenSessao = token;
        String hash = Texto.sha256Hex(token);
        LocalDateTime agora = agora();
        return banco.usar(c -> {
            Object[] s = Banco.um(c, "SELECT id, mentor_id, aluno_id, persistente, visto_em, expira_em FROM sessao WHERE token_hash = ?",
                    x -> new Object[] { x.getLong("id"), Banco.longOuNulo(x, "mentor_id"), Banco.longOuNulo(x, "aluno_id"), x.getInt("persistente") != 0,
                            Banco.dataHora(x, "visto_em"), Banco.dataHora(x, "expira_em") },
                    hash);
            if (s == null)
                return null;
            long sid = (Long) s[0];
            LocalDateTime visto = (LocalDateTime) s[4], expira = (LocalDateTime) s[5];
            if (expira == null || !expira.isAfter(agora)) {
                Banco.executar(c, "DELETE FROM sessao WHERE id = ?", sid);
                return null;
            }
            Usuario u;
            if (s[1] != null) {
                Mentor m = mentorPorId(c, (Long) s[1]);
                if (m == null || !m.ativo)
                    return null;
                u = new Usuario(Usuario.Tipo.MENTOR, m.id, m.nome, m.email, 0, sid);
            } else if (s[2] != null) {
                AlunoLinha a = Repositorio.lerAluno(c, (Long) s[2]);
                if (a == null || !"ativo".equals(a.status))
                    return null;
                u = new Usuario(Usuario.Tipo.ALUNO, a.id, a.nome, a.email, a.turma(), sid);
            } else
                return null;
            /* Renova no máximo a cada 5 minutos, para não gravar a cada requisição. */
            if (visto == null || Duration.between(visto, agora).toMinutes() >= 5)
                Banco.executar(c, "UPDATE sessao SET visto_em = ?, expira_em = ? WHERE id = ?", agora, agora.plus((Boolean) s[3] ? LONGA : CURTA), sid);
            return u;
        });
    }

    /** Encerra todas as sessões de uma pessoa, menos a atual (depois de trocar a senha). */
    public void encerrarOutras(Connection c, Usuario u) throws SQLException {
        if (u.mentor())
            Banco.executar(c, "DELETE FROM sessao WHERE mentor_id = ? AND id <> ?", u.id, u.sessaoId);
        else
            Banco.executar(c, "DELETE FROM sessao WHERE aluno_id = ? AND id <> ?", u.id, u.sessaoId);
    }

    public int limparExpiradas() {
        LocalDateTime agora = agora();
        long ms = System.currentTimeMillis();
        falhas.entrySet().removeIf(e -> ms - e.getValue()[2] > 3_600_000L);
        return banco.usar(c -> Banco.executar(c, "DELETE FROM sessao WHERE expira_em < ?", agora)
                + Banco.executar(c, "DELETE FROM redefinicao_senha WHERE expira_em < ?", agora.minusDays(1)));
    }

    /* ---------------------------------------------------------------- mentores */

    public static Mentor mentorPorEmail(Connection c, String email) throws SQLException {
        return Banco.um(c, "SELECT id, nome, email, senha_hash, agenda_token, ativo FROM mentor WHERE email = ?", Sessoes::mentor, email);
    }

    public static Mentor mentorPorId(Connection c, long id) throws SQLException {
        return Banco.um(c, "SELECT id, nome, email, senha_hash, agenda_token, ativo FROM mentor WHERE id = ?", Sessoes::mentor, id);
    }

    private static Mentor mentor(java.sql.ResultSet r) throws SQLException {
        Mentor m = new Mentor();
        m.id = r.getLong("id");
        m.nome = r.getString("nome");
        m.email = r.getString("email");
        m.senhaHash = r.getString("senha_hash");
        m.agendaToken = r.getString("agenda_token");
        m.ativo = r.getInt("ativo") != 0;
        return m;
    }

    /* ---------------------------------------------------------------- tentativas erradas */

    private void conferirBloqueio(String chave) {
        long[] f = falhas.get(chave);
        if (f == null)
            return;
        long falta = f[1] - System.currentTimeMillis();
        if (falta > 0)
            throw new ErroHttp(429, "muitas-tentativas", "Muitas tentativas. Aguarde " + espera(falta) + " e tente de novo.");
    }

    private static String espera(long ms) {
        long s = Math.max(1, (ms + 999) / 1000);
        return s < 90 ? s + " segundos" : ((s + 59) / 60) + " minutos";
    }

    private ErroHttp falhou(String email, String ip) {
        registrar("e:" + email, 5);
        registrar("ip:" + ip, 20);
        Log.depurar("Login recusado para " + email + " de " + ip);
        return new ErroHttp(401, "login-invalido", "E-mail ou senha incorretos");
    }

    /** A cada "limite" erros seguidos, bloqueia por um tempo que cresce: 30 s, 2 min, 10 min, 30 min. */
    private void registrar(String chave, int limite) {
        long agora = System.currentTimeMillis();
        long[] f = falhas.computeIfAbsent(chave, k -> new long[3]);
        synchronized (f) {
            if (agora - f[2] > 3_600_000L)
                f[0] = 0;
            f[0]++;
            f[2] = agora;
            if (f[0] % limite == 0) {
                long nivel = f[0] / limite;
                long espera = nivel <= 1 ? 30_000L : nivel == 2 ? 120_000L : nivel == 3 ? 600_000L : 1_800_000L;
                f[1] = agora + espera;
            }
        }
    }

    private void limpar(String email, String ip) {
        falhas.remove("e:" + email);
        falhas.remove("ip:" + ip);
    }

    /** Só para os testes automáticos. */
    public void esquecerFalhas() {
        falhas.clear();
    }
}
