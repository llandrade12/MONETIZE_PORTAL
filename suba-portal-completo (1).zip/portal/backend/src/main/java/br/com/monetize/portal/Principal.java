package br.com.monetize.portal;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import br.com.monetize.portal.api.Api;
import br.com.monetize.portal.auth.Contas;
import br.com.monetize.portal.auth.Sessoes;
import br.com.monetize.portal.dados.Sincronizador;
import br.com.monetize.portal.db.Banco;
import br.com.monetize.portal.db.Migracoes;
import br.com.monetize.portal.http.Servidor;
import br.com.monetize.portal.servicos.Administracao;
import br.com.monetize.portal.servicos.Agenda;
import br.com.monetize.portal.servicos.Arquivos;
import br.com.monetize.portal.servicos.Envios;
import br.com.monetize.portal.servicos.Lembretes;
import br.com.monetize.portal.servicos.Manutencao;
import br.com.monetize.portal.servicos.PushServico;
import br.com.monetize.portal.util.Log;
import br.com.monetize.portal.util.Senhas;

/**
 * Ponto de entrada do servidor da Área de Membros.
 *
 * Uso:
 *   java -jar suba-portal.jar [--config=caminho/config.properties]
 *   java -jar suba-portal.jar criar-mentor "Nome" email@dominio.com senha
 *   java -jar suba-portal.jar redefinir-senha email@dominio.com novaSenha
 */
public final class Principal {

    public static final String VERSAO = "1.0.0";

    /** Tudo o que compõe o servidor em execução (os testes usam para subir e derrubar). */
    public static final class Aplicacao implements AutoCloseable {
        public Config config;
        public Banco banco;
        public Sincronizador sinc;
        public Sessoes sessoes;
        public Contas contas;
        public Envios envios;
        public PushServico push;
        public Lembretes lembretes;
        public Administracao admin;
        public Manutencao manutencao;
        public Servidor servidor;
        ScheduledExecutorService relogio;

        @Override
        public void close() {
            if (relogio != null)
                relogio.shutdownNow();
            if (servidor != null)
                servidor.parar();
            if (envios != null)
                envios.parar();
            if (push != null)
                push.parar();
            if (banco != null)
                banco.close();
        }
    }

    public static void main(String[] args) {
        try {
            Path arquivoConfig = Paths.get("config.properties");
            java.util.List<String> comando = new java.util.ArrayList<>();
            for (String a : args) {
                if (a.startsWith("--config="))
                    arquivoConfig = Paths.get(a.substring(9));
                else
                    comando.add(a);
            }
            if (!comando.isEmpty() && (comando.get(0).equals("versao") || comando.get(0).equals("--version"))) {
                System.out.println("Área de Membros " + VERSAO);
                return;
            }
            Config config = new Config(arquivoConfig, System.getenv());
            Log.detalhado(config.logDetalhado());
            if (!Files.isRegularFile(arquivoConfig))
                Log.info("Arquivo " + arquivoConfig.toAbsolutePath() + " não encontrado: usando só as variáveis de ambiente (SOP_...) e os padrões");

            if (!comando.isEmpty()) {
                System.exit(linhaDeComando(config, comando));
                return;
            }
            Aplicacao app = iniciar(config, true);
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                Log.info("Encerrando o servidor");
                app.close();
            }, "encerramento"));
            Log.info("Área de Membros " + VERSAO + " no ar em http://" + config.endereco() + ":" + app.servidor.porta() + " (endereço público: " + config.urlPublica() + ")");
        } catch (Exception e) {
            Log.erro("O SERVIDOR NÃO SUBIU: " + e.getMessage(), e);
            System.exit(1);
        }
    }

    /** Sobe tudo. tarefasPeriodicas = liga os lembretes e a faxina automáticos (os testes desligam). */
    public static Aplicacao iniciar(Config config, boolean tarefasPeriodicas) throws IOException {
        Aplicacao app = new Aplicacao();
        try {
            app.config = config;
            app.banco = conectar(config);
            Migracoes.aplicar(app.banco);

            app.sinc = new Sincronizador(app.banco, config);
            Arquivos arquivos = new Arquivos(app.banco, config);
            app.envios = new Envios(app.banco, config, app.sinc);
            app.push = new PushServico(app.banco, config);
            app.push.preparar();
            app.sessoes = new Sessoes(app.banco, config);
            app.contas = new Contas(app.banco, config, app.sinc, app.sessoes, app.envios);
            app.lembretes = new Lembretes(app.sinc, config);
            app.admin = new Administracao(app.sinc, arquivos);
            app.manutencao = new Manutencao(app.banco, app.sinc, app.sessoes, app.envios, app.lembretes);
            Agenda agenda = new Agenda(app.banco, config);

            app.admin.instalarPadroes();
            app.contas.criarPrimeiroMentor();

            /* Depois de cada gravação confirmada: entrega os push e acorda a fila de envio. */
            final PushServico push = app.push;
            final Envios envios = app.envios;
            app.sinc.aposGravar(ef -> {
                ef.pushes.forEach(push::enviar);
                if (ef.enviosNovos)
                    envios.acordar();
                ef.arquivosRemovidos.forEach(arquivos::remover);
            });

            if (!Files.isRegularFile(config.pastaWeb().resolve("index.html")))
                Log.aviso("A pasta do portal não tem index.html: " + config.pastaWeb() + " (confira web.dir na configuração)");
            if (!config.emailConfigurado())
                Log.aviso("E-mail (SMTP) não configurado: os avisos por e-mail ficam na fila para envio manual e \"Esqueci minha senha\" fica desligado");

            app.servidor = new Servidor(config);
            new Api(config, app.banco, app.sessoes, app.contas, app.sinc, arquivos, app.push, app.lembretes, app.admin, agenda, app.envios).registrar(app.servidor);
            app.servidor.iniciar();
            app.envios.iniciar();

            if (tarefasPeriodicas) {
                app.relogio = Executors.newSingleThreadScheduledExecutor(r -> {
                    Thread t = new Thread(r, "relogio");
                    t.setDaemon(true);
                    return t;
                });
                final Lembretes lembretes = app.lembretes;
                final Manutencao manutencao = app.manutencao;
                app.relogio.scheduleWithFixedDelay(() -> {
                    try {
                        lembretes.rodarNoHorario();
                    } catch (RuntimeException e) {
                        Log.erro("Falha nos lembretes automáticos (tenta de novo em 10 minutos)", e);
                    }
                }, 1, 10, TimeUnit.MINUTES);
                app.relogio.scheduleWithFixedDelay(manutencao::rodar, 5, 360, TimeUnit.MINUTES);
            }
            return app;
        } catch (IOException | RuntimeException e) {
            app.close();
            throw e;
        }
    }

    /** Abre o banco, esperando até 90 segundos por ele (no Docker o banco pode subir depois do servidor). */
    private static Banco conectar(Config config) {
        String url = config.dbUrl();
        try {
            DriverManager.getDriver(url);
        } catch (SQLException e) {
            throw new IllegalStateException("Driver do banco não encontrado para " + url.replaceAll("\\?.*", "")
                    + ". Coloque o arquivo do driver (mysql-connector-j.jar ou mariadb-java-client.jar) na pasta lib, ao lado do suba-portal.jar.");
        }
        Banco banco = new Banco(url, config.dbUsuario(), config.dbSenha(), config.dbConexoes());
        RuntimeException ultimo = null;
        for (int tentativa = 1; tentativa <= 30; tentativa++) {
            try {
                banco.usar(c -> c.isValid(5));
                return banco;
            } catch (RuntimeException e) {
                ultimo = e;
                if (tentativa == 1)
                    Log.aviso("Banco de dados ainda não respondeu (" + raiz(e) + "). Tentando por até 90 segundos...");
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException x) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }
        banco.close();
        throw new IllegalStateException("Não foi possível conectar ao banco de dados em " + url.replaceAll("\\?.*", "")
                + ". Confira db.url, db.usuario e db.senha. Detalhe: " + (ultimo == null ? "?" : raiz(ultimo)));
    }

    private static String raiz(Throwable t) {
        Throwable c = t;
        while (c.getCause() != null && c.getCause() != c)
            c = c.getCause();
        return c.getMessage() == null ? c.getClass().getSimpleName() : c.getMessage();
    }

    /** Comandos de manutenção, para usar no terminal do servidor. Devolve o código de saída. */
    private static int linhaDeComando(Config config, java.util.List<String> cmd) {
        Banco banco = conectar(config);
        try {
            Migracoes.aplicar(banco);
            Sincronizador sinc = new Sincronizador(banco, config);
            Contas contas = new Contas(banco, config, sinc, new Sessoes(banco, config), new Envios(banco, config, sinc));
            switch (cmd.get(0)) {
                case "criar-mentor":
                    if (cmd.size() != 4)
                        return uso();
                    contas.criarMentor(cmd.get(1), cmd.get(2), cmd.get(3));
                    System.out.println("Mentor criado: " + cmd.get(2));
                    return 0;
                case "redefinir-senha": {
                    if (cmd.size() != 3)
                        return uso();
                    if (!Senhas.forte(cmd.get(2))) {
                        System.err.println("A senha precisa ter 8 ou mais caracteres, com letras e números.");
                        return 2;
                    }
                    Sessoes.Mentor m = banco.usar(c -> Contas.porEmail(c, cmd.get(1)));
                    if (m == null) {
                        System.err.println("Não existe mentor com o e-mail " + cmd.get(1));
                        return 2;
                    }
                    contas.senhaDoMentor(m.id, cmd.get(2));
                    System.out.println("Senha redefinida para " + m.email);
                    return 0;
                }
                default:
                    return uso();
            }
        } catch (RuntimeException e) {
            System.err.println("Erro: " + e.getMessage());
            return 1;
        } finally {
            banco.close();
        }
    }

    private static int uso() {
        System.err.println("Uso:\n  java -jar suba-portal.jar [--config=config.properties]\n  java -jar suba-portal.jar criar-mentor \"Nome\" email senha\n  java -jar suba-portal.jar redefinir-senha email novaSenha");
        return 2;
    }
}
