package br.com.monetize.portal.servicos;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import br.com.monetize.portal.Config;
import br.com.monetize.portal.auth.Usuario;
import br.com.monetize.portal.dados.Gravador;
import br.com.monetize.portal.dados.Notificador;
import br.com.monetize.portal.dados.Portal;
import br.com.monetize.portal.dados.Sincronizador;
import br.com.monetize.portal.db.Banco;
import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Log;
import br.com.monetize.portal.util.Texto;

/**
 * Lembretes automáticos: confere aulas, prazos, atrasos, gravações, frequência e etapas do plano de ação
 * e avisa quem precisa, sem o mentor clicar em nada. Cada lembrete sai uma única vez (tabela lembrete_enviado).
 *
 * É a versão no servidor da função autoRun() que o portal tinha no navegador
 * (web/js/compartilhado/core/actions.js): os textos e as regras são os mesmos.
 */
public final class Lembretes {

    private static final String CANAL = "e-mail + whatsapp";

    private final Sincronizador sinc;
    private final Config config;

    public Lembretes(Sincronizador sinc, Config config) {
        this.sinc = sinc;
        this.config = config;
    }

    /** Rodada periódica: só dentro do horário configurado, para ninguém receber aviso de madrugada. */
    public int rodarNoHorario() {
        int hora = sinc.agora().getHour();
        if (hora < config.lembretesInicio() || hora >= config.lembretesFim())
            return 0;
        return rodar(false);
    }

    /**
     * Confere tudo e envia o que estiver na hora. forcar = roda mesmo com os lembretes automáticos
     * desligados (botão "Conferir agora" e depois de uma chamada). Devolve quantos lembretes saíram.
     */
    public int rodar(boolean forcar) {
        return sinc.gravar(Usuario.sistema(), g -> {
            Portal p = Portal.carregar(g.c, g.agora.toLocalDate().toString());
            if (!forcar && !Json.bool(p.cfg, "autoOn"))
                return 0;
            return new Rodada(g, p).executar();
        });
    }

    private static String quando(int d) {
        return d == 0 ? "hoje" : d == 1 ? "amanhã" : "em " + d + " dias";
    }

    private static boolean https(String u) {
        return u != null && u.trim().toLowerCase(java.util.Locale.ROOT).startsWith("https://");
    }

    /** Uma execução, dentro de uma gravação. */
    private static final class Rodada {
        final Gravador g;
        final Portal p;
        final String h;
        int enviados;

        Rodada(Gravador g, Portal p) {
            this.g = g;
            this.p = p;
            this.h = p.hoje;
        }

        /** Marca o lembrete como enviado; devolve false se ele já tinha saído. */
        boolean primeiraVez(Object... partes) throws SQLException {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < partes.length; i++)
                b.append(i > 0 ? "|" : "").append(Gravador.chaveDe(partes[i]));
            String chave = b.toString(), hash = Texto.sha256Hex(chave);
            if (Banco.um(g.c, "SELECT chave_hash FROM lembrete_enviado WHERE chave_hash = ?", r -> r.getString(1), hash) != null)
                return false;
            Banco.executar(g.c, "INSERT INTO lembrete_enviado (chave_hash, chave, enviado_em) VALUES (?, ?, ?)", hash, chave, g.agora);
            enviados++;
            return true;
        }

        /** Notificação para o aluno: caixa do portal, push, e-mail e WhatsApp (os canais externos são decididos na gravação). */
        void avisar(Map<String, Object> aluno, String assunto, String msg, String pagina) throws SQLException {
            String id = g.novoId();
            long aid = Json.num(aluno, "id", 0);
            g.gravar("inbox", id, Json.mapa("id", id, "aid", aid, "t", assunto, "m", msg, "at", g.carimbo, "lido", false, "go", pagina, "canal", CANAL, "auto", true));
            String hid = g.novoId();
            g.gravar("notif", hid, Json.mapa("id", hid, "at", g.carimbo, "ev", assunto, "canal", Notificador.rotuloDosCanais(g, aid, CANAL), "dest", Json.str(aluno, "nome"), "auto", true));
        }

        /** Alerta para o mentor (sino do painel, push e, se ele cadastrou, e-mail e WhatsApp). */
        void alertar(String assunto, String msg, String pagina, Object arg) throws SQLException {
            String id = g.novoId();
            g.gravar("inboxM", id, Json.mapa("id", id, "t", assunto, "m", msg, "at", g.carimbo, "lido", false, "go", pagina, "arg", arg, "auto", true));
        }

        int executar() throws SQLException {
            Map<String, Object> c = p.cfg;
            int lembAula = (int) Json.num(c, "lembAula", 1), lembPrazo = (int) Json.num(c, "lembPrazo", 2);
            int atrasoCada = (int) Math.max(1, Json.num(c, "atrasoCada", 3)), escala = (int) Json.num(c, "escala", 7);
            boolean compensa = Json.bool(c, "compensa");

            for (Map<String, Object> a : p.alunos) {
                if (!"ativo".equals(Json.str(a, "status")) || Json.num(a, "turma", 0) <= 0)
                    continue;
                Object id = a.get("id");
                long tid = p.turmaDe(a);

                /* 1. Aula chegando */
                for (Map<String, Object> x : p.aulasDe(tid)) {
                    if (!"agendada".equals(Json.str(x, "status")))
                        continue;
                    int d = Texto.dias(Json.str(x, "date"), h);
                    if (d >= 0 && d <= lembAula && primeiraVez("aula", x.get("n"), id, Json.str(x, "date"), d != 0 ? "antes" : "hoje"))
                        avisar(a, "Lembrete de encontro", "\"" + Json.str(x, "nome") + "\" é " + quando(d) + ", " + Texto.dl(Json.str(x, "date")) + " às " + Json.str(x, "hora") + "."
                                + (https(Json.str(x, "link")) ? " Link: " + Json.str(x, "link").trim() : ""), "agenda");
                }

                /* 2. Prazo de tarefa chegando */
                for (Map<String, Object> t : p.tarefasDe(a)) {
                    if (!p.liberada(t) || p.entregou(a, t))
                        continue;
                    String prazo = p.prazoDe(a, t);
                    int d = Texto.dias(prazo, h);
                    if (!prazo.isEmpty() && d >= 0 && d <= lembPrazo && primeiraVez("prazo", t.get("id"), id, prazo, d != 0 ? "antes" : "hoje"))
                        avisar(a, "Prazo chegando", "A tarefa \"" + Json.str(t, "t") + "\" vence " + quando(d) + " (" + Texto.df(prazo) + ").", "tarefas");
                }

                /* 3. Tarefa em atraso (repete a cada N dias) e alerta ao mentor quando o atraso se prolonga */
                List<Map<String, Object>> at = p.atrasos(a);
                if (!at.isEmpty()) {
                    int atraso = 0;
                    List<String> ids = new ArrayList<>(), nomes = new ArrayList<>();
                    for (Map<String, Object> t : at) {
                        atraso = Math.max(atraso, Texto.dias(h, p.prazoDe(a, t)));
                        ids.add(Gravador.chaveDe(t.get("id")));
                        nomes.add(Json.str(t, "t"));
                    }
                    String lista = String.join(",", ids);
                    if (primeiraVez("atraso", id, lista, Math.floorDiv(atraso - 1, atrasoCada)))
                        avisar(a, "Tarefa em atraso", (at.size() == 1 ? "A tarefa \"" + nomes.get(0) + "\" está em atraso."
                                : "Você tem " + at.size() + " tarefas em atraso: " + String.join(", ", nomes) + ".") + " Entregue assim que puder para não perder o ritmo.", "tarefas");
                    if (atraso >= escala && primeiraVez("escala", id, lista))
                        alertar("Atraso prolongado: " + Json.str(a, "nome"), at.size() + " tarefa(s) em atraso há " + atraso + " dia(s). Vale um contato pessoal.", "alunoD", id);
                }

                /* 4. Gravação esperando (3 dias depois do encontro) */
                List<Map<String, Object>> semVer = new ArrayList<>();
                List<String> ns = new ArrayList<>();
                for (Map<String, Object> x : p.baseDeFrequencia(a)) {
                    if (Json.verdadeiro(x.get("video")) && !p.assistiu(a, x) && Texto.dias(h, Json.str(x, "date")) >= 3) {
                        semVer.add(x);
                        ns.add(Gravador.chaveDe(x.get("n")));
                    }
                }
                if (!semVer.isEmpty() && primeiraVez("grav", id, String.join(",", ns)))
                    avisar(a, "Gravação esperando por você", (semVer.size() == 1 ? "A gravação de \"" + Json.str(semVer.get(0), "nome") + "\" ainda não foi assistida."
                            : "Há " + semVer.size() + " gravações que você ainda não assistiu.") + (compensa ? " Assistindo, você compensa a falta." : ""), "aulas");

                /* 5. Frequência abaixo do mínimo (avisa o aluno e o mentor) ou no limite de faltas */
                Portal.Frequencia f = p.frequencia(a);
                if (f.abaixo) {
                    if (primeiraVez("freq", id, f.n)) {
                        avisar(a, "Frequência abaixo do mínimo", "Sua frequência está em " + f.pct + "% e o mínimo para o certificado é " + f.minTexto() + "%."
                                + (compensa ? " Assista às gravações dos encontros que você perdeu para compensar." : " Não falte aos próximos encontros."), "frequencia");
                        alertar("Frequência baixa: " + Json.str(a, "nome"), f.pct + "% de presença (" + f.ok + " de " + f.n + " encontros). Mínimo de " + f.minTexto() + "% para o certificado.", "freq", null);
                    }
                } else if (f.n > 0 && f.restam == 0 && f.faltas > 0 && primeiraVez("freqlim", id, f.n)) {
                    avisar(a, "Você está no limite de faltas", "Sua frequência está em " + f.pct + "%. Mais uma falta e ela fica abaixo do mínimo de " + f.minTexto() + "% exigido para o certificado.", "frequencia");
                }

                /* 6. Etapas do plano de ação */
                for (Map<String, Object> m : p.metas) {
                    if (!Gravador.chaveDe(m.get("aid")).equals(Gravador.chaveDe(id)) || !"aprovada".equals(Json.str(m, "st")) || Json.verdadeiro(m.get("feita")))
                        continue;
                    for (Object o : Json.lista(m, "etapas")) {
                        Map<String, Object> e = Json.obj(o);
                        if (e == null || Json.verdadeiro(e.get("feito")) || Json.str(e, "prazo").isEmpty())
                            continue;
                        String prazo = Json.str(e, "prazo");
                        if (Texto.data(prazo) == null)
                            continue;
                        int d = Texto.dias(prazo, h);
                        if (d >= 0 && d <= lembPrazo) {
                            if (primeiraVez("etapa", e.get("id"), prazo, d != 0 ? "antes" : "hoje"))
                                avisar(a, "Etapa do seu plano de ação", "\"" + Json.str(e, "t") + "\" vence " + quando(d) + ".", "evolucao");
                        } else if (d < 0 && primeiraVez("etapaA", e.get("id"), prazo)) {
                            avisar(a, "Etapa do plano em atraso", "\"" + Json.str(e, "t") + "\" passou do prazo (" + Texto.df(prazo) + "). Conclua ou ajuste a data.", "evolucao");
                        }
                    }
                }
            }

            /* 7. Para o mentor: aula que passou sem chamada */
            for (Map<String, Object> x : p.aulas) {
                String data = Json.str(x, "date");
                if ("agendada".equals(Json.str(x, "status")) && Texto.data(data) != null && Texto.dias(h, data) >= 1 && primeiraVez("semreg", x.get("n"), data))
                    alertar("Aula sem registro", "\"" + Json.str(x, "nome") + "\" era em " + Texto.df(data) + ". Faça a chamada e registre a gravação.", "freq", null);
            }
            if (enviados > 0)
                Log.info("Lembretes automáticos: " + enviados + " enviado(s)");
            return enviados;
        }
    }

    /** Esquece os lembretes enviados há mais de um ano (a tabela não cresce para sempre). */
    public int limparAntigos(Banco banco) {
        LocalDateTime corte = sinc.agora().minusDays(365);
        return banco.usar(c -> Banco.executar(c, "DELETE FROM lembrete_enviado WHERE enviado_em < ?", corte));
    }
}
