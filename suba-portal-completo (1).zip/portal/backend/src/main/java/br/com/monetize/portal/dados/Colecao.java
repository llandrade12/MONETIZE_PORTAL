package br.com.monetize.portal.dados;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Descrição de uma coleção de registros do portal (turmas, aulas, entregas, notas...).
 *
 * O portal trabalha com um objeto de estado único; cada chave desse objeto é uma coleção. O servidor
 * guarda cada registro em uma linha da tabela "registro" e usa esta descrição para saber o formato,
 * de quem é o registro e o que um aluno pode ler ou gravar. O mentor lê e grava tudo.
 */
public final class Colecao {

    /** Formato no estado do portal. */
    public enum Tipo {
        /** Lista de objetos; cada objeto tem um campo que é a chave (id ou n). */
        LISTA,
        /** Objeto usado como dicionário: chave -> valor. */
        MAPA,
        /** Um valor único (configurações, lista de competências...). */
        VALOR
    }

    /** De onde sai o aluno dono do registro. */
    public enum Dono {
        NINGUEM,
        /** Campo "aid" do registro. */
        CAMPO_AID,
        /** Chave no formato "aluno-item" (ex.: entrega "12-5" = aluno 12, tarefa 5). */
        PREFIXO,
        /** A chave é o próprio id do aluno. */
        CHAVE,
        /** Chave no formato "aluno|assunto". */
        BARRA
    }

    /** O que o aluno enxerga. */
    public enum Leitura {
        NADA, PROPRIO, TODOS,
        /** Registros com lista "turmas": vazia vale para todos; senão, só para as turmas listadas. */
        TURMA, ESPECIAL
    }

    /** O que o aluno pode gravar. */
    public enum Escrita {
        NADA, PROPRIO,
        /** Pode acrescentar um registro novo, mas não alterar nem apagar. */
        SO_CRIAR, ESPECIAL
    }

    public final String nome;
    public final Tipo tipo;
    /** Campo que identifica o registro (só para listas). */
    public final String campoChave;
    /** A lista é mantida do mais novo para o mais antigo. */
    public final boolean recentePrimeiro;
    public final Dono dono;
    public final Leitura leitura;
    public final Escrita escrita;
    /** Campos que o aluno pode alterar em um registro dele (vazio = todos). */
    public final Set<String> camposAluno;
    /** O aluno pode apagar um registro dele? */
    public final boolean alunoApaga;

    Colecao(String nome, Tipo tipo, String campoChave, boolean recentePrimeiro, Dono dono, Leitura leitura, Escrita escrita, boolean alunoApaga, String... camposAluno) {
        this.nome = nome;
        this.tipo = tipo;
        this.campoChave = campoChave;
        this.recentePrimeiro = recentePrimeiro;
        this.dono = dono;
        this.leitura = leitura;
        this.escrita = escrita;
        this.alunoApaga = alunoApaga;
        this.camposAluno = camposAluno.length == 0 ? Collections.emptySet() : Collections.unmodifiableSet(new HashSet<>(Arrays.asList(camposAluno)));
    }

    /** Aluno dono do registro, ou null. */
    public Long donoDe(String chave, Object valor) {
        try {
            switch (dono) {
                case CAMPO_AID: {
                    Object aid = valor instanceof java.util.Map ? ((java.util.Map<?, ?>) valor).get("aid") : null;
                    long n = br.com.monetize.portal.util.Json.num(aid, 0);
                    return n > 0 ? n : null;
                }
                case PREFIXO: {
                    int i = chave.indexOf('-');
                    return i > 0 ? Long.valueOf(chave.substring(0, i)) : null;
                }
                case BARRA: {
                    int i = chave.indexOf('|');
                    return i > 0 ? Long.valueOf(chave.substring(0, i)) : null;
                }
                case CHAVE:
                    return Long.valueOf(chave);
                default:
                    return null;
            }
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @Override
    public String toString() {
        return nome;
    }
}
