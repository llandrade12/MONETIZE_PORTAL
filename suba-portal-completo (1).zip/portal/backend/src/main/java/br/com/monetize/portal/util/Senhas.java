package br.com.monetize.portal.util;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.util.Base64;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Senhas: o banco guarda só o resumo, nunca a senha.
 *
 * Formato: pbkdf2$<iterações>$<sal em base64>$<resumo em base64> (PBKDF2 com HMAC-SHA-256).
 * Também confere o formato antigo do portal sem servidor ("legado$<sha256>"), usado só para
 * quem restaura uma cópia feita naquela versão; no primeiro login a senha é regravada no formato novo.
 */
public final class Senhas {

    private Senhas() {
    }

    public static final int ITERACOES = 310_000;
    private static final int BITS = 256;
    /** Acima disto o resumo é recusado (um valor absurdo, vindo de uma cópia adulterada, travaria o login). */
    private static final int ITERACOES_MAX = 5_000_000;

    public static String gerar(String senha) {
        byte[] sal = Texto.aleatorio(16);
        return "pbkdf2$" + ITERACOES + "$" + Base64.getEncoder().encodeToString(sal) + "$"
                + Base64.getEncoder().encodeToString(pbkdf2(senha, sal, ITERACOES));
    }

    /** Confere a senha. O e-mail só é usado pelo formato antigo. */
    public static boolean confere(String senha, String guardado, String email) {
        if (senha == null || guardado == null || guardado.isEmpty())
            return false;
        try {
            if (guardado.startsWith("pbkdf2$")) {
                String[] p = guardado.split("\\$");
                if (p.length != 4)
                    return false;
                int it = Integer.parseInt(p[1]);
                if (it < 1 || it > ITERACOES_MAX)
                    return false;
                byte[] sal = Base64.getDecoder().decode(p[2]), esperado = Base64.getDecoder().decode(p[3]);
                return MessageDigest.isEqual(esperado, pbkdf2(senha, sal, it));
            }
            if (guardado.startsWith("legado$"))
                return MessageDigest.isEqual(guardado.substring(7).getBytes(StandardCharsets.UTF_8),
                        legado(email, senha).getBytes(StandardCharsets.UTF_8));
        } catch (RuntimeException e) {
            return false;
        }
        return false;
    }

    /** A senha precisa ser regravada (formato antigo ou menos iterações do que o padrão atual)? */
    public static boolean precisaAtualizar(String guardado) {
        if (guardado == null || !guardado.startsWith("pbkdf2$"))
            return true;
        String[] p = guardado.split("\\$");
        try {
            return p.length != 4 || Integer.parseInt(p[1]) < ITERACOES;
        } catch (NumberFormatException e) {
            return true;
        }
    }

    /**
     * Resumo de senha vindo de uma cópia dos dados: devolve no formato guardado no banco, ou null se o texto
     * não for um resumo reconhecido (o aluno fica sem senha até o mentor criar uma).
     */
    public static String importado(String s) {
        if (s == null)
            return null;
        String t = s.trim();
        if (t.matches("[0-9a-f]{64}"))
            return "legado$" + t;
        if (t.matches("legado\\$[0-9a-f]{64}"))
            return t;
        if (t.matches("pbkdf2\\$\\d{1,7}\\$[A-Za-z0-9+/=]{8,100}\\$[A-Za-z0-9+/=]{20,200}")) {
            int it = Integer.parseInt(t.split("\\$")[1]);
            return it >= 1000 && it <= ITERACOES_MAX ? t : null;
        }
        return null;
    }

    /** Mesma regra da tela: 8 ou mais caracteres, com letras e números. */
    public static boolean forte(String s) {
        return s != null && s.length() >= 8 && s.length() <= 200 && s.matches(".*\\d.*") && s.matches("(?i).*[a-z].*");
    }

    private static byte[] pbkdf2(String senha, byte[] sal, int iteracoes) {
        try {
            PBEKeySpec spec = new PBEKeySpec(senha.toCharArray(), sal, iteracoes, BITS);
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("PBKDF2 indisponível nesta instalação do Java", e);
        }
    }

    /** Resumo usado pelo portal antigo (no navegador): 5.000 rodadas de SHA-256 sobre "sop|email|senha". */
    public static String legado(String email, String senha) {
        String h = "sop|" + String.valueOf(email).trim().toLowerCase(java.util.Locale.ROOT) + "|" + senha;
        for (int i = 0; i < 5000; i++)
            h = Texto.sha256Hex(h + i);
        return h;
    }
}
