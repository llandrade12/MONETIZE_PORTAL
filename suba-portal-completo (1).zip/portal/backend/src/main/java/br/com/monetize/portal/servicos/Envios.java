package br.com.monetize.portal.servicos;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;

import br.com.monetize.portal.Config;
import br.com.monetize.portal.auth.Usuario;
import br.com.monetize.portal.dados.Notificador;
import br.com.monetize.portal.dados.Sincronizador;
import br.com.monetize.portal.db.Banco;
import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Log;
import br.com.monetize.portal.util.Texto;

/**
 * Fila de saída: envia os e-mails (SMTP) e entrega as mensagens ao webhook de automação, em segundo plano.
 *
 * Cada mensagem é uma linha da tabela "envio". Se o envio falha, tenta de novo com espera crescente
 * (1, 5, 30 e 120 minutos); depois da quinta falha, marca como erro. O item correspondente em
 * Notificações > E-mail e WhatsApp acompanha a situação: enviando, enviado ou erro.
 */
public final class Envios implements Runnable {

    private static final int[] ESPERA_MIN = { 1, 5, 30, 120 };

    private static final class Envio {
        long id;
        String filaChave, canal, destino, nome, assunto, corpo;
        int tentativas;
    }

    private final Banco banco;
    private final Config config;
    private final Sincronizador sinc;
    private final Smtp smtp;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).followRedirects(HttpClient.Redirect.NORMAL).build();
    private final Object sinal = new Object();
    private volatile boolean parar;
    private boolean acordado;
    private Thread thread;

    public Envios(Banco banco, Config config, Sincronizador sinc) {
        this.banco = banco;
        this.config = config;
        this.sinc = sinc;
        String host = URI.create(config.urlPublica()).getHost();
        this.smtp = config.emailConfigurado()
                ? new Smtp(config.smtpHost(), config.smtpPorta(), config.smtpSeguranca(), config.smtpUsuario(), config.smtpSenha(),
                        config.logico("smtp.verificar-certificado", true), host, 30_000)
                : null;
    }

    public void iniciar() {
        thread = new Thread(this, "envios");
        thread.setDaemon(true);
        thread.start();
    }

    public void parar() {
        parar = true;
        acordar();
        if (thread != null)
            thread.interrupt();
    }

    /** Avisa que há mensagens novas (não precisa esperar o próximo ciclo). */
    public void acordar() {
        synchronized (sinal) {
            acordado = true;
            sinal.notifyAll();
        }
    }

    @Override
    public void run() {
        while (!parar) {
            try {
                int n = ciclo();
                if (n == 0) {
                    synchronized (sinal) {
                        if (!acordado)
                            sinal.wait(20_000);
                        acordado = false;
                    }
                }
            } catch (InterruptedException e) {
                return;
            } catch (RuntimeException e) {
                Log.erro("Falha na fila de envio (nova tentativa em 30 s)", e);
                try {
                    Thread.sleep(30_000);
                } catch (InterruptedException x) {
                    return;
                }
            }
        }
    }

    /** Processa as mensagens que estão na hora. Devolve quantas processou. */
    public int ciclo() throws InterruptedException {
        LocalDateTime agora = sinc.agora();
        List<Envio> l = banco.usar(c -> Banco.consultar(c,
                "SELECT id, fila_chave, canal, destino, nome, assunto, corpo, tentativas FROM envio WHERE status = 'pendente' AND proxima_em <= ? ORDER BY id LIMIT 20", r -> {
                    Envio e = new Envio();
                    e.id = r.getLong("id");
                    e.filaChave = r.getString("fila_chave");
                    e.canal = r.getString("canal");
                    e.destino = r.getString("destino");
                    e.nome = r.getString("nome");
                    e.assunto = r.getString("assunto");
                    e.corpo = r.getString("corpo");
                    e.tentativas = r.getInt("tentativas");
                    return e;
                }, agora));
        for (Envio e : l) {
            if (parar)
                break;
            processar(e);
            if (e.canal.equals("email") && config.smtpIntervaloMs() > 0)
                Thread.sleep(config.smtpIntervaloMs());
        }
        return l.size();
    }

    private void processar(Envio e) {
        String erro = null;
        boolean definitivo = false;
        try {
            Map<String, Object> corpo = Json.lerObjeto(e.corpo);
            if (e.canal.equals("email"))
                email(e, corpo);
            else if (e.canal.equals("webhook"))
                webhook(e, corpo);
            else {
                erro = "Canal desconhecido: " + e.canal;
                definitivo = true;
            }
        } catch (Smtp.SmtpException x) {
            erro = x.getMessage();
            definitivo = x.definitivo;
        } catch (IOException | RuntimeException x) {
            erro = x.getClass().getSimpleName() + ": " + x.getMessage();
        } catch (InterruptedException x) {
            Thread.currentThread().interrupt();
            return;
        }
        final String falha = erro;
        final boolean fim = falha == null || definitivo || e.tentativas + 1 > ESPERA_MIN.length;
        LocalDateTime agora = sinc.agora();
        if (falha == null) {
            banco.usar(c -> Banco.executar(c, "UPDATE envio SET status = 'enviado', tentativas = tentativas + 1, enviado_em = ?, erro = NULL WHERE id = ?", agora, e.id));
        } else if (fim) {
            Log.aviso("Envio " + e.id + " (" + e.canal + " para " + e.destino + ") falhou de vez: " + falha);
            banco.usar(c -> Banco.executar(c, "UPDATE envio SET status = 'erro', tentativas = tentativas + 1, erro = ? WHERE id = ?", Texto.cortar(falha, 500), e.id));
        } else {
            Log.aviso("Envio " + e.id + " (" + e.canal + " para " + e.destino + ") falhou, nova tentativa depois: " + falha);
            banco.usar(c -> Banco.executar(c, "UPDATE envio SET tentativas = tentativas + 1, proxima_em = ?, erro = ? WHERE id = ?",
                    agora.plusMinutes(ESPERA_MIN[Math.min(e.tentativas, ESPERA_MIN.length - 1)]), Texto.cortar(falha, 500), e.id));
        }
        if (fim && e.filaChave != null)
            situacaoNaFila(e.filaChave, falha == null ? "enviado" : "erro", falha);
    }

    /** Atualiza o item que o mentor vê em Notificações > E-mail e WhatsApp. */
    private void situacaoNaFila(String chave, String st, String erro) {
        try {
            sinc.gravar(Usuario.sistema(), g -> {
                Map<String, Object> item = Json.obj(g.ler("fila", chave));
                if (item != null) {
                    item.put("st", st);
                    if (erro != null)
                        item.put("erro", Texto.cortar(erro, 300));
                    else
                        item.remove("erro");
                    g.gravar("fila", chave, item);
                }
                return null;
            });
        } catch (RuntimeException x) {
            Log.erro("Não foi possível atualizar a situação do envio na fila", x);
        }
    }

    /* ---------------------------------------------------------------- e-mail */

    private void email(Envio e, Map<String, Object> corpo) throws IOException {
        if (smtp == null)
            throw new Smtp.SmtpException("O e-mail (SMTP) não está configurado no servidor", true);
        Smtp.Mensagem m = new Smtp.Mensagem();
        m.de = config.smtpRemetente();
        m.deNome = config.smtpRemetenteNome();
        m.para = e.destino.trim();
        m.paraNome = e.nome;
        m.assunto = e.assunto;
        String msg = Json.str(corpo, "msg"), papel = Json.str(corpo, "papel"), ir = Json.str(corpo, "ir");
        String base = config.urlPublica();
        String saudacao = "Olá, " + Texto.primeiroNome(Texto.ou(e.nome, "tudo bem")) + ".";
        if (papel.equals("senha")) {
            String link = Json.str(corpo, "link");
            m.texto = saudacao + "\n\n" + msg + "\n\n" + link + "\n\nSe você não pediu a troca de senha, ignore este e-mail: nada muda.\n\n" + Notificador.MARCA + " · Área de Membros";
            m.html = EmailModelo.html(saudacao, e.assunto, msg, link, "Criar nova senha",
                    "O link vale por 1 hora e só pode ser usado uma vez. Se você não pediu a troca de senha, ignore este e-mail: nada muda.");
        } else {
            String link = base + "/" + (papel.equals("mentor") ? "mentor.html" : "aluno.html") + (ir.matches("[A-Za-z]{1,30}") ? "#ir=" + ir : "");
            m.texto = Notificador.texto(e.nome, e.assunto, msg) + "\n" + link;
            m.html = EmailModelo.html(saudacao, e.assunto, msg, link, "Abrir a Área de Membros",
                    papel.equals("mentor") ? "Você recebe este e-mail porque cadastrou este endereço para os alertas do painel do mentor."
                            : "Você recebe este e-mail porque participa da mentoria. Para deixar de receber, desligue os avisos por e-mail em Perfil e certificado, na Área de Membros.");
        }
        smtp.enviar(m);
    }

    /** Conferência da configuração de e-mail: tenta enviar na hora e devolve o erro, se houver. */
    public String testarEmail(String para, String nome) {
        if (smtp == null)
            return "O e-mail (SMTP) não está configurado no servidor";
        Smtp.Mensagem m = new Smtp.Mensagem();
        m.de = config.smtpRemetente();
        m.deNome = config.smtpRemetenteNome();
        m.para = para;
        m.paraNome = nome;
        m.assunto = "Teste de e-mail da Área de Membros";
        String msg = "Se você recebeu esta mensagem, o envio de e-mails do portal está funcionando.";
        m.texto = msg + "\n\n" + Notificador.MARCA + " · Área de Membros";
        m.html = EmailModelo.html("Olá, " + Texto.primeiroNome(nome) + ".", m.assunto, msg, config.urlPublica(), "Abrir a Área de Membros", "Mensagem de teste enviada pelo painel do mentor.");
        try {
            smtp.enviar(m);
            return null;
        } catch (IOException | RuntimeException x) {
            return x.getMessage() == null ? x.getClass().getSimpleName() : x.getMessage();
        }
    }

    /* ---------------------------------------------------------------- webhook (n8n, Make, Zapier) */

    private void webhook(Envio e, Map<String, Object> corpo) throws IOException, InterruptedException {
        corpo.put("enviado_em", ZonedDateTime.now(config.fuso()).toOffsetDateTime().toString());
        HttpRequest req = HttpRequest.newBuilder(URI.create(e.destino)).timeout(Duration.ofSeconds(20))
                .header("Content-Type", "application/json; charset=utf-8").header("User-Agent", "AreaDeMembros/1.0")
                .POST(HttpRequest.BodyPublishers.ofString(Json.texto(corpo), StandardCharsets.UTF_8)).build();
        HttpResponse<Void> r = http.send(req, HttpResponse.BodyHandlers.discarding());
        if (r.statusCode() / 100 != 2)
            throw new IOException("O serviço de automação respondeu " + r.statusCode());
    }

    /* ---------------------------------------------------------------- envio avulso (redefinição de senha) */

    /** Coloca na fila um e-mail que não nasce de uma notificação do portal. */
    public void emailAvulso(String para, String nome, String assunto, Map<String, Object> corpo) {
        LocalDateTime agora = sinc.agora();
        banco.usar(c -> Banco.executar(c, "INSERT INTO envio (fila_chave, canal, destino, nome, assunto, corpo, status, tentativas, proxima_em, criado_em) VALUES (NULL, 'email', ?, ?, ?, ?, 'pendente', 0, ?, ?)",
                Texto.cortar(para, 255), Texto.cortar(Texto.semEmoji(nome), 160), Texto.cortar(assunto, 255), Json.texto(corpo), agora, agora));
        acordar();
    }

    /** Remove da tabela os envios concluídos há mais de 60 dias. */
    public int limparAntigos() {
        LocalDateTime corte = sinc.agora().minusDays(60);
        return banco.usar(c -> Banco.executar(c, "DELETE FROM envio WHERE status <> 'pendente' AND criado_em < ?", corte));
    }
}
