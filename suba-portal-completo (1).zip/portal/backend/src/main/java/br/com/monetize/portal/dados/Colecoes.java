package br.com.monetize.portal.dados;

import static br.com.monetize.portal.dados.Colecao.Dono.BARRA;
import static br.com.monetize.portal.dados.Colecao.Dono.CAMPO_AID;
import static br.com.monetize.portal.dados.Colecao.Dono.CHAVE;
import static br.com.monetize.portal.dados.Colecao.Dono.NINGUEM;
import static br.com.monetize.portal.dados.Colecao.Dono.PREFIXO;
import static br.com.monetize.portal.dados.Colecao.Tipo.LISTA;
import static br.com.monetize.portal.dados.Colecao.Tipo.MAPA;
import static br.com.monetize.portal.dados.Colecao.Tipo.VALOR;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import br.com.monetize.portal.dados.Colecao.Escrita;
import br.com.monetize.portal.dados.Colecao.Leitura;

/**
 * Catálogo das coleções do portal. A mesma lista existe no navegador, em web/js/compartilhado/core/api.js
 * (constante COLECOES): ao criar uma coleção nova, acrescente nos dois lugares.
 */
public final class Colecoes {

    private Colecoes() {
    }

    /** Coleção dos alunos: fica na tabela "aluno", não em "registro". */
    public static final String ALUNOS = "alunos";

    /** Chave usada na tabela para as coleções de valor único. */
    public static final String CHAVE_VALOR = "_";

    private static final Map<String, Colecao> TODAS = new LinkedHashMap<>();

    private static void lista(String nome, String campo, boolean recente, Colecao.Dono dono, Leitura l, Escrita e, boolean apaga, String... campos) {
        TODAS.put(nome, new Colecao(nome, LISTA, campo, recente, dono, l, e, apaga, campos));
    }

    private static void mapa(String nome, Colecao.Dono dono, Leitura l, Escrita e, boolean apaga, String... campos) {
        TODAS.put(nome, new Colecao(nome, MAPA, null, false, dono, l, e, apaga, campos));
    }

    private static void valor(String nome, Leitura l) {
        TODAS.put(nome, new Colecao(nome, VALOR, null, false, NINGUEM, l, Escrita.NADA, false));
    }

    static {
        /* ---- cadastros do mentor ---- */
        lista("turmas", "id", false, NINGUEM, Leitura.ESPECIAL, Escrita.NADA, false);
        lista(ALUNOS, "id", false, NINGUEM, Leitura.ESPECIAL, Escrita.ESPECIAL, false,
                "nome", "tel", "nasc", "cargo", "civil", "formacao", "cidade", "empresa", "bio", "foto", "canais", "saida");
        lista("aulas", "n", false, NINGUEM, Leitura.TURMA, Escrita.NADA, false);
        lista("eventos", "id", false, NINGUEM, Leitura.TURMA, Escrita.NADA, false);
        lista("tarefas", "id", false, NINGUEM, Leitura.TURMA, Escrita.NADA, false);
        lista("recs", "id", true, NINGUEM, Leitura.TURMA, Escrita.NADA, false);
        lista("avisos", "id", false, NINGUEM, Leitura.ESPECIAL, Escrita.ESPECIAL, false);
        lista("faq", "id", false, NINGUEM, Leitura.TODOS, Escrita.NADA, false);

        /* ---- registros de cada aluno (listas) ---- */
        lista("metas", "id", false, CAMPO_AID, Leitura.PROPRIO, Escrita.ESPECIAL, false);
        lista("contest", "id", false, CAMPO_AID, Leitura.PROPRIO, Escrita.SO_CRIAR, false);
        lista("just", "id", true, CAMPO_AID, Leitura.PROPRIO, Escrita.SO_CRIAR, false);
        lista("diario", "id", true, CAMPO_AID, Leitura.PROPRIO, Escrita.PROPRIO, true,
                "id", "aid", "n", "tit", "txt", "at", "upd", "share", "avisou");
        lista("chamados", "id", true, CAMPO_AID, Leitura.PROPRIO, Escrita.ESPECIAL, false);
        lista("lgpd", "id", true, CAMPO_AID, Leitura.PROPRIO, Escrita.ESPECIAL, false);
        lista("inbox", "id", true, CAMPO_AID, Leitura.PROPRIO, Escrita.ESPECIAL, false);
        lista("fila", "id", true, CAMPO_AID, Leitura.PROPRIO, Escrita.NADA, false);

        /* ---- só o mentor lê; o aluno apenas acrescenta (alertas e histórico gerados pelas ações dele) ---- */
        lista("inboxM", "id", true, NINGUEM, Leitura.NADA, Escrita.SO_CRIAR, false);
        lista("notif", "id", true, NINGUEM, Leitura.NADA, Escrita.SO_CRIAR, false);
        lista("log", "id", true, NINGUEM, Leitura.NADA, Escrita.SO_CRIAR, false);

        /* ---- registros de cada aluno (dicionários "aluno-item") ---- */
        mapa("ent", PREFIXO, Leitura.PROPRIO, Escrita.ESPECIAL, false);
        mapa("notas", PREFIXO, Leitura.PROPRIO, Escrita.NADA, false);
        mapa("prazo", PREFIXO, Leitura.PROPRIO, Escrita.NADA, false);
        mapa("pres", PREFIXO, Leitura.PROPRIO, Escrita.NADA, false);
        mapa("presObs", PREFIXO, Leitura.PROPRIO, Escrita.NADA, false);
        mapa("vis", PREFIXO, Leitura.PROPRIO, Escrita.PROPRIO, true);
        mapa("prog", PREFIXO, Leitura.PROPRIO, Escrita.PROPRIO, true);
        mapa("rasc", PREFIXO, Leitura.PROPRIO, Escrita.PROPRIO, true);
        mapa("recSt", PREFIXO, Leitura.PROPRIO, Escrita.PROPRIO, true);

        /* ---- um registro por aluno ---- */
        mapa("roda", CHAVE, Leitura.PROPRIO, Escrita.ESPECIAL, false);
        mapa("rot", CHAVE, Leitura.PROPRIO, Escrita.PROPRIO, false);
        mapa("compA", CHAVE, Leitura.PROPRIO, Escrita.NADA, false);
        mapa("termos", CHAVE, Leitura.PROPRIO, Escrita.ESPECIAL, false);
        mapa("certLib", CHAVE, Leitura.PROPRIO, Escrita.NADA, false);
        mapa("priv", CHAVE, Leitura.NADA, Escrita.NADA, false);
        mapa("aval", CHAVE, Leitura.NADA, Escrita.NADA, false);
        mapa("nlog", BARRA, Leitura.NADA, Escrita.NADA, false);

        /* ---- por turma ---- */
        mapa("certs", NINGUEM, Leitura.ESPECIAL, Escrita.NADA, false);

        /* ---- valores únicos ---- */
        valor("cfg", Leitura.ESPECIAL);
        valor("compL", Leitura.TODOS);
        valor("mentor", Leitura.TODOS);
        valor("mentores", Leitura.TODOS);
    }

    public static Colecao de(String nome) {
        return nome == null ? null : TODAS.get(nome);
    }

    public static Collection<Colecao> todas() {
        return Collections.unmodifiableCollection(TODAS.values());
    }
}
