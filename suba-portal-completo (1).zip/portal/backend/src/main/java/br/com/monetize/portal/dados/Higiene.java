package br.com.monetize.portal.dados;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Texto;

/**
 * Confere o formato de tudo o que um aluno grava.
 *
 * O que um aluno escreve aparece depois na tela do mentor. Por isso cada campo é conferido aqui antes de ser
 * guardado: texto tem de ser texto (com tamanho máximo), data tem de ser data, código tem de ser código, e
 * campos que o portal não conhece são descartados. Assim um registro montado à mão, fora das telas do portal,
 * não consegue quebrar nem adulterar a página de outra pessoa.
 */
final class Higiene {

    private Higiene() {
    }

    /** Códigos de registros, etapas e arquivos: letras, números, hífen e sublinhado. */
    static final Pattern CODIGO = Pattern.compile("[A-Za-z0-9_-]{1,60}");
    private static final Pattern DATA = Pattern.compile("\\d{4}-\\d{2}-\\d{2}");
    /** Nome de página do portal (destino de uma notificação). */
    private static final Pattern PAGINA = Pattern.compile("[A-Za-z]{1,30}");
    private static final Pattern FOTO = Pattern.compile("data:image/(png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}");
    private static final Pattern LINK = Pattern.compile("https://[^\\s\"'<>`\\\\]{1,1990}");
    /** Chaves dos registros da rotina: sem caracteres que tenham significado em HTML. */
    private static final Pattern CHAVE_LIVRE = Pattern.compile("[^\"'<>&`\\\\\\p{Cntrl}]{1,80}");
    private static final Pattern CAMPO = Pattern.compile("[A-Za-z][A-Za-z0-9_]{0,23}");

    static final int FOTO_MAX = 400_000;

    /* ---------------------------------------------------------------- valores simples */

    static Map<String, Object> objeto(Object o) {
        Map<String, Object> m = Json.obj(o);
        if (m == null)
            throw new Recusa("formato");
        return m;
    }

    /** Texto com tamanho máximo. Número e verdadeiro/falso viram texto; lista e objeto são recusados. */
    static String texto(Object v, int max) {
        if (v == null)
            return "";
        if (v instanceof String)
            return Texto.cortar((String) v, max);
        if (v instanceof Number || v instanceof Boolean)
            return Texto.cortar(Gravador.chaveDe(v), max);
        throw new Recusa("formato");
    }

    /** Aplica {@link #texto} aos campos presentes. */
    static void textos(Map<String, Object> m, int max, String... campos) {
        for (String c : campos)
            if (m.containsKey(c))
                m.put(c, texto(m.get(c), max));
    }

    /** Data "AAAA-MM-DD" válida, ou vazio. */
    static String data(Object v) {
        if (!(v instanceof String))
            return "";
        String s = ((String) v).trim();
        return DATA.matcher(s).matches() && Texto.data(s) != null ? s : "";
    }

    /** Código de um registro: número inteiro não negativo ou texto de código. */
    static Object codigo(Object v) {
        if (v instanceof Long && (Long) v >= 0)
            return v;
        if (v instanceof String && CODIGO.matcher((String) v).matches())
            return v;
        throw new Recusa("formato");
    }

    static Object codigoOuNulo(Object v) {
        return v == null || "".equals(v) ? null : codigo(v);
    }

    /** Nome de página do portal, ou o padrão quando o valor não é um nome de página. */
    static String pagina(Object v, String padrao) {
        return v instanceof String && PAGINA.matcher((String) v).matches() ? (String) v : padrao;
    }

    /** Endereço https, ou vazio. */
    static String link(Object v) {
        if (!(v instanceof String))
            return "";
        String s = ((String) v).trim();
        return LINK.matcher(s).matches() ? s : "";
    }

    /** Número dentro da faixa (fora dela, ou quando não é número, vale o mínimo). */
    static Object numero(Object v, double min, double max) {
        if (!(v instanceof Number))
            return (long) min;
        double d = ((Number) v).doubleValue();
        if (Double.isNaN(d) || d < min)
            return (long) min;
        if (d > max)
            return (long) max;
        if (v instanceof Long)
            return v;
        /* Três casas decimais bastam para segundos de vídeo e percentuais. */
        return BigDecimal.valueOf(Math.round(d * 1000) / 1000.0);
    }

    /** Foto do perfil: imagem embutida (PNG, JPEG ou WebP) dentro do tamanho máximo, ou null. */
    static String foto(Object v) {
        if (v == null || "".equals(v))
            return null;
        if (v instanceof String && ((String) v).length() <= FOTO_MAX && FOTO.matcher((String) v).matches())
            return (String) v;
        throw new Recusa("foto-invalida");
    }

    /** Só os campos informados (os demais são descartados). */
    static Map<String, Object> so(Map<String, Object> m, String... campos) {
        Map<String, Object> r = new LinkedHashMap<>();
        for (String c : campos)
            if (m.containsKey(c))
                r.put(c, m.get(c));
        return r;
    }

    private static List<Object> lista(Object v, int max) {
        List<Object> l = Json.lista(v);
        if (l == null)
            throw new Recusa("formato");
        if (l.size() > max)
            throw new Recusa("grande-demais");
        return l;
    }

    /* ---------------------------------------------------------------- registros */

    /** Arquivos de uma entrega: {id, name, size, type}, no máximo cinco. */
    static List<Object> arquivos(Object v) {
        List<Object> r = new ArrayList<>();
        if (v == null)
            return r;
        List<Object> l = Json.lista(v);
        if (l == null)
            throw new Recusa("formato");
        if (l.size() > 5)
            throw new Recusa("arquivos-demais");
        for (Object o : l) {
            Map<String, Object> f = objeto(o);
            Object id = f.get("id");
            if (!(id instanceof String) || !CODIGO.matcher((String) id).matches())
                throw new Recusa("formato");
            r.add(Json.mapa("id", id, "name", texto(f.get("name"), 200), "size", numero(f.get("size"), 0, 1e12), "type", texto(f.get("type"), 120)));
        }
        return r;
    }

    /** Etapas de uma meta do plano de ação: {id, t, prazo, feito}. */
    static List<Object> etapas(Object v) {
        List<Object> r = new ArrayList<>();
        if (v == null)
            return r;
        for (Object o : lista(v, 40)) {
            Map<String, Object> e = objeto(o);
            Object id = e.get("id");
            if (!(id instanceof String) || !CODIGO.matcher((String) id).matches())
                throw new Recusa("formato");
            r.add(Json.mapa("id", id, "t", texto(e.get("t"), 300), "prazo", data(e.get("prazo")), "feito", Json.verdadeiro(e.get("feito"))));
        }
        return r;
    }

    /** Posição do vídeo de uma aula: {t, d, w, p, auto}. */
    static Map<String, Object> progresso(Object v) {
        Map<String, Object> p = objeto(v);
        Map<String, Object> r = Json.mapa("t", numero(p.get("t"), 0, 1e6), "d", numero(p.get("d"), 0, 1e6), "w", numero(p.get("w"), 0, 1e6), "p", numero(p.get("p"), 0, 100));
        if (Json.verdadeiro(p.get("auto")))
            r.put("auto", texto(p.get("auto"), 20));
        return r;
    }

    /** Rascunho de uma entrega: {txt, link, at}. */
    static Map<String, Object> rascunho(Object v) {
        Map<String, Object> p = objeto(v);
        return Json.mapa("txt", texto(p.get("txt"), 20_000), "link", texto(p.get("link"), 2000), "at", texto(p.get("at"), 20));
    }

    /* ---------------------------------------------------------------- rotina */

    /**
     * Rotina e hábitos do aluno:
     * hab {chave: "y" | "n" | ""}, bib {chave: 1}, treino [[{campos}]], obj [{t, m [textos], done [0 | 1]}]
     * e as listas de leituras e conteúdos [{campos, fap {f, a, p}}].
     */
    static Map<String, Object> rotina(Object v) {
        Map<String, Object> p = objeto(v);
        if (p.size() > 20)
            throw new Recusa("formato");
        Map<String, Object> r = new LinkedHashMap<>();
        for (Map.Entry<String, Object> e : p.entrySet()) {
            String k = e.getKey();
            if (!CAMPO.matcher(k).matches())
                throw new Recusa("formato");
            switch (k) {
                case "hab": {
                    Map<String, Object> hab = new LinkedHashMap<>();
                    for (Map.Entry<String, Object> h : limitado(objeto(e.getValue()), 3000).entrySet()) {
                        Object s = h.getValue();
                        if (chaveLivre(h.getKey()) && ("y".equals(s) || "n".equals(s) || "".equals(s)))
                            hab.put(h.getKey(), s);
                    }
                    r.put(k, hab);
                    break;
                }
                case "bib": {
                    Map<String, Object> bib = new LinkedHashMap<>();
                    for (Map.Entry<String, Object> b : limitado(objeto(e.getValue()), 2000).entrySet())
                        if (chaveLivre(b.getKey()) && Json.verdadeiro(b.getValue()))
                            bib.put(b.getKey(), 1L);
                    r.put(k, bib);
                    break;
                }
                case "treino": {
                    List<Object> semanas = new ArrayList<>();
                    for (Object semana : lista(e.getValue(), 60)) {
                        List<Object> treinos = new ArrayList<>();
                        for (Object t : lista(semana, 30))
                            treinos.add(simples(t, 200));
                        semanas.add(treinos);
                    }
                    r.put(k, semanas);
                    break;
                }
                case "obj": {
                    List<Object> objetivos = new ArrayList<>();
                    for (Object o : lista(e.getValue(), 12)) {
                        Map<String, Object> ob = objeto(o);
                        List<Object> fases = new ArrayList<>(), feitas = new ArrayList<>();
                        for (Object f : lista(ob.get("m") == null ? new ArrayList<>() : ob.get("m"), 12))
                            fases.add(texto(f, 300));
                        for (Object f : lista(ob.get("done") == null ? new ArrayList<>() : ob.get("done"), 12))
                            feitas.add(Json.verdadeiro(f) ? 1L : 0L);
                        objetivos.add(Json.mapa("t", texto(ob.get("t"), 300), "m", fases, "done", feitas));
                    }
                    r.put(k, objetivos);
                    break;
                }
                default: {
                    /* Listas de leituras e conteúdos (livros, audiolivros, podcasts...). */
                    List<Object> itens = new ArrayList<>();
                    for (Object o : lista(e.getValue(), 80)) {
                        Map<String, Object> bruto = objeto(o);
                        Map<String, Object> item = simples(so(bruto, semCampo(bruto, "fap")), 300);
                        if (bruto.get("fap") != null)
                            item.put("fap", simples(bruto.get("fap"), 2000));
                        itens.add(item);
                    }
                    r.put(k, itens);
                    break;
                }
            }
        }
        for (String obrigatorio : new String[] { "hab", "bib", "treino", "obj" })
            if (!r.containsKey(obrigatorio))
                throw new Recusa("formato");
        return r;
    }

    private static boolean chaveLivre(String k) {
        return CHAVE_LIVRE.matcher(k).matches();
    }

    private static Map<String, Object> limitado(Map<String, Object> m, int max) {
        if (m.size() > max)
            throw new Recusa("grande-demais");
        return m;
    }

    private static String[] semCampo(Map<String, Object> m, String fora) {
        List<String> l = new ArrayList<>();
        for (String k : m.keySet())
            if (!k.equals(fora))
                l.add(k);
        return l.toArray(new String[0]);
    }

    /** Objeto de um nível só: nomes de campo simples e valores de texto, número ou verdadeiro/falso. */
    private static Map<String, Object> simples(Object v, int max) {
        Map<String, Object> m = objeto(v);
        if (m.size() > 16)
            throw new Recusa("formato");
        Map<String, Object> r = new LinkedHashMap<>();
        for (Map.Entry<String, Object> e : m.entrySet()) {
            if (!CAMPO.matcher(e.getKey()).matches())
                throw new Recusa("formato");
            Object x = e.getValue();
            if (x == null)
                continue;
            if (x instanceof Boolean || x instanceof Long)
                r.put(e.getKey(), x);
            else
                r.put(e.getKey(), texto(x, max));
        }
        return r;
    }
}
