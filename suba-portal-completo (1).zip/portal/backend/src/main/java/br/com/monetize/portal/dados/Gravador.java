package br.com.monetize.portal.dados;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import br.com.monetize.portal.Config;
import br.com.monetize.portal.auth.Usuario;
import br.com.monetize.portal.dados.Colecao.Tipo;
import br.com.monetize.portal.dados.Repositorio.AlunoLinha;
import br.com.monetize.portal.dados.Repositorio.Reg;
import br.com.monetize.portal.db.Banco;
import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Senhas;
import br.com.monetize.portal.util.Texto;

/**
 * Uma gravação em andamento: a conexão dentro da transação, quem está gravando, o número da alteração
 * e os efeitos a disparar depois. Toda escrita nos registros do portal passa por aqui, para que os
 * ganchos (notificar, enfileirar e-mail, manter a tabela de alunos) valham para todos os caminhos.
 */
public final class Gravador {

    /** Formato aceito para chaves de registro. */
    private static final Pattern CHAVE_OK = Pattern.compile("[A-Za-z0-9_.|:@-]{1,150}");
    /** Tamanho máximo de um registro em JSON (a foto do perfil, reduzida, fica bem abaixo disto). */
    private static final int REGISTRO_MAX = 600_000;
    private static final Set<String> STATUS = new HashSet<>(Arrays.asList("pendente", "ativo", "bloqueado", "removido"));

    public final Connection c;
    public final Usuario u;
    public final long rev;
    public final LocalDateTime agora;
    /** Data e hora no formato do portal: 15/03/2026 20:30. */
    public final String carimbo;
    public final Config config;
    public final Efeitos efeitos = new Efeitos();
    /** Restaurando uma cópia: aceita o resumo de senha que veio no arquivo. */
    public boolean restaurando;

    private Map<String, Object> cfg;
    private String nomeMentor;
    private int contador;

    Gravador(Connection c, Usuario u, long rev, LocalDateTime agora, Config config) {
        this.c = c;
        this.u = u;
        this.rev = rev;
        this.agora = agora;
        this.carimbo = Texto.carimbo(agora);
        this.config = config;
    }

    /* ---------------------------------------------------------------- leitura */

    /** Valor de um registro existente (já convertido de JSON), ou null. */
    public Object ler(String colecao, String chave) throws SQLException {
        Reg r = Repositorio.vivo(c, colecao, chave);
        return r == null ? null : Json.ler(r.dados);
    }

    /** Configurações do portal, completadas com os padrões. */
    public Map<String, Object> cfg() throws SQLException {
        if (cfg == null)
            cfg = Padroes.cfgCom(Json.obj(ler("cfg", Colecoes.CHAVE_VALOR)));
        return cfg;
    }

    /** Nome do mentor responsável (Configurações). */
    public String nomeMentor() throws SQLException {
        if (nomeMentor == null) {
            Object v = ler("mentor", Colecoes.CHAVE_VALOR);
            nomeMentor = v instanceof String && !((String) v).isEmpty() ? (String) v : "Mentor";
        }
        return nomeMentor;
    }

    /** O arquivo existe e foi enviado por este aluno? */
    boolean arquivoDoAluno(String arquivoId, long alunoId) throws SQLException {
        return Banco.um(c, "SELECT id FROM arquivo WHERE id = ? AND aluno_id = ?", r -> r.getString(1), arquivoId, alunoId) != null;
    }

    /** Identificador novo para registros criados pelo servidor. */
    public String novoId() {
        return Texto.uid() + Integer.toString(contador++, 36);
    }

    /* ---------------------------------------------------------------- escrita direta (sem conferir permissão) */

    public void gravar(String colecao, String chave, Object valor) throws SQLException {
        Colecao col = exigir(colecao);
        Reg atual = Repositorio.vivo(c, colecao, chave);
        Object antigo = atual == null ? null : Json.ler(atual.dados);
        if (antigo != null && Json.igual(antigo, valor))
            return;
        gravarInterno(col, chave, valor, Json.texto(valor), antigo);
    }

    public boolean apagar(String colecao, String chave) throws SQLException {
        Colecao col = exigir(colecao);
        Reg atual = Repositorio.vivo(c, colecao, chave);
        if (atual == null)
            return false;
        apagarInterno(col, chave, Json.ler(atual.dados));
        return true;
    }

    private static Colecao exigir(String colecao) {
        Colecao col = Colecoes.de(colecao);
        if (col == null || col.nome.equals(Colecoes.ALUNOS))
            throw new IllegalArgumentException("Coleção inválida para gravação direta: " + colecao);
        return col;
    }

    private void gravarInterno(Colecao col, String chave, Object valor, String json, Object antigo) throws SQLException {
        Repositorio.gravar(c, col.nome, chave, col.donoDe(chave, valor), json, rev, agora);
        efeitos.mudou = true;
        if (col.nome.equals("cfg"))
            cfg = null;
        if (col.nome.equals("mentor"))
            nomeMentor = null;
        /* Registro novo: dispara os canais externos (menos ao restaurar uma cópia, quando nada deve ser reenviado). */
        if (antigo == null && !restaurando) {
            if (col.nome.equals("inbox"))
                Notificador.aoCriarNotificacao(this, Json.obj(valor));
            else if (col.nome.equals("inboxM"))
                Notificador.aoCriarAlertaDoMentor(this, Json.obj(valor));
        }
    }

    private void apagarInterno(Colecao col, String chave, Object antigo) throws SQLException {
        Repositorio.apagar(c, col.nome, chave, rev, agora);
        efeitos.mudou = true;
        if (col.nome.equals("aulas"))
            aoApagarAula(chave, Json.obj(antigo));
    }

    /**
     * Aula excluída: as anotações dos alunos sobre ela são deles e continuam no diário, como anotação livre.
     * (O painel do mentor faz o mesmo com as anotações que ele enxerga; aqui vale para todas, inclusive as privadas.)
     */
    private void aoApagarAula(String chave, Map<String, Object> aula) throws SQLException {
        String nome = aula == null ? "" : Json.str(aula, "nome");
        for (Reg r : Repositorio.vivosDe(c, "diario")) {
            Map<String, Object> d = Json.obj(Json.ler(r.dados));
            if (d == null || d.get("n") == null || !chave.equals(chaveDe(d.get("n"))))
                continue;
            d.put("n", null);
            if (Json.str(d, "tit").isEmpty())
                d.put("tit", nome);
            Repositorio.gravar(c, "diario", r.chave, r.alunoId, Json.texto(d), rev, agora);
        }
    }

    /* ---------------------------------------------------------------- operações vindas do portal */

    /** Texto usado como chave a partir do campo de identificação de um registro (id numérico ou texto). */
    public static String chaveDe(Object id) {
        if (id == null)
            return "";
        if (id instanceof java.math.BigDecimal)
            return ((java.math.BigDecimal) id).toPlainString();
        return String.valueOf(id);
    }

    /**
     * Aplica uma operação {c, k, v | set/del | rm} conferindo as permissões de quem enviou.
     * Devolve o trecho JSON a ecoar para o portal quando o servidor guardou algo diferente do pedido, ou null.
     */
    public String aplicar(Map<String, Object> op) throws SQLException {
        Colecao col = Colecoes.de(Json.str(op, "c"));
        if (col == null)
            throw new Recusa("colecao-desconhecida");
        String k = col.tipo == Tipo.VALOR ? Colecoes.CHAVE_VALOR : Json.str(op, "k");
        if (!CHAVE_OK.matcher(k).matches())
            throw new Recusa("chave-invalida");
        boolean rm = Json.bool(op, "rm");
        if (col.nome.equals(Colecoes.ALUNOS))
            return aplicarAluno(op, k, rm);

        Reg atual = Repositorio.vivo(c, col.nome, k);
        Object antigo = atual == null ? null : Json.ler(atual.dados);
        Object pedido = rm ? null : pedido(op, antigo);
        /* As regras do aluno podem ajustar o registro (carimbo de data, campos que só o servidor define):
           elas trabalham em uma cópia, para que o portal receba de volta o que de fato ficou guardado. */
        Object fim = u.aluno() ? Permissoes.aluno(this, col, k, antigo, Json.copia(pedido), rm) : pedido;

        if (rm) {
            if (atual != null)
                apagarInterno(col, k, antigo);
            return null;
        }
        if (fim == null)
            throw new Recusa("valor-vazio");
        if (col.tipo == Tipo.LISTA) {
            Map<String, Object> m = Json.obj(fim);
            if (m == null)
                throw new Recusa("formato");
            if (!k.equals(chaveDe(m.get(col.campoChave))))
                throw new Recusa("chave-diferente");
        }
        String json = Json.texto(fim);
        if (json.length() > REGISTRO_MAX)
            throw new Recusa("grande-demais");
        if (antigo == null || !Json.igual(antigo, fim))
            gravarInterno(col, k, fim, json, antigo);

        String leitor = Estado.paraLeitor(c, u, col, k, col.donoDe(k, fim), json);
        if (leitor == null)
            return eco(col.nome, k, null);
        return Json.igual(pedido, fim) && leitor.equals(json) ? null : eco(col.nome, k, leitor);
    }

    private static String eco(String colecao, String chave, String json) {
        StringBuilder b = new StringBuilder();
        Estado.mud(b, colecao, chave, json);
        return b.toString();
    }

    /** Valor pedido: o registro inteiro ("v") ou o registro atual com os campos alterados ("set") e removidos ("del"). */
    private static Object pedido(Map<String, Object> op, Object antigo) {
        if (op.containsKey("v")) {
            Object v = op.get("v");
            if (v == null)
                throw new Recusa("valor-vazio");
            return v;
        }
        Map<String, Object> base = Json.obj(antigo);
        if (base == null)
            throw new Recusa("inexistente");
        Map<String, Object> novo = Json.obj(Json.copia(base));
        Map<String, Object> set = Json.obj(op.get("set"));
        if (set != null)
            novo.putAll(set);
        for (Object campo : Json.lista(op, "del"))
            novo.remove(String.valueOf(campo));
        return novo;
    }

    /* ---------------------------------------------------------------- alunos (tabela própria) */

    private String aplicarAluno(Map<String, Object> op, String k, boolean rm) throws SQLException {
        if (rm)
            throw new Recusa("aluno-nao-e-apagado");
        long id;
        try {
            id = Long.parseLong(k);
        } catch (NumberFormatException e) {
            throw new Recusa("chave-invalida");
        }
        if (id <= 0)
            throw new Recusa("chave-invalida");
        AlunoLinha atual = Repositorio.lerAluno(c, id);
        Map<String, Object> antigo = atual == null ? null : Json.lerObjeto(Estado.alunoJson(atual));
        Map<String, Object> pedido = Json.obj(pedido(op, antigo));
        if (pedido == null)
            throw new Recusa("formato");
        Map<String, Object> fim = u.aluno() ? Permissoes.proprioCadastro(this, id, antigo, Json.obj(Json.copia(pedido))) : pedido;
        String leitor = gravarAluno(id, atual, Json.obj(Json.copia(fim)));
        return Json.igual(pedido, Json.ler(leitor)) ? null : eco(Colecoes.ALUNOS, k, leitor);
    }

    /**
     * Grava a ficha do aluno e mantém as colunas da tabela (login, turma, situação, senha).
     * Devolve a ficha como o portal a recebe.
     */
    public String gravarAluno(long id, AlunoLinha atual, Map<String, Object> d) throws SQLException {
        Object senhaNova = d.remove("senhaNova");
        Object senhaImportada = d.remove("senha");
        d.remove("temSenha");
        d.put("id", id);

        String nome = Json.str(d, "nome").trim();
        if (nome.isEmpty())
            throw new Recusa("nome-obrigatorio");
        String email = Json.str(d, "email").trim();
        String emailLogin = email.toLowerCase(Locale.ROOT);
        if (emailLogin.length() > 190 || (!emailLogin.isEmpty() && !emailLogin.matches("\\S+@\\S+\\.\\S+")))
            throw new Recusa("email-invalido");
        /* O e-mail é o login: fica sempre em minúsculas, na coluna e na ficha. */
        d.put("email", emailLogin);
        String status = Json.str(d, "status");
        if (!STATUS.contains(status)) {
            status = atual != null ? atual.status : "pendente";
            d.put("status", status);
        }
        long turma = Json.num(d, "turma", 0);

        if (!emailLogin.isEmpty()) {
            AlunoLinha outro = Repositorio.alunoPorEmail(c, emailLogin);
            if (outro != null && outro.id != id)
                throw new Recusa("email-em-uso");
            Long mentor = Banco.um(c, "SELECT id FROM mentor WHERE email = ?", r -> r.getLong(1), emailLogin);
            if (mentor != null)
                throw new Recusa("email-de-mentor");
        }

        AlunoLinha a = new AlunoLinha();
        a.id = id;
        a.nome = Texto.cortar(Texto.semEmoji(nome), 160);
        a.email = emailLogin.isEmpty() ? null : emailLogin;
        a.telefone = Texto.vazio(Json.str(d, "tel")) ? null : Texto.cortar(Texto.semEmoji(Json.str(d, "tel").trim()), 40);
        a.turmaId = turma > 0 ? turma : null;
        a.status = status;
        a.senhaHash = atual == null ? null : atual.senhaHash;
        a.rev = rev;

        if (senhaNova instanceof String && !((String) senhaNova).isEmpty()) {
            if (!Senhas.forte((String) senhaNova))
                throw new Recusa("senha-fraca");
            a.senhaHash = Senhas.gerar((String) senhaNova);
        } else if (restaurando && senhaImportada instanceof String && !((String) senhaImportada).isEmpty()) {
            a.senhaHash = Senhas.importado((String) senhaImportada);
        }
        /* Sem e-mail não há login (cadastro apagado a pedido, pela LGPD): a senha deixa de existir. */
        if (a.email == null)
            a.senhaHash = null;

        a.dados = Json.texto(d);
        if (a.dados.length() > REGISTRO_MAX)
            throw new Recusa("grande-demais");

        if (atual == null) {
            a.agendaToken = Texto.segredo(24);
            Repositorio.inserirAluno(c, a, agora);
            Repositorio.garantirIdAcimaDe(c, id);
        } else {
            a.agendaToken = atual.agendaToken;
            Repositorio.atualizarAluno(c, a, agora);
            /* Mudou o nome: o histórico passa a mostrar o nome novo. */
            if (!restaurando && !a.nome.equals(atual.nome))
                trocarNomeNosHistoricos(id, atual.nome, a.nome);
            /* Quem deixa de estar ativo é desconectado na hora. */
            if (!"ativo".equals(status) && "ativo".equals(atual.status))
                Banco.executar(c, "DELETE FROM sessao WHERE aluno_id = ?", id);
        }
        efeitos.mudou = true;
        return Estado.alunoJson(a);
    }

    /* ---------------------------------------------------------------- nome do aluno nos históricos */

    /** Coleções em que o nome de um aluno aparece dentro de textos, e os campos de cada uma. */
    private static final String[][] HISTORICOS = { { "log", "who", "m" }, { "notif", "dest" }, { "inboxM", "t", "m" }, { "fila", "nome", "ev", "txt" }, { "lgpd", "nome" } };

    /**
     * Troca o nome de um aluno nos históricos: registro de ações, avisos enviados, alertas do mentor e
     * mensagens da fila. É usado quando o nome do cadastro muda (o histórico acompanha) e quando os dados
     * do aluno são excluídos (o nome some de todo lugar).
     */
    public void trocarNomeNosHistoricos(long alunoId, String de, String para) throws SQLException {
        if (de == null || de.trim().length() < 3 || de.equals(para))
            return;
        /* Nomes de outros alunos que contêm este ("João Silva Neto" contém "João Silva") ficam protegidos. */
        List<String> maiores = new ArrayList<>();
        for (AlunoLinha outro : Repositorio.alunos(c))
            if (outro.id != alunoId && outro.nome != null && outro.nome.length() > de.trim().length() && outro.nome.contains(de.trim()))
                maiores.add(outro.nome);
        /* Só o nome inteiro: "Ana Lima" não pode ser trocado dentro de "Mariana Lima". */
        Pattern nome = Pattern.compile("(?<![\\p{L}\\p{N}])" + Pattern.quote(de.trim()) + "(?![\\p{L}\\p{N}])");
        String novo = java.util.regex.Matcher.quoteReplacement(para);
        for (String[] h : HISTORICOS) {
            for (Reg r : Repositorio.vivosDe(c, h[0])) {
                if (!r.dados.contains(de.trim()) && !r.dados.contains("\\"))
                    continue;
                Map<String, Object> m = Json.obj(Json.ler(r.dados));
                if (m == null)
                    continue;
                boolean mudou = false;
                for (int i = 1; i < h.length; i++) {
                    Object v = m.get(h[i]);
                    if (!(v instanceof String))
                        continue;
                    String t = (String) v;
                    for (int n = 0; n < maiores.size(); n++)
                        t = t.replace(maiores.get(n), "\u0000" + n + "\u0000");
                    t = nome.matcher(t).replaceAll(novo);
                    for (int n = 0; n < maiores.size(); n++)
                        t = t.replace("\u0000" + n + "\u0000", maiores.get(n));
                    if (!t.equals(v)) {
                        m.put(h[i], t);
                        mudou = true;
                    }
                }
                if (mudou)
                    gravar(h[0], r.chave, m);
            }
        }
    }

    /* ---------------------------------------------------------------- utilidades para os ganchos */

    /** Coloca uma mensagem na fila de saída do servidor (e-mail por SMTP ou entrega ao webhook). */
    void enfileirar(String filaChave, String canal, String destino, String nome, String assunto, Map<String, Object> corpo) throws SQLException {
        Banco.executar(c, "INSERT INTO envio (fila_chave, canal, destino, nome, assunto, corpo, status, tentativas, proxima_em, criado_em) VALUES (?, ?, ?, ?, ?, ?, 'pendente', 0, ?, ?)",
                filaChave, canal, Texto.cortar(destino, 600), Texto.cortar(Texto.semEmoji(nome), 160), Texto.cortar(Texto.semEmoji(assunto), 255), Json.texto(corpo), agora, agora);
        efeitos.enviosNovos = true;
    }

    /** Lista de objetos de um campo, ignorando o que não for objeto. */
    static List<Map<String, Object>> objetos(Map<String, Object> m, String campo) {
        List<Map<String, Object>> l = new ArrayList<>();
        for (Object o : Json.lista(m, campo)) {
            Map<String, Object> x = Json.obj(o);
            if (x != null)
                l.add(x);
        }
        return l;
    }

    static Map<String, Object> novoMapa() {
        return new LinkedHashMap<>();
    }
}
