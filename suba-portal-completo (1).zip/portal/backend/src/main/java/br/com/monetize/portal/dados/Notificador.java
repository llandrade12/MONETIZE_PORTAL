package br.com.monetize.portal.dados;

import java.sql.SQLException;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

import br.com.monetize.portal.dados.Repositorio.AlunoLinha;
import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Texto;

/**
 * Entrega das notificações fora do portal.
 *
 * O portal (ou a rotina de lembretes) cria a notificação na caixa do aluno ("inbox") ou o alerta do
 * mentor ("inboxM"). No momento em que esse registro é gravado, o servidor decide os canais:
 * push para os aparelhos inscritos, e-mail e WhatsApp conforme as preferências do aluno e as
 * configurações do mentor. Cada mensagem externa vira um item em "fila" (o que o mentor vê em
 * Notificações > E-mail e WhatsApp) e, quando o envio é automático, uma linha na tabela "envio".
 */
public final class Notificador {

    private Notificador() {
    }

    private static final Pattern SO_PORTAL = Pattern.compile("somente|só no portal", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern EMAIL = Pattern.compile("e-?mail", Pattern.CASE_INSENSITIVE);
    private static final Pattern WHATS = Pattern.compile("whats", Pattern.CASE_INSENSITIVE);
    /** Nome da marca na assinatura das mensagens (o mesmo de BRAND.nome no portal). */
    public static final String MARCA = "Monetize";

    /** Texto da mensagem como vai por e-mail em texto puro e por WhatsApp. */
    public static String texto(String nome, String assunto, String msg) {
        return "Olá, " + Texto.primeiroNome(nome) + ". " + assunto + ": " + msg + "\n\n" + MARCA + " · Área de Membros";
    }

    /** Notificação nova para um aluno: {id, aid, t (assunto), m (mensagem), go (página), canal, auto}. */
    static void aoCriarNotificacao(Gravador g, Map<String, Object> n) throws SQLException {
        if (n == null)
            return;
        long aid = Json.num(n, "aid", 0);
        AlunoLinha a = aid > 0 ? Repositorio.lerAluno(g.c, aid) : null;
        if (a == null)
            return;
        String assunto = Json.str(n, "t"), msg = Json.str(n, "m"), destino = Json.str(n, "go");
        boolean auto = Json.bool(n, "auto");
        g.efeitos.pushes.add(new Efeitos.Push(false, aid, assunto, msg, destino.isEmpty() ? "notificacoes" : destino));

        String canal = n.containsKey("canal") ? Json.str(n, "canal") : "e-mail + whatsapp";
        Map<String, Object> ficha = Json.lerObjeto(a.dados);
        boolean[] usar = canaisExternos(g, a, ficha, canal);
        if (usar[0])
            externa(g, aid, a.nome, "email", a.email, assunto, msg, destino, auto, "aluno");
        if (usar[1])
            externa(g, aid, a.nome, "whats", Json.str(ficha, "tel"), assunto, msg, destino, auto, "aluno");
    }

    /**
     * Canais externos que valem para este aluno e este pedido: [e-mail, WhatsApp].
     * Respeita o pedido ("somente no portal", "e-mail", "WhatsApp"), os canais ligados pelo mentor
     * e as preferências do próprio aluno.
     */
    public static boolean[] canaisExternos(Gravador g, AlunoLinha a, Map<String, Object> ficha, String canal) throws SQLException {
        boolean[] r = new boolean[2];
        if (a == null || canal == null || SO_PORTAL.matcher(canal).find())
            return r;
        Map<String, Object> pref = Json.obj(ficha, "canais");
        Map<String, Object> geral = Json.obj(g.cfg(), "canais");
        r[0] = EMAIL.matcher(canal).find() && Json.bool(geral, "email") && !desligado(pref, "email") && !Texto.vazio(a.email);
        r[1] = WHATS.matcher(canal).find() && Json.bool(geral, "whats") && !desligado(pref, "whats") && Texto.digitos(Json.str(ficha, "tel")).length() >= 10;
        return r;
    }

    /** Texto para o histórico de envios: "Portal", "Portal + e-mail", "Portal + e-mail + WhatsApp"... */
    public static String rotuloDosCanais(Gravador g, long alunoId, String canal) throws SQLException {
        AlunoLinha a = Repositorio.lerAluno(g.c, alunoId);
        boolean[] usar = a == null ? new boolean[2] : canaisExternos(g, a, Json.lerObjeto(a.dados), canal);
        return "Portal" + (usar[0] ? " + e-mail" : "") + (usar[1] ? " + WhatsApp" : "");
    }

    /** Alerta novo para o mentor: {id, t, m, go, arg, auto}. */
    static void aoCriarAlertaDoMentor(Gravador g, Map<String, Object> n) throws SQLException {
        if (n == null)
            return;
        String assunto = Json.str(n, "t"), msg = Json.str(n, "m");
        boolean auto = Json.bool(n, "auto");
        g.efeitos.pushes.add(new Efeitos.Push(true, 0, assunto, msg, Json.str(n, "go")));
        Map<String, Object> cfg = g.cfg();
        Map<String, Object> geral = Json.obj(cfg, "canais");
        String email = Json.str(cfg, "mentorEmail").trim(), tel = Json.str(cfg, "mentorTel");
        if (!email.isEmpty() && Json.bool(geral, "email"))
            externa(g, 0, g.nomeMentor(), "email", email, assunto, msg, "", auto, "mentor");
        if (Texto.digitos(tel).length() >= 10 && Json.bool(geral, "whats"))
            externa(g, 0, g.nomeMentor(), "whats", tel, assunto, msg, "", auto, "mentor");
    }

    private static boolean desligado(Map<String, Object> pref, String canal) {
        return pref != null && Boolean.FALSE.equals(pref.get(canal));
    }

    /**
     * Cria o item da fila e decide como ele sai:
     * e-mail pelo SMTP do servidor; sem SMTP, pelo webhook (se houver); WhatsApp pelo webhook.
     * Sem nenhum dos dois, o item fica como "manual": o mentor envia com um clique na tela.
     */
    private static void externa(Gravador g, long aid, String nome, String canal, String para, String assunto, String msg, String destino, boolean auto, String papel) throws SQLException {
        String webhook = Json.str(g.cfg(), "webhook").trim();
        boolean temWebhook = webhook.toLowerCase(Locale.ROOT).startsWith("https://");
        boolean smtp = canal.equals("email") && g.config.emailConfigurado();
        String id = g.novoId();
        String texto = texto(nome, assunto, msg);
        Map<String, Object> item = Json.mapa("id", id, "at", g.carimbo, "aid", aid, "nome", nome, "c", canal, "to", para,
                "ev", assunto, "txt", texto, "st", smtp || temWebhook ? "enviando" : "manual", "auto", auto);
        g.gravar("fila", id, item);
        if (smtp) {
            g.enfileirar(id, "email", para, nome, assunto, Json.mapa("nome", nome, "assunto", assunto, "msg", msg, "ir", destino, "papel", papel));
        } else if (temWebhook) {
            g.enfileirar(id, "webhook", webhook, nome, assunto, Json.mapa("canal", canal.equals("whats") ? "whatsapp" : "email",
                    "para", canal.equals("whats") ? Texto.digitos(para) : para, "nome", nome, "assunto", assunto, "mensagem", texto, "automatico", auto));
        }
    }
}
