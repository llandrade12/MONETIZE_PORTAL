package br.com.monetize.portal.servicos;

import java.time.LocalDateTime;
import java.util.List;

import br.com.monetize.portal.auth.Sessoes;
import br.com.monetize.portal.auth.Usuario;
import br.com.monetize.portal.dados.Estado;
import br.com.monetize.portal.dados.Repositorio;
import br.com.monetize.portal.dados.Repositorio.Reg;
import br.com.monetize.portal.dados.Sincronizador;
import br.com.monetize.portal.db.Banco;
import br.com.monetize.portal.util.Log;

/** Faxina periódica: o que venceu ou já não serve sai do banco, para ele não crescer sem necessidade. */
public final class Manutencao {

    /** Quantos registros manter nas listas de histórico (os mais antigos saem). */
    private static final Object[][] LIMITES = { { "fila", 400 }, { "notif", 300 }, { "log", 500 }, { "inboxM", 200 } };
    private static final int NOTIFICACOES_POR_ALUNO = 200;
    private static final int DIAS_DE_MARCAS = 30;

    private final Banco banco;
    private final Sincronizador sinc;
    private final Sessoes sessoes;
    private final Envios envios;
    private final Lembretes lembretes;

    public Manutencao(Banco banco, Sincronizador sinc, Sessoes sessoes, Envios envios, Lembretes lembretes) {
        this.banco = banco;
        this.sinc = sinc;
        this.sessoes = sessoes;
        this.envios = envios;
        this.lembretes = lembretes;
    }

    public void rodar() {
        try {
            sessoes.limparExpiradas();
            envios.limparAntigos();
            lembretes.limparAntigos(banco);
            historicos();
            marcasDeExclusao();
        } catch (RuntimeException e) {
            Log.erro("Falha na faxina periódica (tenta de novo no próximo ciclo)", e);
        }
    }

    /** Mantém só os registros mais recentes das listas de histórico. */
    private void historicos() {
        sinc.gravar(Usuario.sistema(), g -> {
            for (Object[] lim : LIMITES) {
                List<Reg> l = Repositorio.vivosDe(g.c, (String) lim[0]);
                for (int i = 0; i < l.size() - (Integer) lim[1]; i++)
                    g.apagar((String) lim[0], l.get(i).chave);
            }
            /* Caixa de notificações: as mais antigas de cada aluno, além do limite. */
            List<Long> cheios = Banco.consultar(g.c, "SELECT aluno_id FROM registro WHERE colecao = 'inbox' AND apagado = 0 AND aluno_id IS NOT NULL GROUP BY aluno_id HAVING COUNT(*) > " + NOTIFICACOES_POR_ALUNO,
                    r -> r.getLong(1));
            for (Long aid : cheios) {
                List<String> chaves = Banco.consultar(g.c, "SELECT chave FROM registro WHERE colecao = 'inbox' AND apagado = 0 AND aluno_id = ? ORDER BY seq", r -> r.getString(1), aid);
                for (int i = 0; i < chaves.size() - NOTIFICACOES_POR_ALUNO; i++)
                    g.apagar("inbox", chaves.get(i));
            }
            return null;
        });
    }

    /**
     * Registros excluídos ficam marcados por 30 dias, para os aparelhos abertos saberem que saíram.
     * Depois disso a marca é removida; um aparelho que ficou mais tempo sem conferir baixa tudo de novo.
     */
    private void marcasDeExclusao() {
        LocalDateTime corte = sinc.agora().minusDays(DIAS_DE_MARCAS);
        banco.transacao(c -> {
            Long maior = Banco.um(c, "SELECT MAX(rev) FROM registro WHERE apagado = 1 AND atualizado_em < ?", r -> Banco.longOuNulo(r, 1), corte);
            if (maior == null)
                return null;
            if (maior > Estado.purga(c)) {
                Banco.executar(c, "DELETE FROM parametro WHERE nome = ?", Estado.PARAM_PURGA);
                Banco.executar(c, "INSERT INTO parametro (nome, valor) VALUES (?, ?)", Estado.PARAM_PURGA, String.valueOf(maior));
            }
            return Banco.executar(c, "DELETE FROM registro WHERE apagado = 1 AND atualizado_em < ?", corte);
        });
    }
}
