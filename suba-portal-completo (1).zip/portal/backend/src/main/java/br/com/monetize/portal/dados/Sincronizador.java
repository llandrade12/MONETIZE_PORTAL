package br.com.monetize.portal.dados;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import br.com.monetize.portal.Config;
import br.com.monetize.portal.auth.Usuario;
import br.com.monetize.portal.db.Banco;
import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Log;

/**
 * Porta de entrada de todas as gravações nos registros do portal.
 *
 * Uma gravação por vez: cada uma recebe um número de alteração maior que a anterior e é confirmada
 * no banco antes de a próxima começar. É isso que permite ao portal perguntar "o que mudou depois
 * da alteração N?" sem perder nada.
 */
public final class Sincronizador {

    /** Trabalho feito dentro de uma gravação. */
    public interface Tarefa<T> {
        T com(Gravador g) throws SQLException;
    }

    /** Chamado depois que a gravação foi confirmada (enviar push, acordar a fila de e-mail). */
    public interface AposGravar {
        void depois(Efeitos efeitos);
    }

    /** Resposta de uma sincronização vinda do portal. */
    public static final class Resultado {
        public long rev;
        /** Registros que o servidor guardou diferente do que foi pedido (trechos JSON prontos). */
        public final List<String> eco = new ArrayList<>();
        /** Operações recusadas: {i: posição na lista, motivo}. */
        public final List<Map<String, Object>> recusadas = new ArrayList<>();
    }

    public static final int OPERACOES_MAX = 3000;

    private final Banco banco;
    private final Config config;
    private final ZoneId fuso;
    private final Object trava = new Object();
    private volatile AposGravar apos = e -> {
    };

    public Sincronizador(Banco banco, Config config) {
        this.banco = banco;
        this.config = config;
        this.fuso = config.fuso();
    }

    public void aposGravar(AposGravar a) {
        this.apos = a;
    }

    public LocalDateTime agora() {
        return LocalDateTime.now(fuso);
    }

    /** Executa uma gravação (tudo ou nada) e dispara os efeitos depois de confirmada. */
    public <T> T gravar(Usuario u, Tarefa<T> tarefa) {
        final Efeitos[] efeitos = new Efeitos[1];
        T r;
        synchronized (trava) {
            r = banco.transacao(c -> {
                Gravador g = new Gravador(c, u, Repositorio.proximaRev(c), agora(), config);
                efeitos[0] = g.efeitos;
                return tarefa.com(g);
            });
        }
        if (efeitos[0] != null) {
            try {
                apos.depois(efeitos[0]);
            } catch (RuntimeException e) {
                Log.erro("Falha ao disparar os efeitos de uma gravação", e);
            }
        }
        return r;
    }

    /** Aplica as operações enviadas pelo portal, conferindo as permissões de quem enviou. */
    public Resultado aplicar(Usuario u, List<Object> ops) {
        return gravar(u, g -> {
            Resultado res = new Resultado();
            res.rev = g.rev;
            for (int i = 0; i < ops.size(); i++) {
                Map<String, Object> op = Json.obj(ops.get(i));
                try {
                    if (op == null)
                        throw new Recusa("formato");
                    String eco = g.aplicar(op);
                    if (eco != null)
                        res.eco.add(eco);
                } catch (Recusa x) {
                    res.recusadas.add(Json.mapa("i", (long) i, "motivo", x.motivo));
                    Log.depurar("Operação recusada (" + x.motivo + ") de " + u + ": " + (op == null ? "?" : Json.str(op, "c") + "/" + Json.str(op, "k")));
                }
            }
            return res;
        });
    }
}
