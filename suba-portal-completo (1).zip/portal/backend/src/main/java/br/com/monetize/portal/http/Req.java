package br.com.monetize.portal.http;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.GZIPOutputStream;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;

import br.com.monetize.portal.auth.Usuario;
import br.com.monetize.portal.util.Json;

/** Uma requisição HTTP e os atalhos para respondê-la. */
public final class Req {

    public final HttpExchange x;
    public final String metodo;
    /** Caminho já decodificado, sem a parte depois de "?". */
    public final String caminho;
    private final Map<String, String> query = new HashMap<>();
    private final boolean confiarNoProxy;
    /** Quem está logado (null em rotas públicas ou sem sessão). */
    public Usuario usuario;
    /** Código da sessão recebido no cookie (para o logout). */
    public String tokenSessao;
    /** Trecho variável do caminho, nas rotas com parâmetro (ex.: o id em /api/arquivos/{id}). */
    public String parametro = "";
    private boolean respondeu;
    int statusEnviado;

    Req(HttpExchange x, boolean confiarNoProxy) {
        this.x = x;
        this.confiarNoProxy = confiarNoProxy;
        this.metodo = x.getRequestMethod().toUpperCase(Locale.ROOT);
        String bruto = x.getRequestURI().getRawPath();
        String c;
        try {
            c = URLDecoder.decode(bruto == null ? "/" : bruto.replace("+", "%2B"), StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            c = "/";
        }
        this.caminho = c;
        String q = x.getRequestURI().getRawQuery();
        if (q != null) {
            for (String par : q.split("&")) {
                int i = par.indexOf('=');
                try {
                    String k = URLDecoder.decode(i < 0 ? par : par.substring(0, i), StandardCharsets.UTF_8);
                    String v = i < 0 ? "" : URLDecoder.decode(par.substring(i + 1), StandardCharsets.UTF_8);
                    query.put(k, v);
                } catch (IllegalArgumentException e) {
                    /* parâmetro malformado: ignora */
                }
            }
        }
    }

    public boolean respondeu() {
        return respondeu;
    }

    /* ---------- entrada ---------- */

    public String q(String nome) {
        String v = query.get(nome);
        return v == null ? "" : v;
    }

    public long qLong(String nome, long padrao) {
        try {
            return Long.parseLong(q(nome).trim());
        } catch (NumberFormatException e) {
            return padrao;
        }
    }

    public String cabecalho(String nome) {
        String v = x.getRequestHeaders().getFirst(nome);
        return v == null ? "" : v;
    }

    public String cookie(String nome) {
        List<String> l = x.getRequestHeaders().get("Cookie");
        if (l == null)
            return null;
        for (String linha : l) {
            for (String par : linha.split(";")) {
                int i = par.indexOf('=');
                if (i > 0 && par.substring(0, i).trim().equals(nome))
                    return par.substring(i + 1).trim();
            }
        }
        return null;
    }

    /** Endereço de quem fez a requisição (o do proxy repassa em X-Forwarded-For). */
    public String ip() {
        if (confiarNoProxy) {
            String f = cabecalho("X-Forwarded-For");
            if (!f.isEmpty()) {
                String primeiro = f.split(",")[0].trim();
                if (!primeiro.isEmpty() && primeiro.length() <= 64)
                    return primeiro;
            }
            String r = cabecalho("X-Real-IP");
            if (!r.isEmpty() && r.length() <= 64)
                return r.trim();
        }
        return x.getRemoteAddress() == null || x.getRemoteAddress().getAddress() == null ? "?" : x.getRemoteAddress().getAddress().getHostAddress();
    }

    /** Corpo da requisição, com limite de tamanho. */
    public byte[] corpo(long maximo) throws IOException {
        String tam = cabecalho("Content-Length");
        if (!tam.isEmpty()) {
            try {
                if (Long.parseLong(tam.trim()) > maximo)
                    throw new ErroHttp(413, "grande-demais", "O conteúdo enviado é maior do que o permitido");
            } catch (NumberFormatException e) {
                throw ErroHttp.pedidoInvalido("Content-Length inválido");
            }
        }
        try (InputStream in = x.getRequestBody()) {
            ByteArrayOutputStream b = new ByteArrayOutputStream(4096);
            byte[] buf = new byte[8192];
            long total = 0;
            int n;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > maximo)
                    throw new ErroHttp(413, "grande-demais", "O conteúdo enviado é maior do que o permitido");
                b.write(buf, 0, n);
            }
            return b.toByteArray();
        }
    }

    public Map<String, Object> json(int maximo) throws IOException {
        byte[] b = corpo(maximo);
        if (b.length == 0)
            return new HashMap<>();
        try {
            return Json.lerObjeto(new String(b, StandardCharsets.UTF_8));
        } catch (Json.JsonException e) {
            throw ErroHttp.pedidoInvalido("JSON inválido");
        }
    }

    /* ---------- saída ---------- */

    public Headers saida() {
        return x.getResponseHeaders();
    }

    public void json(int status, String json) throws IOException {
        saida().set("Cache-Control", "no-store");
        bytes(status, "application/json; charset=utf-8", json.getBytes(StandardCharsets.UTF_8), true);
    }

    public void json(String json) throws IOException {
        json(200, json);
    }

    public void json(Map<String, Object> m) throws IOException {
        json(200, Json.texto(m));
    }

    public void ok() throws IOException {
        json(200, "{\"ok\":true}");
    }

    public void texto(int status, String tipo, String texto) throws IOException {
        bytes(status, tipo, texto.getBytes(StandardCharsets.UTF_8), true);
    }

    /** Envia a resposta. comprimir = usa gzip quando o navegador aceita e o conteúdo é grande o bastante. */
    public void bytes(int status, String tipo, byte[] dados, boolean comprimir) throws IOException {
        if (respondeu)
            return;
        respondeu = true;
        statusEnviado = status;
        if (tipo != null)
            saida().set("Content-Type", tipo);
        byte[] corpo = dados;
        if (comprimir && dados.length > 1024 && cabecalho("Accept-Encoding").toLowerCase(Locale.ROOT).contains("gzip")) {
            ByteArrayOutputStream b = new ByteArrayOutputStream(dados.length / 3 + 64);
            try (GZIPOutputStream g = new GZIPOutputStream(b)) {
                g.write(dados);
            }
            corpo = b.toByteArray();
            saida().set("Content-Encoding", "gzip");
            saida().add("Vary", "Accept-Encoding");
        }
        boolean semCorpo = metodo.equals("HEAD") || status == 204 || status == 304;
        if (semCorpo) {
            if (status != 204 && status != 304)
                saida().set("Content-Length", String.valueOf(corpo.length));
            x.sendResponseHeaders(status, -1);
        } else {
            x.sendResponseHeaders(status, corpo.length == 0 ? -1 : corpo.length);
            if (corpo.length > 0) {
                try (OutputStream out = x.getResponseBody()) {
                    out.write(corpo);
                }
            }
        }
    }

    /** Resposta enviada aos poucos (download de arquivo): devolve o fluxo onde escrever o corpo. */
    public OutputStream corpoDireto(int status, long tamanho) throws IOException {
        respondeu = true;
        statusEnviado = status;
        x.sendResponseHeaders(status, tamanho <= 0 ? -1 : tamanho);
        return x.getResponseBody();
    }

    public void vazio(int status) throws IOException {
        if (respondeu)
            return;
        respondeu = true;
        statusEnviado = status;
        x.sendResponseHeaders(status, -1);
    }

    public void erro(int status, String codigo, String mensagem) throws IOException {
        json(status, Json.texto(Json.mapa("erro", codigo, "msg", mensagem)));
    }

    public void redirecionar(String para) throws IOException {
        saida().set("Location", para);
        vazio(302);
    }
}
