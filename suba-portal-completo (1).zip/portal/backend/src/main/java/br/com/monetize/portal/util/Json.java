package br.com.monetize.portal.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * JSON sem dependências externas.
 *
 * Tipos usados na leitura: objeto = LinkedHashMap (mantém a ordem das chaves), lista = ArrayList,
 * texto = String, inteiro = Long, decimal = BigDecimal (preserva o valor exato enviado pelo portal),
 * booleano = Boolean e null.
 */
public final class Json {

    private Json() {
    }

    /** Erro de leitura: o texto recebido não é JSON válido. */
    public static final class JsonException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        public JsonException(String msg) {
            super(msg);
        }
    }

    /* ---------------------------------------------------------------- leitura */

    public static Object ler(String texto) {
        if (texto == null)
            throw new JsonException("JSON vazio");
        Leitor l = new Leitor(texto);
        l.espacos();
        Object v = l.valor(0);
        l.espacos();
        if (l.i < l.s.length())
            throw l.erro("conteúdo depois do fim do JSON");
        return v;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> lerObjeto(String texto) {
        Object o = ler(texto);
        if (!(o instanceof Map))
            throw new JsonException("Era esperado um objeto JSON");
        return (Map<String, Object>) o;
    }

    private static final class Leitor {
        private static final int PROFUNDIDADE_MAXIMA = 64;
        final String s;
        int i;

        Leitor(String s) {
            this.s = s;
        }

        JsonException erro(String m) {
            return new JsonException("JSON inválido na posição " + i + ": " + m);
        }

        void espacos() {
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == ' ' || c == '\n' || c == '\r' || c == '\t')
                    i++;
                else
                    break;
            }
        }

        Object valor(int nivel) {
            if (nivel > PROFUNDIDADE_MAXIMA)
                throw erro("estrutura profunda demais");
            if (i >= s.length())
                throw erro("fim inesperado");
            char c = s.charAt(i);
            switch (c) {
                case '{':
                    return objeto(nivel);
                case '[':
                    return lista(nivel);
                case '"':
                    return texto();
                case 't':
                    literal("true");
                    return Boolean.TRUE;
                case 'f':
                    literal("false");
                    return Boolean.FALSE;
                case 'n':
                    literal("null");
                    return null;
                default:
                    if (c == '-' || (c >= '0' && c <= '9'))
                        return numero();
                    throw erro("caractere inesperado '" + c + "'");
            }
        }

        void literal(String l) {
            if (!s.startsWith(l, i))
                throw erro("literal desconhecido");
            i += l.length();
        }

        Map<String, Object> objeto(int nivel) {
            Map<String, Object> m = new LinkedHashMap<>();
            i++;
            espacos();
            if (i < s.length() && s.charAt(i) == '}') {
                i++;
                return m;
            }
            while (true) {
                espacos();
                if (i >= s.length() || s.charAt(i) != '"')
                    throw erro("era esperada uma chave entre aspas");
                String k = texto();
                espacos();
                if (i >= s.length() || s.charAt(i) != ':')
                    throw erro("era esperado ':'");
                i++;
                espacos();
                m.put(k, valor(nivel + 1));
                espacos();
                if (i >= s.length())
                    throw erro("objeto sem fim");
                char c = s.charAt(i++);
                if (c == '}')
                    return m;
                if (c != ',')
                    throw erro("era esperado ',' ou '}'");
            }
        }

        List<Object> lista(int nivel) {
            List<Object> l = new ArrayList<>();
            i++;
            espacos();
            if (i < s.length() && s.charAt(i) == ']') {
                i++;
                return l;
            }
            while (true) {
                espacos();
                l.add(valor(nivel + 1));
                espacos();
                if (i >= s.length())
                    throw erro("lista sem fim");
                char c = s.charAt(i++);
                if (c == ']')
                    return l;
                if (c != ',')
                    throw erro("era esperado ',' ou ']'");
            }
        }

        String texto() {
            i++;
            StringBuilder b = null;
            int ini = i;
            while (true) {
                if (i >= s.length())
                    throw erro("texto sem fim");
                char c = s.charAt(i);
                if (c == '"') {
                    String r = b == null ? s.substring(ini, i) : b.append(s, ini, i).toString();
                    i++;
                    return r;
                }
                if (c < 0x20)
                    throw erro("caractere de controle dentro de texto");
                if (c == '\\') {
                    if (b == null)
                        b = new StringBuilder();
                    b.append(s, ini, i);
                    i++;
                    if (i >= s.length())
                        throw erro("escape sem fim");
                    char e = s.charAt(i++);
                    switch (e) {
                        case '"':
                            b.append('"');
                            break;
                        case '\\':
                            b.append('\\');
                            break;
                        case '/':
                            b.append('/');
                            break;
                        case 'b':
                            b.append('\b');
                            break;
                        case 'f':
                            b.append('\f');
                            break;
                        case 'n':
                            b.append('\n');
                            break;
                        case 'r':
                            b.append('\r');
                            break;
                        case 't':
                            b.append('\t');
                            break;
                        case 'u':
                            if (i + 4 > s.length())
                                throw erro("escape \\u incompleto");
                            int cp = 0;
                            for (int k = 0; k < 4; k++) {
                                int d = Character.digit(s.charAt(i + k), 16);
                                if (d < 0)
                                    throw erro("escape \\u inválido");
                                cp = cp * 16 + d;
                            }
                            b.append((char) cp);
                            i += 4;
                            break;
                        default:
                            throw erro("escape desconhecido");
                    }
                    ini = i;
                } else
                    i++;
            }
        }

        Object numero() {
            int ini = i;
            boolean decimal = false;
            if (s.charAt(i) == '-')
                i++;
            if (i >= s.length())
                throw erro("número incompleto");
            if (s.charAt(i) == '0')
                i++;
            else if (s.charAt(i) >= '1' && s.charAt(i) <= '9')
                while (i < s.length() && s.charAt(i) >= '0' && s.charAt(i) <= '9')
                    i++;
            else
                throw erro("número inválido");
            if (i < s.length() && s.charAt(i) == '.') {
                decimal = true;
                i++;
                int d = i;
                while (i < s.length() && s.charAt(i) >= '0' && s.charAt(i) <= '9')
                    i++;
                if (d == i)
                    throw erro("número inválido");
            }
            if (i < s.length() && (s.charAt(i) == 'e' || s.charAt(i) == 'E')) {
                decimal = true;
                i++;
                if (i < s.length() && (s.charAt(i) == '+' || s.charAt(i) == '-'))
                    i++;
                int d = i;
                while (i < s.length() && s.charAt(i) >= '0' && s.charAt(i) <= '9')
                    i++;
                if (d == i)
                    throw erro("número inválido");
            }
            String t = s.substring(ini, i);
            if (!decimal && t.length() <= 18)
                return Long.valueOf(t);
            if (t.length() > 400)
                throw erro("número grande demais");
            BigDecimal bd = new BigDecimal(t);
            /* Expoentes absurdos (1e999999999) custariam memória e tempo em qualquer conta feita com o valor. */
            if (Math.abs((long) bd.scale()) > 400)
                throw erro("número grande demais");
            if (!decimal) {
                try {
                    return bd.longValueExact();
                } catch (ArithmeticException ex) {
                    return bd;
                }
            }
            return bd;
        }
    }

    /* ---------------------------------------------------------------- escrita */

    public static String texto(Object o) {
        StringBuilder b = new StringBuilder(256);
        escrever(b, o);
        return b.toString();
    }

    public static void escrever(StringBuilder b, Object o) {
        if (o == null) {
            b.append("null");
        } else if (o instanceof String) {
            aspas(b, (String) o);
        } else if (o instanceof Boolean) {
            b.append(((Boolean) o).booleanValue() ? "true" : "false");
        } else if (o instanceof BigDecimal) {
            BigDecimal d = (BigDecimal) o;
            b.append(Math.abs(d.scale()) > 60 ? d.toString() : d.toPlainString());
        } else if (o instanceof Long || o instanceof Integer || o instanceof Short || o instanceof Byte || o instanceof BigInteger) {
            b.append(o.toString());
        } else if (o instanceof Number) {
            double d = ((Number) o).doubleValue();
            if (Double.isNaN(d) || Double.isInfinite(d))
                b.append("null");
            else if (d == Math.rint(d) && Math.abs(d) < 1e15)
                b.append((long) d);
            else
                b.append(new BigDecimal(Double.toString(d)).toPlainString());
        } else if (o instanceof Map) {
            b.append('{');
            boolean primeiro = true;
            for (Map.Entry<?, ?> e : ((Map<?, ?>) o).entrySet()) {
                if (!primeiro)
                    b.append(',');
                primeiro = false;
                aspas(b, String.valueOf(e.getKey()));
                b.append(':');
                escrever(b, e.getValue());
            }
            b.append('}');
        } else if (o instanceof Iterable) {
            b.append('[');
            boolean primeiro = true;
            for (Object x : (Iterable<?>) o) {
                if (!primeiro)
                    b.append(',');
                primeiro = false;
                escrever(b, x);
            }
            b.append(']');
        } else if (o instanceof Object[]) {
            b.append('[');
            Object[] a = (Object[]) o;
            for (int k = 0; k < a.length; k++) {
                if (k > 0)
                    b.append(',');
                escrever(b, a[k]);
            }
            b.append(']');
        } else if (o instanceof Cru) {
            b.append(((Cru) o).json);
        } else {
            aspas(b, o.toString());
        }
    }

    /**
     * Texto entre aspas. Caracteres fora do plano básico (emoji) saem como \\uXXXX, para o JSON guardado
     * no banco não depender de a conexão estar em utf8mb4.
     */
    public static void aspas(StringBuilder b, String s) {
        b.append('"');
        for (int k = 0; k < s.length(); k++) {
            char c = s.charAt(k);
            switch (c) {
                case '"':
                    b.append("\\\"");
                    break;
                case '\\':
                    b.append("\\\\");
                    break;
                case '\n':
                    b.append("\\n");
                    break;
                case '\r':
                    b.append("\\r");
                    break;
                case '\t':
                    b.append("\\t");
                    break;
                case '\b':
                    b.append("\\b");
                    break;
                case '\f':
                    b.append("\\f");
                    break;
                default:
                    if (c < 0x20 || c == 0x2028 || c == 0x2029 || Character.isSurrogate(c) || c == 0x7f) {
                        b.append("\\u");
                        String h = Integer.toHexString(c);
                        for (int z = h.length(); z < 4; z++)
                            b.append('0');
                        b.append(h);
                    } else
                        b.append(c);
            }
        }
        b.append('"');
    }

    /** JSON já pronto (vindo do banco), inserido sem reprocessar. */
    public static final class Cru {
        final String json;

        public Cru(String json) {
            this.json = json;
        }

        @Override
        public String toString() {
            return json;
        }
    }

    /* ---------------------------------------------------------------- acesso */

    @SuppressWarnings("unchecked")
    public static Map<String, Object> obj(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : null;
    }

    @SuppressWarnings("unchecked")
    public static List<Object> lista(Object o) {
        return o instanceof List ? (List<Object>) o : null;
    }

    /** Lista do campo (vazia quando o campo não existe ou não é lista). */
    public static List<Object> lista(Map<String, Object> m, String campo) {
        List<Object> l = m == null ? null : lista(m.get(campo));
        return l == null ? new ArrayList<>() : l;
    }

    public static Map<String, Object> obj(Map<String, Object> m, String campo) {
        return m == null ? null : obj(m.get(campo));
    }

    public static String str(Map<String, Object> m, String campo) {
        Object v = m == null ? null : m.get(campo);
        if (v == null)
            return "";
        if (v instanceof String)
            return (String) v;
        if (v instanceof BigDecimal)
            return ((BigDecimal) v).toPlainString();
        return v instanceof Map || v instanceof List ? texto(v) : String.valueOf(v);
    }

    public static boolean bool(Map<String, Object> m, String campo) {
        return verdadeiro(m == null ? null : m.get(campo));
    }

    /** Mesma regra de "verdadeiro" do JavaScript, que é como o portal testa os campos. */
    public static boolean verdadeiro(Object v) {
        if (v == null)
            return false;
        if (v instanceof Boolean)
            return (Boolean) v;
        if (v instanceof String)
            return !((String) v).isEmpty();
        if (v instanceof Number)
            return ((Number) v).doubleValue() != 0 && !Double.isNaN(((Number) v).doubleValue());
        return true;
    }

    public static long num(Map<String, Object> m, String campo, long padrao) {
        return num(m == null ? null : m.get(campo), padrao);
    }

    public static long num(Object v, long padrao) {
        if (v instanceof Number)
            return ((Number) v).longValue();
        if (v instanceof String) {
            try {
                return new BigDecimal(((String) v).trim()).longValue();
            } catch (RuntimeException e) {
                return padrao;
            }
        }
        return padrao;
    }

    public static double dec(Object v, double padrao) {
        if (v instanceof Number)
            return ((Number) v).doubleValue();
        if (v instanceof String) {
            try {
                return Double.parseDouble(((String) v).trim().replace(',', '.'));
            } catch (RuntimeException e) {
                return padrao;
            }
        }
        return padrao;
    }

    /** Cópia profunda de uma árvore lida por {@link #ler}. */
    public static Object copia(Object o) {
        if (o instanceof Map) {
            Map<String, Object> m = new LinkedHashMap<>();
            for (Map.Entry<?, ?> e : ((Map<?, ?>) o).entrySet())
                m.put(String.valueOf(e.getKey()), copia(e.getValue()));
            return m;
        }
        if (o instanceof List) {
            List<Object> l = new ArrayList<>();
            for (Object x : (List<?>) o)
                l.add(copia(x));
            return l;
        }
        return o;
    }

    /** Dois valores são o mesmo JSON? A ordem das chaves de um objeto não importa; 1 e 1.0 são o mesmo número. */
    public static boolean igual(Object a, Object b) {
        if (a == b)
            return true;
        if (a == null || b == null)
            return false;
        if (a instanceof Map && b instanceof Map) {
            Map<?, ?> ma = (Map<?, ?>) a, mb = (Map<?, ?>) b;
            if (ma.size() != mb.size())
                return false;
            for (Map.Entry<?, ?> e : ma.entrySet()) {
                if (!mb.containsKey(e.getKey()) || !igual(e.getValue(), mb.get(e.getKey())))
                    return false;
            }
            return true;
        }
        if (a instanceof List && b instanceof List) {
            List<?> la = (List<?>) a, lb = (List<?>) b;
            if (la.size() != lb.size())
                return false;
            for (int k = 0; k < la.size(); k++)
                if (!igual(la.get(k), lb.get(k)))
                    return false;
            return true;
        }
        if (a instanceof Number && b instanceof Number) {
            try {
                return new BigDecimal(a.toString()).compareTo(new BigDecimal(b.toString())) == 0;
            } catch (NumberFormatException e) {
                return a.equals(b);
            }
        }
        return a.equals(b);
    }

    /** Atalho para montar objetos: mapa("a", 1, "b", "x"). */
    public static Map<String, Object> mapa(Object... pares) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (int k = 0; k + 1 < pares.length; k += 2)
            m.put(String.valueOf(pares[k]), pares[k + 1]);
        return m;
    }
}
