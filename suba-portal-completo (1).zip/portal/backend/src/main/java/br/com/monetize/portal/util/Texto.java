package br.com.monetize.portal.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.Base64;

/** Funções de texto, datas e identificadores, com os mesmos formatos que o portal usa na tela. */
public final class Texto {

    private Texto() {
    }

    private static final SecureRandom ALEATORIO = new SecureRandom();
    private static final DateTimeFormatter CARIMBO = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private static final String[] MES = { "jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez" };
    private static final String[] DOW = { "dom", "seg", "ter", "qua", "qui", "sex", "sáb" };

    public static boolean vazio(String s) {
        return s == null || s.trim().isEmpty();
    }

    public static String ou(String s, String padrao) {
        return vazio(s) ? padrao : s;
    }

    public static String cortar(String s, int max) {
        if (s == null)
            return null;
        return s.length() <= max ? s : s.substring(0, max);
    }

    /** Só os dígitos (telefones). */
    public static String digitos(String s) {
        return s == null ? "" : s.replaceAll("\\D", "");
    }

    public static String primeiroNome(String nome) {
        String n = nome == null ? "" : nome.trim();
        int i = n.indexOf(' ');
        return i < 0 ? n : n.substring(0, i);
    }

    /** Remove caracteres fora do plano básico (emoji), para colunas de texto comuns do banco. */
    public static String semEmoji(String s) {
        if (s == null)
            return null;
        StringBuilder b = null;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isSurrogate(c)) {
                if (b == null)
                    b = new StringBuilder(s.length()).append(s, 0, i);
            } else if (b != null)
                b.append(c);
        }
        return b == null ? s : b.toString();
    }

    /* ---------- identificadores e segredos ---------- */

    /** Identificador curto, no mesmo formato que o portal gera no navegador. */
    public static String uid() {
        return Long.toString(System.currentTimeMillis(), 36) + Integer.toString(0x100000 + ALEATORIO.nextInt(0xEFFFFF), 36).substring(0, 4);
    }

    /** Segredo aleatório para cookies, links de redefinição e endereço da agenda (base64 sem símbolos). */
    public static String segredo(int bytes) {
        byte[] b = new byte[bytes];
        ALEATORIO.nextBytes(b);
        return b64url(b);
    }

    public static byte[] aleatorio(int bytes) {
        byte[] b = new byte[bytes];
        ALEATORIO.nextBytes(b);
        return b;
    }

    public static String b64url(byte[] b) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(b);
    }

    public static byte[] deB64url(String s) {
        String t = s.trim().replace('+', '-').replace('/', '_').replace("=", "");
        return Base64.getUrlDecoder().decode(t);
    }

    public static byte[] sha256(byte[] dados) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(dados);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    public static String sha256Hex(String s) {
        return hex(sha256(s.getBytes(StandardCharsets.UTF_8)));
    }

    public static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) {
            sb.append(Character.forDigit((x >> 4) & 0xF, 16));
            sb.append(Character.forDigit(x & 0xF, 16));
        }
        return sb.toString();
    }

    /** Comparação em tempo constante (evita medir o tempo para adivinhar segredos). */
    public static boolean igualSeguro(String a, String b) {
        if (a == null || b == null)
            return false;
        return MessageDigest.isEqual(a.getBytes(StandardCharsets.UTF_8), b.getBytes(StandardCharsets.UTF_8));
    }

    /* ---------- datas (o portal guarda datas como "2026-03-15" e carimbos como "15/03/2026 20:30") ---------- */

    public static String carimbo(LocalDateTime agora) {
        return CARIMBO.format(agora);
    }

    public static LocalDate data(String iso) {
        if (iso == null || iso.length() < 10)
            return null;
        try {
            return LocalDate.parse(iso.substring(0, 10));
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    public static String iso(LocalDate d) {
        return d.toString();
    }

    /** Soma dias a uma data ISO (vazio quando a data é inválida). */
    public static String somaDias(String iso, int dias) {
        LocalDate d = data(iso);
        return d == null ? "" : d.plusDays(dias).toString();
    }

    /** Dias de a até b (a - b), como a função diff() do portal. Datas inválidas contam como 0. */
    public static int dias(String a, String b) {
        LocalDate da = data(a), db = data(b);
        if (da == null || db == null)
            return 0;
        return (int) ChronoUnit.DAYS.between(db, da);
    }

    /** "15/03" */
    public static String df(String iso) {
        LocalDate d = data(iso);
        return d == null ? "—" : doisDigitos(d.getDayOfMonth()) + "/" + doisDigitos(d.getMonthValue());
    }

    /** "15/03/2026" */
    public static String dfy(String iso) {
        LocalDate d = data(iso);
        return d == null ? "—" : df(iso) + "/" + d.getYear();
    }

    /** "dom, 15 de mar" */
    public static String dl(String iso) {
        LocalDate d = data(iso);
        if (d == null)
            return "—";
        int dow = d.getDayOfWeek() == DayOfWeek.SUNDAY ? 0 : d.getDayOfWeek().getValue();
        return DOW[dow] + ", " + d.getDayOfMonth() + " de " + MES[d.getMonthValue() - 1];
    }

    public static String doisDigitos(int n) {
        return n < 10 ? "0" + n : String.valueOf(n);
    }
}
