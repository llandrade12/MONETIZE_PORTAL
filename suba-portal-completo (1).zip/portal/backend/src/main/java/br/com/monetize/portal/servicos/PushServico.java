package br.com.monetize.portal.servicos;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.Duration;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import br.com.monetize.portal.Config;
import br.com.monetize.portal.auth.Usuario;
import br.com.monetize.portal.dados.Efeitos;
import br.com.monetize.portal.db.Banco;
import br.com.monetize.portal.http.ErroHttp;
import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Log;
import br.com.monetize.portal.util.Texto;

/**
 * Notificações push: guarda os aparelhos inscritos e entrega as mensagens aos serviços de push dos
 * navegadores (Google, Mozilla, Apple, Microsoft). O par de chaves do servidor (VAPID) é criado sozinho
 * na primeira execução e fica na tabela "parametro".
 */
public final class PushServico {

    /** Serviços de push aceitos. O servidor só envia para estes endereços. */
    private static final String[] SERVICOS = { ".googleapis.com", ".push.services.mozilla.com", ".notify.windows.com", ".push.apple.com" };

    private static final class Inscricao {
        long id;
        String endpoint, p256dh, auth;
    }

    private final Banco banco;
    private final Config config;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();
    private final ThreadPoolExecutor fila = new ThreadPoolExecutor(2, 2, 60, TimeUnit.SECONDS, new ArrayBlockingQueue<>(5000), r -> {
        Thread t = new Thread(r, "push");
        t.setDaemon(true);
        return t;
    });
    private PrivateKey privada;
    private byte[] publica;
    /** Só para os testes: aceita qualquer endereço https/http como serviço de push. */
    boolean aceitarQualquerServico;

    public PushServico(Banco banco, Config config) {
        this.banco = banco;
        this.config = config;
    }

    /** Carrega as chaves do servidor, criando-as na primeira vez. */
    public void preparar() {
        banco.transacao(c -> {
            String priv = parametro(c, "vapid_privada"), pub = parametro(c, "vapid_publica");
            try {
                if (priv == null || pub == null) {
                    KeyPair par = WebPush.novoPar();
                    priv = WebPush.privadaTexto(par.getPrivate());
                    pub = Texto.b64url(WebPush.pontoDe(par.getPublic()));
                    Banco.executar(c, "DELETE FROM parametro WHERE nome IN ('vapid_privada', 'vapid_publica')");
                    Banco.executar(c, "INSERT INTO parametro (nome, valor) VALUES ('vapid_privada', ?)", priv);
                    Banco.executar(c, "INSERT INTO parametro (nome, valor) VALUES ('vapid_publica', ?)", pub);
                    Log.info("Push: chaves do servidor criadas");
                }
                privada = WebPush.privadaDe(priv);
                publica = Texto.deB64url(pub);
            } catch (GeneralSecurityException e) {
                throw new IllegalStateException("Não foi possível preparar as chaves do push", e);
            }
            return null;
        });
    }

    private static String parametro(Connection c, String nome) throws SQLException {
        return Banco.um(c, "SELECT valor FROM parametro WHERE nome = ?", r -> r.getString(1), nome);
    }

    /** Chave pública do servidor, que o navegador usa para criar a inscrição. */
    public String chavePublica() {
        return Texto.b64url(publica);
    }

    public void parar() {
        fila.shutdownNow();
    }

    /* ---------------------------------------------------------------- inscrições */

    public void inscrever(Usuario u, String endpoint, String p256dh, String auth) {
        validarEndpoint(endpoint);
        try {
            if (Texto.deB64url(p256dh).length != 65 || Texto.deB64url(auth).length != 16)
                throw ErroHttp.pedidoInvalido("Chaves da inscrição em formato inesperado");
        } catch (IllegalArgumentException e) {
            throw ErroHttp.pedidoInvalido("Chaves da inscrição em formato inesperado");
        }
        String hash = Texto.sha256Hex(endpoint);
        banco.transacao(c -> {
            Banco.executar(c, "DELETE FROM push_inscricao WHERE endpoint_hash = ?", hash);
            Banco.executar(c, "INSERT INTO push_inscricao (mentor_id, aluno_id, endpoint_hash, endpoint, p256dh, auth, falhas, criado_em) VALUES (?, ?, ?, ?, ?, ?, 0, ?)",
                    u.mentor() ? u.id : null, u.aluno() ? u.id : null, hash, endpoint, p256dh, auth, java.time.LocalDateTime.now(config.fuso()));
            /* No máximo 10 aparelhos por pessoa: os mais antigos saem. */
            List<Long> ids = Banco.consultar(c, "SELECT id FROM push_inscricao WHERE " + (u.mentor() ? "mentor_id" : "aluno_id") + " = ? ORDER BY id DESC", r -> r.getLong(1), u.id);
            for (int i = 10; i < ids.size(); i++)
                Banco.executar(c, "DELETE FROM push_inscricao WHERE id = ?", ids.get(i));
            return null;
        });
    }

    public void remover(Usuario u, String endpoint) {
        if (endpoint == null || endpoint.isEmpty())
            return;
        banco.usar(c -> Banco.executar(c, "DELETE FROM push_inscricao WHERE endpoint_hash = ? AND " + (u.mentor() ? "mentor_id" : "aluno_id") + " = ?", Texto.sha256Hex(endpoint), u.id));
    }

    private void validarEndpoint(String endpoint) {
        URI u;
        try {
            u = URI.create(endpoint);
        } catch (RuntimeException e) {
            throw ErroHttp.pedidoInvalido("Endereço de push inválido");
        }
        if (endpoint.length() > 2000 || u.getHost() == null)
            throw ErroHttp.pedidoInvalido("Endereço de push inválido");
        if (aceitarQualquerServico)
            return;
        String host = u.getHost().toLowerCase(Locale.ROOT);
        boolean ok = "https".equalsIgnoreCase(u.getScheme());
        boolean conhecido = false;
        for (String s : SERVICOS)
            conhecido = conhecido || host.endsWith(s);
        if (!ok || !conhecido)
            throw ErroHttp.pedidoInvalido("Serviço de push não reconhecido");
    }

    /* ---------------------------------------------------------------- entrega */

    /** Entrega em segundo plano (não atrasa a resposta de quem gerou a notificação). */
    public void enviar(Efeitos.Push p) {
        try {
            fila.execute(() -> {
                try {
                    enviarAgora(p);
                } catch (RuntimeException e) {
                    Log.erro("Falha ao enviar push", e);
                }
            });
        } catch (RejectedExecutionException e) {
            Log.aviso("Fila de push cheia: notificação descartada (a pessoa ainda vê o aviso dentro do portal)");
        }
    }

    /** Entrega para todos os aparelhos do destinatário. Devolve quantos aceitaram. */
    public int enviarAgora(Efeitos.Push p) {
        List<Inscricao> l = banco.usar(c -> Banco.consultar(c,
                "SELECT id, endpoint, p256dh, auth FROM push_inscricao WHERE " + (p.paraMentores ? "mentor_id IS NOT NULL" : "aluno_id = ?"), r -> {
                    Inscricao i = new Inscricao();
                    i.id = r.getLong("id");
                    i.endpoint = r.getString("endpoint");
                    i.p256dh = r.getString("p256dh");
                    i.auth = r.getString("auth");
                    return i;
                }, p.paraMentores ? new Object[0] : new Object[] { p.alunoId }));
        if (l.isEmpty())
            return 0;
        String pagina = p.paraMentores ? "mentor.html" : "aluno.html";
        String url = config.urlPublica() + "/" + pagina + (p.destino != null && p.destino.matches("[A-Za-z]{1,30}") ? "#ir=" + p.destino : "");
        byte[] msg = Json.texto(Json.mapa("t", Texto.cortar(p.titulo, 120), "b", Texto.cortar(p.corpo, 300), "u", url)).getBytes(StandardCharsets.UTF_8);
        int ok = 0;
        for (Inscricao i : l) {
            int status = entregar(i, msg);
            if (status / 100 == 2) {
                ok++;
                banco.usar(c -> Banco.executar(c, "UPDATE push_inscricao SET falhas = 0 WHERE id = ? AND falhas > 0", i.id));
            } else if (status == 404 || status == 410 || status == 403) {
                /* O aparelho cancelou a inscrição (ou ela é de outra chave): não adianta insistir. */
                banco.usar(c -> Banco.executar(c, "DELETE FROM push_inscricao WHERE id = ?", i.id));
            } else {
                /* Falha passageira (serviço fora do ar, sem rede): conta a falha e desiste do aparelho depois de 15 seguidas. */
                banco.transacao(c -> {
                    Banco.executar(c, "UPDATE push_inscricao SET falhas = falhas + 1 WHERE id = ?", i.id);
                    return Banco.executar(c, "DELETE FROM push_inscricao WHERE id = ? AND falhas >= 15", i.id);
                });
            }
        }
        return ok;
    }

    /** Código HTTP devolvido pelo serviço de push (0 = não conseguiu conectar). */
    private int entregar(Inscricao i, byte[] msg) {
        try {
            byte[] corpo = WebPush.cifrar(msg, Texto.deB64url(i.p256dh), Texto.deB64url(i.auth));
            HttpRequest req = HttpRequest.newBuilder(URI.create(i.endpoint)).timeout(Duration.ofSeconds(20))
                    .header("TTL", "86400").header("Urgency", "normal").header("Content-Encoding", "aes128gcm").header("Content-Type", "application/octet-stream")
                    .header("Authorization", WebPush.vapid(i.endpoint, config.pushContato(), privada, publica, System.currentTimeMillis() / 1000))
                    .POST(HttpRequest.BodyPublishers.ofByteArray(corpo)).build();
            HttpResponse<String> r = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (r.statusCode() / 100 != 2)
                Log.depurar("Push recusado (" + r.statusCode() + "): " + Texto.cortar(r.body(), 200));
            return r.statusCode();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return 0;
        } catch (GeneralSecurityException | java.io.IOException | RuntimeException e) {
            Log.depurar("Push não entregue: " + e.getMessage());
            return 0;
        }
    }
}
