package br.com.monetize.portal.dados;

import java.util.ArrayList;
import java.util.List;

/** O que precisa acontecer depois que uma gravação é confirmada no banco (fora da transação). */
public final class Efeitos {

    /** Notificação push a enviar. */
    public static final class Push {
        public final boolean paraMentores;
        public final long alunoId;
        public final String titulo;
        public final String corpo;
        /** Página do portal que abre ao tocar na notificação (ex.: "tarefas"). */
        public final String destino;

        public Push(boolean paraMentores, long alunoId, String titulo, String corpo, String destino) {
            this.paraMentores = paraMentores;
            this.alunoId = alunoId;
            this.titulo = titulo;
            this.corpo = corpo;
            this.destino = destino;
        }
    }

    /** Algum registro foi de fato alterado? */
    public boolean mudou;
    /** Entraram mensagens novas na fila de envio (e-mail ou webhook)? */
    public boolean enviosNovos;
    public final List<Push> pushes = new ArrayList<>();
    /** Arquivos em disco a remover (caminhos relativos à pasta de arquivos). */
    public final List<String> arquivosRemovidos = new ArrayList<>();
}
