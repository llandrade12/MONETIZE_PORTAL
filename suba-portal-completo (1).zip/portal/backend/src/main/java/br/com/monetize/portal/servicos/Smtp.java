package br.com.monetize.portal.servicos;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.cert.X509Certificate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Envio de e-mail por SMTP, sem bibliotecas externas.
 *
 * Aceita os três modos usados pelos provedores: SSL direto (porta 465), STARTTLS (porta 587) e sem
 * criptografia (só para testes). Autentica com LOGIN ou PLAIN. A mensagem vai em UTF-8, com versão
 * em texto e em HTML.
 */
public final class Smtp {

    /** Um e-mail a enviar. */
    public static final class Mensagem {
        public String de;
        public String deNome;
        public String para;
        public String paraNome;
        public String assunto;
        public String texto;
        public String html;
    }

    /** O servidor de e-mail recusou ou não respondeu. definitivo = não adianta tentar de novo (ex.: endereço inexistente). */
    public static final class SmtpException extends IOException {
        private static final long serialVersionUID = 1L;
        public final boolean definitivo;

        public SmtpException(String m, boolean definitivo) {
            super(m);
            this.definitivo = definitivo;
        }
    }

    private static final DateTimeFormatter DATA = DateTimeFormatter.ofPattern("EEE, d MMM yyyy HH:mm:ss Z", Locale.ENGLISH);

    private final String host;
    private final int porta;
    private final String seguranca;
    private final String usuario;
    private final String senha;
    private final boolean verificarCertificado;
    private final String nomeLocal;
    private final int tempoMs;

    public Smtp(String host, int porta, String seguranca, String usuario, String senha, boolean verificarCertificado, String nomeLocal, int tempoMs) {
        this.host = host;
        this.porta = porta;
        this.seguranca = seguranca == null ? "" : seguranca.toLowerCase(Locale.ROOT);
        this.usuario = usuario == null ? "" : usuario;
        this.senha = senha == null ? "" : senha;
        this.verificarCertificado = verificarCertificado;
        this.nomeLocal = nomeLocal == null || !nomeLocal.matches("[A-Za-z0-9.-]{1,200}") ? "localhost" : nomeLocal;
        this.tempoMs = tempoMs;
    }

    public void enviar(Mensagem m) throws IOException {
        endereco(m.de);
        endereco(m.para);
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(host, porta), tempoMs);
            s.setSoTimeout(tempoMs);
            if (seguranca.equals("ssl"))
                s = proteger(s);
            Conversa c = new Conversa(s);
            c.esperar(220);
            List<String> ext = c.ehlo(nomeLocal);
            if (seguranca.equals("starttls")) {
                if (!tem(ext, "STARTTLS"))
                    throw new SmtpException("O servidor de e-mail " + host + ":" + porta + " não oferece STARTTLS. Confira smtp.seguranca e smtp.porta.", false);
                c.comando("STARTTLS", 220);
                s = proteger(s);
                c = new Conversa(s);
                ext = c.ehlo(nomeLocal);
            }
            if (!usuario.isEmpty())
                autenticar(c, ext);
            c.comando("MAIL FROM:<" + m.de + ">", 250);
            c.comando("RCPT TO:<" + m.para + ">", 250, 251);
            c.comando("DATA", 354);
            c.dados(montar(m));
            c.esperar(250);
            try {
                c.comando("QUIT", 221);
            } catch (IOException e) {
                /* a mensagem já foi aceita; o fechamento é só cortesia */
            }
        } finally {
            try {
                s.close();
            } catch (IOException e) {
                /* encerrando */
            }
        }
    }

    private Socket proteger(Socket s) throws IOException {
        try {
            SSLSocketFactory f;
            if (verificarCertificado) {
                f = (SSLSocketFactory) SSLSocketFactory.getDefault();
            } else {
                SSLContext ctx = SSLContext.getInstance("TLS");
                ctx.init(null, new TrustManager[] { new X509TrustManager() {
                    @Override
                    public void checkClientTrusted(X509Certificate[] c, String a) {
                    }

                    @Override
                    public void checkServerTrusted(X509Certificate[] c, String a) {
                    }

                    @Override
                    public X509Certificate[] getAcceptedIssuers() {
                        return new X509Certificate[0];
                    }
                } }, null);
                f = ctx.getSocketFactory();
            }
            SSLSocket ssl = (SSLSocket) f.createSocket(s, host, porta, true);
            if (verificarCertificado) {
                SSLParameters p = ssl.getSSLParameters();
                p.setEndpointIdentificationAlgorithm("HTTPS");
                ssl.setSSLParameters(p);
            }
            ssl.setSoTimeout(tempoMs);
            ssl.startHandshake();
            return ssl;
        } catch (GeneralSecurityException e) {
            throw new IOException("Falha ao preparar a conexão segura: " + e.getMessage(), e);
        } catch (javax.net.ssl.SSLException e) {
            throw new SmtpException("Não foi possível abrir conexão segura com " + host + ":" + porta + " (" + e.getMessage()
                    + "). Se o certificado do provedor é de outro nome, use em smtp.host o nome do servidor indicado por ele.", false);
        }
    }

    private void autenticar(Conversa c, List<String> ext) throws IOException {
        String auth = "";
        for (String e : ext)
            if (e.toUpperCase(Locale.ROOT).startsWith("AUTH"))
                auth = e.toUpperCase(Locale.ROOT);
        try {
            if (auth.contains("PLAIN") || auth.isEmpty() || !auth.contains("LOGIN")) {
                String cred = "\0" + usuario + "\0" + senha;
                c.comando("AUTH PLAIN " + b64(cred), 235);
            } else {
                c.comando("AUTH LOGIN", 334);
                c.comando(b64(usuario), 334);
                c.comando(b64(senha), 235);
            }
        } catch (SmtpException e) {
            throw new SmtpException("O servidor de e-mail recusou o usuário ou a senha (smtp.usuario e smtp.senha): " + e.getMessage(), false);
        }
    }

    private static boolean tem(List<String> ext, String nome) {
        for (String e : ext)
            if (e.toUpperCase(Locale.ROOT).startsWith(nome))
                return true;
        return false;
    }

    private static String b64(String s) {
        return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8));
    }

    /** Endereço simples e sem quebras de linha (impede injeção de cabeçalhos). */
    static String endereco(String e) throws SmtpException {
        if (e == null || !e.matches("[^\\s<>\"(),;:\\\\@]{1,64}@[A-Za-z0-9.-]{1,180}\\.[A-Za-z0-9-]{2,24}"))
            throw new SmtpException("Endereço de e-mail inválido: " + e, true);
        return e;
    }

    /* ---------------------------------------------------------------- mensagem */

    static String montar(Mensagem m) {
        String limite = "=_sop_" + UUID.randomUUID().toString().replace("-", "");
        String dominio = m.de.substring(m.de.indexOf('@') + 1);
        StringBuilder b = new StringBuilder(4096);
        b.append("Date: ").append(DATA.format(ZonedDateTime.now())).append("\r\n");
        b.append("From: ").append(nomeEEndereco(m.deNome, m.de)).append("\r\n");
        b.append("To: ").append(nomeEEndereco(m.paraNome, m.para)).append("\r\n");
        b.append("Subject: ").append(palavra(limpar(m.assunto), 9)).append("\r\n");
        b.append("Message-ID: <").append(UUID.randomUUID()).append('@').append(dominio).append(">\r\n");
        b.append("MIME-Version: 1.0\r\n");
        b.append("Auto-Submitted: auto-generated\r\n");
        b.append("X-Auto-Response-Suppress: All\r\n");
        if (m.html == null) {
            b.append("Content-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n");
            b.append(corpo(m.texto));
        } else {
            b.append("Content-Type: multipart/alternative;\r\n boundary=\"").append(limite).append("\"\r\n\r\n");
            b.append("--").append(limite).append("\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n").append(corpo(m.texto));
            b.append("--").append(limite).append("\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n").append(corpo(m.html));
            b.append("--").append(limite).append("--\r\n");
        }
        return b.toString();
    }

    private static String limpar(String s) {
        return s == null ? "" : s.replaceAll("[\\r\\n\\t\\u0000-\\u001f]+", " ").trim();
    }

    private static String nomeEEndereco(String nome, String email) {
        String n = limpar(nome);
        if (n.isEmpty())
            return "<" + email + ">";
        /* Nome só com caracteres simples vai entre aspas; com acentos, vai codificado. */
        boolean simples = n.matches("[A-Za-z0-9 .,'()/:+_&-]{1,60}");
        String rotulo = simples ? "\"" + n + "\"" : palavra(n, 6);
        /* O endereço desce para a linha seguinte quando a linha passaria do tamanho recomendado (78). */
        boolean cabe = simples && 6 + rotulo.length() + email.length() + 3 <= 76;
        return rotulo + (cabe ? " <" : "\r\n <") + email + ">";
    }

    /**
     * Texto de cabeçalho. Só ASCII simples vai direto; o resto vai codificado (=?UTF-8?B?...?=), em pedaços
     * curtos e sem cortar um caractere ao meio. usado = caracteres já ocupados na primeira linha.
     */
    static String palavra(String s, int usado) {
        if (s.matches("[A-Za-z0-9 .,!?'()/:+_-]*") && s.length() + usado <= 74)
            return s;
        StringBuilder b = new StringBuilder();
        int i = 0;
        boolean primeira = true;
        while (i < s.length()) {
            int fim = i, bytes = 0;
            while (fim < s.length()) {
                int cp = s.codePointAt(fim);
                int n = new String(Character.toChars(cp)).getBytes(StandardCharsets.UTF_8).length;
                if (bytes + n > 39)
                    break;
                bytes += n;
                fim += Character.charCount(cp);
            }
            if (fim == i)
                fim = i + Character.charCount(s.codePointAt(i));
            if (!primeira)
                b.append("\r\n ");
            primeira = false;
            b.append("=?UTF-8?B?").append(Base64.getEncoder().encodeToString(s.substring(i, fim).getBytes(StandardCharsets.UTF_8))).append("?=");
            i = fim;
        }
        return b.toString();
    }

    /** Corpo em base64, com linhas de 76 caracteres. */
    private static String corpo(String s) {
        return Base64.getMimeEncoder(76, new byte[] { '\r', '\n' }).encodeToString((s == null ? "" : s).getBytes(StandardCharsets.UTF_8)) + "\r\n";
    }

    /* ---------------------------------------------------------------- conversa SMTP */

    private static final class Conversa {
        final BufferedReader in;
        final OutputStream out;

        Conversa(Socket s) throws IOException {
            in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.ISO_8859_1));
            out = s.getOutputStream();
        }

        /** Lê a resposta (que pode ter várias linhas) e confere o código. Devolve as linhas, sem o código. */
        List<String> esperar(int... codigos) throws IOException {
            List<String> linhas = new ArrayList<>();
            int codigo;
            while (true) {
                String l = in.readLine();
                if (l == null)
                    throw new SmtpException("O servidor de e-mail fechou a conexão", false);
                if (l.length() < 3)
                    throw new SmtpException("Resposta inesperada do servidor de e-mail: " + l, false);
                try {
                    codigo = Integer.parseInt(l.substring(0, 3));
                } catch (NumberFormatException e) {
                    throw new SmtpException("Resposta inesperada do servidor de e-mail: " + l, false);
                }
                linhas.add(l.length() > 4 ? l.substring(4) : "");
                if (l.length() == 3 || l.charAt(3) != '-')
                    break;
                if (linhas.size() > 200)
                    throw new SmtpException("Resposta longa demais do servidor de e-mail", false);
            }
            for (int c : codigos)
                if (c == codigo)
                    return linhas;
            throw new SmtpException(codigo + " " + String.join(" ", linhas), codigo >= 500);
        }

        List<String> comando(String linha, int... codigos) throws IOException {
            out.write((linha + "\r\n").getBytes(StandardCharsets.UTF_8));
            out.flush();
            return esperar(codigos);
        }

        List<String> ehlo(String nome) throws IOException {
            return comando("EHLO " + nome, 250);
        }

        /** Envia a mensagem: linhas terminadas em CRLF, ponto inicial duplicado e a linha final com um ponto só. */
        void dados(String msg) throws IOException {
            StringBuilder b = new StringBuilder(msg.length() + 64);
            for (String l : msg.split("\r\n", -1)) {
                if (l.startsWith("."))
                    b.append('.');
                b.append(l).append("\r\n");
            }
            String tudo = b.toString();
            if (tudo.endsWith("\r\n\r\n"))
                tudo = tudo.substring(0, tudo.length() - 2);
            out.write(tudo.getBytes(StandardCharsets.UTF_8));
            out.write(".\r\n".getBytes(StandardCharsets.US_ASCII));
            out.flush();
        }
    }
}
