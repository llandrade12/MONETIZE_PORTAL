package br.com.monetize.portal.servicos;

/** Aparência dos e-mails do portal: fundo escuro, dourado da marca e um botão para abrir a Área de Membros. */
public final class EmailModelo {

    private EmailModelo() {
    }

    static String esc(String s) {
        if (s == null)
            return "";
        StringBuilder b = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '&':
                    b.append("&amp;");
                    break;
                case '<':
                    b.append("&lt;");
                    break;
                case '>':
                    b.append("&gt;");
                    break;
                case '"':
                    b.append("&quot;");
                    break;
                case '\'':
                    b.append("&#39;");
                    break;
                default:
                    b.append(c);
            }
        }
        return b.toString();
    }

    /** Texto com quebras de linha e endereços https clicáveis. */
    private static String paragrafos(String msg) {
        String e = esc(msg).replaceAll("(https://[^\\s<]+[^\\s<.,;:!?)])", "<a href=\"$1\" style=\"color:#c98b06\">$1</a>");
        return e.replace("\r\n", "\n").replace("\n", "<br>");
    }

    /**
     * @param saudacao   primeira linha (ex.: "Olá, Ana.")
     * @param titulo     assunto em destaque
     * @param msg        texto da mensagem
     * @param botaoUrl   endereço do botão (null = sem botão)
     * @param botaoTexto texto do botão
     * @param rodape     linha final, em letras pequenas
     */
    public static String html(String saudacao, String titulo, String msg, String botaoUrl, String botaoTexto, String rodape) {
        StringBuilder b = new StringBuilder(2048);
        b.append("<!DOCTYPE html><html lang=\"pt-BR\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><title>")
                .append(esc(titulo)).append("</title></head>");
        b.append("<body style=\"margin:0;padding:0;background:#f3efe4;font-family:Arial,Helvetica,sans-serif;color:#1c1a16\">");
        b.append("<table role=\"presentation\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"background:#f3efe4\"><tr><td align=\"center\" style=\"padding:24px 12px\">");
        b.append("<table role=\"presentation\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"max-width:560px;background:#ffffff;border-radius:14px;overflow:hidden;border:1px solid #e6dfcd\">");
        b.append("<tr><td style=\"background:#0e0e0e;padding:22px 28px\"><span style=\"font-size:20px;font-weight:bold;letter-spacing:2px;color:#fdb621\">MONETIZE</span>")
                .append("<br><span style=\"font-size:11px;letter-spacing:1px;color:#b5af9d\">MENTORING AND CONSULTING · ÁREA DE MEMBROS</span></td></tr>");
        b.append("<tr><td style=\"padding:28px\">");
        if (saudacao != null && !saudacao.isEmpty())
            b.append("<p style=\"margin:0 0 10px;font-size:15px;color:#5c574c\">").append(esc(saudacao)).append("</p>");
        b.append("<h1 style=\"margin:0 0 14px;font-size:21px;line-height:1.3;color:#1c1a16\">").append(esc(titulo)).append("</h1>");
        b.append("<p style=\"margin:0;font-size:15px;line-height:1.6;color:#1c1a16\">").append(paragrafos(msg)).append("</p>");
        if (botaoUrl != null && !botaoUrl.isEmpty())
            b.append("<p style=\"margin:26px 0 0\"><a href=\"").append(esc(botaoUrl))
                    .append("\" style=\"display:inline-block;background:#fdb621;color:#1a1203;font-weight:bold;font-size:15px;text-decoration:none;padding:13px 22px;border-radius:10px\">")
                    .append(esc(botaoTexto)).append("</a></p>");
        b.append("</td></tr>");
        b.append("<tr><td style=\"padding:16px 28px 22px;border-top:1px solid #eee7d6;font-size:12px;line-height:1.5;color:#8a8472\">").append(esc(rodape)).append("</td></tr>");
        b.append("</table></td></tr></table></body></html>");
        return b.toString();
    }
}
