package br.com.monetize.portal.dados;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Freio contra abuso: quantas vezes por hora um mesmo aluno pode gerar certos registros
 * (alertas ao mentor, chamados, comentários). Os limites são folgados para o uso normal.
 */
final class Limites {

    private Limites() {
    }

    private static final long JANELA_MS = 3_600_000L;
    private static final Map<String, long[]> CONTADORES = new ConcurrentHashMap<>();

    static void conferir(long alunoId, String tipo, int maximoPorHora) {
        if (alunoId <= 0)
            return;
        long agora = System.currentTimeMillis();
        long[] c = CONTADORES.computeIfAbsent(alunoId + "|" + tipo, x -> new long[] { agora, 0 });
        synchronized (c) {
            if (agora - c[0] > JANELA_MS) {
                c[0] = agora;
                c[1] = 0;
            }
            if (c[1] >= maximoPorHora)
                throw new Recusa("limite-por-hora");
            c[1]++;
        }
        if (CONTADORES.size() > 20_000)
            CONTADORES.entrySet().removeIf(e -> agora - e.getValue()[0] > JANELA_MS);
    }

    /** Só para os testes automáticos. */
    static void zerar() {
        CONTADORES.clear();
    }
}
