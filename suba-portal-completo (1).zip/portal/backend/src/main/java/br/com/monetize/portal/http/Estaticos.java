package br.com.monetize.portal.http;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.GZIPOutputStream;

/**
 * Entrega os arquivos do portal (HTML, CSS, JS e imagens) a partir da pasta "web".
 * Para atualizar a aparência do portal basta trocar os arquivos da pasta; não é preciso reiniciar o servidor.
 */
public final class Estaticos {

    private static final Map<String, String> TIPOS = new HashMap<>();
    static {
        TIPOS.put("html", "text/html; charset=utf-8");
        TIPOS.put("css", "text/css; charset=utf-8");
        TIPOS.put("js", "text/javascript; charset=utf-8");
        TIPOS.put("json", "application/json; charset=utf-8");
        TIPOS.put("webmanifest", "application/manifest+json; charset=utf-8");
        TIPOS.put("svg", "image/svg+xml");
        TIPOS.put("png", "image/png");
        TIPOS.put("jpg", "image/jpeg");
        TIPOS.put("jpeg", "image/jpeg");
        TIPOS.put("webp", "image/webp");
        TIPOS.put("gif", "image/gif");
        TIPOS.put("ico", "image/x-icon");
        TIPOS.put("woff2", "font/woff2");
        TIPOS.put("woff", "font/woff");
        TIPOS.put("txt", "text/plain; charset=utf-8");
        TIPOS.put("pdf", "application/pdf");
    }

    /** Política de conteúdo das páginas: só carrega scripts e estilos do próprio portal e de endereços https. */
    static final String CSP = "default-src 'self'; script-src 'self' 'unsafe-inline' https:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
            + "font-src 'self' data: https://fonts.gstatic.com; img-src 'self' data: blob: https:; media-src 'self' blob: https:; frame-src 'self' blob: https:; "
            + "connect-src 'self' https:; worker-src 'self'; manifest-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'";

    private static final long CACHE_MAX = 24L * 1024 * 1024;

    private final Path raiz;
    private final Map<String, byte[]> comprimidos = new ConcurrentHashMap<>();
    private long cacheBytes;

    public Estaticos(Path raiz) {
        this.raiz = raiz.toAbsolutePath().normalize();
    }

    public Path raiz() {
        return raiz;
    }

    /** Responde com o arquivo pedido. Devolve false se ele não existe. */
    public boolean servir(Req r) throws IOException {
        String c = r.caminho;
        if (c.endsWith("/"))
            c += "index.html";
        if (c.contains("\\") || c.contains("\0") || c.contains("/.") || c.contains("//"))
            return false;
        Path arq = raiz.resolve(c.substring(1)).normalize();
        if (!arq.startsWith(raiz) || !Files.isRegularFile(arq) || !Files.isReadable(arq))
            return false;

        String nome = arq.getFileName().toString();
        int p = nome.lastIndexOf('.');
        String ext = p < 0 ? "" : nome.substring(p + 1).toLowerCase(Locale.ROOT);
        String tipo = TIPOS.get(ext);
        if (tipo == null)
            return false;

        long tam = Files.size(arq), mod = Files.getLastModifiedTime(arq).toMillis();
        String etag = "\"" + Long.toHexString(tam) + "-" + Long.toHexString(mod) + "\"";
        boolean texto = tipo.startsWith("text/") || tipo.startsWith("application/") && !ext.equals("pdf") || ext.equals("svg");
        r.saida().set("ETag", etag);
        /* Código e páginas: o navegador sempre confere se mudou (resposta 304 quando está igual). Imagens e fontes: guarda por 7 dias. */
        r.saida().set("Cache-Control", texto ? "no-cache" : "public, max-age=604800");
        if (ext.equals("html"))
            r.saida().set("Content-Security-Policy", CSP);
        if (etag.equals(r.cabecalho("If-None-Match"))) {
            r.vazio(304);
            return true;
        }
        if (texto && tam > 1024 && r.cabecalho("Accept-Encoding").toLowerCase(Locale.ROOT).contains("gzip")) {
            byte[] gz = comprimido(arq, etag);
            r.saida().set("Content-Encoding", "gzip");
            r.saida().add("Vary", "Accept-Encoding");
            r.bytes(200, tipo, gz, false);
            return true;
        }
        r.bytes(200, tipo, Files.readAllBytes(arq), false);
        return true;
    }

    private byte[] comprimido(Path arq, String etag) throws IOException {
        String chave = arq + "|" + etag;
        byte[] gz = comprimidos.get(chave);
        if (gz != null)
            return gz;
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        try (GZIPOutputStream g = new GZIPOutputStream(b)) {
            g.write(Files.readAllBytes(arq));
        }
        gz = b.toByteArray();
        synchronized (this) {
            if (cacheBytes + gz.length > CACHE_MAX) {
                comprimidos.clear();
                cacheBytes = 0;
            }
            if (comprimidos.put(chave, gz) == null)
                cacheBytes += gz.length;
        }
        return gz;
    }
}
