package br.com.monetize.portal.util;

import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Registro simples na saída padrão (o systemd e o Docker guardam essa saída). */
public final class Log {

    private Log() {
    }

    private static final DateTimeFormatter F = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static volatile boolean detalhado = false;
    /** Saída sempre em UTF-8, para os acentos não dependerem do idioma configurado no servidor. */
    private static final PrintStream SAIDA = new PrintStream(new FileOutputStream(FileDescriptor.out), true, StandardCharsets.UTF_8);

    public static void detalhado(boolean v) {
        detalhado = v;
    }

    public static void info(String msg) {
        escrever("INFO ", msg, null);
    }

    public static void aviso(String msg) {
        escrever("AVISO", msg, null);
    }

    public static void erro(String msg, Throwable t) {
        escrever("ERRO ", msg, t);
    }

    public static void depurar(String msg) {
        if (detalhado)
            escrever("DEBUG", msg, null);
    }

    private static synchronized void escrever(String nivel, String msg, Throwable t) {
        StringBuilder b = new StringBuilder(160);
        b.append(F.format(LocalDateTime.now())).append(' ').append(nivel).append(' ').append(msg);
        if (t != null) {
            StringWriter w = new StringWriter();
            t.printStackTrace(new PrintWriter(w));
            b.append('\n').append(w.toString().trim());
        }
        SAIDA.println(b);
    }
}
