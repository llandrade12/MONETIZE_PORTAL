package br.com.monetize.portal.db;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import br.com.monetize.portal.util.Log;

/**
 * Cria e atualiza as tabelas do banco.
 *
 * Cada arquivo em resources/db (V001__..., V002__...) é aplicado uma única vez, em ordem, e anotado na
 * tabela esquema_versao. Para mudar o banco em uma versão futura, acrescente um novo arquivo e registre-o
 * em {@link #ARQUIVOS}; nunca edite um arquivo já aplicado em produção.
 */
public final class Migracoes {

    private Migracoes() {
    }

    private static final String[] ARQUIVOS = { "V001__esquema_inicial.sql" };

    public static void aplicar(Banco banco) {
        banco.usar(c -> {
            try (Statement s = c.createStatement()) {
                s.execute("CREATE TABLE IF NOT EXISTS esquema_versao (versao INT NOT NULL, descricao VARCHAR(200) NOT NULL, aplicado_em DATETIME NOT NULL, PRIMARY KEY (versao))");
            }
            List<Integer> feitas = Banco.consultar(c, "SELECT versao FROM esquema_versao", r -> r.getInt(1));
            for (String arq : ARQUIVOS) {
                int versao = Integer.parseInt(arq.substring(1, 4));
                if (feitas.contains(versao))
                    continue;
                Log.info("Banco de dados: aplicando " + arq);
                for (String sql : comandos(ler(arq))) {
                    try (Statement s = c.createStatement()) {
                        s.execute(sql);
                    } catch (SQLException e) {
                        throw new SQLException("Falha ao aplicar " + arq + " no comando que começa com \"" + sql.substring(0, Math.min(70, sql.length())).replace('\n', ' ') + "\": " + e.getMessage(), e);
                    }
                }
                Banco.executar(c, "INSERT INTO esquema_versao (versao, descricao, aplicado_em) VALUES (?, ?, ?)", versao, arq, LocalDateTime.now());
            }
            return null;
        });
    }

    private static String ler(String arq) throws SQLException {
        try (InputStream in = Migracoes.class.getResourceAsStream("/db/" + arq)) {
            if (in == null)
                throw new SQLException("Arquivo de banco não encontrado dentro do programa: db/" + arq);
            StringBuilder b = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String l;
                while ((l = r.readLine()) != null)
                    b.append(l).append('\n');
            }
            return b.toString();
        } catch (IOException e) {
            throw new SQLException("Não foi possível ler db/" + arq, e);
        }
    }

    /** Separa o arquivo em comandos (terminados por ponto e vírgula no fim da linha) e descarta comentários. */
    static List<String> comandos(String texto) {
        List<String> l = new ArrayList<>();
        StringBuilder b = new StringBuilder();
        for (String linha : texto.split("\n")) {
            String t = linha.trim();
            if (t.isEmpty() || t.startsWith("--"))
                continue;
            b.append(linha).append('\n');
            if (t.endsWith(";")) {
                String sql = b.toString().trim();
                l.add(sql.substring(0, sql.length() - 1).trim());
                b.setLength(0);
            }
        }
        if (b.toString().trim().length() > 0)
            l.add(b.toString().trim());
        return l;
    }
}
