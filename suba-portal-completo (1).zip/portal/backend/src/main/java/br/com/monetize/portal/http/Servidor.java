package br.com.monetize.portal.http;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import br.com.monetize.portal.Config;
import br.com.monetize.portal.auth.Usuario;
import br.com.monetize.portal.db.Banco.BancoException;
import br.com.monetize.portal.util.Json.JsonException;
import br.com.monetize.portal.util.Log;

/**
 * Servidor HTTP (o que vem embutido no Java). Entrega as páginas do portal e atende a API em /api.
 * Em produção fica atrás de um proxy (Nginx, Apache ou o do EasyPanel), que cuida do HTTPS.
 */
public final class Servidor {

    /** Código que trata uma rota. */
    public interface Tratador {
        void tratar(Req r) throws Exception;
    }

    /** Descobre quem está logado a partir do cookie. */
    public interface Autenticador {
        Usuario identificar(Req r);
    }

    public enum Acesso {
        PUBLICO, LOGADO, MENTOR
    }

    /** Cabeçalho que o portal manda em toda chamada à API (um site de terceiros não consegue mandá-lo). */
    public static final String CABECALHO_PORTAL = "X-Portal";

    private static final class Rota {
        final String metodo, caminho;
        final boolean comParametro;
        final Acesso acesso;
        final Tratador tratador;

        Rota(String metodo, String caminho, Acesso acesso, Tratador tratador) {
            this.metodo = metodo;
            this.comParametro = caminho.endsWith("/*");
            this.caminho = comParametro ? caminho.substring(0, caminho.length() - 1) : caminho;
            this.acesso = acesso;
            this.tratador = tratador;
        }
    }

    private final Config config;
    private final Estaticos estaticos;
    private final List<Rota> rotas = new ArrayList<>();
    private Autenticador autenticador = r -> null;
    private HttpServer http;
    private ExecutorService executor;

    public Servidor(Config config) {
        this.config = config;
        this.estaticos = new Estaticos(config.pastaWeb());
    }

    public void autenticador(Autenticador a) {
        this.autenticador = a;
    }

    /** Registra uma rota. Caminho terminado em "/*" aceita um trecho variável, disponível em Req.parametro. */
    public void rota(String metodo, String caminho, Acesso acesso, Tratador t) {
        rotas.add(new Rota(metodo, caminho, acesso, t));
    }

    public void iniciar() throws IOException {
        /* Limites de tempo do servidor embutido, para conexões lentas não prenderem as threads. */
        definirSeAusente("sun.net.httpserver.maxReqTime", "120");
        definirSeAusente("sun.net.httpserver.maxRspTime", "300");
        definirSeAusente("sun.net.httpserver.idleInterval", "30");
        http = HttpServer.create(new InetSocketAddress(config.endereco(), config.porta()), 200);
        AtomicInteger n = new AtomicInteger();
        ThreadFactory fabrica = run -> {
            Thread t = new Thread(run, "http-" + n.incrementAndGet());
            t.setDaemon(true);
            return t;
        };
        executor = new ThreadPoolExecutor(config.threads(), config.threads(), 60, TimeUnit.SECONDS, new LinkedBlockingQueue<>(2000), fabrica);
        http.setExecutor(executor);
        http.createContext("/", this::atender);
        http.start();
    }

    private static void definirSeAusente(String prop, String valor) {
        if (System.getProperty(prop) == null)
            System.setProperty(prop, valor);
    }

    public int porta() {
        return http.getAddress().getPort();
    }

    public void parar() {
        if (http != null)
            http.stop(2);
        if (executor != null)
            executor.shutdownNow();
    }

    private void atender(HttpExchange x) {
        long inicio = System.nanoTime();
        Req r = new Req(x, config.confiarNoProxy());
        try {
            cabecalhosDeSeguranca(r);
            despachar(r);
        } catch (ErroHttp e) {
            responderErro(r, e.status, e.codigo, e.getMessage());
        } catch (JsonException e) {
            responderErro(r, 400, "pedido-invalido", "JSON inválido");
        } catch (BancoException e) {
            Log.erro("Banco de dados indisponível em " + r.metodo + " " + r.caminho, e);
            responderErro(r, 503, "banco-indisponivel", "O banco de dados não respondeu. Tente de novo em instantes.");
        } catch (IOException e) {
            Log.depurar("Conexão interrompida em " + r.metodo + " " + r.caminho + ": " + e.getMessage());
        } catch (Exception | StackOverflowError e) {
            Log.erro("Erro inesperado em " + r.metodo + " " + r.caminho, e);
            responderErro(r, 500, "erro-interno", "Erro interno. A equipe pode ver o detalhe no registro do servidor.");
        } finally {
            Log.depurar(r.metodo + " " + r.caminho + " -> " + r.statusEnviado + " em " + (System.nanoTime() - inicio) / 1_000_000 + " ms");
            x.close();
        }
    }

    private void cabecalhosDeSeguranca(Req r) {
        r.saida().set("X-Content-Type-Options", "nosniff");
        r.saida().set("Referrer-Policy", "strict-origin-when-cross-origin");
        r.saida().set("X-Frame-Options", "SAMEORIGIN");
        r.saida().set("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()");
        if (config.https())
            r.saida().set("Strict-Transport-Security", "max-age=15552000");
    }

    private void despachar(Req r) throws Exception {
        boolean api = r.caminho.startsWith("/api/") || r.caminho.startsWith("/agenda/");
        if (!api) {
            if (!r.metodo.equals("GET") && !r.metodo.equals("HEAD"))
                throw new ErroHttp(405, "metodo", "Método não permitido");
            if (!estaticos.servir(r))
                r.texto(404, "text/plain; charset=utf-8", "Página não encontrada");
            return;
        }
        boolean caminhoExiste = false;
        for (Rota rota : rotas) {
            String param = casa(rota, r.caminho);
            if (param == null)
                continue;
            caminhoExiste = true;
            if (!rota.metodo.equals(r.metodo) && !(rota.metodo.equals("GET") && r.metodo.equals("HEAD")))
                continue;
            r.parametro = param;
            boolean leitura = r.metodo.equals("GET") || r.metodo.equals("HEAD");
            if (!leitura && !"1".equals(r.cabecalho(CABECALHO_PORTAL)))
                throw new ErroHttp(403, "origem", "Requisição recusada");
            r.usuario = autenticador.identificar(r);
            if (rota.acesso != Acesso.PUBLICO && r.usuario == null)
                throw new ErroHttp(401, "sem-sessao", "Sua sessão terminou. Entre de novo.");
            if (rota.acesso == Acesso.MENTOR && !r.usuario.mentor())
                throw ErroHttp.proibido();
            r.saida().set("Cache-Control", "no-store");
            rota.tratador.tratar(r);
            if (!r.respondeu())
                r.ok();
            return;
        }
        if (caminhoExiste)
            throw new ErroHttp(405, "metodo", "Método não permitido");
        throw ErroHttp.naoEncontrado();
    }

    /** Parâmetro capturado ("" nas rotas fixas) se o caminho casa com a rota; null se não casa. */
    private static String casa(Rota rota, String caminho) {
        if (!rota.comParametro)
            return rota.caminho.equals(caminho) ? "" : null;
        if (!caminho.startsWith(rota.caminho) || caminho.length() == rota.caminho.length())
            return null;
        String p = caminho.substring(rota.caminho.length());
        return p.contains("/") ? null : p;
    }

    private static void responderErro(Req r, int status, String codigo, String msg) {
        if (r.respondeu())
            return;
        try {
            r.saida().remove("Content-Encoding");
            r.erro(status, codigo, msg);
        } catch (IOException e) {
            /* o navegador já fechou a conexão */
        }
    }
}
