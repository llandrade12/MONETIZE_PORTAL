package br.com.monetize.portal.servicos;

import java.math.BigInteger;
import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.ECParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.ECPublicKeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Texto;

/**
 * Web Push sem bibliotecas externas: criptografia da mensagem (RFC 8291, codificação aes128gcm da RFC 8188)
 * e identificação do servidor (VAPID, RFC 8292), usando só o que vem no Java.
 */
public final class WebPush {

    private WebPush() {
    }

    private static final String CURVA = "secp256r1";

    /* ---------------------------------------------------------------- chaves */

    public static KeyPair novoPar() {
        try {
            KeyPairGenerator g = KeyPairGenerator.getInstance("EC");
            g.initialize(new ECGenParameterSpec(CURVA));
            return g.generateKeyPair();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Curva P-256 indisponível nesta instalação do Java", e);
        }
    }

    private static ECParameterSpec parametros() throws GeneralSecurityException {
        AlgorithmParameters p = AlgorithmParameters.getInstance("EC");
        p.init(new ECGenParameterSpec(CURVA));
        return p.getParameterSpec(ECParameterSpec.class);
    }

    /** Chave pública no formato usado pelo navegador: 0x04 + X (32 bytes) + Y (32 bytes). */
    public static byte[] pontoDe(PublicKey chave) {
        ECPoint w = ((ECPublicKey) chave).getW();
        byte[] r = new byte[65];
        r[0] = 4;
        copiar32(w.getAffineX(), r, 1);
        copiar32(w.getAffineY(), r, 33);
        return r;
    }

    private static void copiar32(BigInteger n, byte[] destino, int pos) {
        byte[] b = n.toByteArray();
        int ini = b.length > 32 ? b.length - 32 : 0, len = Math.min(32, b.length);
        System.arraycopy(b, ini, destino, pos + 32 - len, len);
    }

    public static PublicKey publicaDe(byte[] ponto) throws GeneralSecurityException {
        if (ponto.length != 65 || ponto[0] != 4)
            throw new GeneralSecurityException("Chave pública P-256 em formato inesperado");
        BigInteger x = new BigInteger(1, java.util.Arrays.copyOfRange(ponto, 1, 33)), y = new BigInteger(1, java.util.Arrays.copyOfRange(ponto, 33, 65));
        return KeyFactory.getInstance("EC").generatePublic(new ECPublicKeySpec(new ECPoint(x, y), parametros()));
    }

    public static String privadaTexto(PrivateKey k) {
        return Base64.getEncoder().encodeToString(k.getEncoded());
    }

    public static PrivateKey privadaDe(String pkcs8Base64) throws GeneralSecurityException {
        return KeyFactory.getInstance("EC").generatePrivate(new PKCS8EncodedKeySpec(Base64.getDecoder().decode(pkcs8Base64)));
    }

    /* ---------------------------------------------------------------- criptografia da mensagem */

    /**
     * Corpo da requisição ao serviço de push (Content-Encoding: aes128gcm).
     *
     * @param p256dh chave pública do aparelho (65 bytes)
     * @param auth   segredo de autenticação do aparelho (16 bytes)
     */
    public static byte[] cifrar(byte[] mensagem, byte[] p256dh, byte[] auth) throws GeneralSecurityException {
        return cifrar(mensagem, p256dh, auth, novoPar(), Texto.aleatorio(16));
    }

    /** Versão com par de chaves e sal informados (para conferir com o exemplo da RFC 8291). */
    static byte[] cifrar(byte[] mensagem, byte[] p256dh, byte[] auth, KeyPair efemero, byte[] sal) throws GeneralSecurityException {
        byte[] nossaPublica = pontoDe(efemero.getPublic());
        KeyAgreement ka = KeyAgreement.getInstance("ECDH");
        ka.init(efemero.getPrivate());
        ka.doPhase(publicaDe(p256dh), true);
        byte[] segredo = ka.generateSecret();

        /* RFC 8291, seção 3.4 */
        byte[] prkChave = hmac(auth, segredo);
        byte[] ikm = hmac(prkChave, juntar("WebPush: info\0".getBytes(StandardCharsets.US_ASCII), p256dh, nossaPublica, new byte[] { 1 }));
        /* RFC 8188, seção 2.2 */
        byte[] prk = hmac(sal, ikm);
        byte[] cek = java.util.Arrays.copyOf(hmac(prk, juntar("Content-Encoding: aes128gcm\0".getBytes(StandardCharsets.US_ASCII), new byte[] { 1 })), 16);
        byte[] nonce = java.util.Arrays.copyOf(hmac(prk, juntar("Content-Encoding: nonce\0".getBytes(StandardCharsets.US_ASCII), new byte[] { 1 })), 12);

        Cipher aes = Cipher.getInstance("AES/GCM/NoPadding");
        aes.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(cek, "AES"), new GCMParameterSpec(128, nonce));
        /* Um único registro: o conteúdo seguido do delimitador 0x02 (último registro). */
        byte[] cifrado = aes.doFinal(juntar(mensagem, new byte[] { 2 }));

        ByteBuffer b = ByteBuffer.allocate(16 + 4 + 1 + 65 + cifrado.length);
        b.put(sal).putInt(4096).put((byte) 65).put(nossaPublica).put(cifrado);
        return b.array();
    }

    private static byte[] hmac(byte[] chave, byte[] dados) throws GeneralSecurityException {
        Mac m = Mac.getInstance("HmacSHA256");
        m.init(new SecretKeySpec(chave, "HmacSHA256"));
        return m.doFinal(dados);
    }

    private static byte[] juntar(byte[]... partes) {
        int n = 0;
        for (byte[] p : partes)
            n += p.length;
        byte[] r = new byte[n];
        int pos = 0;
        for (byte[] p : partes) {
            System.arraycopy(p, 0, r, pos, p.length);
            pos += p.length;
        }
        return r;
    }

    /* ---------------------------------------------------------------- VAPID */

    /**
     * Valor do cabeçalho Authorization para o serviço de push.
     *
     * @param endpoint endereço de entrega do aparelho
     * @param contato  "mailto:..." ou "https://..." de quem responde pelo servidor
     */
    public static String vapid(String endpoint, String contato, PrivateKey privada, byte[] publica, long agoraSegundos) throws GeneralSecurityException {
        URI u = URI.create(endpoint);
        String aud = u.getScheme() + "://" + u.getHost() + (u.getPort() > 0 ? ":" + u.getPort() : "");
        String cabecalho = Texto.b64url("{\"typ\":\"JWT\",\"alg\":\"ES256\"}".getBytes(StandardCharsets.UTF_8));
        String corpo = Texto.b64url(Json.texto(Json.mapa("aud", aud, "exp", agoraSegundos + 12 * 3600, "sub", contato)).getBytes(StandardCharsets.UTF_8));
        Signature s = Signature.getInstance("SHA256withECDSAinP1363Format");
        s.initSign(privada);
        s.update((cabecalho + "." + corpo).getBytes(StandardCharsets.US_ASCII));
        String jwt = cabecalho + "." + corpo + "." + Texto.b64url(s.sign());
        return "vapid t=" + jwt + ", k=" + Texto.b64url(publica);
    }

    /** Monta a chave privada a partir do número secreto (usado só nos testes, com o exemplo da RFC). */
    static KeyPair parDe(byte[] secreto, byte[] publica) throws GeneralSecurityException {
        KeyFactory kf = KeyFactory.getInstance("EC");
        PrivateKey priv = kf.generatePrivate(new java.security.spec.ECPrivateKeySpec(new BigInteger(1, secreto), parametros()));
        return new KeyPair(publicaDe(publica), priv);
    }
}
