package br.com.monetize.portal.servicos;

import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import br.com.monetize.portal.Config;
import br.com.monetize.portal.auth.Sessoes;
import br.com.monetize.portal.dados.Gravador;
import br.com.monetize.portal.dados.Notificador;
import br.com.monetize.portal.dados.Portal;
import br.com.monetize.portal.dados.Repositorio;
import br.com.monetize.portal.dados.Repositorio.AlunoLinha;
import br.com.monetize.portal.db.Banco;
import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Texto;

/**
 * Agenda por assinatura (formato iCalendar, .ics).
 *
 * Cada aluno e cada mentor tem um endereço próprio e secreto. Quem assina esse endereço no Google Agenda,
 * no iPhone ou no Outlook passa a ver os encontros, eventos e prazos, e a agenda se atualiza sozinha quando
 * o mentor muda uma data. O aluno recebe só o que é da turma dele.
 */
public final class Agenda {

    private static final DateTimeFormatter UTC = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'");

    private final Banco banco;
    private final Config config;
    private final ZoneId fuso;

    public Agenda(Banco banco, Config config) {
        this.banco = banco;
        this.config = config;
        this.fuso = config.fuso();
    }

    /** Endereço da agenda de um código. */
    public String url(String token) {
        return config.urlPublica() + "/agenda/" + token + ".ics";
    }

    /** Conteúdo .ics para o código informado, ou null se o código não existe (ou o aluno não está ativo). */
    public String ics(String token) {
        if (token == null || !token.matches("[A-Za-z0-9_-]{16,64}"))
            return null;
        return banco.usar(c -> {
            LocalDateTime agora = LocalDateTime.now(fuso);
            String hoje = agora.toLocalDate().toString();
            AlunoLinha a = Repositorio.alunoPorAgenda(c, token);
            if (a != null) {
                if (!"ativo".equals(a.status))
                    return null;
                Portal p = Portal.carregar(c, hoje);
                return montar(p, p.aluno(a.id), agora);
            }
            Long mentor = Banco.um(c, "SELECT id FROM mentor WHERE agenda_token = ? AND ativo = 1", r -> r.getLong(1), token);
            if (mentor == null)
                return null;
            return montar(Portal.carregar(c, hoje), null, agora);
        });
    }

    /** Código da agenda do mentor. */
    public static String tokenDoMentor(Connection c, long mentorId) throws SQLException {
        Sessoes.Mentor m = Sessoes.mentorPorId(c, mentorId);
        return m == null ? null : m.agendaToken;
    }

    /** aluno = null monta a agenda do mentor (todas as turmas). */
    String montar(Portal p, Map<String, Object> aluno, LocalDateTime agora) {
        boolean mentor = aluno == null;
        long tid = mentor ? 0 : p.turmaDe(aluno);
        String carimbo = UTC.format(agora.atZone(fuso).withZoneSameInstant(ZoneOffset.UTC));
        List<String> l = new ArrayList<>();
        l.add("BEGIN:VCALENDAR");
        l.add("VERSION:2.0");
        l.add("PRODID:-//Monetize//Area de Membros//PT-BR");
        l.add("CALSCALE:GREGORIAN");
        l.add("METHOD:PUBLISH");
        l.add("X-WR-CALNAME:" + esc(Notificador.MARCA + " · Mentoria"));
        l.add("X-WR-TIMEZONE:" + fuso.getId());
        l.add("REFRESH-INTERVAL;VALUE=DURATION:PT1H");
        l.add("X-PUBLISHED-TTL:PT1H");

        for (Map<String, Object> a : p.aulasDe(tid)) {
            String status = Json.str(a, "status");
            LocalDate dia = Texto.data(Json.str(a, "date"));
            if (status.equals("cancelada") || dia == null)
                continue;
            /* A pauta e o link aparecem para o aluno a partir da véspera, como no portal. */
            boolean pauta = mentor || Portal.realizada(a) || Texto.dias(Json.str(a, "date"), p.hoje) <= 1;
            String link = pauta && https(Json.str(a, "link")) ? Json.str(a, "link").trim() : "";
            StringBuilder desc = new StringBuilder("Encontro da mentoria com " + Texto.ou(Json.str(a, "mentor"), p.mentor) + ".");
            if (pauta && !Json.str(a, "obj").isEmpty())
                desc.append("\nPauta: ").append(Json.str(a, "obj"));
            desc.append(link.isEmpty() ? "\nO link da reunião fica na página da aula, no portal." : "\nLink da reunião: " + link);
            evento(l, "aula-" + Gravador.chaveDe(a.get("n")), carimbo, Notificador.MARCA + " · " + Json.str(a, "nome"), dia, hora(Json.str(a, "hora")),
                    (int) Math.max(15, Json.num(a, "dur", 120)), desc.toString(), link);
        }
        for (Map<String, Object> e : p.eventos) {
            LocalDate dia = Texto.data(Json.str(e, "d"));
            if (dia != null && Portal.naTurma(e, tid))
                evento(l, "evento-" + Gravador.chaveDe(e.get("id")), carimbo, Notificador.MARCA + " · " + Json.str(e, "t"), dia, null, 0, "Evento da mentoria.", "");
        }
        for (Map<String, Object> t : mentor ? p.tarefas : p.tarefasDe(aluno)) {
            if (!mentor && (!p.liberada(t) || p.entregou(aluno, t)))
                continue;
            LocalDate dia = Texto.data(mentor ? Json.str(t, "due") : p.prazoDe(aluno, t));
            if (dia != null)
                evento(l, "tarefa-" + Gravador.chaveDe(t.get("id")), carimbo, "Prazo: " + Json.str(t, "t"), dia, null, 0, "Prazo de entrega da tarefa na Área de Membros.", "");
        }
        l.add("END:VCALENDAR");
        StringBuilder b = new StringBuilder(l.size() * 40);
        for (String linha : l)
            dobrar(b, linha);
        return b.toString();
    }

    private void evento(List<String> l, String uid, String carimbo, String titulo, LocalDate dia, LocalTime hora, int minutos, String desc, String local) {
        l.add("BEGIN:VEVENT");
        l.add("UID:" + uid + "@monetize-area-de-membros");
        l.add("DTSTAMP:" + carimbo);
        if (hora != null) {
            LocalDateTime ini = LocalDateTime.of(dia, hora);
            l.add("DTSTART:" + UTC.format(ini.atZone(fuso).withZoneSameInstant(ZoneOffset.UTC)));
            l.add("DTEND:" + UTC.format(ini.plusMinutes(minutos).atZone(fuso).withZoneSameInstant(ZoneOffset.UTC)));
        } else {
            l.add("DTSTART;VALUE=DATE:" + dia.toString().replace("-", ""));
            l.add("DTEND;VALUE=DATE:" + dia.plusDays(1).toString().replace("-", ""));
        }
        l.add("SUMMARY:" + esc(titulo));
        if (!desc.isEmpty())
            l.add("DESCRIPTION:" + esc(desc));
        if (!local.isEmpty())
            l.add("LOCATION:" + esc(local));
        l.add("URL:" + config.urlPublica() + "/");
        if (hora != null) {
            l.add("BEGIN:VALARM");
            l.add("ACTION:DISPLAY");
            l.add("DESCRIPTION:" + esc(titulo));
            l.add("TRIGGER:-PT60M");
            l.add("END:VALARM");
        }
        l.add("END:VEVENT");
    }

    private static LocalTime hora(String h) {
        try {
            return h == null || h.isEmpty() ? LocalTime.of(20, 0) : LocalTime.parse(h.length() == 5 ? h : h.substring(0, Math.min(8, h.length())));
        } catch (DateTimeParseException e) {
            return LocalTime.of(20, 0);
        }
    }

    private static boolean https(String u) {
        return u != null && u.trim().toLowerCase(java.util.Locale.ROOT).startsWith("https://");
    }

    /** Escapa texto conforme o padrão iCalendar. */
    static String esc(String s) {
        return (s == null ? "" : s).replace("\\", "\\\\").replace("\r\n", "\n").replace("\r", "\n").replace("\n", "\\n").replace(",", "\\,").replace(";", "\\;");
    }

    /** Linhas de no máximo 75 bytes; a continuação começa com um espaço (sem cortar um caractere ao meio). */
    static void dobrar(StringBuilder b, String linha) {
        int bytes = 0;
        for (int i = 0; i < linha.length();) {
            int cp = linha.codePointAt(i);
            int n = new String(Character.toChars(cp)).getBytes(StandardCharsets.UTF_8).length;
            if (bytes + n > 73) {
                b.append("\r\n ");
                bytes = 1;
            }
            b.appendCodePoint(cp);
            bytes += n;
            i += Character.charCount(cp);
        }
        b.append("\r\n");
    }
}
