package br.com.monetize.portal.auth;

/** Quem está fazendo a requisição: um mentor (acesso total) ou um aluno (só o que é dele e da turma dele). */
public final class Usuario {

    public enum Tipo {
        MENTOR, ALUNO
    }

    public final Tipo tipo;
    public final long id;
    public final String nome;
    public final String email;
    /** Turma do aluno (0 = sem turma). Sempre 0 para mentor. */
    public final long turmaId;
    /** Sessão de login que originou a requisição (0 para tarefas internas do servidor). */
    public final long sessaoId;

    public Usuario(Tipo tipo, long id, String nome, String email, long turmaId, long sessaoId) {
        this.tipo = tipo;
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.turmaId = turmaId;
        this.sessaoId = sessaoId;
    }

    public boolean mentor() {
        return tipo == Tipo.MENTOR;
    }

    public boolean aluno() {
        return tipo == Tipo.ALUNO;
    }

    /** Usuário interno, para as rotinas automáticas (lembretes, fila de envio). Tem acesso de mentor. */
    public static Usuario sistema() {
        return new Usuario(Tipo.MENTOR, 0, "Sistema", "", 0, 0);
    }

    @Override
    public String toString() {
        return (mentor() ? "mentor#" : "aluno#") + id;
    }
}
