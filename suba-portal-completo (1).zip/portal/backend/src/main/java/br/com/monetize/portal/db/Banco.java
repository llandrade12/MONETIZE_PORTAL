package br.com.monetize.portal.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import br.com.monetize.portal.util.Log;

/**
 * Acesso ao banco por JDBC, com um conjunto pequeno de conexões reaproveitadas.
 *
 * Todo o SQL do sistema é simples e portátil (MySQL 8, MariaDB 10.4 ou mais novo); datas são gravadas
 * como LocalDateTime no fuso configurado, sem conversão pelo driver.
 */
public final class Banco implements AutoCloseable {

    /** Operação que usa uma conexão. */
    public interface Uso<T> {
        T com(Connection c) throws SQLException;
    }

    /** Leitura de uma linha do resultado. */
    public interface Linha<T> {
        T ler(ResultSet r) throws SQLException;
    }

    /** Erro de banco convertido em exceção não verificada. */
    public static final class BancoException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        public BancoException(String m, Throwable causa) {
            super(m, causa);
        }
    }

    private final String url, usuario, senha;
    private final int maximo;
    private final BlockingQueue<Connection> livres;
    private final AtomicInteger abertas = new AtomicInteger();
    private volatile boolean fechado;

    public Banco(String url, String usuario, String senha, int maximo) {
        this.url = url;
        this.usuario = usuario;
        this.senha = senha;
        this.maximo = maximo;
        this.livres = new ArrayBlockingQueue<>(maximo);
    }

    public String url() {
        return url;
    }

    private Connection abrir() throws SQLException {
        Connection c = usuario == null || usuario.isEmpty() ? DriverManager.getConnection(url) : DriverManager.getConnection(url, usuario, senha);
        c.setAutoCommit(true);
        return c;
    }

    private Connection pegar() throws SQLException {
        if (fechado)
            throw new SQLException("Banco encerrado");
        while (true) {
            Connection c = livres.poll();
            if (c == null)
                break;
            if (valida(c))
                return c;
            descartar(c);
        }
        while (true) {
            int n = abertas.get();
            if (n >= maximo)
                break;
            if (abertas.compareAndSet(n, n + 1)) {
                try {
                    return abrir();
                } catch (SQLException | RuntimeException e) {
                    abertas.decrementAndGet();
                    throw e;
                }
            }
        }
        try {
            Connection c = livres.poll(20, TimeUnit.SECONDS);
            if (c == null)
                throw new SQLException("Banco ocupado: nenhuma conexão livre em 20 segundos");
            if (valida(c))
                return c;
            descartar(c);
            return pegar();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new SQLException("Interrompido esperando conexão");
        }
    }

    private static boolean valida(Connection c) {
        try {
            return !c.isClosed() && c.isValid(3);
        } catch (SQLException e) {
            return false;
        }
    }

    private void descartar(Connection c) {
        abertas.decrementAndGet();
        try {
            c.close();
        } catch (SQLException e) {
            /* conexão já estava perdida */
        }
    }

    private void devolver(Connection c, boolean saudavel) {
        if (!saudavel || fechado) {
            descartar(c);
            return;
        }
        try {
            if (!c.getAutoCommit())
                c.setAutoCommit(true);
        } catch (SQLException e) {
            descartar(c);
            return;
        }
        if (!livres.offer(c))
            descartar(c);
    }

    /** Executa com uma conexão em modo de confirmação automática. */
    public <T> T usar(Uso<T> uso) {
        Connection c;
        try {
            c = pegar();
        } catch (SQLException e) {
            throw new BancoException("Não foi possível conectar ao banco de dados: " + e.getMessage(), e);
        }
        boolean ok = false;
        try {
            T r = uso.com(c);
            ok = true;
            return r;
        } catch (SQLException e) {
            throw new BancoException("Erro no banco de dados: " + e.getMessage(), e);
        } catch (RuntimeException | Error e) {
            ok = true; /* a conexão continua boa: o erro foi da regra, não do banco */
            throw e;
        } finally {
            devolver(c, ok);
        }
    }

    /** Executa tudo ou nada: se algo falhar, desfaz. */
    public <T> T transacao(Uso<T> uso) {
        Connection c;
        try {
            c = pegar();
        } catch (SQLException e) {
            throw new BancoException("Não foi possível conectar ao banco de dados: " + e.getMessage(), e);
        }
        boolean ok = false;
        try {
            c.setAutoCommit(false);
            T r = uso.com(c);
            c.commit();
            ok = true;
            return r;
        } catch (SQLException e) {
            desfazer(c);
            throw new BancoException("Erro no banco de dados: " + e.getMessage(), e);
        } catch (RuntimeException | Error e) {
            desfazer(c);
            ok = true; /* a conexão continua boa: o erro foi da regra, não do banco */
            throw e;
        } finally {
            devolver(c, ok);
        }
    }

    private static void desfazer(Connection c) {
        try {
            c.rollback();
        } catch (SQLException e) {
            Log.aviso("Falha ao desfazer a transação: " + e.getMessage());
        }
    }

    /* ---------- atalhos ---------- */

    public static void parametros(PreparedStatement ps, Object... args) throws SQLException {
        for (int i = 0; i < args.length; i++) {
            Object a = args[i];
            if (a == null)
                ps.setNull(i + 1, Types.NULL);
            else if (a instanceof String)
                ps.setString(i + 1, (String) a);
            else if (a instanceof Long)
                ps.setLong(i + 1, (Long) a);
            else if (a instanceof Integer)
                ps.setInt(i + 1, (Integer) a);
            else if (a instanceof Boolean)
                ps.setInt(i + 1, ((Boolean) a) ? 1 : 0);
            else if (a instanceof LocalDateTime)
                ps.setObject(i + 1, a);
            else
                ps.setObject(i + 1, a);
        }
    }

    public static int executar(Connection c, String sql, Object... args) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            parametros(ps, args);
            return ps.executeUpdate();
        }
    }

    /** INSERT em tabela com chave AUTO_INCREMENT; devolve a chave gerada. */
    public static long inserir(Connection c, String sql, Object... args) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            parametros(ps, args);
            ps.executeUpdate();
            try (ResultSet r = ps.getGeneratedKeys()) {
                return r.next() ? r.getLong(1) : 0L;
            }
        }
    }

    public static <T> List<T> consultar(Connection c, String sql, Linha<T> linha, Object... args) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            parametros(ps, args);
            try (ResultSet r = ps.executeQuery()) {
                List<T> l = new ArrayList<>();
                while (r.next())
                    l.add(linha.ler(r));
                return l;
            }
        }
    }

    public static <T> T um(Connection c, String sql, Linha<T> linha, Object... args) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            parametros(ps, args);
            try (ResultSet r = ps.executeQuery()) {
                return r.next() ? linha.ler(r) : null;
            }
        }
    }

    /** Long de uma coluna que pode ser nula. */
    public static Long longOuNulo(ResultSet r, String coluna) throws SQLException {
        long v = r.getLong(coluna);
        return r.wasNull() ? null : v;
    }

    public static Long longOuNulo(ResultSet r, int coluna) throws SQLException {
        long v = r.getLong(coluna);
        return r.wasNull() ? null : v;
    }

    public static LocalDateTime dataHora(ResultSet r, String coluna) throws SQLException {
        return r.getObject(coluna, LocalDateTime.class);
    }

    @Override
    public void close() {
        fechado = true;
        Connection c;
        while ((c = livres.poll()) != null) {
            try {
                c.close();
            } catch (SQLException e) {
                /* encerrando */
            }
        }
    }
}
