package br.com.monetize.portal.dados;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import br.com.monetize.portal.auth.Usuario;
import br.com.monetize.portal.dados.Colecao.Leitura;
import br.com.monetize.portal.dados.Colecao.Tipo;
import br.com.monetize.portal.dados.Repositorio.AlunoLinha;
import br.com.monetize.portal.dados.Repositorio.Reg;
import br.com.monetize.portal.db.Banco;
import br.com.monetize.portal.util.Json;

/**
 * Monta o que cada pessoa recebe do banco: o estado completo (ao abrir o portal) e só as alterações
 * (a cada conferência periódica). É aqui que fica a regra de quem enxerga o quê.
 *
 * Mentor: tudo, menos as anotações do diário que o aluno não compartilhou.
 * Aluno: o cadastro dele, a turma dele, as aulas, tarefas, eventos e recomendações da turma dele,
 * os avisos dirigidos a ele e os registros dele (entregas, notas, presença, metas...). Nada de outros alunos.
 */
public final class Estado {

    private Estado() {
    }

    /** Parâmetro com o número da alteração até onde as marcas de exclusão já foram descartadas. */
    public static final String PARAM_PURGA = "rev_purga";

    private static final class Ctx {
        final Connection c;
        final Usuario u;
        Map<Long, String> nomes;

        Ctx(Connection c, Usuario u) {
            this.c = c;
            this.u = u;
        }

        String nome(long aid) throws SQLException {
            if (nomes == null) {
                nomes = new HashMap<>();
                for (AlunoLinha a : Repositorio.alunos(c))
                    nomes.put(a.id, a.nome);
            }
            return nomes.get(aid);
        }
    }

    /* ---------------------------------------------------------------- estado completo */

    /** JSON {"rev":n,"dados":{...}} com tudo o que a pessoa pode ver. */
    public static String completo(Connection c, Usuario u) throws SQLException {
        Ctx ctx = new Ctx(c, u);
        long rev = Repositorio.revAtual(c);
        Map<String, List<String[]>> porColecao = new LinkedHashMap<>();
        for (Colecao col : Colecoes.todas())
            porColecao.put(col.nome, new ArrayList<>());

        List<Reg> regs = u.mentor() ? Repositorio.vivos(c) : Repositorio.vivosParaAluno(c, u.id);
        for (Reg r : regs) {
            Colecao col = Colecoes.de(r.colecao);
            if (col == null)
                continue;
            String json = paraLeitor(ctx, col, r.chave, r.alunoId, r.dados);
            if (json != null)
                porColecao.get(col.nome).add(new String[] { r.chave, json });
        }
        List<String[]> alunos = porColecao.get(Colecoes.ALUNOS);
        if (u.mentor()) {
            for (AlunoLinha a : Repositorio.alunos(c))
                alunos.add(new String[] { String.valueOf(a.id), alunoJson(a) });
        } else {
            AlunoLinha eu = Repositorio.lerAluno(c, u.id);
            if (eu != null)
                alunos.add(new String[] { String.valueOf(eu.id), alunoJson(eu) });
        }

        StringBuilder b = new StringBuilder(8192);
        b.append("{\"rev\":").append(rev).append(",\"dados\":{");
        boolean primeira = true;
        for (Colecao col : Colecoes.todas()) {
            List<String[]> itens = porColecao.get(col.nome);
            if (itens.isEmpty())
                continue;
            if (!primeira)
                b.append(',');
            primeira = false;
            Json.aspas(b, col.nome);
            b.append(':');
            if (col.tipo == Tipo.VALOR) {
                b.append(itens.get(itens.size() - 1)[1]);
            } else if (col.tipo == Tipo.LISTA) {
                if (col.recentePrimeiro)
                    Collections.reverse(itens);
                b.append('[');
                for (int i = 0; i < itens.size(); i++) {
                    if (i > 0)
                        b.append(',');
                    b.append(itens.get(i)[1]);
                }
                b.append(']');
            } else {
                b.append('{');
                for (int i = 0; i < itens.size(); i++) {
                    if (i > 0)
                        b.append(',');
                    Json.aspas(b, itens.get(i)[0]);
                    b.append(':').append(itens.get(i)[1]);
                }
                b.append('}');
            }
        }
        b.append("}}");
        return b.toString();
    }

    /* ---------------------------------------------------------------- só o que mudou */

    /**
     * JSON {"rev":n,"mud":[{"c":coleção,"k":chave,"v":valor} | {"c":coleção,"k":chave,"rm":true}]}.
     * Devolve {"recarregar":true} quando o aparelho ficou tempo demais sem conferir e precisa baixar tudo de novo.
     */
    public static String mudancas(Connection c, Usuario u, long desde) throws SQLException {
        long rev = Repositorio.revAtual(c);
        if (desde > rev || desde < purga(c))
            return "{\"rev\":" + rev + ",\"recarregar\":true}";
        StringBuilder b = new StringBuilder(1024);
        b.append("{\"rev\":").append(rev).append(",\"mud\":[");
        if (desde < rev) {
            Ctx ctx = new Ctx(c, u);
            boolean primeiro = true;
            List<Reg> regs = u.mentor() ? Repositorio.desde(c, desde) : Repositorio.desdeParaAluno(c, desde, u.id);
            for (Reg r : regs) {
                Colecao col = Colecoes.de(r.colecao);
                if (col == null || (u.aluno() && col.leitura == Leitura.NADA))
                    continue;
                String json = r.apagado ? null : paraLeitor(ctx, col, r.chave, r.alunoId, r.dados);
                if (!primeiro)
                    b.append(',');
                primeiro = false;
                mud(b, col.nome, r.chave, json);
            }
            for (AlunoLinha a : Repositorio.alunosDesde(c, desde)) {
                if (u.aluno() && a.id != u.id)
                    continue;
                if (!primeiro)
                    b.append(',');
                primeiro = false;
                mud(b, Colecoes.ALUNOS, String.valueOf(a.id), alunoJson(a));
            }
        }
        b.append("]}");
        return b.toString();
    }

    /** Uma alteração no formato enviado ao portal (json null = registro removido). */
    public static void mud(StringBuilder b, String colecao, String chave, String json) {
        b.append("{\"c\":");
        Json.aspas(b, colecao);
        b.append(",\"k\":");
        Json.aspas(b, chave);
        if (json == null)
            b.append(",\"rm\":true}");
        else
            b.append(",\"v\":").append(json).append('}');
    }

    public static long purga(Connection c) throws SQLException {
        String v = Banco.um(c, "SELECT valor FROM parametro WHERE nome = ?", r -> r.getString(1), PARAM_PURGA);
        try {
            return v == null ? 0 : Long.parseLong(v.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /* ---------------------------------------------------------------- quem vê o quê */

    /** O registro como esta pessoa deve receber, ou null se ela não pode ver. */
    public static String paraLeitor(Connection c, Usuario u, Colecao col, String chave, Long alunoId, String dados) throws SQLException {
        return paraLeitor(new Ctx(c, u), col, chave, alunoId, dados);
    }

    private static String paraLeitor(Ctx ctx, Colecao col, String chave, Long alunoId, String dados) throws SQLException {
        Usuario u = ctx.u;
        if (u.mentor()) {
            /* O diário é do aluno: o mentor só recebe o que foi compartilhado. */
            if (col.nome.equals("diario"))
                return Json.bool(Json.obj(Json.ler(dados)), "share") ? dados : null;
            return dados;
        }
        switch (col.leitura) {
            case NADA:
                return null;
            case TODOS:
                return dados;
            case PROPRIO:
                return alunoId != null && alunoId == u.id ? dados : null;
            case TURMA:
                return naTurma(Json.obj(Json.ler(dados)), u.turmaId) ? dados : null;
            default:
                break;
        }
        switch (col.nome) {
            case "turmas":
                return u.turmaId > 0 && chave.equals(String.valueOf(u.turmaId)) ? dados : null;
            case "certs":
                return u.turmaId > 0 && chave.equals(String.valueOf(u.turmaId)) ? dados : null;
            case "cfg": {
                Map<String, Object> cfg = Json.obj(Json.ler(dados));
                if (cfg == null)
                    return null;
                cfg.remove("webhook");
                cfg.remove("mentorEmail");
                cfg.remove("mentorTel");
                return Json.texto(cfg);
            }
            case "avisos": {
                Map<String, Object> a = Json.obj(Json.ler(dados));
                if (a == null || !avisoPara(a, u))
                    return null;
                /* Quem comentou: o aluno não recebe o cadastro dos colegas, então o nome vai junto do comentário. */
                boolean mudou = false;
                for (Object o : Json.lista(a, "coms")) {
                    Map<String, Object> com = Json.obj(o);
                    long aid = com == null ? 0 : Json.num(com, "aid", 0);
                    if (aid > 0) {
                        String nome = ctx.nome(aid);
                        if (nome != null) {
                            com.put("nome", nome);
                            mudou = true;
                        }
                    }
                }
                return mudou ? Json.texto(a) : dados;
            }
            default:
                return null;
        }
    }

    /** Aula, tarefa, evento ou recomendação vale para a turma? Lista vazia = todas as turmas. */
    public static boolean naTurma(Map<String, Object> registro, long turmaId) {
        if (registro == null)
            return false;
        List<Object> turmas = Json.lista(registro, "turmas");
        if (turmas.isEmpty())
            return true;
        if (turmaId <= 0)
            return false;
        for (Object t : turmas)
            if (Json.num(t, -1) == turmaId)
                return true;
        return false;
    }

    /** O aviso é para este aluno? alvo = "todos", "t" + id da turma, ou o id do aluno. */
    public static boolean avisoPara(Map<String, Object> aviso, Usuario u) {
        Object alvo = aviso.get("alvo");
        if ("todos".equals(alvo))
            return true;
        if (alvo instanceof String) {
            String s = (String) alvo;
            if (s.startsWith("t"))
                return s.equals("t" + u.turmaId);
            return s.equals(String.valueOf(u.id));
        }
        return alvo instanceof Number && ((Number) alvo).longValue() == u.id;
    }

    /** Ficha do aluno como o portal recebe: os dados guardados mais o indicador "temSenha". */
    public static String alunoJson(AlunoLinha a) {
        String d = a.dados.trim();
        String extra = "\"temSenha\":" + (a.senhaHash != null && !a.senhaHash.isEmpty());
        if (d.length() <= 2)
            return "{" + extra + "}";
        return d.substring(0, d.length() - 1) + "," + extra + "}";
    }
}
