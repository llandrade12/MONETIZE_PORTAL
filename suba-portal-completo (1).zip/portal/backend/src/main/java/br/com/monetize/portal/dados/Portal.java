package br.com.monetize.portal.dados;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.monetize.portal.dados.Repositorio.AlunoLinha;
import br.com.monetize.portal.dados.Repositorio.Reg;
import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Texto;

/**
 * Retrato dos dados do portal em memória, com as mesmas regras de cálculo que o navegador usa
 * (web/js/compartilhado/core/selectors.js): quais aulas e tarefas valem para cada aluno, prazos,
 * atrasos e frequência. O servidor precisa delas para os lembretes automáticos e para a agenda.
 *
 * Ao mudar uma regra no selectors.js, mude aqui também.
 */
public final class Portal {

    public final List<Map<String, Object>> turmas = new ArrayList<>();
    public final List<Map<String, Object>> alunos = new ArrayList<>();
    public final List<Map<String, Object>> aulas = new ArrayList<>();
    public final List<Map<String, Object>> tarefas = new ArrayList<>();
    public final List<Map<String, Object>> eventos = new ArrayList<>();
    public final List<Map<String, Object>> metas = new ArrayList<>();
    public final Map<String, Object> ent = new HashMap<>();
    public final Map<String, Object> prazo = new HashMap<>();
    public final Map<String, Object> pres = new HashMap<>();
    public final Map<String, Object> vis = new HashMap<>();
    public Map<String, Object> cfg = Padroes.cfg();
    public String mentor = "Mentor";
    /** Data de hoje no fuso do portal (AAAA-MM-DD). */
    public final String hoje;

    public Portal(String hoje) {
        this.hoje = hoje;
    }

    /** Lê do banco o que as regras precisam. */
    public static Portal carregar(Connection c, String hoje) throws SQLException {
        Portal p = new Portal(hoje);
        for (AlunoLinha a : Repositorio.alunos(c)) {
            Map<String, Object> m = Json.obj(Json.ler(a.dados));
            if (m != null)
                p.alunos.add(m);
        }
        for (Reg r : Repositorio.vivos(c)) {
            switch (r.colecao) {
                case "turmas":
                    adicionar(p.turmas, r);
                    break;
                case "aulas":
                    adicionar(p.aulas, r);
                    break;
                case "tarefas":
                    adicionar(p.tarefas, r);
                    break;
                case "eventos":
                    adicionar(p.eventos, r);
                    break;
                case "metas":
                    adicionar(p.metas, r);
                    break;
                case "ent":
                    p.ent.put(r.chave, Json.ler(r.dados));
                    break;
                case "prazo":
                    p.prazo.put(r.chave, Json.ler(r.dados));
                    break;
                case "pres":
                    p.pres.put(r.chave, Json.ler(r.dados));
                    break;
                case "vis":
                    p.vis.put(r.chave, Json.ler(r.dados));
                    break;
                case "cfg":
                    p.cfg = Padroes.cfgCom(Json.obj(Json.ler(r.dados)));
                    break;
                case "mentor": {
                    Object v = Json.ler(r.dados);
                    if (v instanceof String && !((String) v).isEmpty())
                        p.mentor = (String) v;
                    break;
                }
                default:
                    break;
            }
        }
        return p;
    }

    private static void adicionar(List<Map<String, Object>> l, Reg r) {
        Map<String, Object> m = Json.obj(Json.ler(r.dados));
        if (m != null)
            l.add(m);
    }

    /* ---------------------------------------------------------------- alunos e turmas */

    public Map<String, Object> aluno(long id) {
        for (Map<String, Object> a : alunos)
            if (Json.num(a, "id", 0) == id)
                return a;
        return null;
    }

    public Map<String, Object> turma(long id) {
        for (Map<String, Object> t : turmas)
            if (Json.num(t, "id", 0) == id)
                return t;
        return null;
    }

    /** Turma do aluno para os filtros: o id da turma ou -1 (sem turma). */
    public long turmaDe(Map<String, Object> aluno) {
        long t = aluno == null ? 0 : Json.num(aluno, "turma", 0);
        return t > 0 ? t : -1;
    }

    /** Item com lista de turmas (aula, tarefa, evento). tid 0 = qualquer; lista vazia = vale para todas. */
    public static boolean naTurma(Map<String, Object> x, long tid) {
        if (tid == 0)
            return true;
        List<Object> turmas = Json.lista(x, "turmas");
        if (turmas.isEmpty())
            return true;
        for (Object t : turmas)
            if (Json.num(t, Long.MIN_VALUE) == tid)
                return true;
        return false;
    }

    /* ---------------------------------------------------------------- aulas */

    public List<Map<String, Object>> aulasDe(long tid) {
        List<Map<String, Object>> l = new ArrayList<>();
        for (Map<String, Object> a : aulas)
            if (naTurma(a, tid))
                l.add(a);
        l.sort((a, b) -> {
            int c = (Json.str(a, "date") + Json.str(a, "hora")).compareTo(Json.str(b, "date") + Json.str(b, "hora"));
            return c != 0 ? c : Long.compare(Json.num(a, "n", 0), Json.num(b, "n", 0));
        });
        return l;
    }

    public static boolean realizada(Map<String, Object> aula) {
        String s = Json.str(aula, "status");
        return s.equals("realizada") || s.equals("parcial");
    }

    public List<Map<String, Object>> realizadas(long tid) {
        List<Map<String, Object>> l = new ArrayList<>();
        for (Map<String, Object> a : aulasDe(tid))
            if (realizada(a))
                l.add(a);
        return l;
    }

    /* ---------------------------------------------------------------- tarefas */

    public List<Map<String, Object>> tarefasDe(Map<String, Object> aluno) {
        List<Map<String, Object>> l = new ArrayList<>();
        long tid = turmaDe(aluno);
        for (Map<String, Object> t : tarefas)
            if (naTurma(t, tid))
                l.add(t);
        return l;
    }

    private static String chave(Map<String, Object> aluno, Object item) {
        return Gravador.chaveDe(aluno.get("id")) + "-" + Gravador.chaveDe(item);
    }

    /** Prazo do aluno: o reaberto pelo mentor, ou o da tarefa. */
    public String prazoDe(Map<String, Object> aluno, Map<String, Object> tarefa) {
        Object p = prazo.get(chave(aluno, tarefa.get("id")));
        return Json.verdadeiro(p) ? String.valueOf(p) : Json.str(tarefa, "due");
    }

    /** A tarefa já está liberada para os alunos? (data de liberação, ou 7 dias antes do prazo) */
    public boolean liberada(Map<String, Object> tarefa) {
        String lib = Json.str(tarefa, "lib");
        if (lib.isEmpty())
            lib = Texto.somaDias(Json.str(tarefa, "due"), -7);
        return !lib.isEmpty() && lib.compareTo(hoje) <= 0;
    }

    public boolean entregou(Map<String, Object> aluno, Map<String, Object> tarefa) {
        return Json.verdadeiro(ent.get(chave(aluno, tarefa.get("id"))));
    }

    public boolean atrasada(Map<String, Object> aluno, Map<String, Object> tarefa) {
        return liberada(tarefa) && !entregou(aluno, tarefa) && prazoDe(aluno, tarefa).compareTo(hoje) < 0;
    }

    public List<Map<String, Object>> atrasos(Map<String, Object> aluno) {
        List<Map<String, Object>> l = new ArrayList<>();
        for (Map<String, Object> t : tarefasDe(aluno))
            if (atrasada(aluno, t))
                l.add(t);
        return l;
    }

    /* ---------------------------------------------------------------- presença e frequência */

    public boolean assistiu(Map<String, Object> aluno, Map<String, Object> aula) {
        return Json.verdadeiro(vis.get(chave(aluno, aula.get("n"))));
    }

    /** Encontros que contam para o aluno: os realizados na turma dele desde a matrícula. */
    public List<Map<String, Object>> baseDeFrequencia(Map<String, Object> aluno) {
        String mat = Json.str(aluno, "mat");
        List<Map<String, Object>> l = new ArrayList<>();
        for (Map<String, Object> a : realizadas(turmaDe(aluno)))
            if (mat.isEmpty() || Json.str(a, "date").compareTo(mat) >= 0)
                l.add(a);
        return l;
    }

    /** Situação efetiva em um encontro: P, A, J, C (compensada pela gravação) ou F. */
    public String situacao(Map<String, Object> aluno, Map<String, Object> aula) {
        Object s = pres.get(chave(aluno, aula.get("n")));
        if ("P".equals(s) || "A".equals(s) || "J".equals(s))
            return (String) s;
        return Json.bool(cfg, "compensa") && assistiu(aluno, aula) ? "C" : "F";
    }

    private boolean contaPresenca(String s) {
        return s.equals("P") || s.equals("A") || s.equals("C") || (s.equals("J") && Json.bool(cfg, "justAbona"));
    }

    public double frequenciaMinima(Map<String, Object> aluno) {
        Map<String, Object> t = turma(Json.num(aluno, "turma", 0));
        Object fm = t == null ? null : t.get("freqMin");
        if (fm != null && !"".equals(fm))
            return Json.dec(fm, 0);
        return Json.dec(cfg.get("freqMin"), 75);
    }

    /** Total de encontros previstos para o aluno (cadastrados ou planejados nas unidades da turma). */
    public int totalPrevisto(Map<String, Object> aluno) {
        String mat = Json.str(aluno, "mat");
        int todas = 0, depois = 0;
        for (Map<String, Object> a : aulasDe(turmaDe(aluno))) {
            if (Json.str(a, "status").equals("cancelada"))
                continue;
            todas++;
            if (mat.isEmpty() || Json.str(a, "date").compareTo(mat) >= 0)
                depois++;
        }
        long plano = 0;
        Map<String, Object> t = turma(Json.num(aluno, "turma", 0));
        for (Object u : Json.lista(t, "unidades"))
            plano += Math.max(0, Json.num(Json.obj(u), "qtd", 0));
        return (int) Math.max(depois, plano - (todas - depois));
    }

    /** Resumo da frequência do aluno. */
    public static final class Frequencia {
        /** Encontros que contam. */
        public int n;
        /** Presenças (inclui atraso, compensada e, conforme a regra, justificada). */
        public int ok;
        public int pct;
        public double min;
        public int faltas;
        /** Faltas que ainda cabem antes de ficar abaixo do mínimo. */
        public int restam;
        public boolean abaixo;

        /** O mínimo como aparece nas mensagens: sem casas decimais quando é inteiro. */
        public String minTexto() {
            return min == Math.rint(min) ? String.valueOf((long) min) : String.valueOf(min).replace('.', ',');
        }
    }

    public Frequencia frequencia(Map<String, Object> aluno) {
        Frequencia f = new Frequencia();
        List<Map<String, Object>> base = baseDeFrequencia(aluno);
        f.n = base.size();
        for (Map<String, Object> a : base)
            if (contaPresenca(situacao(aluno, a)))
                f.ok++;
        f.min = frequenciaMinima(aluno);
        f.pct = f.n > 0 ? pct(f.ok, f.n) : 100;
        int tot = totalPrevisto(aluno);
        int maxFaltas = (int) Math.floor(tot * (100 - f.min) / 100.0 + 1e-9);
        f.faltas = f.n - f.ok;
        f.restam = maxFaltas - f.faltas;
        f.abaixo = f.n > 0 && pct(f.ok, f.n) < f.min;
        return f;
    }

    public static int pct(int a, int b) {
        return b == 0 ? 0 : (int) Math.round(a * 100.0 / b);
    }
}
