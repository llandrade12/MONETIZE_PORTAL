package br.com.monetize.portal.http;

/** Resposta de erro para o portal: código HTTP, código curto e mensagem para a pessoa. */
public final class ErroHttp extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public final int status;
    public final String codigo;

    public ErroHttp(int status, String codigo, String mensagem) {
        super(mensagem, null, false, false);
        this.status = status;
        this.codigo = codigo;
    }

    public static ErroHttp pedidoInvalido(String mensagem) {
        return new ErroHttp(400, "pedido-invalido", mensagem);
    }

    public static ErroHttp naoEncontrado() {
        return new ErroHttp(404, "nao-encontrado", "Não encontrado");
    }

    public static ErroHttp proibido() {
        return new ErroHttp(403, "sem-permissao", "Você não tem permissão para isto");
    }
}
