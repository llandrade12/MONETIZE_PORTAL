package br.com.monetize.portal.dados;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import br.com.monetize.portal.util.Json;

/**
 * Valores iniciais do portal. São os mesmos de web/js/compartilhado/data/constants.js (CFG0, COMP0 e FAQ0):
 * ao mudar um padrão, mude nos dois lugares.
 */
public final class Padroes {

    private Padroes() {
    }

    /** Regras configuráveis (Configurações e Notificações > Automação). */
    public static Map<String, Object> cfg() {
        Map<String, Object> c = new LinkedHashMap<>();
        c.put("freqMin", 75L);
        c.put("certFreq", true);
        c.put("compensa", true);
        c.put("justAbona", true);
        c.put("pctVisto", 90L);
        c.put("autoOn", true);
        c.put("lembAula", 1L);
        c.put("lembPrazo", 2L);
        c.put("atrasoCada", 3L);
        c.put("escala", 7L);
        c.put("canais", Json.mapa("email", true, "whats", true));
        c.put("webhook", "");
        c.put("mentorEmail", "");
        c.put("mentorTel", "");
        return c;
    }

    /** Configuração guardada, completada com os padrões. */
    public static Map<String, Object> cfgCom(Map<String, Object> guardada) {
        Map<String, Object> c = cfg();
        if (guardada != null) {
            Map<String, Object> canais = Json.obj(c.get("canais"));
            c.putAll(guardada);
            Map<String, Object> g = Json.obj(guardada.get("canais"));
            if (g != null)
                canais.putAll(g);
            c.put("canais", canais);
        }
        return c;
    }

    /** Competências iniciais (nome e peso). O mentor edita em Competências. */
    public static List<Object> competencias() {
        Object[][] c = { { "Autorresponsabilidade", 25L }, { "Disciplina", 25L }, { "Gestão", 20L }, { "Liderança", 15L }, { "Finanças", 15L } };
        List<Object> l = new ArrayList<>();
        for (Object[] x : c)
            l.add(Json.mapa("nome", x[0], "peso", x[1], "desc", ""));
        return l;
    }

    /** Perguntas frequentes iniciais (categoria, pergunta, resposta). O mentor edita em Suporte. */
    public static List<Map<String, Object>> faq() {
        String[][] f = {
                { "Acesso", "Esqueci minha senha. O que eu faço?", "Na tela de entrada, toque em \"Esqueci minha senha\" para receber um link no seu e-mail. Se o e-mail não chegar, peça ao seu mentor uma senha nova. Depois de entrar, você pode trocá-la em Perfil e certificado, no botão \"Alterar senha\"." },
                { "Acesso", "Como recebo os avisos no celular?", "Abra o portal no navegador do celular e use \"Instalar aplicativo\". Depois, em Perfil e certificado, ligue \"Notificações neste aparelho\". No iPhone, as notificações só funcionam com o portal instalado na Tela de Início." },
                { "Aulas", "Perdi o encontro ao vivo. Como recupero?", "A gravação fica na página da aula depois do encontro. Assistindo até o fim, a aula é marcada como assistida automaticamente e a falta pode ser compensada, conforme a regra da sua turma." },
                { "Aulas", "Parei o vídeo no meio. Preciso recomeçar?", "Não. O portal lembra onde você parou e continua do mesmo ponto, em qualquer aparelho." },
                { "Aulas", "Como coloco os encontros na minha agenda?", "Em Agenda, use \"Assinar no Google Agenda\": os encontros da sua turma passam a aparecer na sua agenda e se atualizam sozinhos quando o mentor muda uma data." },
                { "Frequência", "Como funciona a frequência mínima?", "Contam os encontros realizados desde a sua matrícula. Em \"Minha frequência\" você vê o percentual, quantas faltas ainda pode ter e o status de cada encontro." },
                { "Frequência", "Tive um imprevisto e faltei. Posso justificar?", "Sim. Em \"Minha frequência\", toque em \"Justificar\" no encontro e escreva o motivo. O mentor aprova ou recusa e você é avisado." },
                { "Tarefas", "Fechei a janela da entrega sem enviar. Perdi o texto?", "Não. O texto fica salvo como rascunho automaticamente. Abra a tarefa de novo e continue de onde parou." },
                { "Certificado", "Quando recebo o certificado?", "No encerramento da turma, para quem atingiu a frequência mínima. Ele fica disponível no seu perfil." },
                { "Pagamento", "Onde vejo boletos e notas fiscais?", "O pagamento é feito na plataforma de vendas da matrícula. Se precisar de segunda via ou tiver cobrança indevida, abra um chamado na categoria Pagamento." } };
        List<Map<String, Object>> l = new ArrayList<>();
        for (int i = 0; i < f.length; i++)
            l.add(Json.mapa("id", "q" + i, "cat", f[i][0], "q", f[i][1], "a", f[i][2]));
        return l;
    }
}
