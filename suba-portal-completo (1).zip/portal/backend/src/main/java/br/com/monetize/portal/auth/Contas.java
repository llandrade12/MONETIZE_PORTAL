package br.com.monetize.portal.auth;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import br.com.monetize.portal.Config;
import br.com.monetize.portal.auth.Sessoes.Mentor;
import br.com.monetize.portal.dados.Colecoes;
import br.com.monetize.portal.dados.Repositorio;
import br.com.monetize.portal.dados.Repositorio.AlunoLinha;
import br.com.monetize.portal.dados.Sincronizador;
import br.com.monetize.portal.db.Banco;
import br.com.monetize.portal.http.ErroHttp;
import br.com.monetize.portal.servicos.Envios;
import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Log;
import br.com.monetize.portal.util.Senhas;
import br.com.monetize.portal.util.Texto;

/** Senhas e acessos: trocar a própria senha, "esqueci minha senha" por e-mail e as contas de mentor. */
public final class Contas {

    private final Banco banco;
    private final Config config;
    private final Sincronizador sinc;
    private final Sessoes sessoes;
    private final Envios envios;
    /** Pedidos de redefinição por e-mail e por endereço na última hora: {início da janela, quantidade}. */
    private final Map<String, long[]> pedidos = new ConcurrentHashMap<>();

    public Contas(Banco banco, Config config, Sincronizador sinc, Sessoes sessoes, Envios envios) {
        this.banco = banco;
        this.config = config;
        this.sinc = sinc;
        this.sessoes = sessoes;
        this.envios = envios;
    }

    private static void exigirForte(String senha) {
        if (!Senhas.forte(senha))
            throw new ErroHttp(400, "senha-fraca", "Use 8 ou mais caracteres, com letras e números");
    }

    /* ---------------------------------------------------------------- a própria senha */

    public void trocarSenha(Usuario u, String atual, String nova) {
        exigirForte(nova);
        String guardada = banco.usar(c -> u.mentor() ? Sessoes.mentorPorId(c, u.id).senhaHash : Repositorio.lerAluno(c, u.id).senhaHash);
        if (!Senhas.confere(atual, guardada, u.email))
            throw new ErroHttp(400, "senha-atual", "A senha atual não confere");
        String hash = Senhas.gerar(nova);
        gravarSenha(u.mentor(), u.id, hash, u);
    }

    /** Grava o resumo da senha e encerra as outras sessões da pessoa. manter = sessão que continua aberta (ou null). */
    private void gravarSenha(boolean mentor, long id, String hash, Usuario manter) {
        sinc.gravar(Usuario.sistema(), g -> {
            if (mentor) {
                Banco.executar(g.c, "UPDATE mentor SET senha_hash = ? WHERE id = ?", hash, id);
                Banco.executar(g.c, "DELETE FROM sessao WHERE mentor_id = ? AND id <> ?", id, manter == null ? 0L : manter.sessaoId);
            } else {
                /* O número da alteração sobe para o painel do mentor ver que o aluno agora tem senha. */
                Banco.executar(g.c, "UPDATE aluno SET senha_hash = ?, rev = ?, atualizado_em = ? WHERE id = ?", hash, g.rev, g.agora, id);
                Banco.executar(g.c, "DELETE FROM sessao WHERE aluno_id = ? AND id <> ?", id, manter == null ? 0L : manter.sessaoId);
                g.efeitos.mudou = true;
            }
            return null;
        });
    }

    /* ---------------------------------------------------------------- esqueci minha senha */

    /**
     * Envia o link de redefinição, se o e-mail for de alguém com acesso. A resposta para quem pediu é
     * sempre a mesma, para não revelar quais e-mails têm cadastro.
     */
    public void esqueci(String email, String ip) {
        if (!config.emailConfigurado())
            throw new ErroHttp(503, "sem-email", "O envio de e-mails não está configurado. Peça uma senha nova ao mentor.");
        String e = email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
        if (!e.matches("\\S+@\\S+\\.\\S+") || e.length() > 190)
            throw ErroHttp.pedidoInvalido("Informe um e-mail válido");
        if (!dentroDoLimite("e:" + e, 3) || !dentroDoLimite("ip:" + ip, 12))
            return;
        Object[] alvo = banco.usar(c -> {
            Mentor m = Sessoes.mentorPorEmail(c, e);
            if (m != null)
                return m.ativo ? new Object[] { true, m.id, m.nome, m.email } : null;
            AlunoLinha a = Repositorio.alunoPorEmail(c, e);
            return a != null && "ativo".equals(a.status) ? new Object[] { false, a.id, a.nome, a.email } : null;
        });
        if (alvo == null) {
            Log.depurar("Redefinição pedida para e-mail sem acesso: " + e);
            return;
        }
        boolean mentor = (Boolean) alvo[0];
        long id = (Long) alvo[1];
        String token = Texto.segredo(32);
        LocalDateTime agora = sinc.agora();
        banco.usar(c -> Banco.executar(c, "INSERT INTO redefinicao_senha (token_hash, mentor_id, aluno_id, criado_em, expira_em, usado) VALUES (?, ?, ?, ?, ?, 0)",
                Texto.sha256Hex(token), mentor ? id : null, mentor ? null : id, agora, agora.plusHours(1)));
        envios.emailAvulso((String) alvo[3], (String) alvo[2], "Criar nova senha da Área de Membros", Json.mapa("papel", "senha",
                "msg", "Recebemos um pedido para criar uma nova senha de acesso à Área de Membros. Use o botão abaixo (ou o link) em até 1 hora.",
                "link", config.urlPublica() + "/index.html#redefinir=" + token));
    }

    private boolean dentroDoLimite(String chave, int maximoPorHora) {
        long agora = System.currentTimeMillis();
        long[] p = pedidos.computeIfAbsent(chave, k -> new long[] { agora, 0 });
        synchronized (p) {
            if (agora - p[0] > 3_600_000L) {
                p[0] = agora;
                p[1] = 0;
            }
            if (p[1] >= maximoPorHora)
                return false;
            p[1]++;
        }
        if (pedidos.size() > 20_000)
            pedidos.entrySet().removeIf(x -> agora - x.getValue()[0] > 3_600_000L);
        return true;
    }

    /** Conclui a redefinição: confere o link, grava a senha nova e encerra as sessões abertas da pessoa. */
    public void redefinir(String token, String nova) {
        exigirForte(nova);
        if (token == null || token.length() < 20 || token.length() > 100)
            throw new ErroHttp(400, "link-invalido", "Este link não vale mais. Peça um novo em \"Esqueci minha senha\".");
        String hash = Texto.sha256Hex(token);
        LocalDateTime agora = sinc.agora();
        Object[] alvo = banco.transacao(c -> {
            Object[] r = Banco.um(c, "SELECT mentor_id, aluno_id, expira_em, usado FROM redefinicao_senha WHERE token_hash = ?",
                    x -> new Object[] { Banco.longOuNulo(x, "mentor_id"), Banco.longOuNulo(x, "aluno_id"), Banco.dataHora(x, "expira_em"), x.getInt("usado") != 0 }, hash);
            if (r == null || (Boolean) r[3] || r[2] == null || !((LocalDateTime) r[2]).isAfter(agora))
                return null;
            Banco.executar(c, "UPDATE redefinicao_senha SET usado = 1 WHERE token_hash = ?", hash);
            return r;
        });
        if (alvo == null)
            throw new ErroHttp(400, "link-invalido", "Este link não vale mais. Peça um novo em \"Esqueci minha senha\".");
        boolean mentor = alvo[0] != null;
        gravarSenha(mentor, (Long) (mentor ? alvo[0] : alvo[1]), Senhas.gerar(nova), null);
    }

    /* ---------------------------------------------------------------- contas de mentor */

    public List<Map<String, Object>> mentores() {
        return banco.usar(c -> Banco.consultar(c, "SELECT id, nome, email, ativo, ultimo_acesso FROM mentor ORDER BY id", r -> {
            LocalDateTime ult = Banco.dataHora(r, "ultimo_acesso");
            return Json.mapa("id", r.getLong("id"), "nome", r.getString("nome"), "email", r.getString("email"), "ativo", r.getInt("ativo") != 0,
                    "ultimo", ult == null ? "" : Texto.carimbo(ult));
        }));
    }

    public long criarMentor(String nome, String email, String senha) {
        String n = nome == null ? "" : Texto.semEmoji(nome).trim(), e = email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
        if (n.length() < 3 || n.length() > 160)
            throw ErroHttp.pedidoInvalido("Informe o nome");
        if (!e.matches("\\S+@\\S+\\.\\S+") || e.length() > 190)
            throw ErroHttp.pedidoInvalido("Informe um e-mail válido");
        exigirForte(senha);
        String hash = Senhas.gerar(senha);
        LocalDateTime agora = sinc.agora();
        long id = banco.transacao(c -> {
            if (Sessoes.mentorPorEmail(c, e) != null)
                throw new ErroHttp(409, "email-em-uso", "Já existe um mentor com este e-mail");
            if (Repositorio.alunoPorEmail(c, e) != null)
                throw new ErroHttp(409, "email-em-uso", "Este e-mail já é o login de um aluno");
            return Banco.inserir(c, "INSERT INTO mentor (nome, email, senha_hash, agenda_token, ativo, criado_em) VALUES (?, ?, ?, ?, 1, ?)", n, e, hash, Texto.segredo(24), agora);
        });
        registrarNome(n);
        return id;
    }

    /**
     * O primeiro mentor criado vira o "mentor responsável" (nome que aparece no painel, nos avisos e no
     * certificado; pode ser trocado em Configurações). Todo mentor entra na lista de sugestões de mentor da aula.
     */
    private void registrarNome(String nome) {
        sinc.gravar(Usuario.sistema(), g -> {
            if (g.ler("mentor", Colecoes.CHAVE_VALOR) == null)
                g.gravar("mentor", Colecoes.CHAVE_VALOR, nome);
            List<Object> nomes = new ArrayList<>();
            List<Object> atuais = Json.lista(g.ler("mentores", Colecoes.CHAVE_VALOR));
            if (atuais != null)
                nomes.addAll(atuais);
            if (!nomes.contains(nome) && nomes.size() < 200) {
                nomes.add(nome);
                g.gravar("mentores", Colecoes.CHAVE_VALOR, nomes);
            }
            return null;
        });
    }

    public void removerMentor(Usuario quem, long id) {
        if (id == quem.id)
            throw ErroHttp.pedidoInvalido("Você não pode remover o seu próprio acesso");
        banco.transacao(c -> {
            Banco.executar(c, "DELETE FROM sessao WHERE mentor_id = ?", id);
            Banco.executar(c, "DELETE FROM push_inscricao WHERE mentor_id = ?", id);
            Banco.executar(c, "DELETE FROM redefinicao_senha WHERE mentor_id = ?", id);
            return Banco.executar(c, "DELETE FROM mentor WHERE id = ?", id);
        });
    }

    public void senhaDoMentor(long id, String nova) {
        exigirForte(nova);
        if (banco.usar(c -> Sessoes.mentorPorId(c, id)) == null)
            throw ErroHttp.naoEncontrado();
        gravarSenha(true, id, Senhas.gerar(nova), null);
    }

    /* ---------------------------------------------------------------- primeiro acesso */

    /**
     * Na primeira execução (nenhum mentor cadastrado), cria o mentor com os dados de admin.* da configuração.
     * Devolve true se criou o acesso.
     */
    public boolean criarPrimeiroMentor() {
        Long quantos = banco.usar(c -> Banco.um(c, "SELECT COUNT(*) FROM mentor", r -> r.getLong(1)));
        if (quantos != null && quantos > 0)
            return false;
        String email = config.adminEmail(), senha = config.adminSenha(), nome = Texto.ou(config.adminNome(), "Mentor");
        if (email.isEmpty() || senha.isEmpty()) {
            Log.aviso("NENHUM MENTOR CADASTRADO. Preencha admin.nome, admin.email e admin.senha na configuração e reinicie o servidor para criar o primeiro acesso.");
            return false;
        }
        if (!Senhas.forte(senha))
            throw new IllegalArgumentException("admin.senha precisa ter 8 ou mais caracteres, com letras e números");
        criarMentor(nome, email, senha);
        Log.info("Primeiro acesso criado para o mentor " + email + ". Depois de entrar, troque a senha em Configurações e apague admin.senha da configuração.");
        return true;
    }

    /** Usado pelos comandos de linha (criar-mentor, redefinir-senha). */
    public static Mentor porEmail(Connection c, String email) throws SQLException {
        return Sessoes.mentorPorEmail(c, email.trim().toLowerCase(Locale.ROOT));
    }

    List<Long> idsDeMentores() {
        return new ArrayList<>(banco.usar(c -> Banco.consultar(c, "SELECT id FROM mentor", r -> r.getLong(1))));
    }
}
