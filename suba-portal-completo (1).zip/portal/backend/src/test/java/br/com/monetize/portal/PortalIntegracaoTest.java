package br.com.monetize.portal;

import static br.com.monetize.portal.apoio.Cliente.alterar;
import static br.com.monetize.portal.apoio.Cliente.apagar;
import static br.com.monetize.portal.apoio.Cliente.gravar;
import static br.com.monetize.portal.apoio.Cliente.j;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import br.com.monetize.portal.apoio.Cliente;
import br.com.monetize.portal.apoio.Cliente.Resp;
import br.com.monetize.portal.apoio.ServidorDeTeste;
import br.com.monetize.portal.apoio.SmtpFalso.Recebida;
import br.com.monetize.portal.util.Json;

/**
 * O servidor inteiro, de ponta a ponta, pela API: instalação zerada, login, o que cada perfil vê e grava,
 * arquivos, notificações e e-mails, lembretes, agenda, senhas, cópia e restauração, exclusão de dados.
 *
 * Os testes rodam em ordem e contam uma história só: o mentor monta a turma, os alunos usam o portal.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PortalIntegracaoTest {

    private static ServidorDeTeste srv;
    private static Cliente mentor, ana, bruno;
    private static long turmaA, turmaB, idAna, idBruno, idCaio, aula1, tarefa1;
    private static final String HOJE = LocalDate.now(ZoneId.of("America/Bahia")).toString();
    private static String copia;

    private static String dia(int somar) {
        return LocalDate.parse(HOJE).plusDays(somar).toString();
    }

    @BeforeClass
    public static void subir() throws Exception {
        srv = new ServidorDeTeste();
    }

    @AfterClass
    public static void derrubar() {
        if (srv != null)
            srv.close();
    }

    private static List<Object> lista(Map<String, Object> dados, String colecao) {
        return Json.lista(dados, colecao);
    }

    private static Map<String, Object> mapa(Map<String, Object> dados, String colecao) {
        Map<String, Object> m = Json.obj(dados, colecao);
        return m == null ? new java.util.LinkedHashMap<>() : m;
    }

    /** Registro de uma lista com o campo igual ao valor, ou null. */
    private static Map<String, Object> achar(List<Object> l, String campo, Object valor) {
        for (Object o : l) {
            Map<String, Object> m = Json.obj(o);
            if (m != null && Json.igual(m.get(campo), valor))
                return m;
        }
        return null;
    }

    private static void esperarEmails(int quantos) throws InterruptedException {
        assertTrue("esperava " + quantos + " e-mail(s), chegaram " + srv.smtp.recebidas.size(), srv.smtp.esperar(quantos, 8000));
    }

    /* ================================================================ instalação e páginas */

    @Test
    public void t01_servidorNoArEPaginasProtegidas() throws Exception {
        Cliente c = srv.cliente();
        Map<String, Object> saude = c.get("/api/saude").exigir(200).json();
        assertEquals(Boolean.TRUE, saude.get("ok"));
        assertEquals(Principal.VERSAO, saude.get("versao"));

        Resp pagina = c.get("/").exigir(200);
        assertTrue(pagina.texto().contains("Portal de teste"));
        assertTrue(pagina.cabecalho("Content-Type").startsWith("text/html"));
        assertTrue(pagina.cabecalho("Content-Security-Policy").contains("object-src 'none'"));
        assertEquals("nosniff", pagina.cabecalho("X-Content-Type-Options"));
        assertEquals("SAMEORIGIN", pagina.cabecalho("X-Frame-Options"));
        assertEquals("no-cache", pagina.cabecalho("Cache-Control"));

        /* O navegador que já tem a página recebe só a confirmação de que ela não mudou. */
        String etag = pagina.cabecalho("ETag");
        assertFalse(etag.isEmpty());
        assertEquals(0, c.get("/index.html", "If-None-Match", etag).exigir(304).bytes.length);

        /* Texto grande sai comprimido para quem aceita. */
        Resp js = c.get("/js/app.js", "Accept-Encoding", "gzip").exigir(200);
        assertEquals("gzip", js.cabecalho("Content-Encoding"));
        assertTrue(js.bytes.length < 500);

        /* Nada fora da pasta do portal, nenhum arquivo oculto, nenhum tipo desconhecido. */
        c.get("/../config.properties").exigir(404);
        c.get("/%2e%2e/config.properties").exigir(404);
        c.get("/js/..%2f..%2fconfig.properties").exigir(404);
        c.get("/.segredo").exigir(404);
        c.get("/dados.sql").exigir(404);
        c.get("/nao-existe.html").exigir(404);
        c.post("/index.html", null).exigir(405);
        c.get("/api/rota-que-nao-existe").exigir(404);
        c.delete("/api/estado").exigir(405);
    }

    @Test
    public void t02_semSessaoNadaDeDados() throws Exception {
        Cliente c = srv.cliente();
        assertEquals("sem-sessao", c.get("/api/estado").exigir(401).erro());
        c.get("/api/mudancas?rev=0").exigir(401);
        c.post("/api/sync", Json.mapa("ops", new ArrayList<>())).exigir(401);
        c.get("/api/admin/copia").exigir(401);
        c.get("/api/arquivos/abcdef").exigir(401);
        c.cookie = "um-cookie-inventado-que-nao-existe-no-banco";
        c.get("/api/estado").exigir(401);

        Map<String, Object> pub = srv.cliente().get("/api/publico").exigir(200).json();
        assertEquals("a tela de login sabe se o \"esqueci minha senha\" funciona", Boolean.TRUE, pub.get("email"));
        assertEquals("nada além do necessário é público", 3, pub.size());
    }

    @Test
    public void t03_loginDoMentorEPortalZerado() throws Exception {
        Cliente c = srv.cliente();
        assertEquals("login-invalido", c.entrar(ServidorDeTeste.MENTOR_EMAIL, "senha-errada1").exigir(401).erro());
        assertEquals("login-invalido", c.entrar("ninguem@teste.com", "Qualquer123").exigir(401).erro());
        assertEquals("login-invalido", c.entrar("", "").exigir(401).erro());
        c.postBruto("/api/auth/entrar", "{isto nao e json").exigir(400);

        /* Uma página de outro site não consegue mandar o cabeçalho do portal: a chamada é recusada. */
        c.cabecalhoDoPortal = false;
        assertEquals("origem", c.entrar(ServidorDeTeste.MENTOR_EMAIL, ServidorDeTeste.MENTOR_SENHA).exigir(403).erro());
        c.cabecalhoDoPortal = true;

        Resp r = c.entrar("  MENTOR@Teste.com ", ServidorDeTeste.MENTOR_SENHA).exigir(200);
        assertEquals("admin", Json.str(Json.obj(r.json(), "eu"), "role"));
        assertTrue(c.ultimoSetCookie, c.ultimoSetCookie.contains("HttpOnly") && c.ultimoSetCookie.contains("SameSite=Lax") && c.ultimoSetCookie.contains("Path=/"));
        assertFalse("sem \"manter conectado\" o cookie vale só até fechar o navegador", c.ultimoSetCookie.contains("Max-Age"));
        mentor = c;

        Map<String, Object> e = mentor.estado();
        Map<String, Object> eu = Json.obj(e, "eu"), s = Json.obj(e, "srv"), d = Json.obj(e, "dados");
        assertEquals(ServidorDeTeste.MENTOR_NOME, eu.get("nome"));
        assertEquals(ServidorDeTeste.MENTOR_EMAIL, eu.get("email"));
        assertEquals(Boolean.TRUE, s.get("email"));
        assertEquals("chave pública do push: 65 bytes em base64", 87, Json.str(s, "push").length());
        assertTrue(Json.str(s, "agenda").matches("http://localhost:\\d+/agenda/[\\w-]{20,}\\.ics"));

        /* O sistema nasce zerado: nenhum aluno, turma, aula, tarefa, aviso ou notificação. */
        for (String vazia : new String[] { "turmas", "alunos", "aulas", "eventos", "tarefas", "recs", "avisos", "metas", "inbox", "inboxM", "fila", "notif", "log", "diario", "chamados" })
            assertTrue(vazia + " deveria nascer vazia", lista(d, vazia).isEmpty());
        for (String vazia : new String[] { "ent", "notas", "pres", "prog", "roda", "rot", "certs", "termos" })
            assertTrue(vazia + " deveria nascer vazia", mapa(d, vazia).isEmpty());
        assertEquals("competências iniciais (editáveis)", 5, lista(d, "compL").size());
        assertEquals("perguntas frequentes iniciais (editáveis)", 10, lista(d, "faq").size());
        assertEquals(ServidorDeTeste.MENTOR_NOME, d.get("mentor"));
        assertEquals("[" + ServidorDeTeste.MENTOR_NOME + "]", lista(d, "mentores").toString());
        assertFalse("as configurações só existem depois que o mentor muda alguma", d.containsKey("cfg"));
    }

    /* ================================================================ o mentor monta a turma */

    @Test
    public void t04_mentorCadastraTurmaAlunosAulaETarefa() throws Exception {
        List<Object> ids = Json.lista(mentor.get("/api/ids").exigir(200).json(), "ids");
        long primeiro = Json.num(ids.get(0), 0), ultimo = Json.num(ids.get(1), 0);
        assertEquals("um bloco de 50 códigos", 49, ultimo - primeiro);
        turmaA = primeiro;
        turmaB = primeiro + 1;
        idAna = primeiro + 2;
        idBruno = primeiro + 3;
        idCaio = primeiro + 4;
        aula1 = primeiro + 5;
        tarefa1 = primeiro + 6;
        assertTrue("o bloco seguinte não repete códigos", Json.num(Json.lista(mentor.get("/api/ids").json(), "ids").get(0), 0) > ultimo);

        Map<String, Object> r = mentor.sync(
                gravar("turmas", turmaA, j("{'id':" + turmaA + ",'nome':'Suba o Padrão','sigla':'SOP','cor':'#c9a24b','inicio':'" + dia(-30) + "','unidades':[]}")),
                gravar("turmas", turmaB, j("{'id':" + turmaB + ",'nome':'Turma B','sigla':'TB','cor':'#5b8def','unidades':[]}")),
                gravar("alunos", idAna, j("{'id':" + idAna + ",'nome':'Ana Beatriz Souza','email':'Ana@Teste.com','tel':'(71) 98888-7777','nasc':'1990-05-10','mat':'" + dia(-20)
                        + "','turma':" + turmaA + ",'status':'ativo','canais':{'email':true,'whats':true},'senhaNova':'Aluna12345'}")),
                gravar("alunos", idBruno, j("{'id':" + idBruno + ",'nome':'Bruno Lima','email':'bruno@teste.com','tel':'','nasc':'1988-01-02','mat':'" + dia(-20)
                        + "','turma':" + turmaB + ",'status':'ativo','senhaNova':'Bruno12345'}")),
                gravar("alunos", idCaio, j("{'id':" + idCaio + ",'nome':'Caio Pendente','email':'caio@teste.com','nasc':'1985-03-04','turma':" + turmaA
                        + ",'status':'pendente','senhaNova':'Caio12345'}")),
                gravar("aulas", aula1, j("{'n':" + aula1 + ",'nome':'Mentalidade de dono','date':'" + dia(1) + "','hora':'20:00','dur':120,'status':'agendada','turmas':[" + turmaA
                        + "],'obj':'Pauta da aula','link':'https://meet.exemplo.com/sala','mats':[],'topicos':[],'hist':[],'un':{}}")),
                gravar("tarefas", tarefa1, j("{'id':" + tarefa1 + ",'t':'Mapa de indicadores','desc':'Liste cinco indicadores.','due':'" + dia(2) + "','comp':'Gestão','turmas':[" + turmaA + "],'links':[]}")),
                gravar("avisos", "av1", j("{'id':'av1','t':'Bem-vindos','m':'Primeiro aviso.','autor':'Carlos Mentor','at':'01/10/2026 10:00','alvo':'todos','pin':false,'coms':[]}")),
                gravar("avisos", "av2", j("{'id':'av2','t':'Só turma B','m':'Recado da B.','autor':'Carlos Mentor','at':'01/10/2026 10:05','alvo':'t" + turmaB + "','pin':false,'coms':[]}")),
                gravar("priv", idAna, "Anotação reservada do mentor sobre a Ana"),
                gravar("aval", idAna, j("{'w0':{'Disciplina':4}}")));
        assertTrue("nada recusado: " + r, Json.lista(r, "recusadas").isEmpty());

        /* A senha não volta para o painel: só o indicador de que o aluno tem senha. */
        String eco = Json.texto(Json.lista(r, "eco"));
        assertEquals("os três cadastros voltam ajustados", 3, Json.lista(r, "eco").size());
        assertFalse(eco.contains("senhaNova") || eco.contains("Aluna12345"));
        assertTrue(eco.contains("\"temSenha\":true"));

        String estado = mentor.get("/api/estado").exigir(200).texto();
        assertFalse("nenhuma senha, nem resumo de senha, sai no estado", estado.contains("Aluna12345") || estado.contains("pbkdf2") || estado.contains("senhaNova"));
        Map<String, Object> d = mentor.dados();
        assertEquals(3, lista(d, "alunos").size());
        assertEquals("o e-mail de login é guardado em minúsculas", "ana@teste.com", achar(lista(d, "alunos"), "id", idAna).get("email"));

        /* Regras do cadastro que valem até para o mentor. */
        assertEquals("email-em-uso", mentor.recusa(gravar("alunos", ultimo, j("{'id':" + ultimo + ",'nome':'Outra Ana','email':'ana@teste.com','status':'ativo','senhaNova':'Outra12345'}"))));
        assertEquals("email-de-mentor", mentor.recusa(gravar("alunos", ultimo, j("{'id':" + ultimo + ",'nome':'Clone','email':'mentor@teste.com','status':'ativo'}"))));
        assertEquals("senha-fraca", mentor.recusa(gravar("alunos", ultimo, j("{'id':" + ultimo + ",'nome':'Fraca','email':'f@teste.com','status':'ativo','senhaNova':'123'}"))));
        assertEquals("nome-obrigatorio", mentor.recusa(gravar("alunos", ultimo, j("{'id':" + ultimo + ",'nome':'  ','email':'f@teste.com'}"))));
        assertEquals("aluno-nao-e-apagado", mentor.recusa(apagar("alunos", idCaio)));
        assertEquals("colecao-desconhecida", mentor.recusa(gravar("inventada", "x", "y")));
        assertEquals("chave-invalida", mentor.recusa(gravar("avisos", "com espaço", j("{'id':'com espaço'}"))));
        assertEquals("chave-diferente", mentor.recusa(gravar("avisos", "av9", j("{'id':'outro'}"))));
        assertEquals("inexistente", mentor.recusa(alterar("avisos", "nao-existe", j("{'pin':true}"))));
    }

    /* ================================================================ o aluno */

    @Test
    public void t05_alunoEntraESoRecebeOQueEhDele() throws Exception {
        ana = srv.cliente();
        Resp r = ana.entrar("ana@teste.com", "Aluna12345").exigir(200);
        assertEquals("aluno", Json.str(Json.obj(r.json(), "eu"), "role"));
        assertEquals(idAna, Json.num(Json.obj(r.json(), "eu"), "aid", 0));
        bruno = srv.cliente();
        bruno.entrar("bruno@teste.com", "Bruno12345").exigir(200);

        /* Cadastro pendente: a senha está certa, mas o acesso ainda não foi liberado. */
        assertEquals("pendente", srv.cliente().entrar("caio@teste.com", "Caio12345").exigir(403).erro());
        assertEquals("com a senha errada, nem isso é revelado", "login-invalido", srv.cliente().entrar("caio@teste.com", "Errada12345").exigir(401).erro());

        Map<String, Object> d = ana.dados();
        assertEquals("só o próprio cadastro", 1, lista(d, "alunos").size());
        assertEquals("Ana Beatriz Souza", Json.obj(lista(d, "alunos").get(0)).get("nome"));
        assertEquals("só a própria turma", 1, lista(d, "turmas").size());
        assertEquals(1, lista(d, "aulas").size());
        assertEquals(1, lista(d, "tarefas").size());
        assertEquals("o aviso da turma B não chega", 1, lista(d, "avisos").size());
        for (String reservada : new String[] { "priv", "aval", "nlog", "inboxM", "notif", "log" })
            assertFalse(reservada + " é só do mentor", d.containsKey(reservada));
        assertEquals(5, lista(d, "compL").size());
        assertEquals(10, lista(d, "faq").size());
        String tudo = ana.get("/api/estado").texto();
        assertFalse(tudo.contains("Bruno") || tudo.contains("bruno@") || tudo.contains("Caio") || tudo.contains("reservada do mentor") || tudo.contains("Recado da B"));

        Map<String, Object> db = bruno.dados();
        assertTrue("Bruno é de outra turma: não recebe a aula nem a tarefa da turma A", lista(db, "aulas").isEmpty() && lista(db, "tarefas").isEmpty());
        assertEquals("recebe o aviso geral e o da turma dele", 2, lista(db, "avisos").size());

        /* Rotas do painel não atendem aluno. */
        for (String rota : new String[] { "/api/ids", "/api/mentores", "/api/admin/copia" })
            assertEquals(rota, "sem-permissao", ana.get(rota).exigir(403).erro());
        ana.post("/api/admin/zerar", Json.mapa("senha", "Aluna12345")).exigir(403);
        ana.post("/api/lembretes/rodar", null).exigir(403);
        ana.post("/api/admin/lgpd-apagar", Json.mapa("id", idBruno)).exigir(403);
        ana.post("/api/mentores", Json.mapa("nome", "Invasora", "email", "x@teste.com", "senha", "Invasora123")).exigir(403);
    }

    @Test
    public void t06_oQueOAlunoNaoPodeGravar() throws Exception {
        String k = idAna + "-" + tarefa1;
        /* Coisas do mentor. */
        assertEquals("sem-permissao", ana.recusa(gravar("notas", k, 10)));
        assertEquals("sem-permissao", ana.recusa(gravar("pres", idAna + "-" + aula1, "P")));
        assertEquals("sem-permissao", ana.recusa(gravar("prazo", k, dia(30))));
        assertEquals("sem-permissao", ana.recusa(gravar("certLib", idAna, true)));
        assertEquals("sem-permissao", ana.recusa(gravar("compA", idAna, j("{'Disciplina':{'nota':10}}"))));
        assertEquals("sem-permissao", ana.recusa(gravar("aulas", aula1, j("{'n':" + aula1 + ",'nome':'Alterada'}"))));
        assertEquals("sem-permissao", ana.recusa(apagar("tarefas", tarefa1)));
        assertEquals("sem-permissao", ana.recusa(gravar("cfg", "_", j("{'freqMin':0}"))));
        assertEquals("sem-permissao", ana.recusa(gravar("mentor", "_", "Ana")));
        assertEquals("sem-permissao", ana.recusa(gravar("turmas", turmaA, j("{'id':" + turmaA + ",'nome':'Minha'}"))));
        assertEquals("sem-permissao", ana.recusa(gravar("fila", "f1", j("{'id':'f1','aid':" + idAna + "}"))));
        /* Coisas de outro aluno. */
        assertEquals("nao-e-seu", ana.recusa(gravar("ent", idBruno + "-" + tarefa1, j("{'txt':'entrega falsa'}"))));
        assertEquals("nao-e-seu", ana.recusa(gravar("rot", idBruno, j("{'hab':{},'bib':{},'treino':[],'obj':[]}"))));
        assertEquals("nao-e-seu", ana.recusa(gravar("diario", "d-b", j("{'id':'d-b','aid':" + idBruno + ",'txt':'no diário do colega'}"))));
        assertEquals("nao-e-seu", ana.recusa(gravar("inbox", "n-b", j("{'id':'n-b','aid':" + idBruno + ",'t':'Aviso falso','m':'x'}"))));
        assertEquals("sem-permissao", ana.recusa(gravar("alunos", idBruno, j("{'id':" + idBruno + ",'nome':'Bruno Alterado'}"))));
        assertEquals("sem-permissao", ana.recusa(gravar("alunos", 999999, j("{'id':999999,'nome':'Aluna Nova','email':'nova@teste.com','status':'ativo'}"))));
        /* Formatos que o portal não produz. */
        assertEquals("formato", ana.recusa(gravar("vis", idAna + "-" + aula1, false)));
        assertEquals("formato", ana.recusa(gravar("recSt", idAna + "-r1", "<b>")));
        assertEquals("formato", ana.recusa(gravar("rot", idAna, j("{'hab':'<script>'}"))));
        assertEquals("formato", ana.recusa(gravar("rot", idAna, j("{'hab':{},'bib':{}}"))));
        assertEquals("formato", ana.recusa(gravar("prog", idAna + "-" + aula1, "50%")));
        assertEquals("formato", ana.recusa(gravar("metas", "m-x", j("{'id':'m-x','aid':" + idAna + ",'t':'Meta','etapas':[{'id':'e\\u0027);alert(1);//','t':'x'}]}"))));
        assertEquals("formato", ana.recusa(gravar("ent", k, j("{'txt':'x','files':[{'id':'a\\u0027)+alert(1)+(\\u0027','name':'x.pdf'}]}"))));
        assertEquals("formato", ana.recusa(gravar("chamados", "c-x", j("{'id':'c-x','aid':" + idAna + ",'t':'Sem mensagem','msgs':[]}"))));

        Map<String, Object> d = mentor.dados();
        assertTrue("nada disso foi gravado", mapa(d, "notas").isEmpty() && mapa(d, "pres").isEmpty() && mapa(d, "ent").isEmpty() && lista(d, "metas").isEmpty() && lista(d, "chamados").isEmpty());
        assertEquals("Bruno Lima", achar(lista(d, "alunos"), "id", idBruno).get("nome"));
        assertEquals(3, lista(d, "alunos").size());
    }

    @Test
    public void t07_cadastroDoAluno_soOsCamposDele() throws Exception {
        String foto = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2Q==";
        Map<String, Object> r = ana.sync(alterar("alunos", idAna, Json.mapa("nome", "Ana B. Souza", "bio", "Empresária.", "cidade", "Salvador", "foto", foto, "nasc", "1990-05-11",
                "canais", Json.mapa("email", true, "whats", false, "outro", "x"),
                /* tentativas de mexer no que é do mentor */
                "status", "bloqueado", "turma", turmaB, "email", "outra@teste.com", "mat", "2020-01-01", "senhaNova", "Trocada12345", "temSenha", false)));
        assertTrue(Json.lista(r, "recusadas").isEmpty());
        assertEquals("o servidor devolve o cadastro como ficou", 1, Json.lista(r, "eco").size());

        Map<String, Object> a = achar(lista(mentor.dados(), "alunos"), "id", idAna);
        assertEquals("Ana B. Souza", a.get("nome"));
        assertEquals("Salvador", a.get("cidade"));
        assertEquals(foto, a.get("foto"));
        assertEquals("1990-05-11", a.get("nasc"));
        assertEquals("{email=true, whats=false}", a.get("canais").toString());
        assertEquals("ativo", a.get("status"));
        assertEquals(turmaA, Json.num(a, "turma", 0));
        assertEquals("ana@teste.com", a.get("email"));
        assertEquals(dia(-20), a.get("mat"));
        srv.cliente().entrar("ana@teste.com", "Aluna12345").exigir(200);
        srv.cliente().entrar("ana@teste.com", "Trocada12345").exigir(401);

        /* Conteúdo que quebraria a tela do mentor não entra. */
        assertEquals("foto-invalida", ana.recusa(alterar("alunos", idAna, Json.mapa("foto", "data:image/svg+xml;base64,PHN2Zz4="))));
        assertEquals("foto-invalida", ana.recusa(alterar("alunos", idAna, Json.mapa("foto", "\"><img src=x onerror=alert(1)>"))));
        assertEquals("foto-invalida", ana.recusa(alterar("alunos", idAna, Json.mapa("foto", "https://fora.exemplo.com/rastreador.png"))));
        assertEquals("nome-invalido", ana.recusa(alterar("alunos", idAna, Json.mapa("nome", "A"))));
        assertEquals("formato", ana.recusa(alterar("alunos", idAna, Json.mapa("cidade", Json.mapa("x", 1)))));
        ana.sync(alterar("alunos", idAna, Json.mapa("nasc", "\"><script>alert(1)</script>", "tel", 71988887777L)));
        a = achar(lista(mentor.dados(), "alunos"), "id", idAna);
        assertEquals("data inválida vira vazio", "", a.get("nasc"));
        assertEquals("número vira texto", "71988887777", a.get("tel"));
        assertEquals("a foto continua a mesma", foto, a.get("foto"));
        ana.sync(alterar("alunos", idAna, Json.mapa("nasc", "1990-05-10", "tel", "(71) 98888-7777")));

        /* Pedido de saída: fica com a data do servidor e o aluno não desfaz. */
        ana.sync(alterar("alunos", idAna, Json.mapa("saida", Json.mapa("motivo", "Vou pausar.", "at", "01/01/2000 00:00"))));
        Map<String, Object> saida = Json.obj(achar(lista(mentor.dados(), "alunos"), "id", idAna), "saida");
        assertEquals("Vou pausar.", saida.get("motivo"));
        assertNotEquals("01/01/2000 00:00", saida.get("at"));
        ana.sync(Json.mapa("c", "alunos", "k", String.valueOf(idAna), "del", new ArrayList<>(List.of("saida"))));
        assertNotNull(Json.obj(achar(lista(mentor.dados(), "alunos"), "id", idAna), "saida"));
        /* O mentor desfaz (o aluno desistiu de sair). */
        mentor.sync(Json.mapa("c", "alunos", "k", String.valueOf(idAna), "del", new ArrayList<>(List.of("saida"))));
        assertNull(achar(lista(mentor.dados(), "alunos"), "id", idAna).get("saida"));
    }

    @Test
    public void t08_registrosDoAluno_oServidorCompletaEProtege() throws Exception {
        Map<String, Object> r = ana.sync(
                gravar("termos", idAna, "01/01/2000 00:00"),
                gravar("vis", idAna + "-" + aula1, 1),
                gravar("prog", idAna + "-" + aula1, j("{'t':125.5,'d':3600,'w':130,'p':250,'auto':'07/10/2026 10:00','x':'<b>'}")),
                gravar("recSt", idAna + "-r1", "quero"),
                gravar("rot", idAna, j("{'hab':{'Oração|0-1':'y','Jejum|0-3':'\\\"><img src=x onerror=alert(1)>'},'bib':{'Tiago-1':1},'treino':[[{'status':'Treinei','type':'Corrida','km':'5,2'}]],"
                        + "'obj':[{'t':'Dobrar o faturamento','m':['Fase 1'],'done':[1]}],'livros':[{'title':'O Livro','fap':{'f':'fato'}}]}")),
                gravar("diario", "d1", j("{'id':'d1','aid':" + idAna + ",'n':" + aula1 + ",'tit':'','txt':'Anotação privada','at':'07/10/2026 10:00','upd':'07/10/2026 10:00','share':false,'resp':'Resposta forjada','respAt':'x'}")),
                gravar("diario", "d2", j("{'id':'d2','aid':" + idAna + ",'n':null,'tit':'Reflexão','txt':'Anotação compartilhada','at':'07/10/2026 10:01','upd':'07/10/2026 10:01','share':true}")),
                gravar("just", "j1", j("{'id':'j1','aid':" + idAna + ",'n':" + aula1 + ",'motivo':'Viagem a trabalho','st':'aprovada','resp':'ok forjado','at':'x'}")),
                gravar("contest", "c1", j("{'id':'c1','aid':" + idAna + ",'tid':" + tarefa1 + ",'msg':'Rever a nota','resp':'forjada'}")),
                gravar("metas", "m1", j("{'id':'m1','aid':" + idAna + ",'t':'Contratar um gerente','prazo':'" + dia(60) + "','st':'aprovada','obs':'x','feita':'ontem',"
                        + "'checkins':[{'at':'x','txt':'forjado','who':'Carlos Mentor'}],'etapas':[{'id':'e1','t':'Publicar a vaga','prazo':'" + dia(1) + "','feito':false},{'id':'e2','t':'Entrevistar','prazo':'ontem','feito':0}]}")),
                gravar("chamados", "ch1", j("{'id':'ch1','aid':" + idAna + ",'cat':'Acesso','t':'Não abre a gravação','st':'resolvido','msgs':[{'adm':true,'txt':'Mensagem como se fosse da equipe','at':'x'}]}")),
                gravar("lgpd", "l1", j("{'id':'l1','aid':" + idAna + ",'nome':'Outro Nome','tipo':'outra','motivo':'Quero sair','st':'concluido','fim':'x'}")),
                gravar("inboxM", "im1", j("{'id':'im1','t':'Chamado de Ana','m':'Não abre','go':'suporte\\u0027);alert(1);//','arg':'1);alert(2);//','auto':true,'lido':true}")),
                gravar("inboxM", "im2", j("{'id':'im2','t':'Entrega de Ana','m':'Tarefa entregue','go':'alunoD','arg':" + idAna + "}")),
                gravar("log", "lg1", j("{'id':'lg1','who':'Carlos Mentor','m':'Entregou a tarefa','at':'x'}")),
                gravar("notif", "nf1", j("{'id':'nf1','ev':'Evento','canal':'Portal','dest':'Carlos','auto':true}")));
        List<Object> recusadas = Json.lista(r, "recusadas");
        assertEquals("só o alerta com destino adulterado é recusado: " + recusadas, 1, recusadas.size());
        assertEquals(12L, Json.num(Json.obj(recusadas.get(0)), "i", -1));

        Map<String, Object> d = mentor.dados();
        assertNotEquals("o aceite dos termos leva a data do servidor", "01/01/2000 00:00", mapa(d, "termos").get(String.valueOf(idAna)));
        assertEquals("{t=125.5, d=3600, w=130, p=100, auto=07/10/2026 10:00}", mapa(d, "prog").get(idAna + "-" + aula1).toString());
        Map<String, Object> rot = Json.obj(mapa(d, "rot").get(String.valueOf(idAna)));
        assertEquals("marcação de hábito adulterada é descartada", "{Oração|0-1=y}", rot.get("hab").toString());
        assertEquals("[{t=Dobrar o faturamento, m=[Fase 1], done=[1]}]", rot.get("obj").toString());
        assertEquals("[{title=O Livro, fap={f=fato}}]", rot.get("livros").toString());

        assertEquals("o mentor só recebe a anotação compartilhada", 1, lista(d, "diario").size());
        Map<String, Object> d2 = Json.obj(lista(d, "diario").get(0));
        assertEquals("Anotação compartilhada", d2.get("txt"));
        Map<String, Object> d1 = achar(lista(ana.dados(), "diario"), "id", "d1");
        assertEquals("a resposta do mentor não pode ser criada pelo aluno", "", d1.get("resp"));
        assertFalse(d1.containsKey("respAt"));

        Map<String, Object> just = Json.obj(lista(d, "just").get(0));
        assertEquals("pendente", just.get("st"));
        assertEquals("", just.get("resp"));
        assertNotEquals("x", just.get("at"));
        assertEquals("", Json.obj(lista(d, "contest").get(0)).get("resp"));

        Map<String, Object> meta = Json.obj(lista(d, "metas").get(0));
        assertEquals("proposta", meta.get("st"));
        assertEquals("", meta.get("obs"));
        assertFalse(meta.containsKey("feita"));
        assertEquals("acompanhamento não nasce com a meta", "[]", meta.get("checkins").toString());
        assertEquals("[{id=e1, t=Publicar a vaga, prazo=" + dia(1) + ", feito=false}, {id=e2, t=Entrevistar, prazo=, feito=false}]", meta.get("etapas").toString());

        Map<String, Object> ch = Json.obj(lista(d, "chamados").get(0));
        assertEquals("aberto", ch.get("st"));
        assertEquals("mensagem do aluno nunca sai como da equipe", Boolean.FALSE, Json.obj(Json.lista(ch, "msgs").get(0)).get("adm"));

        Map<String, Object> lg = Json.obj(lista(d, "lgpd").get(0));
        assertEquals("pendente", lg.get("st"));
        assertEquals("exclusao", lg.get("tipo"));
        assertEquals("Ana B. Souza", lg.get("nome"));
        assertFalse(lg.containsKey("fim"));

        assertEquals(1, lista(d, "inboxM").size());
        Map<String, Object> im = Json.obj(lista(d, "inboxM").get(0));
        assertEquals("im2", im.get("id"));
        assertEquals("alunoD", im.get("go"));
        assertEquals(idAna, Json.num(im, "arg", 0));
        assertEquals(Boolean.FALSE, im.get("lido"));
        assertEquals("quem fez a ação é sempre quem está logado", "Ana B. Souza", Json.obj(lista(d, "log").get(0)).get("who"));
        assertEquals(Boolean.FALSE, Json.obj(lista(d, "notif").get(0)).get("auto"));

        /* O que só se cria não se altera nem se apaga depois. */
        ana.sync(alterar("just", "j1", Json.mapa("st", "aprovada", "motivo", "Outro motivo")));
        assertEquals("pendente", Json.obj(lista(mentor.dados(), "just").get(0)).get("st"));
        assertEquals("Viagem a trabalho", Json.obj(lista(mentor.dados(), "just").get(0)).get("motivo"));
        assertEquals("sem-permissao", ana.recusa(apagar("just", "j1")));
        assertEquals("sem-permissao", ana.recusa(apagar("chamados", "ch1")));
        assertEquals("sem-permissao", ana.recusa(apagar("metas", "m1")));
        /* O que é dele, ele apaga. */
        assertEquals("", ana.recusa(apagar("diario", "d1")));
        assertEquals("", ana.recusa(apagar("recSt", idAna + "-r1")));
        assertNull(achar(lista(ana.dados(), "diario"), "id", "d1"));
    }

    @Test
    public void t09_mentorRespondeEOAlunoContinua() throws Exception {
        mentor.sync(alterar("metas", "m1", Json.mapa("st", "aprovada")),
                alterar("chamados", "ch1", Json.mapa("st", "respondido", "msgs", new ArrayList<>(List.of(
                        Json.mapa("adm", false, "txt", "Mensagem como se fosse da equipe", "at", "x"), Json.mapa("adm", true, "txt", "Tente pelo computador.", "at", "07/10/2026 11:00"))))),
                alterar("diario", "d2", Json.mapa("resp", "Boa reflexão.", "respAt", "07/10/2026 11:00")),
                alterar("turmas", turmaA, Json.mapa("rodaIni", HOJE)));

        /* Meta aprovada: marca etapa, registra acompanhamento e conclui. O comentário do mentor não some. */
        mentor.sync(alterar("metas", "m1", Json.mapa("checkins", new ArrayList<>(List.of(Json.mapa("at", "07/10/2026 11:05", "txt", "Bom plano.", "who", "Carlos Mentor"))))));
        ana.sync(alterar("metas", "m1", Json.mapa("checkins", new ArrayList<>(List.of(Json.mapa("at", "x", "txt", "Vaga publicada.", "who", "Carlos Mentor"))),
                "etapas", new ArrayList<>(List.of(j("{'id':'e1','t':'Publicar a vaga','prazo':'" + dia(1) + "','feito':true}"))), "feita", "sim", "st", "ajustar", "obs", "nota do aluno")));
        Map<String, Object> meta = Json.obj(lista(mentor.dados(), "metas").get(0));
        List<Object> cks = Json.lista(meta, "checkins");
        assertEquals(2, cks.size());
        assertEquals("o registro do aluno entra sem nome de mentor", "", Json.obj(cks.get(0)).get("who"));
        assertEquals("Vaga publicada.", Json.obj(cks.get(0)).get("txt"));
        assertEquals("o comentário do mentor continua", "Bom plano.", Json.obj(cks.get(1)).get("txt"));
        assertEquals("aprovada", meta.get("st"));
        assertEquals("", meta.get("obs"));
        assertTrue("concluída com a data do servidor", Json.str(meta, "feita").matches("\\d{2}/\\d{2}/\\d{4} \\d{2}:\\d{2}"));

        /* Chamado: o aluno responde e marca como resolvido; as mensagens da equipe ficam intactas. */
        ana.sync(alterar("chamados", "ch1", Json.mapa("st", "resolvido", "msgs", new ArrayList<>(List.of(Json.mapa("adm", true, "txt", "Forjada", "at", "y"), Json.mapa("adm", false, "txt", "Funcionou.", "at", "07/10/2026 11:10"))))));
        Map<String, Object> ch = Json.obj(lista(mentor.dados(), "chamados").get(0));
        assertEquals("resolvido", ch.get("st"));
        assertEquals("[Mensagem como se fosse da equipe, Tente pelo computador., Funcionou.]", Json.lista(ch, "msgs").stream().map(m -> Json.str(Json.obj(m), "txt")).collect(Collectors.toList()).toString());

        /* Diário: o aluno edita o texto, mas não a resposta do mentor. */
        ana.sync(alterar("diario", "d2", Json.mapa("txt", "Texto revisado", "resp", "Resposta trocada")));
        Map<String, Object> d2 = Json.obj(lista(mentor.dados(), "diario").get(0));
        assertEquals("Texto revisado", d2.get("txt"));
        assertEquals("Boa reflexão.", d2.get("resp"));
        /* Deixou de compartilhar: some do painel do mentor. */
        mentor.estado();
        ana.sync(alterar("diario", "d2", Json.mapa("share", false)));
        assertTrue(lista(mentor.dados(), "diario").isEmpty());

        /* Roda da Vida: só depois de liberada; enviada, não muda mais. A final ainda está fechada. */
        ana.estado();
        ana.sync(gravar("roda", idAna, j("{'ini':[8,7,6,5,4,3,2,1],'fin':[10,10,10,10,10,10,10,10],'iniSent':true,'finSent':true}")));
        Map<String, Object> roda = Json.obj(mapa(mentor.dados(), "roda").get(String.valueOf(idAna)));
        assertEquals("[8, 7, 6, 5, 4, 3, 2, 1]", roda.get("ini").toString());
        assertEquals(Boolean.TRUE, roda.get("iniSent"));
        assertEquals("[5, 5, 5, 5, 5, 5, 5, 5]", roda.get("fin").toString());
        assertEquals(Boolean.FALSE, roda.get("finSent"));
        ana.sync(gravar("roda", idAna, j("{'ini':[1,1,1,1,1,1,1,1],'iniSent':false}")));
        roda = Json.obj(mapa(mentor.dados(), "roda").get(String.valueOf(idAna)));
        assertEquals("[8, 7, 6, 5, 4, 3, 2, 1]", roda.get("ini").toString());
        assertEquals(Boolean.TRUE, roda.get("iniSent"));
        assertEquals("Bruno, de turma sem liberação, não envia", Boolean.FALSE,
                Json.obj(Json.obj(Json.lista(bruno.sync(gravar("roda", idBruno, j("{'ini':[9,9,9,9,9,9,9,9],'iniSent':true}"))), "eco").get(0)), "v").get("iniSent"));

        /* Mural: comenta no aviso que enxerga, em nome dele mesmo; não altera o aviso. */
        ana.sync(alterar("avisos", "av1", Json.mapa("t", "Título trocado", "pin", true, "coms", new ArrayList<>(List.of(
                Json.mapa("aid", idAna, "txt", "Obrigada!", "at", "07/10/2026 12:00"), Json.mapa("aid", idBruno, "txt", "Comentário em nome do colega", "at", "07/10/2026 12:00"))))));
        Map<String, Object> av = achar(lista(mentor.dados(), "avisos"), "id", "av1");
        assertEquals("Bem-vindos", av.get("t"));
        assertEquals(Boolean.FALSE, av.get("pin"));
        assertEquals(1, Json.lista(av, "coms").size());
        assertEquals("sem-permissao", ana.recusa(alterar("avisos", "av2", Json.mapa("coms", new ArrayList<>(List.of(Json.mapa("aid", idAna, "txt", "Na turma dos outros")))))));
        /* O colega vê o comentário com o nome de quem escreveu (ele não recebe o cadastro dos outros alunos). */
        Map<String, Object> com = Json.obj(Json.lista(achar(lista(bruno.dados(), "avisos"), "id", "av1"), "coms").get(0));
        assertEquals("Ana B. Souza", com.get("nome"));
    }

    /* ================================================================ arquivos */

    @Test
    public void t10_arquivosDaEntrega() throws Exception {
        byte[] pdf = "%PDF-1.4 conteúdo de teste".getBytes(StandardCharsets.UTF_8);
        String k = idAna + "-" + tarefa1;
        assertEquals(pdf.length, Json.num(ana.put("/api/arquivos/arqAna01?nome=Mapa%20de%20indicadores.pdf&tipo=application%2Fpdf", pdf).exigir(200).json(), "tamanho", 0));
        assertEquals("formato", ana.put("/api/arquivos/arqAna02?nome=virus.exe", pdf).exigir(415).erro());
        assertEquals("formato", ana.put("/api/arquivos/arqAna02?nome=pagina.html", pdf).exigir(415).erro());
        assertEquals("grande-demais", ana.put("/api/arquivos/arqAna02?nome=grande.pdf", new byte[1024 * 1024 + 1]).exigir(413).erro());
        ana.put("/api/arquivos/arqAna02?nome=vazio.pdf", new byte[0]).exigir(400);
        ana.put("/api/arquivos/..%2F..%2Ffora?nome=a.pdf", pdf).exigir(404);
        ana.put("/api/arquivos/a.b?nome=a.pdf", pdf).exigir(400);
        assertEquals("o conteúdo de um arquivo enviado não é trocado", "ja-existe", ana.put("/api/arquivos/arqAna01?nome=outro.pdf", "outro".getBytes(StandardCharsets.UTF_8)).exigir(409).erro());
        assertEquals("ja-existe", bruno.put("/api/arquivos/arqAna01?nome=outro.pdf", pdf).exigir(409).erro());
        bruno.put("/api/arquivos/arqBruno1?nome=do-bruno.pdf", pdf).exigir(200);

        /* A entrega só aceita arquivos que o próprio aluno enviou. */
        Map<String, Object> r = ana.sync(gravar("ent", k, j("{'txt':'Segue o mapa.','link':'javascript:alert(1)','at':'x','nota':10,"
                + "'files':[{'id':'arqAna01','name':'Mapa de indicadores.pdf','size':" + pdf.length + ",'type':'application/pdf'},{'id':'arqBruno1','name':'do-bruno.pdf','size':1,'type':''},{'id':'naoexiste','name':'x.pdf'}]}")));
        assertTrue(Json.lista(r, "recusadas").isEmpty());
        Map<String, Object> ent = Json.obj(mapa(mentor.dados(), "ent").get(k));
        assertEquals("Segue o mapa.", ent.get("txt"));
        assertEquals("link que não é https não entra", "", ent.get("link"));
        assertFalse(ent.containsKey("nota"));
        assertEquals(1, Json.lista(ent, "files").size());
        assertEquals("arqAna01", Json.obj(Json.lista(ent, "files").get(0)).get("id"));

        /* Quem baixa: a dona e o mentor. O colega, não. */
        Resp baixado = ana.get("/api/arquivos/arqAna01").exigir(200);
        assertEquals(new String(pdf, StandardCharsets.UTF_8), baixado.texto());
        assertEquals("application/pdf", baixado.cabecalho("Content-Type"));
        assertTrue(baixado.cabecalho("Content-Disposition").startsWith("attachment;"));
        assertTrue(baixado.cabecalho("Content-Disposition").contains("Mapa%20de%20indicadores.pdf"));
        mentor.get("/api/arquivos/arqAna01").exigir(200);
        bruno.get("/api/arquivos/arqAna01").exigir(404);
        srv.cliente().get("/api/arquivos/arqAna01").exigir(401);
        bruno.delete("/api/arquivos/arqAna01").exigir(403);

        /* Material do mentor: todo aluno baixa, nenhum aluno apaga. */
        mentor.put("/api/arquivos/matAula01?nome=slides.pptx", pdf).exigir(200);
        mentor.put("/api/arquivos/matAula01?nome=slides-v2.pptx", pdf).exigir(200);
        ana.get("/api/arquivos/matAula01").exigir(200);
        ana.delete("/api/arquivos/matAula01").exigir(403);

        /* Antes da nota a aluna pode corrigir a entrega; depois, nem a entrega nem o arquivo mudam. */
        ana.sync(alterar("ent", k, Json.mapa("txt", "Segue o mapa revisado.")));
        assertEquals("Segue o mapa revisado.", Json.obj(mapa(mentor.dados(), "ent").get(k)).get("txt"));
        mentor.sync(gravar("notas", k, 8.5));
        assertEquals("ja-avaliada", ana.recusa(alterar("ent", k, Json.mapa("txt", "Trocando depois da nota"))));
        assertEquals("ja-avaliada", ana.delete("/api/arquivos/arqAna01").exigir(409).erro());
        mentor.get("/api/arquivos/arqAna01").exigir(200);
        assertEquals("8.5", mapa(ana.dados(), "notas").get(k).toString());
        assertEquals("sem-permissao", ana.recusa(gravar("notas", k, 10)));

        /* Arquivo de entrega ainda não avaliada: o dono apaga. */
        bruno.delete("/api/arquivos/arqBruno1").exigir(200);
        bruno.get("/api/arquivos/arqBruno1").exigir(404);
        try (Stream<Path> s = Files.walk(srv.pasta.resolve("arquivos"))) {
            assertEquals("no disco ficam só os dois arquivos vivos", 2, s.filter(Files::isRegularFile).count());
        }
    }

    /* ================================================================ notificações, e-mail e lembretes */

    @Test
    public void t11_notificacaoViraEmailConformeAsPreferencias() throws Exception {
        srv.smtp.recebidas.clear();
        ana.sync(alterar("alunos", idAna, Json.mapa("canais", Json.mapa("email", true, "whats", true))));
        mentor.sync(
                gravar("inbox", "n1", j("{'id':'n1','aid':" + idAna + ",'t':'Nota lançada','m':'Sua tarefa “Mapa de indicadores” recebeu nota 8,5.','at':'07/10/2026 12:00','lido':false,'go':'tarefas','canal':'E-mail + push'}")),
                gravar("inbox", "n2", j("{'id':'n2','aid':" + idAna + ",'t':'Só no portal','m':'Sem e-mail.','at':'07/10/2026 12:00','lido':false,'go':'inicio','canal':'Somente no portal'}")),
                gravar("inbox", "n3", j("{'id':'n3','aid':" + idBruno + ",'t':'Para o Bruno','m':'Aviso do Bruno.','at':'07/10/2026 12:00','lido':false,'go':'inicio','canal':'E-mail + WhatsApp'}")));
        esperarEmails(2);
        Recebida e = srv.smtp.ultimaPara("ana@teste.com");
        assertNotNull(e);
        assertEquals("portal@exemplo.com", e.de);
        assertEquals("Nota lançada", e.cabecalho("Subject"));
        assertEquals("\"Ana B. Souza\" <ana@teste.com>", e.cabecalho("To"));
        assertTrue(e.parte("text/plain"), e.parte("text/plain").startsWith("Olá, Ana. Nota lançada: Sua tarefa “Mapa de indicadores” recebeu nota 8,5."));
        assertTrue("o e-mail leva direto para a página do aviso", e.parte("text/plain").contains(srv.base + "/aluno.html#ir=tarefas"));
        assertTrue(e.parte("text/html").contains("href=\"" + srv.base + "/aluno.html#ir=tarefas\""));
        assertEquals(1, srv.smtp.para("ana@teste.com").size());
        assertEquals(1, srv.smtp.para("bruno@teste.com").size());

        /* Fila que o mentor acompanha: e-mail enviado; WhatsApp sem serviço de automação fica para envio manual. */
        Thread.sleep(300);
        List<Object> fila = lista(mentor.dados(), "fila");
        assertEquals("Ana: e-mail. Bruno: e-mail (ele não tem telefone).", 2, fila.size());
        for (Object o : fila)
            assertEquals("enviado", Json.obj(o).get("st"));
        assertEquals("a aluna vê só as mensagens enviadas a ela", 1, lista(ana.dados(), "fila").size());

        /* A aluna desliga o e-mail no perfil: o aviso chega só no portal. */
        ana.sync(alterar("alunos", idAna, Json.mapa("canais", Json.mapa("email", false, "whats", true))));
        mentor.sync(gravar("inbox", "n4", j("{'id':'n4','aid':" + idAna + ",'t':'Depois de desligar','m':'x','at':'07/10/2026 12:05','lido':false,'go':'inicio','canal':'E-mail + WhatsApp'}")));
        Thread.sleep(400);
        assertEquals(1, srv.smtp.para("ana@teste.com").size());
        Map<String, Object> wa = achar(lista(mentor.dados(), "fila"), "ev", "Depois de desligar");
        assertEquals("whats", wa.get("c"));
        assertEquals("manual", wa.get("st"));
        assertEquals("(71) 98888-7777", wa.get("to"));

        /* O mentor desliga o e-mail para todos: ninguém recebe. */
        ana.sync(alterar("alunos", idAna, Json.mapa("canais", Json.mapa("email", true, "whats", false))));
        mentor.sync(gravar("cfg", "_", Json.mapa("canais", Json.mapa("email", false, "whats", true), "webhook", "https://automacao.exemplo.com/gancho", "mentorEmail", "equipe@exemplo.com", "mentorTel", "")));
        mentor.sync(gravar("inbox", "n5", j("{'id':'n5','aid':" + idAna + ",'t':'Canal desligado','m':'x','at':'07/10/2026 12:06','lido':false,'go':'inicio','canal':'E-mail'}")));
        Thread.sleep(300);
        assertEquals(1, srv.smtp.para("ana@teste.com").size());

        /* As configurações chegam ao aluno sem os dados internos do mentor. */
        Map<String, Object> cfgAluno = Json.obj(ana.dados(), "cfg");
        assertNotNull(cfgAluno.get("canais"));
        assertFalse(cfgAluno.containsKey("webhook") || cfgAluno.containsKey("mentorEmail") || cfgAluno.containsKey("mentorTel"));
        assertFalse(ana.get("/api/estado").texto().contains("automacao.exemplo.com"));

        /* Alerta ao mentor por e-mail quando ele cadastra um endereço. */
        mentor.sync(gravar("cfg", "_", Json.mapa("canais", Json.mapa("email", true, "whats", true), "webhook", "", "mentorEmail", "equipe@exemplo.com", "mentorTel", "")));
        ana.sync(gravar("inboxM", "im3", j("{'id':'im3','t':'Pedido de saída: Ana','m':'Motivo informado.','go':'alunos','arg':null}")));
        assertTrue(srv.smtp.esperar(srv.smtp.recebidas.size() + (srv.smtp.para("equipe@exemplo.com").isEmpty() ? 1 : 0), 8000));
        Recebida al = srv.smtp.ultimaPara("equipe@exemplo.com");
        assertNotNull(al);
        assertEquals("Pedido de saída: Ana", al.cabecalho("Subject"));
        assertTrue(al.parte("text/plain").contains(srv.base + "/mentor.html"));

        /* A aluna marca a notificação como lida; o texto dela não muda. */
        ana.sync(alterar("inbox", "n1", Json.mapa("lido", true, "t", "Título trocado")));
        Map<String, Object> n1 = achar(lista(ana.dados(), "inbox"), "id", "n1");
        assertEquals(Boolean.TRUE, n1.get("lido"));
        assertEquals("Nota lançada", n1.get("t"));
    }

    @Test
    public void t12_emailDeTesteDoPainel() throws Exception {
        int antes = srv.smtp.recebidas.size();
        Map<String, Object> r = mentor.post("/api/admin/teste-email", Json.mapa("para", "")).exigir(200).json();
        assertEquals(Boolean.TRUE, r.get("ok"));
        assertEquals(ServidorDeTeste.MENTOR_EMAIL, r.get("para"));
        assertEquals(antes + 1, srv.smtp.recebidas.size());
        assertEquals("Teste de e-mail da Área de Membros", srv.smtp.ultimaPara(ServidorDeTeste.MENTOR_EMAIL).cabecalho("Subject"));

        /* Quando o provedor recusa, o painel mostra o motivo em vez de fingir que enviou. */
        srv.smtp.destinatarioInexistente = "naoexiste@exemplo.com";
        r = mentor.post("/api/admin/teste-email", Json.mapa("para", "naoexiste@exemplo.com")).exigir(200).json();
        assertEquals(Boolean.FALSE, r.get("ok"));
        assertTrue(Json.str(r, "erro"), Json.str(r, "erro").startsWith("550"));
        srv.smtp.destinatarioInexistente = null;
    }

    @Test
    public void t13_lembretesAutomaticosSaemUmaVezSo() throws Exception {
        /* Uma segunda meta, aprovada e em andamento, com uma etapa que vence amanhã. */
        ana.sync(gravar("metas", "m2", j("{'id':'m2','aid':" + idAna + ",'t':'Organizar o financeiro','prazo':'" + dia(40) + "','etapas':[{'id':'f1','t':'Separar as contas','prazo':'" + dia(1) + "','feito':false}]}")));
        mentor.sync(alterar("metas", "m2", Json.mapa("st", "aprovada")));
        Thread.sleep(300);
        srv.smtp.recebidas.clear();
        int antes = lista(ana.dados(), "inbox").size();
        Map<String, Object> r = mentor.post("/api/lembretes/rodar", null).exigir(200).json();
        /* Para a Ana: aula amanhã e etapa do plano vencendo amanhã. A tarefa já foi entregue e a primeira meta já foi
           concluída: nenhuma das duas gera lembrete. */
        List<String> assuntos = lista(ana.dados(), "inbox").stream().map(o -> Json.str(Json.obj(o), "t")).collect(Collectors.toList());
        assertEquals(assuntos.toString(), antes + 2, assuntos.size());
        assertTrue(assuntos.contains("Lembrete de encontro"));
        assertTrue(assuntos.contains("Etapa do seu plano de ação"));
        assertFalse(assuntos.contains("Prazo chegando"));
        assertEquals(2L, Json.num(r, "n", -1));
        Map<String, Object> lembrete = achar(lista(ana.dados(), "inbox"), "t", "Lembrete de encontro");
        assertTrue(Json.str(lembrete, "m"), Json.str(lembrete, "m").contains("\"Mentalidade de dono\" é amanhã") && Json.str(lembrete, "m").contains("https://meet.exemplo.com/sala"));
        assertEquals(Boolean.TRUE, lembrete.get("auto"));
        assertEquals("agenda", lembrete.get("go"));
        esperarEmails(2);
        assertEquals(2, srv.smtp.para("ana@teste.com").size());
        assertTrue("o Bruno, de outra turma, não recebe", srv.smtp.para("bruno@teste.com").isEmpty());

        assertEquals("na segunda conferência nada sai de novo", 0L, Json.num(mentor.post("/api/lembretes/rodar", null).exigir(200).json(), "n", -1));
        assertEquals(antes + 2, lista(ana.dados(), "inbox").size());

        /* Tarefa nova vencendo amanhã, ainda não entregue: sai o lembrete de prazo. */
        long tarefa2 = tarefa1 + 10;
        mentor.sync(gravar("tarefas", tarefa2, j("{'id':" + tarefa2 + ",'t':'Rotina de reuniões','due':'" + dia(1) + "','turmas':[],'links':[]}")));
        assertEquals("um para a Ana e um para o Bruno (a tarefa vale para todas as turmas)", 2L, Json.num(mentor.post("/api/lembretes/rodar", null).json(), "n", -1));
        assertNotNull(achar(lista(bruno.dados(), "inbox"), "t", "Prazo chegando"));

        /* Aula que passou sem chamada vira alerta para o mentor; depois da chamada, frequência baixa avisa o aluno. */
        long aula0 = aula1 + 10;
        mentor.sync(gravar("aulas", aula0, j("{'n':" + aula0 + ",'nome':'Aula inaugural','date':'" + dia(-3) + "','hora':'20:00','status':'agendada','turmas':[" + turmaA + "]}")));
        mentor.post("/api/lembretes/rodar", null).exigir(200);
        assertNotNull(achar(lista(mentor.dados(), "inboxM"), "t", "Aula sem registro"));
        mentor.sync(alterar("aulas", aula0, Json.mapa("status", "realizada")), gravar("pres", idAna + "-" + aula0, "F"));
        mentor.post("/api/lembretes/rodar", null).exigir(200);
        assertNotNull("0% de presença, mínimo de 75%", achar(lista(ana.dados(), "inbox"), "t", "Frequência abaixo do mínimo"));
        assertNotNull(achar(lista(mentor.dados(), "inboxM"), "t", "Frequência baixa: Ana B. Souza"));

        /* Com os lembretes desligados em Automação, a rodada periódica não envia nada. */
        mentor.sync(alterar("cfg", "_", Json.mapa("autoOn", false)));
        long tarefa3 = tarefa1 + 11;
        mentor.sync(gravar("tarefas", tarefa3, j("{'id':" + tarefa3 + ",'t':'Outra tarefa','due':'" + dia(1) + "','turmas':[],'links':[]}")));
        assertEquals(0, srv.app.lembretes.rodar(false));
        mentor.sync(alterar("cfg", "_", Json.mapa("autoOn", true)), apagar("tarefas", tarefa3));
    }

    /* ================================================================ agenda */

    @Test
    public void t14_agendaPorAssinatura() throws Exception {
        String url = Json.str(Json.obj(ana.estado(), "srv"), "agenda");
        Resp r = srv.cliente().get(url).exigir(200);
        assertTrue(r.cabecalho("Content-Type").startsWith("text/calendar"));
        String ics = r.texto().replace("\r\n ", "");
        assertTrue(ics.startsWith("BEGIN:VCALENDAR"));
        assertTrue(ics.contains("SUMMARY:Monetize · Mentalidade de dono"));
        assertTrue("a pauta e o link aparecem a partir da véspera", ics.contains("Pauta da aula") && ics.contains("LOCATION:https://meet.exemplo.com/sala"));
        assertTrue(ics.contains("SUMMARY:Prazo: Rotina de reuniões"));
        assertFalse("tarefa já entregue sai da agenda", ics.contains("Prazo: Mapa de indicadores"));

        String doBruno = srv.cliente().get(Json.str(Json.obj(bruno.estado(), "srv"), "agenda")).exigir(200).texto();
        assertFalse("o Bruno não recebe encontros da turma A", doBruno.contains("Mentalidade de dono"));
        String doMentor = srv.cliente().get(Json.str(Json.obj(mentor.estado(), "srv"), "agenda")).exigir(200).texto().replace("\r\n ", "");
        assertTrue(doMentor.contains("Mentalidade de dono") && doMentor.contains("Prazo: Mapa de indicadores"));

        srv.cliente().get("/agenda/codigo-que-nao-existe-0000000.ics").exigir(404);
        srv.cliente().get("/agenda/curto.ics").exigir(404);
        srv.cliente().get(url.replace(".ics", ".txt")).exigir(404);

        /* Aluno bloqueado: a agenda dele para de responder e a sessão cai na hora. */
        mentor.sync(alterar("alunos", idBruno, Json.mapa("status", "bloqueado")));
        srv.cliente().get(Json.str(Json.obj(mentor.estado(), "srv"), "agenda")).exigir(200);
        bruno.get("/api/estado").exigir(401);
        assertEquals("bloqueado", srv.cliente().entrar("bruno@teste.com", "Bruno12345").exigir(403).erro());
        mentor.sync(alterar("alunos", idBruno, Json.mapa("status", "ativo")));
        bruno.entrar("bruno@teste.com", "Bruno12345").exigir(200);
    }

    /* ================================================================ o que mudou */

    @Test
    public void t15_cadaUmRecebeSoAsMudancasQuePodeVer() throws Exception {
        mentor.estado();
        ana.estado();
        bruno.estado();
        assertTrue(ana.mudancas().isEmpty());

        mentor.sync(gravar("notas", idBruno + "-" + tarefa1, 6), gravar("priv", idBruno, "Reservado"), alterar("aulas", aula1, Json.mapa("obj", "Pauta nova")),
                gravar("recs", "r1", j("{'id':'r1','t':'Livro indicado','tipo':'livro','turmas':[" + turmaB + "]}")), gravar("diario", "dm", j("{'id':'dm','aid':" + idAna + ",'txt':'criada pelo mentor','share':false}")));
        /* O que a pessoa não pode ver chega, no máximo, como "remova se tiver" (sem conteúdo nenhum). */
        List<Object> mudAna = ana.mudancas().stream().filter(o -> !Boolean.TRUE.equals(Json.obj(o).get("rm"))).collect(Collectors.toList());
        assertEquals("para a Ana: a aula alterada e a anotação dela. " + mudAna, 2, mudAna.size());
        assertNotNull(achar(mudAna, "c", "aulas"));
        assertNotNull(achar(mudAna, "c", "diario"));
        assertFalse(Json.texto(mudAna).contains("Livro indicado") || Json.texto(mudAna).contains("Reservado"));
        List<Object> mudBruno = bruno.mudancas();
        assertEquals("para o Bruno: a nota dele, a recomendação da turma dele e a aula (de outra turma) como removida. " + mudBruno, 3, mudBruno.size());
        assertFalse(Json.texto(mudBruno).contains("Pauta nova") || Json.texto(mudBruno).contains("criada pelo mentor"));
        assertEquals(Boolean.TRUE, achar(mudBruno, "c", "aulas").get("rm"));
        assertTrue("a anotação privada da Ana não aparece para o mentor", mentor.mudancas().stream().noneMatch(o -> "diario".equals(Json.obj(o).get("c")) && !Boolean.TRUE.equals(Json.obj(o).get("rm"))));

        /* Exclusão: quem tinha o registro recebe a marca de remoção. */
        mentor.sync(apagar("recs", "r1"), apagar("diario", "dm"));
        assertEquals(Boolean.TRUE, achar(bruno.mudancas(), "c", "recs").get("rm"));
        assertEquals(Boolean.TRUE, achar(ana.mudancas(), "c", "diario").get("rm"));
        assertTrue(ana.mudancas().isEmpty());

        /* Número de alteração do futuro, ou inválido. */
        assertEquals(Boolean.TRUE, ana.get("/api/mudancas?rev=999999999").exigir(200).json().get("recarregar"));
        ana.get("/api/mudancas").exigir(400);
        ana.get("/api/mudancas?rev=abc").exigir(400);

        /* Envio repetido (a resposta se perdeu no caminho) não duplica nada. */
        Map<String, Object> op = gravar("contest", "c2", j("{'id':'c2','aid':" + idAna + ",'tid':" + tarefa1 + ",'msg':'Segunda contestação'}"));
        ana.sync(op);
        ana.sync(op);
        assertEquals(2, lista(mentor.dados(), "contest").size());

        /* Lote grande demais e corpo que não é JSON. */
        List<Object> muitas = new ArrayList<>();
        for (int i = 0; i < 3001; i++)
            muitas.add(gravar("vis", idAna + "-" + i, 1));
        ana.post("/api/sync", Json.mapa("ops", muitas)).exigir(413);
        ana.postBruto("/api/sync", "[1,2,3]").exigir(400);
        assertEquals("formato", Json.str(Json.obj(Json.lista(ana.postBruto("/api/sync", "{\"ops\":[42]}").exigir(200).json(), "recusadas").get(0)), "motivo"));
    }

    /* ================================================================ senhas e acessos */

    @Test
    public void t16_trocaDeSenhaEncerraOsOutrosAparelhos() throws Exception {
        Cliente celular = srv.cliente();
        celular.entrar("ana@teste.com", "Aluna12345").exigir(200);
        assertEquals("senha-atual", ana.post("/api/conta/senha", Json.mapa("atual", "errada", "nova", "NovaSenha123")).exigir(400).erro());
        assertEquals("senha-fraca", ana.post("/api/conta/senha", Json.mapa("atual", "Aluna12345", "nova", "curta1")).exigir(400).erro());
        ana.post("/api/conta/senha", Json.mapa("atual", "Aluna12345", "nova", "NovaSenha123")).exigir(200);
        ana.get("/api/estado").exigir(200);
        celular.get("/api/estado").exigir(401);
        srv.cliente().entrar("ana@teste.com", "Aluna12345").exigir(401);
        srv.cliente().entrar("ana@teste.com", "NovaSenha123").exigir(200);

        /* O mentor cria uma senha nova para a aluna: as sessões dela caem? Não: só a senha muda; ela entra com a nova. */
        mentor.sync(alterar("alunos", idAna, Json.mapa("senhaNova", "DoMentor123")));
        srv.cliente().entrar("ana@teste.com", "NovaSenha123").exigir(401);
        ana.entrar("ana@teste.com", "DoMentor123").exigir(200);

        /* Sair encerra a sessão no servidor, não só no navegador. */
        Cliente outro = srv.cliente();
        outro.entrar("ana@teste.com", "DoMentor123").exigir(200);
        String cookie = outro.cookie;
        outro.post("/api/auth/sair", null).exigir(200);
        assertTrue(outro.ultimoSetCookie.contains("Max-Age=0"));
        outro.cookie = cookie;
        outro.get("/api/estado").exigir(401);
    }

    @Test
    public void t17_esqueciMinhaSenhaPorEmail() throws Exception {
        srv.smtp.recebidas.clear();
        Cliente c = srv.cliente();
        c.post("/api/auth/esqueci", Json.mapa("email", "ANA@teste.com")).exigir(200);
        /* E-mail sem cadastro e aluno pendente: mesma resposta, nenhum e-mail (não revela quem tem cadastro). */
        c.post("/api/auth/esqueci", Json.mapa("email", "ninguem@teste.com")).exigir(200);
        c.post("/api/auth/esqueci", Json.mapa("email", "caio@teste.com")).exigir(200);
        c.post("/api/auth/esqueci", Json.mapa("email", "sem-arroba")).exigir(400);
        esperarEmails(1);
        Thread.sleep(300);
        assertEquals(1, srv.smtp.recebidas.size());
        Recebida e = srv.smtp.ultimaPara("ana@teste.com");
        assertEquals("Criar nova senha da Área de Membros", e.cabecalho("Subject"));
        Matcher m = Pattern.compile(Pattern.quote(srv.base) + "/index\\.html#redefinir=([\\w-]{40,})").matcher(e.parte("text/plain"));
        assertTrue(e.parte("text/plain"), m.find());
        String token = m.group(1);
        assertTrue(e.parte("text/html").contains("#redefinir=" + token));

        assertEquals("senha-fraca", c.post("/api/auth/redefinir", Json.mapa("token", token, "senha", "fraca")).exigir(400).erro());
        assertEquals("link-invalido", c.post("/api/auth/redefinir", Json.mapa("token", token.substring(0, 30) + "adulterado", "senha", "Recuperada123")).exigir(400).erro());
        c.post("/api/auth/redefinir", Json.mapa("token", token, "senha", "Recuperada123")).exigir(200);
        assertEquals("o link vale uma vez só", "link-invalido", c.post("/api/auth/redefinir", Json.mapa("token", token, "senha", "OutraVez123")).exigir(400).erro());
        ana.get("/api/estado").exigir(401);
        ana.entrar("ana@teste.com", "DoMentor123").exigir(401);
        ana.entrar("ana@teste.com", "Recuperada123").exigir(200);

        /* No máximo três pedidos por hora para o mesmo e-mail. */
        srv.smtp.recebidas.clear();
        for (int i = 0; i < 5; i++)
            c.post("/api/auth/esqueci", Json.mapa("email", "bruno@teste.com")).exigir(200);
        assertTrue(srv.smtp.esperar(3, 8000));
        Thread.sleep(400);
        assertEquals(3, srv.smtp.recebidas.size());
    }

    @Test
    public void t18_acessosAoPainel() throws Exception {
        List<Object> l = Json.lista(mentor.get("/api/mentores").exigir(200).json(), "mentores");
        assertEquals(1, l.size());
        long meuId = Json.num(Json.obj(l.get(0)), "id", 0);
        assertFalse("a lista não traz senha nem resumo", Json.texto(l).contains("pbkdf2"));

        assertEquals("senha-fraca", mentor.post("/api/mentores", Json.mapa("nome", "Paula Mentora", "email", "paula@teste.com", "senha", "fraca")).exigir(400).erro());
        assertEquals("email-em-uso", mentor.post("/api/mentores", Json.mapa("nome", "Paula Mentora", "email", "MENTOR@teste.com", "senha", "Paula12345")).exigir(409).erro());
        assertEquals("o e-mail de um aluno não pode ser login de mentor", "email-em-uso",
                mentor.post("/api/mentores", Json.mapa("nome", "Paula Mentora", "email", "ana@teste.com", "senha", "Paula12345")).exigir(409).erro());
        long idPaula = Json.num(mentor.post("/api/mentores", Json.mapa("nome", "Paula Mentora", "email", "Paula@Teste.com", "senha", "Paula12345")).exigir(200).json(), "id", 0);
        assertEquals("[Carlos Mentor, Paula Mentora]", lista(mentor.dados(), "mentores").toString());
        assertEquals("o mentor responsável continua sendo o primeiro", ServidorDeTeste.MENTOR_NOME, mentor.dados().get("mentor"));

        Cliente paula = srv.cliente();
        paula.entrar("paula@teste.com", "Paula12345").exigir(200);
        assertEquals("a nova mentora vê todos os alunos", 3, lista(paula.dados(), "alunos").size());
        assertNotEquals("cada mentor tem o seu endereço de agenda", Json.str(Json.obj(paula.estado(), "srv"), "agenda"), Json.str(Json.obj(mentor.estado(), "srv"), "agenda"));

        mentor.post("/api/mentores/senha", Json.mapa("id", idPaula, "senha", "Redefinida123")).exigir(200);
        paula.get("/api/estado").exigir(401);
        paula.entrar("paula@teste.com", "Redefinida123").exigir(200);
        mentor.post("/api/mentores/senha", Json.mapa("id", 999999, "senha", "Redefinida123")).exigir(404);

        mentor.post("/api/mentores/remover", Json.mapa("id", meuId)).exigir(400);
        mentor.post("/api/mentores/remover", Json.mapa("id", idPaula)).exigir(200);
        paula.get("/api/estado").exigir(401);
        srv.cliente().entrar("paula@teste.com", "Redefinida123").exigir(401);
        assertEquals(1, Json.lista(mentor.get("/api/mentores").json(), "mentores").size());
    }

    @Test
    public void t19_tentativasErradasBloqueiamPorUmTempo() throws Exception {
        Cliente c = srv.cliente();
        for (int i = 0; i < 5; i++)
            c.entrar("bruno@teste.com", "Errada" + i + "abc").exigir(401);
        Resp r = c.entrar("bruno@teste.com", "Bruno12345").exigir(429);
        assertEquals("muitas-tentativas", r.erro());
        assertTrue(Json.str(r.json(), "msg"), Json.str(r.json(), "msg").contains("Aguarde"));
        srv.app.sessoes.esquecerFalhas();
        c.entrar("bruno@teste.com", "Bruno12345").exigir(200);
    }

    /* ================================================================ cópia, zerar, restaurar e LGPD */

    @Test
    public void t20_copiaDosDados() throws Exception {
        Resp r = mentor.get("/api/admin/copia").exigir(200);
        assertTrue(r.cabecalho("Content-Disposition").contains("attachment"));
        copia = r.texto();
        Map<String, Object> c = Json.lerObjeto(copia);
        assertEquals(6L, c.get("v"));
        assertEquals(3, Json.lista(c, "alunos").size());
        assertEquals(2, Json.lista(c, "turmas").size());
        assertTrue("a cópia leva o resumo da senha (nunca a senha) para os alunos continuarem entrando depois de restaurar",
                Json.str(achar(Json.lista(c, "alunos"), "id", idAna), "senha").startsWith("pbkdf2$"));
        assertFalse(copia.contains("Recuperada123"));
    }

    @Test
    public void t21_zerarExigeASenhaEApagaTudoMenosOsAcessosAoPainel() throws Exception {
        assertEquals("senha-atual", mentor.post("/api/admin/zerar", Json.mapa("senha", "errada")).exigir(403).erro());
        assertEquals(3, lista(mentor.dados(), "alunos").size());
        long revAntes = mentor.rev;

        mentor.post("/api/admin/zerar", Json.mapa("senha", ServidorDeTeste.MENTOR_SENHA)).exigir(200);
        Map<String, Object> d = mentor.dados();
        for (String vazia : new String[] { "turmas", "alunos", "aulas", "tarefas", "avisos", "inbox", "inboxM", "fila", "notif", "log", "metas", "chamados", "diario" })
            assertTrue(vazia, lista(d, vazia).isEmpty());
        for (String vazia : new String[] { "ent", "notas", "pres", "rot", "roda", "termos" })
            assertTrue(vazia, mapa(d, vazia).isEmpty());
        assertFalse(d.containsKey("cfg"));
        assertEquals(5, lista(d, "compL").size());
        assertEquals(10, lista(d, "faq").size());
        assertEquals(ServidorDeTeste.MENTOR_NOME, d.get("mentor"));

        ana.get("/api/estado").exigir(401);
        srv.cliente().entrar("ana@teste.com", "Recuperada123").exigir(401);
        try (Stream<Path> s = Files.walk(srv.pasta.resolve("arquivos"))) {
            assertEquals("os arquivos enviados saem do disco", 0, s.filter(Files::isRegularFile).count());
        }
        mentor.get("/api/arquivos/arqAna01").exigir(404);
        /* Quem estava com o portal aberto é avisado para baixar tudo de novo. */
        assertEquals(Boolean.TRUE, mentor.get("/api/mudancas?rev=" + revAntes).exigir(200).json().get("recarregar"));
        assertEquals("a agenda do mentor continua no ar, agora vazia", 0, srv.cliente().get(Json.str(Json.obj(mentor.estado(), "srv"), "agenda")).exigir(200).texto().split("BEGIN:VEVENT", -1).length - 1);
    }

    @Test
    public void t22_restaurarTrazTudoDeVolta() throws Exception {
        srv.smtp.recebidas.clear();
        assertEquals("senha-atual", mentor.post("/api/admin/restaurar", Json.mapa("senha", "errada", "copia", Json.lerObjeto(copia))).exigir(403).erro());
        mentor.post("/api/admin/restaurar", Json.mapa("senha", ServidorDeTeste.MENTOR_SENHA, "copia", Json.mapa("qualquer", "coisa"))).exigir(400);
        Map<String, Object> r = mentor.post("/api/admin/restaurar", Json.mapa("senha", ServidorDeTeste.MENTOR_SENHA, "copia", Json.lerObjeto(copia))).exigir(200).json();
        assertEquals(3L, r.get("alunos"));
        assertTrue(Json.lista(r, "avisos").toString(), Json.lista(r, "avisos").isEmpty());

        Map<String, Object> d = mentor.dados();
        assertEquals(3, lista(d, "alunos").size());
        assertEquals(2, lista(d, "turmas").size());
        assertEquals("8.5", mapa(d, "notas").get(idAna + "-" + tarefa1).toString());
        assertEquals("a ordem das listas é a mesma de antes", Json.texto(Json.lerObjeto(copia).get("inbox")), Json.texto(d.get("inbox")));
        assertEquals(Json.texto(Json.lerObjeto(copia).get("avisos")), Json.texto(d.get("avisos")));
        ana.entrar("ana@teste.com", "Recuperada123").exigir(200);
        assertEquals("Ana B. Souza", Json.obj(lista(ana.dados(), "alunos").get(0)).get("nome"));

        /* Restaurar não reenvia notificações antigas nem repete lembretes que já saíram. */
        Thread.sleep(400);
        assertTrue(srv.smtp.recebidas.toString(), srv.smtp.recebidas.isEmpty());
        /* Códigos novos não colidem com os restaurados. */
        assertTrue(Json.num(Json.lista(mentor.get("/api/ids").json(), "ids").get(0), 0) > tarefa1 + 11);

        /* Cópia do portal antigo (sem servidor): senha no formato antigo, presença como verdadeiro/falso, lembretes já enviados. */
        String antigo = br.com.monetize.portal.util.Senhas.legado("dora@teste.com", "Antiga12345");
        Map<String, Object> velha = j("{'v':5,'seqA':7,'turmas':[{'id':1,'nome':'Turma antiga','unidades':[]}],'aulas':[{'n':1,'nome':'Aula antiga','date':'2026-01-10','hora':'20:00','status':'realizada','turmas':[1]}],"
                + "'alunos':[{'id':2,'nome':'Dora Antiga','email':'dora@teste.com','turma':1,'status':'ativo','senha':'" + antigo + "'},{'id':3,'nome':'Sem Senha','email':'sem@teste.com','turma':1,'status':'ativo','senha':'texto-qualquer'}],"
                + "'pres':{'2-1':true,'3-1':false},'auto':{'aula|1|2|2026-01-10|antes':1},'mentor':'Mentor Antigo'}");
        r = mentor.post("/api/admin/restaurar", Json.mapa("senha", ServidorDeTeste.MENTOR_SENHA, "copia", velha)).exigir(200).json();
        assertEquals(2L, r.get("alunos"));
        d = mentor.dados();
        assertEquals("{2-1=P, 3-1=F}", mapa(d, "pres").toString());
        assertEquals("Mentor Antigo", d.get("mentor"));
        assertEquals("as competências padrão entram quando a cópia não traz", 5, lista(d, "compL").size());
        Cliente dora = srv.cliente();
        dora.entrar("dora@teste.com", "Antiga12345").exigir(200);
        assertEquals("depois do primeiro login a senha antiga é regravada no formato novo e continua valendo", 200, srv.cliente().entrar("dora@teste.com", "Antiga12345").status);
        assertEquals("resumo irreconhecível: o aluno fica sem senha até o mentor criar uma", Boolean.FALSE, achar(lista(d, "alunos"), "id", 3L).get("temSenha"));
        srv.cliente().entrar("sem@teste.com", "texto-qualquer").exigir(401);
        assertTrue(Json.num(Json.lista(mentor.get("/api/ids").json(), "ids").get(0), 0) > 7);

        /* Volta para os dados da história. */
        mentor.post("/api/admin/restaurar", Json.mapa("senha", ServidorDeTeste.MENTOR_SENHA, "copia", Json.lerObjeto(copia))).exigir(200);
        ana.entrar("ana@teste.com", "Recuperada123").exigir(200);
    }

    @Test
    public void t23_exclusaoDeDadosPelaLgpd() throws Exception {
        byte[] pdf = "%PDF-1.4 arquivo que vai ser apagado".getBytes(StandardCharsets.UTF_8);
        ana.put("/api/arquivos/arqAna77?nome=documento.pdf", pdf).exigir(200);
        String agenda = Json.str(Json.obj(ana.estado(), "srv"), "agenda");
        mentor.post("/api/admin/lgpd-apagar", Json.mapa("id", 0)).exigir(400);
        mentor.post("/api/admin/lgpd-apagar", Json.mapa("id", 999999)).exigir(404);
        mentor.post("/api/admin/lgpd-apagar", Json.mapa("id", idAna)).exigir(200);

        ana.get("/api/estado").exigir(401);
        srv.cliente().entrar("ana@teste.com", "Recuperada123").exigir(401);
        srv.cliente().get(agenda).exigir(404);
        mentor.get("/api/arquivos/arqAna77").exigir(404);
        try (Stream<Path> s = Files.walk(srv.pasta.resolve("arquivos"))) {
            assertEquals(0, s.filter(Files::isRegularFile).count());
        }

        String tudo = mentor.get("/api/estado").texto();
        for (String rastro : new String[] { "Ana B. Souza", "Ana Beatriz", "ana@teste.com", "98888-7777" }) {
            int i = tudo.indexOf(rastro);
            assertTrue("o nome, o e-mail e o telefone somem de todo o portal; sobrou: " + (i < 0 ? "" : tudo.substring(Math.max(0, i - 200), Math.min(tudo.length(), i + 120))), i < 0);
        }
        Map<String, Object> d = mentor.dados();
        Map<String, Object> a = achar(lista(d, "alunos"), "id", idAna);
        assertEquals("Aluno excluído", a.get("nome"));
        assertEquals("removido", a.get("status"));
        assertEquals("", a.get("email"));
        assertFalse(a.containsKey("foto") || a.containsKey("bio"));
        for (String k : mapa(d, "ent").keySet())
            assertFalse(k.startsWith(idAna + "-"));
        for (String k : mapa(d, "notas").keySet())
            assertFalse(k.startsWith(idAna + "-"));
        assertNull(mapa(d, "rot").get(String.valueOf(idAna)));
        assertNull(mapa(d, "priv").get(String.valueOf(idAna)));
        assertNull(achar(lista(d, "inbox"), "aid", idAna));
        assertNull(achar(lista(d, "metas"), "aid", idAna));
        assertTrue("os comentários dela no mural saem", Json.lista(achar(lista(d, "avisos"), "id", "av1"), "coms").isEmpty());
        Map<String, Object> pedido = achar(lista(d, "lgpd"), "id", "l1");
        assertEquals("o pedido fica registrado como atendido, sem identificação", "concluido", pedido.get("st"));
        assertEquals("Aluno excluído", pedido.get("nome"));
        assertEquals("os outros alunos continuam como estavam", "Bruno Lima", achar(lista(d, "alunos"), "id", idBruno).get("nome"));
        /* O e-mail fica livre para um novo cadastro. */
        long novo = Json.num(Json.lista(mentor.get("/api/ids").json(), "ids").get(0), 0);
        assertEquals("", mentor.recusa(gravar("alunos", novo, j("{'id':" + novo + ",'nome':'Ana de Volta','email':'ana@teste.com','status':'ativo','turma':" + turmaA + ",'senhaNova':'DeVolta12345'}"))));
        srv.cliente().entrar("ana@teste.com", "DeVolta12345").exigir(200);
    }

    @Test
    public void t23b_mudancaDeNomeAcompanhaOHistorico() throws Exception {
        long novo = Json.num(Json.lista(mentor.get("/api/ids").json(), "ids").get(0), 0);
        mentor.sync(gravar("alunos", novo, j("{'id':" + novo + ",'nome':'Bruno Lima Filho','email':'filho@teste.com','status':'ativo','turma':" + turmaB + "}")),
                gravar("log", "lgA", j("{'id':'lgA','at':'x','who':'Carlos Mentor','m':'Lançou a nota de Bruno Lima e de Bruno Lima Filho; Brunolima não é aluno'}")),
                gravar("inboxM", "imA", j("{'id':'imA','t':'Entrega de Bruno Lima','m':'Tarefa entregue por Bruno Lima.','at':'x','lido':true,'go':'avaliacoes','arg':null,'auto':false}")));
        bruno.entrar("bruno@teste.com", "Bruno12345").exigir(200);
        bruno.sync(alterar("alunos", idBruno, Json.mapa("nome", "Bruno de Lima")));
        Map<String, Object> d = mentor.dados();
        assertEquals("só o nome inteiro deste aluno é trocado", "Lançou a nota de Bruno de Lima e de Bruno Lima Filho; Brunolima não é aluno", achar(lista(d, "log"), "id", "lgA").get("m"));
        assertEquals("Entrega de Bruno de Lima", achar(lista(d, "inboxM"), "id", "imA").get("t"));
        assertEquals("Tarefa entregue por Bruno de Lima.", achar(lista(d, "inboxM"), "id", "imA").get("m"));
        bruno.sync(alterar("alunos", idBruno, Json.mapa("nome", "Bruno Lima")));
        assertEquals("Entrega de Bruno Lima", achar(lista(mentor.dados(), "inboxM"), "id", "imA").get("t"));
    }

    /* ================================================================ manutenção */

    @Test
    public void t24_faxinaPeriodicaNaoApagaNadaEmUso() throws Exception {
        int alunos = lista(mentor.dados(), "alunos").size();
        srv.app.manutencao.rodar();
        assertEquals(alunos, lista(mentor.dados(), "alunos").size());
        mentor.get("/api/estado").exigir(200);
        bruno.entrar("bruno@teste.com", "Bruno12345").exigir(200);
    }
}
