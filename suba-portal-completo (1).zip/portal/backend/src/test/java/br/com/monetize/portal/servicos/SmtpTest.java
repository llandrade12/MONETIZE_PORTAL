package br.com.monetize.portal.servicos;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.Assume.assumeNotNull;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import br.com.monetize.portal.apoio.SmtpFalso;
import br.com.monetize.portal.apoio.SmtpFalso.Recebida;
import br.com.monetize.portal.servicos.Smtp.SmtpException;

public class SmtpTest {

    private SmtpFalso servidor;

    @Before
    public void subir() throws IOException {
        servidor = new SmtpFalso();
    }

    @After
    public void derrubar() {
        servidor.close();
    }

    private Smtp cliente(String seguranca, String usuario, String senha, boolean verificar) {
        return new Smtp("localhost", servidor.porta(), seguranca, usuario, senha, verificar, "portal.exemplo.com", 4000);
    }

    private static Smtp.Mensagem mensagem() {
        Smtp.Mensagem m = new Smtp.Mensagem();
        m.de = "portal@exemplo.com";
        m.deNome = "Monetize · Área de Membros";
        m.para = "ana@teste.com";
        m.paraNome = "Ana Beatriz Souza";
        m.assunto = "Nota lançada: avaliação da tarefa “Mapa de indicadores” já está disponível na Área de Membros 🎉";
        m.texto = "Olá, Ana.\n\nSua tarefa foi avaliada.\n.\n..linha que começa com ponto\nhttps://exemplo.com/aluno.html#ir=tarefas";
        m.html = "<p>Olá, <b>Ana</b>.</p><p>Sua tarefa foi avaliada.</p>";
        return m;
    }

    @Test
    public void entregaMensagemComAcentosNosCabecalhosENoCorpo() throws Exception {
        Smtp.Mensagem m = mensagem();
        cliente("nenhuma", "", "", true).enviar(m);

        assertEquals(1, servidor.recebidas.size());
        Recebida r = servidor.recebidas.get(0);
        assertEquals("portal@exemplo.com", r.de);
        assertEquals("ana@teste.com", r.para);
        assertEquals(m.assunto, r.cabecalho("Subject"));
        assertEquals("Monetize · Área de Membros <portal@exemplo.com>", r.cabecalho("From"));
        assertEquals("\"Ana Beatriz Souza\" <ana@teste.com>", r.cabecalho("To"));
        assertEquals("1.0", r.cabecalho("MIME-Version"));
        assertTrue(r.cabecalho("Message-ID").matches("<[0-9a-f-]{36}@exemplo\\.com>"));
        assertNotNull(r.cabecalho("Date"));
        assertEquals("auto-generated", r.cabecalho("Auto-Submitted"));
        assertTrue(r.cabecalho("Content-Type").startsWith("multipart/alternative"));
        assertEquals(m.texto, r.parte("text/plain"));
        assertEquals(m.html, r.parte("text/html"));
        assertTrue(servidor.comandos.contains("EHLO portal.exemplo.com"));
        assertTrue(servidor.comandos.contains("QUIT"));
    }

    @Test
    public void mensagemSoTemAsciiELinhasCurtas() throws Exception {
        cliente("nenhuma", "", "", true).enviar(mensagem());
        String bruto = servidor.recebidas.get(0).bruto;
        for (int i = 0; i < bruto.length(); i++)
            assertTrue("caractere fora do ASCII na posição " + i, bruto.charAt(i) < 127);
        assertFalse("toda quebra de linha é CRLF", bruto.replace("\r\n", "").contains("\n") || bruto.replace("\r\n", "").contains("\r"));
        for (String linha : bruto.split("\r\n"))
            assertTrue("linha com mais de 78 caracteres: " + linha, linha.length() <= 78);
    }

    @Test
    public void mensagemSoDeTexto() throws Exception {
        Smtp.Mensagem m = mensagem();
        m.html = null;
        m.assunto = "Teste simples";
        m.deNome = "";
        cliente("nenhuma", "", "", true).enviar(m);
        Recebida r = servidor.recebidas.get(0);
        assertEquals("Teste simples", r.cabecalho("Subject"));
        assertEquals("<portal@exemplo.com>", r.cabecalho("From"));
        assertTrue(r.cabecalho("Content-Type").startsWith("text/plain"));
        assertEquals(m.texto, r.parte("text/plain"));
    }

    @Test
    public void loginPlain() throws Exception {
        servidor.usuario = "portal@exemplo.com";
        servidor.senha = "s3nh@ com espaço";
        servidor.auth = "PLAIN LOGIN";
        cliente("nenhuma", "portal@exemplo.com", "s3nh@ com espaço", true).enviar(mensagem());
        assertEquals(1, servidor.recebidas.size());
        assertTrue(servidor.comandos.stream().anyMatch(c -> c.startsWith("AUTH PLAIN ")));
    }

    @Test
    public void loginLoginQuandoOServidorSoOfereceEsse() throws Exception {
        servidor.usuario = "portal@exemplo.com";
        servidor.senha = "Segredo123";
        servidor.auth = "LOGIN";
        cliente("nenhuma", "portal@exemplo.com", "Segredo123", true).enviar(mensagem());
        assertEquals(1, servidor.recebidas.size());
        assertTrue(servidor.comandos.contains("AUTH LOGIN"));
        assertTrue(servidor.comandos.contains("(login de portal@exemplo.com)"));
    }

    @Test
    public void senhaErradaGeraMensagemClara() throws Exception {
        servidor.usuario = "portal@exemplo.com";
        servidor.senha = "Segredo123";
        try {
            cliente("nenhuma", "portal@exemplo.com", "errada", true).enviar(mensagem());
            fail("deveria falhar");
        } catch (SmtpException e) {
            assertTrue(e.getMessage(), e.getMessage().contains("smtp.usuario e smtp.senha"));
            assertTrue(e.getMessage(), e.getMessage().contains("535"));
            assertFalse("senha errada se corrige na configuração: o envio fica para nova tentativa", e.definitivo);
        }
        assertTrue(servidor.recebidas.isEmpty());
    }

    @Test
    public void semLoginQuandoOServidorExige() throws Exception {
        servidor.usuario = "portal@exemplo.com";
        servidor.senha = "Segredo123";
        try {
            cliente("nenhuma", "", "", true).enviar(mensagem());
            fail("deveria falhar");
        } catch (SmtpException e) {
            assertTrue(e.getMessage(), e.getMessage().startsWith("530"));
        }
    }

    @Test
    public void destinatarioInexistenteEhErroDefinitivo() throws Exception {
        servidor.destinatarioInexistente = "ana@teste.com";
        try {
            cliente("nenhuma", "", "", true).enviar(mensagem());
            fail("deveria falhar");
        } catch (SmtpException e) {
            assertTrue(e.getMessage(), e.getMessage().startsWith("550"));
            assertTrue(e.definitivo);
        }
    }

    @Test
    public void erroPassageiroPermiteNovaTentativa() throws Exception {
        servidor.falhasPassageiras = 1;
        try {
            cliente("nenhuma", "", "", true).enviar(mensagem());
            fail("deveria falhar");
        } catch (SmtpException e) {
            assertTrue(e.getMessage(), e.getMessage().startsWith("451"));
            assertFalse(e.definitivo);
        }
        cliente("nenhuma", "", "", true).enviar(mensagem());
        assertEquals(1, servidor.recebidas.size());
    }

    @Test
    public void quebraDeLinhaNoAssuntoOuNoNomeNaoCriaCabecalho() throws Exception {
        Smtp.Mensagem m = mensagem();
        m.assunto = "Aviso\r\nBcc: espiao@fora.com\r\n\r\ncorpo injetado";
        m.paraNome = "Ana\r\nBcc: espiao@fora.com";
        cliente("nenhuma", "", "", true).enviar(m);
        Recebida r = servidor.recebidas.get(0);
        assertNull(r.cabecalho("Bcc"));
        assertEquals("Aviso Bcc: espiao@fora.com corpo injetado", r.cabecalho("Subject"));
        assertEquals(1, servidor.comandos.stream().filter(c -> c.startsWith("RCPT TO:")).count());
        assertEquals(m.texto, r.parte("text/plain"));
    }

    @Test
    public void enderecoInvalidoNemChegaAoServidor() throws Exception {
        String[] ruins = { "ana@teste.com>\r\nRCPT TO:<espiao@fora.com", "sem-arroba", "a b@teste.com", "ana@teste", "", "ana@@teste.com", "ana@teste.com\n" };
        for (String ruim : ruins) {
            Smtp.Mensagem m = mensagem();
            m.para = ruim;
            try {
                cliente("nenhuma", "", "", true).enviar(m);
                fail("deveria recusar: " + ruim);
            } catch (SmtpException e) {
                assertTrue(e.definitivo);
            }
        }
        assertTrue(servidor.comandos.isEmpty());
    }

    @Test
    public void servidorQueDerrubaAConexao() throws Exception {
        servidor.derrubar = true;
        try {
            cliente("nenhuma", "", "", true).enviar(mensagem());
            fail("deveria falhar");
        } catch (IOException e) {
            assertFalse(e instanceof SmtpException && ((SmtpException) e).definitivo);
        }
    }

    @Test(timeout = 6000)
    public void servidorQueNaoRespondeNaoTravaOPortal() throws Exception {
        servidor.mudo = true;
        long ini = System.currentTimeMillis();
        try {
            new Smtp("localhost", servidor.porta(), "nenhuma", "", "", true, "x", 700).enviar(mensagem());
            fail("deveria falhar");
        } catch (IOException e) {
            assertTrue("desiste no tempo configurado", System.currentTimeMillis() - ini < 3000);
        }
    }

    @Test
    public void portaFechada() throws Exception {
        int porta = servidor.porta();
        servidor.close();
        try {
            new Smtp("localhost", porta, "nenhuma", "", "", true, "x", 1500).enviar(mensagem());
            fail("deveria falhar");
        } catch (IOException e) {
            assertFalse(e instanceof SmtpException && ((SmtpException) e).definitivo);
        }
    }

    /* ---------- conexão cifrada (o que os provedores usam: SSL na 465, STARTTLS na 587) ---------- */

    @Test
    public void sslDireto() throws Exception {
        assumeNotNull(SmtpFalso.contexto());
        servidor.modo = "ssl";
        servidor.usuario = "portal@exemplo.com";
        servidor.senha = "Segredo123";
        cliente("ssl", "portal@exemplo.com", "Segredo123", false).enviar(mensagem());
        assertEquals(1, servidor.recebidas.size());
        assertTrue(servidor.recebidas.get(0).cifrada);
        assertEquals(mensagem().texto, servidor.recebidas.get(0).parte("text/plain"));
    }

    @Test
    public void starttls() throws Exception {
        assumeNotNull(SmtpFalso.contexto());
        servidor.modo = "starttls";
        servidor.usuario = "portal@exemplo.com";
        servidor.senha = "Segredo123";
        cliente("starttls", "portal@exemplo.com", "Segredo123", false).enviar(mensagem());
        assertEquals(1, servidor.recebidas.size());
        assertTrue(servidor.recebidas.get(0).cifrada);
        int tls = servidor.comandos.indexOf("STARTTLS");
        assertTrue(tls > 0);
        assertTrue("a senha só vai depois de a conexão estar cifrada",
                servidor.comandos.subList(0, tls).stream().noneMatch(c -> c.startsWith("AUTH")));
        assertEquals("depois de cifrar, o cliente se apresenta de novo", 2, servidor.comandos.stream().filter(c -> c.startsWith("EHLO")).count());
    }

    @Test
    public void certificadoDesconhecidoEhRecusadoQuandoAVerificacaoEstaLigada() throws Exception {
        assumeNotNull(SmtpFalso.contexto());
        servidor.modo = "ssl";
        try {
            cliente("ssl", "", "", true).enviar(mensagem());
            fail("deveria recusar o certificado de teste");
        } catch (SmtpException e) {
            assertTrue(e.getMessage(), e.getMessage().contains("conexão segura"));
            assertFalse(e.definitivo);
        }
        assertTrue(servidor.recebidas.isEmpty());
    }

    @Test
    public void provedorSemStarttlsGeraMensagemClara() throws Exception {
        servidor.modo = "starttls";
        servidor.anunciarStarttls = false;
        try {
            cliente("starttls", "", "", false).enviar(mensagem());
            fail("deveria falhar");
        } catch (SmtpException e) {
            assertTrue(e.getMessage(), e.getMessage().contains("STARTTLS"));
        }
        assertTrue("nada é enviado sem a conexão cifrada", servidor.comandos.stream().noneMatch(c -> c.startsWith("MAIL FROM")));
    }

    /* ---------- cabeçalhos ---------- */

    @Test
    public void palavraCodificadaNaoCortaCaractereAoMeio() {
        String s = "çãé🎉".repeat(30);
        String cod = Smtp.palavra(s, 9);
        for (String linha : cod.split("\r\n"))
            assertTrue("linha longa: " + linha.length(), linha.length() <= 76);
        assertEquals(s, SmtpFalsoDecodificador.decodificar(cod));
        assertEquals("Texto simples", Smtp.palavra("Texto simples", 9));
    }

    /** Acesso ao decodificador do servidor de teste. */
    private static final class SmtpFalsoDecodificador {
        static String decodificar(String v) {
            Recebida r = new Recebida();
            r.bruto = "X-Teste: " + v + "\r\n\r\n";
            return r.cabecalho("X-Teste");
        }
    }
}
