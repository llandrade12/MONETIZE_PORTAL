package br.com.monetize.portal.dados;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import br.com.monetize.portal.util.Json;

/** As regras de turma, prazo e frequência no servidor precisam dar o mesmo resultado que as telas do portal. */
public class PortalTest {

    private Portal p;
    private Map<String, Object> ana, bruno, semTurma;

    private static Map<String, Object> j(String json) {
        return Json.lerObjeto(json.replace('\'', '"'));
    }

    @Before
    public void montar() {
        p = new Portal("2026-10-07");
        p.turmas.add(j("{'id':1,'nome':'Turma A','unidades':[{'nome':'U1','qtd':4},{'nome':'U2','qtd':4}]}"));
        p.turmas.add(j("{'id':2,'nome':'Turma B','unidades':[],'freqMin':50}"));
        ana = j("{'id':10,'nome':'Ana','turma':1,'status':'ativo','mat':'2026-09-01'}");
        bruno = j("{'id':11,'nome':'Bruno','turma':2,'status':'ativo','mat':''}");
        semTurma = j("{'id':12,'nome':'Caio','turma':0,'status':'pendente'}");
        p.alunos.add(ana);
        p.alunos.add(bruno);
        p.alunos.add(semTurma);
        /* Turma A: uma aula antes da matrícula da Ana e quatro depois (uma delas cancelada, uma ainda agendada). */
        p.aulas.add(j("{'n':1,'nome':'Antes da matricula','date':'2026-08-20','hora':'20:00','status':'realizada','turmas':[1]}"));
        p.aulas.add(j("{'n':2,'nome':'Aula 2','date':'2026-09-10','hora':'20:00','status':'realizada','turmas':[1],'video':'https://youtu.be/x'}"));
        p.aulas.add(j("{'n':3,'nome':'Aula 3','date':'2026-09-17','hora':'20:00','status':'parcial','turmas':[1]}"));
        p.aulas.add(j("{'n':4,'nome':'Aula 4','date':'2026-09-24','hora':'20:00','status':'cancelada','turmas':[1]}"));
        p.aulas.add(j("{'n':5,'nome':'Aula 5','date':'2026-10-08','hora':'20:00','status':'agendada','turmas':[1]}"));
        /* Aula para todas as turmas (lista vazia) e uma só da turma B. */
        p.aulas.add(j("{'n':6,'nome':'Aula aberta','date':'2026-09-30','hora':'19:00','status':'realizada','turmas':[]}"));
        p.aulas.add(j("{'n':7,'nome':'So da B','date':'2026-09-12','hora':'09:00','status':'realizada','turmas':[2]}"));
        p.tarefas.add(j("{'id':100,'t':'Tarefa vencida','due':'2026-10-01','turmas':[1]}"));
        p.tarefas.add(j("{'id':101,'t':'Tarefa futura','due':'2026-10-20','turmas':[]}"));
        p.tarefas.add(j("{'id':102,'t':'Com liberacao','due':'2026-10-30','lib':'2026-10-07','turmas':[1]}"));
        p.tarefas.add(j("{'id':103,'t':'Da turma B','due':'2026-10-02','turmas':[2]}"));
    }

    @Test
    public void aulasETarefasPorTurma() {
        assertEquals("aulas da turma A, em ordem de data", "[1, 2, 3, 4, 6, 5]", p.aulasDe(1).stream().map(a -> a.get("n")).collect(java.util.stream.Collectors.toList()).toString());
        assertEquals("[7, 6]", p.aulasDe(2).stream().map(a -> a.get("n")).collect(java.util.stream.Collectors.toList()).toString());
        assertEquals(7, p.aulasDe(0).size());
        assertEquals("aluno sem turma só vê o que vale para todas as turmas", 1, p.aulasDe(p.turmaDe(semTurma)).size());
        assertEquals("[100, 101, 102]", p.tarefasDe(ana).stream().map(t -> t.get("id")).collect(java.util.stream.Collectors.toList()).toString());
        assertEquals("[101, 103]", p.tarefasDe(bruno).stream().map(t -> t.get("id")).collect(java.util.stream.Collectors.toList()).toString());
    }

    @Test
    public void liberacaoPrazoEAtraso() {
        Map<String, Object> vencida = p.tarefas.get(0), futura = p.tarefas.get(1), comLib = p.tarefas.get(2);
        assertTrue("sem data de liberação, a tarefa abre 7 dias antes do prazo", p.liberada(vencida));
        assertFalse(p.liberada(futura));
        assertTrue("com data de liberação, vale a data", p.liberada(comLib));
        assertTrue(p.atrasada(ana, vencida));
        assertFalse(p.atrasada(ana, comLib));
        assertEquals(1, p.atrasos(ana).size());

        /* O mentor reabriu o prazo: deixa de estar em atraso. */
        p.prazo.put("10-100", "2026-10-09");
        assertEquals("2026-10-09", p.prazoDe(ana, vencida));
        assertFalse(p.atrasada(ana, vencida));
        p.prazo.remove("10-100");

        /* Entregou: deixa de estar em atraso. */
        p.ent.put("10-100", j("{'txt':'feito','at':'01/10/2026 10:00'}"));
        assertTrue(p.entregou(ana, vencida));
        assertTrue(p.atrasos(ana).isEmpty());
    }

    @Test
    public void vencimentoNoDiaNaoEhAtraso() {
        Portal hoje = new Portal("2026-10-01");
        hoje.tarefas.addAll(p.tarefas);
        assertFalse(hoje.atrasada(ana, p.tarefas.get(0)));
    }

    @Test
    public void frequenciaContaSoDesdeAMatriculaEAulasRealizadas() {
        /* Base da Ana: aulas 2, 3 e 6 (a 1 é anterior à matrícula, a 4 foi cancelada, a 5 ainda não aconteceu). */
        assertEquals(3, p.baseDeFrequencia(ana).size());
        p.pres.put("10-2", "P");
        p.pres.put("10-3", "A");
        Portal.Frequencia f = p.frequencia(ana);
        assertEquals(3, f.n);
        assertEquals(2, f.ok);
        assertEquals(67, f.pct);
        assertEquals(1, f.faltas);
        assertTrue("67% está abaixo do mínimo de 75%", f.abaixo);
        assertEquals("75", f.minTexto());
    }

    @Test
    public void justificadaEGravacaoSeguemAsRegrasConfiguradas() {
        p.pres.put("10-2", "F");
        p.pres.put("10-3", "J");
        p.pres.put("10-6", "P");
        /* Padrão: justificada abona e gravação assistida compensa. */
        assertEquals("F", p.situacao(ana, p.aulas.get(1)));
        assertEquals(2, p.frequencia(ana).ok);
        p.vis.put("10-2", true);
        assertEquals("C", p.situacao(ana, p.aulas.get(1)));
        assertEquals(3, p.frequencia(ana).ok);
        assertFalse(p.frequencia(ana).abaixo);

        p.cfg.put("compensa", false);
        assertEquals("F", p.situacao(ana, p.aulas.get(1)));
        p.cfg.put("justAbona", false);
        Portal.Frequencia f = p.frequencia(ana);
        assertEquals(1, f.ok);
        assertEquals(33, f.pct);
        assertTrue(f.abaixo);
    }

    @Test
    public void semChamadaContaComoFalta() {
        Portal.Frequencia f = p.frequencia(ana);
        assertEquals(0, f.ok);
        assertEquals(3, f.faltas);
        assertEquals(0, f.pct);
    }

    @Test
    public void semEncontrosAFrequenciaEhCheia() {
        Portal vazio = new Portal("2026-10-07");
        Portal.Frequencia f = vazio.frequencia(ana);
        assertEquals(0, f.n);
        assertEquals(100, f.pct);
        assertFalse(f.abaixo);
    }

    @Test
    public void minimoDaTurmaValeMaisQueOGeral() {
        assertEquals(75.0, p.frequenciaMinima(ana), 1e-9);
        assertEquals(50.0, p.frequenciaMinima(bruno), 1e-9);
        p.cfg.put("freqMin", 80L);
        assertEquals(80.0, p.frequenciaMinima(ana), 1e-9);
        p.pres.put("11-7", "P");
        Portal.Frequencia f = p.frequencia(bruno);
        assertEquals(2, f.n);
        assertEquals(50, f.pct);
        assertFalse("50% atinge o mínimo de 50% da turma B", f.abaixo);
    }

    @Test
    public void faltasQueAindaCabem() {
        /* Turma A planeja 8 encontros; um aconteceu antes da matrícula da Ana: ela tem 7 previstos.
           Com mínimo de 75%, cabem floor(7 x 25%) = 1 falta. */
        assertEquals(7, p.totalPrevisto(ana));
        p.pres.put("10-2", "P");
        p.pres.put("10-3", "P");
        p.pres.put("10-6", "P");
        assertEquals(1, p.frequencia(ana).restam);
        p.pres.put("10-6", "F");
        Portal.Frequencia f = p.frequencia(ana);
        assertEquals(0, f.restam);
        assertEquals(1, f.faltas);
    }

    @Test
    public void percentualArredondaComoNaTela() {
        assertEquals(67, Portal.pct(2, 3));
        assertEquals(33, Portal.pct(1, 3));
        assertEquals(13, Portal.pct(1, 8));
        assertEquals(0, Portal.pct(0, 0));
        assertEquals(100, Portal.pct(5, 5));
    }
}
