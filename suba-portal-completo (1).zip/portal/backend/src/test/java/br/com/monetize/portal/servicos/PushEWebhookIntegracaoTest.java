package br.com.monetize.portal.servicos;

import static br.com.monetize.portal.apoio.Cliente.gravar;
import static br.com.monetize.portal.apoio.Cliente.j;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.Signature;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.sun.net.httpserver.HttpServer;

import br.com.monetize.portal.apoio.Cliente;
import br.com.monetize.portal.apoio.ServidorDeTeste;
import br.com.monetize.portal.db.Banco;
import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Texto;

/**
 * Push e webhook de ponta a ponta, com serviços de mentira no lugar do Google/Apple e do n8n/Make:
 * o teste recebe a requisição que o portal faria e confere o conteúdo.
 */
public class PushEWebhookIntegracaoTest {

    /** Uma requisição recebida pelo serviço de mentira. */
    private static final class Recebida {
        String caminho, autorizacao, codificacao, ttl, tipo;
        byte[] corpo;
    }

    private ServidorDeTeste srv;
    private HttpServer servico;
    private final List<Recebida> recebidas = new CopyOnWriteArrayList<>();
    private String enderecoDoServico;
    private Cliente mentor, aluna;
    private long idAluna;

    @Before
    public void subir() throws Exception {
        srv = new ServidorDeTeste();
        srv.app.push.aceitarQualquerServico = true;
        servico = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 20);
        servico.createContext("/", x -> {
            Recebida r = new Recebida();
            r.caminho = x.getRequestURI().getPath();
            r.autorizacao = x.getRequestHeaders().getFirst("Authorization");
            r.codificacao = x.getRequestHeaders().getFirst("Content-Encoding");
            r.ttl = x.getRequestHeaders().getFirst("TTL");
            r.tipo = x.getRequestHeaders().getFirst("Content-Type");
            r.corpo = x.getRequestBody().readAllBytes();
            recebidas.add(r);
            /* Aparelho que cancelou a inscrição: o serviço de push responde 410. */
            int status = r.caminho.contains("cancelado") ? 410 : r.caminho.contains("fora-do-ar") ? 503 : 201;
            x.sendResponseHeaders(status, -1);
            x.close();
        });
        servico.start();
        enderecoDoServico = "http://127.0.0.1:" + servico.getAddress().getPort();

        mentor = srv.mentor();
        long id = Json.num(Json.lista(mentor.get("/api/ids").json(), "ids").get(0), 0);
        idAluna = id + 1;
        mentor.sync(gravar("turmas", id, j("{'id':" + id + ",'nome':'Turma','unidades':[]}")),
                gravar("alunos", idAluna, j("{'id':" + idAluna + ",'nome':'Ana Souza','email':'ana@teste.com','turma':" + id + ",'status':'ativo','canais':{'email':false,'whats':false},'senhaNova':'Aluna12345'}")));
        aluna = srv.cliente();
        aluna.entrar("ana@teste.com", "Aluna12345").exigir(200);
    }

    @After
    public void derrubar() {
        servico.stop(0);
        srv.close();
    }

    private boolean esperar(int n) throws InterruptedException {
        long fim = System.currentTimeMillis() + 8000;
        while (recebidas.size() < n && System.currentTimeMillis() < fim)
            Thread.sleep(20);
        return recebidas.size() >= n;
    }

    private static Map<String, Object> inscricao(String endpoint, KeyPair aparelho, byte[] auth) {
        return Json.mapa("endpoint", endpoint, "keys", Json.mapa("p256dh", Texto.b64url(WebPush.pontoDe(aparelho.getPublic())), "auth", Texto.b64url(auth)));
    }

    @Test
    public void notificacaoChegaCifradaAoAparelhoDoAlunoEAoDoMentor() throws Exception {
        KeyPair celular = WebPush.novoPar(), computador = WebPush.novoPar();
        byte[] authCelular = Texto.aleatorio(16), authComputador = Texto.aleatorio(16);
        aluna.post("/api/push/inscrever", inscricao(enderecoDoServico + "/aparelho/celular-da-ana", celular, authCelular)).exigir(200);
        mentor.post("/api/push/inscrever", inscricao(enderecoDoServico + "/aparelho/computador-do-mentor", computador, authComputador)).exigir(200);

        /* Teste de "Notificações neste aparelho": chega só no aparelho de quem pediu. */
        assertEquals(1L, aluna.post("/api/push/teste", null).exigir(200).json().get("entregues"));
        assertEquals(1, recebidas.size());
        Recebida r = recebidas.get(0);
        assertEquals("/aparelho/celular-da-ana", r.caminho);
        assertEquals("aes128gcm", r.codificacao);
        assertEquals("86400", r.ttl);
        assertEquals("application/octet-stream", r.tipo);
        Map<String, Object> msg = Json.lerObjeto(new String(WebPushTest.decifrar(r.corpo, celular, authCelular), StandardCharsets.UTF_8));
        assertEquals("Notificações ligadas", msg.get("t"));
        assertEquals(srv.base + "/aluno.html", msg.get("u"));

        /* O cabeçalho de identificação leva a chave pública que o portal entrega ao navegador, e a assinatura confere. */
        String chave = Json.str(Json.obj(aluna.estado(), "srv"), "push");
        assertTrue(r.autorizacao, r.autorizacao.startsWith("vapid t=") && r.autorizacao.endsWith(", k=" + chave));
        String[] jwt = r.autorizacao.substring(8, r.autorizacao.indexOf(", k=")).split("\\.");
        Signature s = Signature.getInstance("SHA256withECDSAinP1363Format");
        s.initVerify(WebPush.publicaDe(Texto.deB64url(chave)));
        s.update((jwt[0] + "." + jwt[1]).getBytes(StandardCharsets.US_ASCII));
        assertTrue(s.verify(Texto.deB64url(jwt[2])));
        assertEquals(enderecoDoServico, Json.lerObjeto(new String(Texto.deB64url(jwt[1]), StandardCharsets.UTF_8)).get("aud"));

        /* O mentor lança um aviso para a aluna: push no celular dela, com o endereço da página do aviso. */
        mentor.sync(gravar("inbox", "n1", j("{'id':'n1','aid':" + idAluna + ",'t':'Nota lançada','m':'Sua tarefa recebeu nota 9.','at':'x','lido':false,'go':'tarefas','canal':'Somente no portal'}")));
        assertTrue(esperar(2));
        r = recebidas.get(1);
        assertEquals("/aparelho/celular-da-ana", r.caminho);
        msg = Json.lerObjeto(new String(WebPushTest.decifrar(r.corpo, celular, authCelular), StandardCharsets.UTF_8));
        assertEquals("Nota lançada", msg.get("t"));
        assertEquals("Sua tarefa recebeu nota 9.", msg.get("b"));
        assertEquals(srv.base + "/aluno.html#ir=tarefas", msg.get("u"));

        /* A aluna gera um alerta para o mentor: push no computador dele. */
        aluna.sync(gravar("inboxM", "a1", j("{'id':'a1','t':'Chamado de Ana Souza (Acesso)','m':'Não abre a gravação','go':'suporte','arg':null}")));
        assertTrue(esperar(3));
        r = recebidas.get(2);
        assertEquals("/aparelho/computador-do-mentor", r.caminho);
        msg = Json.lerObjeto(new String(WebPushTest.decifrar(r.corpo, computador, authComputador), StandardCharsets.UTF_8));
        assertEquals("Chamado de Ana Souza (Acesso)", msg.get("t"));
        assertEquals(srv.base + "/mentor.html#ir=suporte", msg.get("u"));

        /* Desligou as notificações no aparelho: não chega mais nada. */
        aluna.post("/api/push/remover", Json.mapa("endpoint", enderecoDoServico + "/aparelho/celular-da-ana")).exigir(200);
        assertEquals(0L, aluna.post("/api/push/teste", null).exigir(200).json().get("entregues"));
        assertEquals(3, recebidas.size());
    }

    @Test
    public void aparelhoQueCancelouAInscricaoSaiDaLista() throws Exception {
        KeyPair a = WebPush.novoPar(), b = WebPush.novoPar();
        aluna.post("/api/push/inscrever", inscricao(enderecoDoServico + "/aparelho/cancelado", a, Texto.aleatorio(16))).exigir(200);
        aluna.post("/api/push/inscrever", inscricao(enderecoDoServico + "/aparelho/ativo", b, Texto.aleatorio(16))).exigir(200);
        aluna.post("/api/push/inscrever", inscricao(enderecoDoServico + "/aparelho/fora-do-ar", b, Texto.aleatorio(16))).exigir(200);
        /* O mesmo aparelho inscrito de novo não vira duas inscrições. */
        aluna.post("/api/push/inscrever", inscricao(enderecoDoServico + "/aparelho/ativo", b, Texto.aleatorio(16))).exigir(200);
        assertEquals(3L, (long) srv.app.banco.usar(c -> Banco.um(c, "SELECT COUNT(*) FROM push_inscricao", r -> r.getLong(1))));

        assertEquals(1L, aluna.post("/api/push/teste", null).exigir(200).json().get("entregues"));
        assertEquals("o cancelado sai; o que estava fora do ar fica para a próxima", 2L,
                (long) srv.app.banco.usar(c -> Banco.um(c, "SELECT COUNT(*) FROM push_inscricao", r -> r.getLong(1))));
        assertEquals(1L, (long) srv.app.banco.usar(c -> Banco.um(c, "SELECT falhas FROM push_inscricao WHERE endpoint LIKE '%fora-do-ar'", r -> r.getLong(1))));
    }

    @Test
    public void soAceitaServicosDePushConhecidos() throws Exception {
        srv.app.push.aceitarQualquerServico = false;
        KeyPair a = WebPush.novoPar();
        byte[] auth = Texto.aleatorio(16);
        /* Sem isso, alguém poderia mandar o servidor fazer requisições para endereços internos da rede. */
        aluna.post("/api/push/inscrever", inscricao(enderecoDoServico + "/aparelho/x", a, auth)).exigir(400);
        aluna.post("/api/push/inscrever", inscricao("https://servidor-interno.exemplo.com/admin", a, auth)).exigir(400);
        aluna.post("/api/push/inscrever", inscricao("https://fcm.googleapis.com.exemplo.com/x", a, auth)).exigir(400);
        aluna.post("/api/push/inscrever", inscricao("http://fcm.googleapis.com/fcm/send/abc", a, auth)).exigir(400);
        aluna.post("/api/push/inscrever", inscricao("nem-e-endereco", a, auth)).exigir(400);
        aluna.post("/api/push/inscrever", inscricao("https://fcm.googleapis.com/fcm/send/abc", a, auth)).exigir(200);
        aluna.post("/api/push/inscrever", inscricao("https://updates.push.services.mozilla.com/wpush/v2/abc", a, auth)).exigir(200);
        aluna.post("/api/push/inscrever", inscricao("https://web.push.apple.com/abc", a, auth)).exigir(200);
        aluna.post("/api/push/inscrever", inscricao("https://wns2-by3p.notify.windows.com/w/?token=abc", a, auth)).exigir(200);
        /* Chaves fora do formato. */
        aluna.post("/api/push/inscrever", Json.mapa("endpoint", "https://fcm.googleapis.com/fcm/send/def", "keys", Json.mapa("p256dh", "curta", "auth", "curta"))).exigir(400);
        aluna.post("/api/push/inscrever", Json.mapa("endpoint", "https://fcm.googleapis.com/fcm/send/def")).exigir(400);
        srv.cliente().post("/api/push/inscrever", inscricao("https://fcm.googleapis.com/fcm/send/ghi", a, auth)).exigir(401);
    }

    @Test
    public void webhookRecebeAMensagemEAFilaMostraQueSaiu() throws Exception {
        /* Um item na fila do painel e a mensagem correspondente na fila de saída, como o portal cria para o WhatsApp. */
        mentor.sync(gravar("fila", "f1", j("{'id':'f1','at':'x','aid':" + idAluna + ",'nome':'Ana Souza','c':'whats','to':'(71) 98888-7777','ev':'Prazo chegando','txt':'Olá, Ana.','st':'enviando','auto':true}")));
        String corpo = Json.texto(Json.mapa("canal", "whatsapp", "para", "71988887777", "nome", "Ana Souza", "assunto", "Prazo chegando", "mensagem", "Olá, Ana. A tarefa vence amanhã 🚀", "automatico", true));
        srv.app.banco.usar(c -> Banco.executar(c, "INSERT INTO envio (fila_chave, canal, destino, nome, assunto, corpo, status, tentativas, proxima_em, criado_em) VALUES ('f1', 'webhook', ?, 'Ana Souza', 'Prazo chegando', ?, 'pendente', 0, ?, ?)",
                enderecoDoServico + "/gancho/portal", corpo, srv.app.sinc.agora(), srv.app.sinc.agora()));
        srv.app.envios.acordar();
        assertTrue(esperar(1));
        Recebida r = recebidas.get(0);
        assertEquals("/gancho/portal", r.caminho);
        assertTrue(r.tipo.startsWith("application/json"));
        Map<String, Object> m = Json.lerObjeto(new String(r.corpo, StandardCharsets.UTF_8));
        assertEquals("whatsapp", m.get("canal"));
        assertEquals("71988887777", m.get("para"));
        assertEquals("Olá, Ana. A tarefa vence amanhã 🚀", m.get("mensagem"));
        assertTrue(Json.str(m, "enviado_em").matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}.*-03:00"));

        long fim = System.currentTimeMillis() + 5000;
        String st = "";
        while (System.currentTimeMillis() < fim && !"enviado".equals(st)) {
            Thread.sleep(50);
            st = Json.str(Json.obj(Json.lista(mentor.dados(), "fila").get(0)), "st");
        }
        assertEquals("enviado", st);

        /* Serviço fora do ar: o envio fica para nova tentativa e o item continua como "enviando". */
        mentor.sync(gravar("fila", "f2", j("{'id':'f2','at':'x','aid':" + idAluna + ",'nome':'Ana Souza','c':'whats','to':'x','ev':'Outro','txt':'x','st':'enviando','auto':true}")));
        srv.app.banco.usar(c -> Banco.executar(c, "INSERT INTO envio (fila_chave, canal, destino, nome, assunto, corpo, status, tentativas, proxima_em, criado_em) VALUES ('f2', 'webhook', ?, 'Ana Souza', 'Outro', '{}', 'pendente', 0, ?, ?)",
                enderecoDoServico + "/gancho/fora-do-ar", srv.app.sinc.agora(), srv.app.sinc.agora()));
        srv.app.envios.acordar();
        assertTrue(esperar(2));
        Thread.sleep(300);
        assertEquals("pendente|1", srv.app.banco.usar(c -> Banco.um(c, "SELECT CONCAT(status, '|', tentativas) FROM envio WHERE fila_chave = 'f2'", x -> x.getString(1))));
        assertFalse(Json.texto(mentor.dados().get("fila")).contains("\"erro\""));
    }
}
