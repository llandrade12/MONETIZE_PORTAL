package br.com.monetize.portal.apoio;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;

/**
 * Servidor de e-mail de mentira, para os testes: fala SMTP de verdade (inclusive SSL e STARTTLS, com um
 * certificado criado na hora), guarda o que recebeu e pode simular recusas.
 */
public final class SmtpFalso implements AutoCloseable {

    /** Uma mensagem aceita pelo servidor. */
    public static final class Recebida {
        public String de;
        public String para;
        /** A mensagem como chegou (cabeçalhos e corpo), já sem a duplicação de pontos. */
        public String bruto;
        public boolean cifrada;

        /** Valor de um cabeçalho, com as linhas de continuação juntas e as palavras codificadas já decodificadas. */
        public String cabecalho(String nome) {
            String cab = bruto.substring(0, bruto.indexOf("\r\n\r\n") + 2);
            Matcher m = Pattern.compile("(?im)^" + Pattern.quote(nome) + ":[ \\t]*(.*(?:\\r\\n[ \\t].*)*)\\r\\n").matcher(cab);
            if (!m.find())
                return null;
            return decodificar(m.group(1).replaceAll("\\r\\n[ \\t]+", " "));
        }

        /** Palavras =?UTF-8?B?...?= viram texto (o espaço entre duas palavras codificadas não conta). */
        static String decodificar(String v) {
            String junto = v.replaceAll("\\?=\\s+=\\?", "?==?");
            Matcher m = Pattern.compile("=\\?UTF-8\\?B\\?([A-Za-z0-9+/=]*)\\?=").matcher(junto);
            StringBuilder b = new StringBuilder();
            int pos = 0;
            java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
            while (m.find()) {
                if (m.start() > pos) {
                    b.append(new String(bytes.toByteArray(), StandardCharsets.UTF_8));
                    bytes.reset();
                    b.append(junto, pos, m.start());
                }
                byte[] d = Base64.getDecoder().decode(m.group(1));
                bytes.write(d, 0, d.length);
                pos = m.end();
            }
            b.append(new String(bytes.toByteArray(), StandardCharsets.UTF_8));
            b.append(junto.substring(pos));
            return b.toString();
        }

        /** Conteúdo decodificado da parte com o tipo informado ("text/plain" ou "text/html"). */
        public String parte(String tipo) {
            String ct = cabecalho("Content-Type");
            String corpo = bruto.substring(bruto.indexOf("\r\n\r\n") + 4);
            if (ct != null && ct.toLowerCase(Locale.ROOT).startsWith(tipo))
                return base64(corpo);
            Matcher lim = Pattern.compile("boundary=\"([^\"]+)\"").matcher(ct == null ? "" : ct);
            if (!lim.find())
                return null;
            for (String p : corpo.split(Pattern.quote("--" + lim.group(1)))) {
                int fim = p.indexOf("\r\n\r\n");
                if (fim < 0)
                    continue;
                if (p.substring(0, fim).toLowerCase(Locale.ROOT).contains("content-type: " + tipo))
                    return base64(p.substring(fim + 4));
            }
            return null;
        }

        private static String base64(String s) {
            return new String(Base64.getMimeDecoder().decode(s.trim()), StandardCharsets.UTF_8);
        }
    }

    public final List<Recebida> recebidas = new CopyOnWriteArrayList<>();
    /** Linhas que o cliente enviou (sem o conteúdo da mensagem), para conferir a conversa. */
    public final List<String> comandos = new CopyOnWriteArrayList<>();

    /** "nenhuma", "ssl" (conexão já cifrada) ou "starttls". */
    public volatile String modo = "nenhuma";
    /** Com usuário definido, o servidor exige login antes de aceitar mensagens. */
    public volatile String usuario;
    public volatile String senha;
    /** Formas de login anunciadas. */
    public volatile String auth = "PLAIN LOGIN";
    /** Destinatário recusado para sempre (550). */
    public volatile String destinatarioInexistente;
    /** Quantas mensagens recusar com erro passageiro (451) antes de aceitar. */
    public volatile int falhasPassageiras;
    /** Anuncia STARTTLS? (falso simula um provedor que não oferece) */
    public volatile boolean anunciarStarttls = true;
    /** Fecha a conexão logo depois da saudação. */
    public volatile boolean derrubar;
    /** Aceita a conexão e não responde nada. */
    public volatile boolean mudo;

    private final ServerSocket servidor;
    private final Thread thread;
    private volatile boolean aberto = true;
    private static SSLContext contexto;

    public SmtpFalso() throws IOException {
        servidor = new ServerSocket(0, 50, InetAddress.getLoopbackAddress());
        thread = new Thread(this::aceitar, "smtp-falso");
        thread.setDaemon(true);
        thread.start();
    }

    public int porta() {
        return servidor.getLocalPort();
    }

    /** Espera até chegarem n mensagens (ou o tempo acabar). */
    public boolean esperar(int n, long ms) throws InterruptedException {
        long fim = System.currentTimeMillis() + ms;
        while (recebidas.size() < n && System.currentTimeMillis() < fim)
            Thread.sleep(20);
        return recebidas.size() >= n;
    }

    /** Última mensagem recebida para o endereço, ou null. */
    public Recebida ultimaPara(String email) {
        for (int i = recebidas.size() - 1; i >= 0; i--)
            if (recebidas.get(i).para.equalsIgnoreCase(email))
                return recebidas.get(i);
        return null;
    }

    public List<Recebida> para(String email) {
        List<Recebida> l = new ArrayList<>();
        for (Recebida r : recebidas)
            if (r.para.equalsIgnoreCase(email))
                l.add(r);
        return l;
    }

    @Override
    public void close() {
        aberto = false;
        try {
            servidor.close();
        } catch (IOException e) {
            /* encerrando */
        }
    }

    private void aceitar() {
        while (aberto) {
            try {
                Socket s = servidor.accept();
                Thread t = new Thread(() -> atender(s), "smtp-falso-conexao");
                t.setDaemon(true);
                t.start();
            } catch (IOException e) {
                return;
            }
        }
    }

    /**
     * Certificado de teste para "localhost", criado com a ferramenta keytool que acompanha o Java.
     * Devolve null se a ferramenta não existir nesta instalação (os testes de conexão cifrada são pulados).
     */
    public static synchronized SSLContext contexto() {
        if (contexto != null)
            return contexto;
        try {
            Path keytool = Path.of(System.getProperty("java.home"), "bin", System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win") ? "keytool.exe" : "keytool");
            if (!Files.isExecutable(keytool))
                return null;
            Path pasta = Files.createTempDirectory("smtp-falso");
            File arquivo = pasta.resolve("teste.p12").toFile();
            Process p = new ProcessBuilder(keytool.toString(), "-genkeypair", "-alias", "smtp", "-keyalg", "RSA", "-keysize", "2048", "-dname", "CN=localhost",
                    "-ext", "SAN=dns:localhost,ip:127.0.0.1", "-validity", "2", "-storetype", "PKCS12", "-keystore", arquivo.getPath(), "-storepass", "changeit",
                    "-keypass", "changeit").redirectErrorStream(true).start();
            p.getInputStream().readAllBytes();
            if (!p.waitFor(60, TimeUnit.SECONDS) || p.exitValue() != 0)
                return null;
            KeyStore ks = KeyStore.getInstance("PKCS12");
            try (InputStream in = Files.newInputStream(arquivo.toPath())) {
                ks.load(in, "changeit".toCharArray());
            }
            KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            kmf.init(ks, "changeit".toCharArray());
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(kmf.getKeyManagers(), null, null);
            Files.deleteIfExists(arquivo.toPath());
            Files.deleteIfExists(pasta);
            contexto = ctx;
            return ctx;
        } catch (Exception e) {
            return null;
        }
    }

    private static Socket cifrar(Socket s) throws IOException {
        SSLSocket ssl = (SSLSocket) contexto().getSocketFactory().createSocket(s, s.getInetAddress().getHostAddress(), s.getPort(), true);
        ssl.setUseClientMode(false);
        ssl.startHandshake();
        return ssl;
    }

    private void atender(Socket bruto) {
        Socket s = bruto;
        try {
            s.setSoTimeout(15000);
            if (mudo) {
                Thread.sleep(5000);
                return;
            }
            boolean cifrada = false;
            if (modo.equals("ssl")) {
                s = cifrar(s);
                cifrada = true;
            }
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            OutputStream out = s.getOutputStream();
            responder(out, "220 smtp.falso.teste ESMTP pronto");
            if (derrubar)
                return;
            boolean logado = usuario == null;
            String de = null, para = null;
            String linha;
            while ((linha = in.readLine()) != null) {
                comandos.add(linha);
                String cmd = linha.toUpperCase(Locale.ROOT);
                if (cmd.startsWith("EHLO")) {
                    StringBuilder b = new StringBuilder("250-smtp.falso.teste\r\n250-SIZE 20000000\r\n250-8BITMIME\r\n");
                    if (modo.equals("starttls") && !cifrada && anunciarStarttls)
                        b.append("250-STARTTLS\r\n");
                    if (usuario != null && !auth.isEmpty())
                        b.append("250-AUTH ").append(auth).append("\r\n");
                    b.append("250 HELP");
                    responder(out, b.toString());
                } else if (cmd.equals("STARTTLS")) {
                    if (!modo.equals("starttls") || cifrada) {
                        responder(out, "502 comando fora de hora");
                        continue;
                    }
                    responder(out, "220 pode cifrar");
                    s = cifrar(s);
                    cifrada = true;
                    in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                    out = s.getOutputStream();
                } else if (cmd.startsWith("AUTH PLAIN")) {
                    String[] p = new String(Base64.getDecoder().decode(linha.substring(11).trim()), StandardCharsets.UTF_8).split("\0", -1);
                    logado = p.length == 3 && p[1].equals(usuario) && p[2].equals(senha);
                    responder(out, logado ? "235 2.7.0 autenticado" : "535 5.7.8 usuario ou senha incorretos");
                } else if (cmd.equals("AUTH LOGIN")) {
                    responder(out, "334 VXNlcm5hbWU6");
                    String u = new String(Base64.getDecoder().decode(in.readLine().trim()), StandardCharsets.UTF_8);
                    responder(out, "334 UGFzc3dvcmQ6");
                    String p = new String(Base64.getDecoder().decode(in.readLine().trim()), StandardCharsets.UTF_8);
                    comandos.add("(login de " + u + ")");
                    logado = u.equals(usuario) && p.equals(senha);
                    responder(out, logado ? "235 2.7.0 autenticado" : "535 5.7.8 usuario ou senha incorretos");
                } else if (cmd.startsWith("MAIL FROM:")) {
                    if (modo.equals("starttls") && !cifrada) {
                        responder(out, "530 5.7.0 use STARTTLS primeiro");
                        continue;
                    }
                    if (!logado) {
                        responder(out, "530 5.7.0 autenticacao exigida");
                        continue;
                    }
                    de = entre(linha);
                    responder(out, "250 2.1.0 remetente aceito");
                } else if (cmd.startsWith("RCPT TO:")) {
                    String alvo = entre(linha);
                    if (de == null)
                        responder(out, "503 5.5.1 informe o remetente antes");
                    else if (alvo.equalsIgnoreCase(destinatarioInexistente))
                        responder(out, "550 5.1.1 caixa postal inexistente");
                    else {
                        para = alvo;
                        responder(out, "250 2.1.5 destinatario aceito");
                    }
                } else if (cmd.equals("DATA")) {
                    if (para == null) {
                        responder(out, "503 5.5.1 sem destinatario");
                        continue;
                    }
                    responder(out, "354 envie a mensagem, termine com um ponto sozinho");
                    StringBuilder msg = new StringBuilder();
                    String l;
                    while ((l = in.readLine()) != null && !l.equals("."))
                        msg.append(l.startsWith(".") ? l.substring(1) : l).append("\r\n");
                    if (falhasPassageiras > 0) {
                        falhasPassageiras--;
                        responder(out, "451 4.3.0 tente de novo mais tarde");
                    } else {
                        Recebida r = new Recebida();
                        r.de = de;
                        r.para = para;
                        r.bruto = msg.toString();
                        r.cifrada = cifrada;
                        recebidas.add(r);
                        responder(out, "250 2.0.0 mensagem aceita");
                    }
                    de = null;
                    para = null;
                } else if (cmd.equals("QUIT")) {
                    responder(out, "221 2.0.0 ate logo");
                    return;
                } else if (cmd.equals("RSET") || cmd.equals("NOOP")) {
                    responder(out, "250 ok");
                } else {
                    responder(out, "500 5.5.2 comando desconhecido");
                }
            }
        } catch (IOException | RuntimeException e) {
            /* conexão encerrada pelo cliente ou conversa inválida: o teste confere o que foi recebido */
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            try {
                s.close();
            } catch (IOException e) {
                /* encerrando */
            }
        }
    }

    private static String entre(String linha) {
        int a = linha.indexOf('<'), b = linha.indexOf('>');
        return a >= 0 && b > a ? linha.substring(a + 1, b) : "";
    }

    private static void responder(OutputStream out, String texto) throws IOException {
        out.write((texto + "\r\n").getBytes(StandardCharsets.UTF_8));
        out.flush();
    }
}
