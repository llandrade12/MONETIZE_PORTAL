package br.com.monetize.portal.servicos;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.Signature;
import java.util.Arrays;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.junit.Test;

import br.com.monetize.portal.util.Json;
import br.com.monetize.portal.util.Texto;

public class WebPushTest {

    /** Exemplo completo da RFC 8291 (seção 5 e apêndice A): o corpo gerado precisa ser idêntico, byte a byte. */
    @Test
    public void exemploDaRfc8291() throws Exception {
        byte[] mensagem = "When I grow up, I want to be a watermelon".getBytes(StandardCharsets.UTF_8);
        byte[] servidorPrivada = Texto.deB64url("yfWPiYE-n46HLnH0KqZOF1fJJU3MYrct3AELtAQ-oRw");
        byte[] servidorPublica = Texto.deB64url("BP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A8");
        byte[] aparelhoPublica = Texto.deB64url("BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcxaOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4");
        byte[] auth = Texto.deB64url("BTBZMqHH6r4Tts7J_aSIgg");
        byte[] sal = Texto.deB64url("DGv6ra1nlYgDCS1FRnbzlw");

        byte[] corpo = WebPush.cifrar(mensagem, aparelhoPublica, auth, WebPush.parDe(servidorPrivada, servidorPublica), sal);

        assertEquals("DGv6ra1nlYgDCS1FRnbzlwAAEABBBP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A_yl95bQpu6cVPTpK4Mqgkf1CXztLVBSt2Ks3oZwbuwXPXLWyouBWLVWGNWQexSgSxsj_Qulcy4a-fN",
                Texto.b64url(corpo));
    }

    /** O que o servidor cifra, o aparelho (com a chave privada dele) consegue ler. */
    @Test
    public void aparelhoDecifraAMensagem() throws Exception {
        KeyPair aparelho = WebPush.novoPar();
        byte[] auth = Texto.aleatorio(16);
        String texto = "{\"t\":\"Nota lançada\",\"b\":\"Sua tarefa foi avaliada 🎉\",\"u\":\"https://exemplo.com/aluno.html#ir=tarefas\"}";

        byte[] corpo = WebPush.cifrar(texto.getBytes(StandardCharsets.UTF_8), WebPush.pontoDe(aparelho.getPublic()), auth);

        assertEquals(texto, new String(decifrar(corpo, aparelho, auth), StandardCharsets.UTF_8));
        assertEquals("tamanho: cabeçalho de 86 bytes + mensagem + 1 de delimitador + 16 de autenticação",
                86 + texto.getBytes(StandardCharsets.UTF_8).length + 1 + 16, corpo.length);
        byte[] outro = WebPush.cifrar(texto.getBytes(StandardCharsets.UTF_8), WebPush.pontoDe(aparelho.getPublic()), auth);
        assertNotEquals("cada envio usa sal e chave novos", Texto.b64url(corpo), Texto.b64url(outro));
    }

    /** Lado do aparelho (RFC 8291, seção 3.4, e RFC 8188): usado só nos testes. */
    public static byte[] decifrar(byte[] corpo, KeyPair aparelho, byte[] auth) throws Exception {
        byte[] sal = Arrays.copyOfRange(corpo, 0, 16);
        int tamanhoChave = corpo[20] & 0xFF;
        byte[] servidorPublica = Arrays.copyOfRange(corpo, 21, 21 + tamanhoChave);
        byte[] cifrado = Arrays.copyOfRange(corpo, 21 + tamanhoChave, corpo.length);

        KeyAgreement ka = KeyAgreement.getInstance("ECDH");
        ka.init(aparelho.getPrivate());
        ka.doPhase(WebPush.publicaDe(servidorPublica), true);
        byte[] segredo = ka.generateSecret();

        byte[] prkChave = hmac(auth, segredo);
        byte[] ikm = hmac(prkChave, juntar("WebPush: info\0".getBytes(StandardCharsets.US_ASCII), WebPush.pontoDe(aparelho.getPublic()), servidorPublica, new byte[] { 1 }));
        byte[] prk = hmac(sal, ikm);
        byte[] cek = Arrays.copyOf(hmac(prk, juntar("Content-Encoding: aes128gcm\0".getBytes(StandardCharsets.US_ASCII), new byte[] { 1 })), 16);
        byte[] nonce = Arrays.copyOf(hmac(prk, juntar("Content-Encoding: nonce\0".getBytes(StandardCharsets.US_ASCII), new byte[] { 1 })), 12);
        Cipher aes = Cipher.getInstance("AES/GCM/NoPadding");
        aes.init(Cipher.DECRYPT_MODE, new SecretKeySpec(cek, "AES"), new GCMParameterSpec(128, nonce));
        byte[] claro = aes.doFinal(cifrado);
        int fim = claro.length - 1;
        while (fim >= 0 && claro[fim] == 0)
            fim--;
        assertEquals("delimitador de último registro", 2, claro[fim]);
        return Arrays.copyOf(claro, fim);
    }

    private static byte[] hmac(byte[] chave, byte[] dados) throws Exception {
        Mac m = Mac.getInstance("HmacSHA256");
        m.init(new SecretKeySpec(chave, "HmacSHA256"));
        return m.doFinal(dados);
    }

    private static byte[] juntar(byte[]... partes) {
        int n = 0;
        for (byte[] p : partes)
            n += p.length;
        byte[] r = new byte[n];
        int pos = 0;
        for (byte[] p : partes) {
            System.arraycopy(p, 0, r, pos, p.length);
            pos += p.length;
        }
        return r;
    }

    @Test
    public void chavePublicaVaiEVolta() throws Exception {
        KeyPair par = WebPush.novoPar();
        byte[] ponto = WebPush.pontoDe(par.getPublic());
        assertEquals(65, ponto.length);
        assertEquals(4, ponto[0]);
        assertArrayEquals(ponto, WebPush.pontoDe(WebPush.publicaDe(ponto)));
        PrivateKey lida = WebPush.privadaDe(WebPush.privadaTexto(par.getPrivate()));
        assertArrayEquals(par.getPrivate().getEncoded(), lida.getEncoded());
    }

    /** O cabeçalho VAPID (RFC 8292) tem um JWT ES256 assinado com a chave do servidor. */
    @Test
    public void cabecalhoVapidTemAssinaturaValida() throws Exception {
        KeyPair servidor = WebPush.novoPar();
        byte[] publica = WebPush.pontoDe(servidor.getPublic());
        long agora = 1_790_000_000L;

        String h = WebPush.vapid("https://fcm.googleapis.com/fcm/send/abc123", "mailto:contato@exemplo.com", servidor.getPrivate(), publica, agora);

        assertTrue(h, h.startsWith("vapid t="));
        String jwt = h.substring(8, h.indexOf(", k="));
        assertEquals(Texto.b64url(publica), h.substring(h.indexOf(", k=") + 4));
        String[] p = jwt.split("\\.");
        assertEquals(3, p.length);
        Map<String, Object> cab = Json.lerObjeto(new String(Texto.deB64url(p[0]), StandardCharsets.UTF_8));
        assertEquals("ES256", cab.get("alg"));
        assertEquals("JWT", cab.get("typ"));
        Map<String, Object> corpo = Json.lerObjeto(new String(Texto.deB64url(p[1]), StandardCharsets.UTF_8));
        assertEquals("o destinatário é só a origem do serviço de push, sem o caminho", "https://fcm.googleapis.com", corpo.get("aud"));
        assertEquals("mailto:contato@exemplo.com", corpo.get("sub"));
        long exp = Json.num(corpo, "exp", 0);
        assertTrue("validade de no máximo 24 horas (exigência do padrão)", exp > agora && exp <= agora + 24 * 3600);

        byte[] assinatura = Texto.deB64url(p[2]);
        assertEquals("assinatura no formato R||S, 64 bytes", 64, assinatura.length);
        Signature s = Signature.getInstance("SHA256withECDSAinP1363Format");
        s.initVerify(servidor.getPublic());
        s.update((p[0] + "." + p[1]).getBytes(StandardCharsets.US_ASCII));
        assertTrue(s.verify(assinatura));
    }

    @Test
    public void vapidMantemAPortaDoServico() throws Exception {
        KeyPair servidor = WebPush.novoPar();
        String h = WebPush.vapid("https://push.exemplo.com:8443/x/y", "mailto:a@b.com", servidor.getPrivate(), WebPush.pontoDe(servidor.getPublic()), 1000);
        String corpo = new String(Texto.deB64url(h.substring(8, h.indexOf(", k=")).split("\\.")[1]), StandardCharsets.UTF_8);
        assertEquals("https://push.exemplo.com:8443", Json.lerObjeto(corpo).get("aud"));
    }
}
