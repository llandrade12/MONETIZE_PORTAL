package br.com.monetize.portal.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.junit.Test;

public class JsonTest {

    @Test
    public void leOsTiposBasicos() {
        Map<String, Object> m = Json.lerObjeto(" { \"a\" : 1 , \"b\":-2.50, \"c\":\"x\", \"d\":true, \"e\":false, \"f\":null, \"g\":[1,[2],{}], \"h\":1e3 } ");
        assertEquals(1L, m.get("a"));
        assertEquals(new BigDecimal("-2.50"), m.get("b"));
        assertEquals("x", m.get("c"));
        assertEquals(Boolean.TRUE, m.get("d"));
        assertEquals(Boolean.FALSE, m.get("e"));
        assertTrue(m.containsKey("f"));
        assertNull(m.get("f"));
        assertEquals(3, ((List<?>) m.get("g")).size());
        assertEquals(1000L, Json.num(m, "h", 0));
    }

    @Test
    public void mantemAOrdemDasChaves() {
        assertEquals("{\"z\":1,\"a\":2,\"m\":3}", Json.texto(Json.ler("{\"z\":1,\"a\":2,\"m\":3}")));
    }

    @Test
    public void escapesDeTexto() {
        String s = (String) Json.ler("\"a\\\"b\\\\c\\/d\\n\\t\\u00e7\\ud83d\\ude00\"");
        assertEquals("a\"b\\c/d\n\t\u00e7\ud83d\ude00", s);
    }

    @Test
    public void emojiSaiEscapadoEVolaIgual() {
        String original = "Parab\u00e9ns \ud83c\udf89 pela entrega";
        String json = Json.texto(original);
        assertTrue("o emoji precisa sair como \\uXXXX: " + json, json.contains("\\ud83c\\udf89"));
        assertTrue("acentos comuns continuam legíveis", json.contains("\u00e9"));
        for (int i = 0; i < json.length(); i++)
            assertFalse("nenhum caractere fora do plano básico no texto gerado", Character.isSurrogate(json.charAt(i)));
        assertEquals(original, Json.ler(json));
    }

    @Test
    public void caracteresDeControleSaemEscapados() {
        String json = Json.texto("a\u0001b\u2028c\"d\\e\r\n");
        assertFalse(json.contains("\u0001"));
        assertFalse(json.contains("\u2028"));
        assertEquals("a\u0001b\u2028c\"d\\e\r\n", Json.ler(json));
    }

    @Test
    public void numerosGrandesEDecimaisVoltamIguais() {
        assertEquals("12345678901234567890", Json.texto(Json.ler("12345678901234567890")));
        assertEquals("0.1", Json.texto(Json.ler("0.1")));
        assertEquals("7.5", Json.texto(Json.ler("7.5")));
        assertEquals("9007199254740993", Json.texto(Json.ler("9007199254740993")));
        assertEquals("1.5", Json.texto(1.5d));
        assertEquals("3", Json.texto(3.0d));
        assertEquals("null", Json.texto(Double.NaN));
    }

    @Test
    public void recusaJsonInvalido() {
        String[] ruins = { "", "{", "[1,]", "{\"a\":}", "{'a':1}", "01", "1.", "-", "tru", "\"abc", "[1] 2", "{\"a\":1,}", "\"a\nb\"", "\"\\x\"", "\"\\u12\"", "nul",
                "1e999999999", "1e-999999999", "\u0661" };
        for (String r : ruins) {
            try {
                Json.ler(r);
                fail("deveria recusar: " + r);
            } catch (Json.JsonException e) {
                /* esperado */
            }
        }
    }

    @Test
    public void recusaEstruturaProfundaDemais() {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 5000; i++)
            b.append('[');
        try {
            Json.ler(b.toString());
            fail("deveria recusar");
        } catch (Json.JsonException e) {
            assertTrue(e.getMessage().contains("profunda"));
        }
    }

    @Test
    public void igualIgnoraOrdemDasChavesEFormatoDoNumero() {
        assertTrue(Json.igual(Json.ler("{\"a\":1,\"b\":[1,2.0,{\"c\":null}]}"), Json.ler("{\"b\":[1.0,2,{\"c\":null}],\"a\":1.00}")));
        assertFalse(Json.igual(Json.ler("{\"a\":1}"), Json.ler("{\"a\":1,\"b\":null}")));
        assertFalse(Json.igual(Json.ler("[1,2]"), Json.ler("[2,1]")));
        assertFalse(Json.igual(Json.ler("\"1\""), Json.ler("1")));
        assertTrue(Json.igual(null, null));
        assertFalse(Json.igual(null, Json.ler("0")));
    }

    @Test
    public void copiaEhProfunda() {
        Map<String, Object> a = Json.lerObjeto("{\"l\":[{\"x\":1}],\"m\":{\"y\":2}}");
        Map<String, Object> b = Json.obj(Json.copia(a));
        Json.obj(Json.lista(b, "l").get(0)).put("x", 9L);
        Json.obj(b, "m").put("y", 9L);
        assertEquals("{\"l\":[{\"x\":1}],\"m\":{\"y\":2}}", Json.texto(a));
    }

    @Test
    public void verdadeiroSegueARegraDoJavaScript() {
        assertFalse(Json.verdadeiro(null));
        assertFalse(Json.verdadeiro(""));
        assertFalse(Json.verdadeiro(0L));
        assertFalse(Json.verdadeiro(new BigDecimal("0.0")));
        assertFalse(Json.verdadeiro(Boolean.FALSE));
        assertTrue(Json.verdadeiro("0"));
        assertTrue(Json.verdadeiro(-1L));
        assertTrue(Json.verdadeiro(Json.ler("[]")));
        assertTrue(Json.verdadeiro(Json.ler("{}")));
    }

    @Test
    public void acessoresToleramCamposAusentesETiposTrocados() {
        Map<String, Object> m = Json.lerObjeto("{\"n\":\"42\",\"s\":7,\"d\":\"7,5\",\"l\":\"x\"}");
        assertEquals(42L, Json.num(m, "n", 0));
        assertEquals(5L, Json.num(m, "ausente", 5));
        assertEquals("7", Json.str(m, "s"));
        assertEquals("", Json.str(m, "ausente"));
        assertEquals("", Json.str(null, "x"));
        assertEquals(7.5, Json.dec(m.get("d"), 0), 1e-9);
        assertTrue(Json.lista(m, "l").isEmpty());
        assertNull(Json.obj(m, "l"));
    }

    @Test
    public void cruEntraSemReprocessar() {
        assertEquals("{\"a\":{\"x\":1}}", Json.texto(Json.mapa("a", new Json.Cru("{\"x\":1}"))));
    }
}
