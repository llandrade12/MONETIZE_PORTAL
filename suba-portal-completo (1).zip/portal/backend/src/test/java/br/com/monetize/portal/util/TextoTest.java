package br.com.monetize.portal.util;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import org.junit.Test;

public class TextoTest {

    @Test
    public void datasNoFormatoDoPortal() {
        assertEquals("15/03", Texto.df("2026-03-15"));
        assertEquals("15/03/2026", Texto.dfy("2026-03-15"));
        assertEquals("dom, 15 de mar", Texto.dl("2026-03-15"));
        assertEquals("sáb, 3 de out", Texto.dl("2026-10-03"));
        assertEquals("—", Texto.df("15/03/2026"));
        assertEquals("—", Texto.dl(""));
        assertEquals("07/10/2026 09:05", Texto.carimbo(LocalDateTime.of(2026, 10, 7, 9, 5, 59)));
    }

    @Test
    public void contasComDatas() {
        assertEquals("2026-03-01", Texto.somaDias("2026-02-27", 2));
        assertEquals("2024-02-29", Texto.somaDias("2024-03-07", -7));
        assertEquals("", Texto.somaDias("ontem", 1));
        assertEquals(3, Texto.dias("2026-03-04", "2026-03-01"));
        assertEquals(-3, Texto.dias("2026-03-01", "2026-03-04"));
        assertEquals(0, Texto.dias("2026-03-01", ""));
        assertEquals(366, Texto.dias("2025-01-01", "2024-01-01"));
        assertNull(Texto.data("2026-02-30"));
        assertNull(Texto.data(null));
    }

    @Test
    public void semEmojiTiraSoOQueOBancoComumNaoGuarda() {
        assertEquals("João  Açaí", Texto.semEmoji("João 😀 Açaí"));
        assertEquals("sem mudança", Texto.semEmoji("sem mudança"));
        assertNull(Texto.semEmoji(null));
    }

    @Test
    public void utilidades() {
        assertEquals("71988887777", Texto.digitos("(71) 98888-7777"));
        assertEquals("", Texto.digitos(null));
        assertEquals("Ana", Texto.primeiroNome("  Ana Beatriz Souza "));
        assertEquals("", Texto.primeiroNome(null));
        assertEquals("abc", Texto.cortar("abcdef", 3));
        assertNull(Texto.cortar(null, 3));
        assertEquals("padrao", Texto.ou("  ", "padrao"));
        assertEquals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", Texto.sha256Hex(""));
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", Texto.sha256Hex("abc"));
        assertTrue(Texto.igualSeguro("abc", "abc"));
        assertFalse(Texto.igualSeguro("abc", "abd"));
        assertFalse(Texto.igualSeguro(null, "abc"));
    }

    @Test
    public void base64DeEnderecoVaiEVolta() {
        byte[] b = { 0, -1, 127, -128, 62, 63, 1 };
        String t = Texto.b64url(b);
        assertFalse(t.contains("=") || t.contains("+") || t.contains("/"));
        assertArrayEquals(b, Texto.deB64url(t));
        /* Alguns navegadores entregam as chaves do push em base64 comum, com preenchimento. */
        assertArrayEquals(b, Texto.deB64url(java.util.Base64.getEncoder().encodeToString(b)));
    }

    @Test
    public void segredosEIdentificadoresNaoSeRepetem() {
        Set<String> vistos = new HashSet<>();
        for (int i = 0; i < 2000; i++)
            assertTrue(vistos.add(Texto.segredo(24)));
        assertEquals(32, Texto.segredo(24).length());
        assertTrue(Texto.uid().matches("[0-9a-z]{10,16}"));
        assertNotEquals(Texto.segredo(32), Texto.segredo(32));
    }
}
