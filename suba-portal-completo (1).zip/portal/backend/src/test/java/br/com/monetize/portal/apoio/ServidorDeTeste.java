package br.com.monetize.portal.apoio;

import java.io.IOException;
import java.net.ServerSocket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

import br.com.monetize.portal.Config;
import br.com.monetize.portal.Principal;

/**
 * Sobe o servidor completo para os testes: banco H2 em memória (no modo de compatibilidade com MySQL),
 * servidor de e-mail de mentira e pastas temporárias. Nenhuma tarefa periódica roda sozinha.
 */
public final class ServidorDeTeste implements AutoCloseable {

    public static final String MENTOR_EMAIL = "mentor@teste.com";
    public static final String MENTOR_SENHA = "Mentor12345";
    public static final String MENTOR_NOME = "Carlos Mentor";

    private static final AtomicInteger SEQUENCIA = new AtomicInteger();

    public final Principal.Aplicacao app;
    public final SmtpFalso smtp;
    public final String base;
    public final Path pasta;
    public final Config config;

    public ServidorDeTeste() throws IOException {
        this(new HashMap<>());
    }

    /** extras: configurações a mais, no formato das variáveis de ambiente (SOP_...). */
    public ServidorDeTeste(Map<String, String> extras) throws IOException {
        int porta;
        try (ServerSocket s = new ServerSocket(0)) {
            porta = s.getLocalPort();
        }
        smtp = new SmtpFalso();
        pasta = Files.createTempDirectory("portal-teste");
        Path web = Files.createDirectories(pasta.resolve("web"));
        Files.write(web.resolve("index.html"), "<!doctype html><title>Portal de teste</title><p>entrada</p>".getBytes(StandardCharsets.UTF_8));
        Files.write(web.resolve("aluno.html"), "<!doctype html><title>Aluno</title>".getBytes(StandardCharsets.UTF_8));
        Files.createDirectories(web.resolve("js"));
        Files.write(web.resolve("js/app.js"), ("/* " + "x".repeat(3000) + " */\nconsole.log('portal');\n").getBytes(StandardCharsets.UTF_8));
        Files.write(web.resolve(".segredo"), "nao deve ser entregue".getBytes(StandardCharsets.UTF_8));
        Files.write(web.resolve("dados.sql"), "tipo de arquivo que o servidor nao entrega".getBytes(StandardCharsets.UTF_8));
        Files.write(pasta.resolve("config.properties"), "db.senha=fora-da-pasta-web".getBytes(StandardCharsets.UTF_8));

        Map<String, String> amb = new HashMap<>();
        amb.put("SOP_PORTA", String.valueOf(porta));
        amb.put("SOP_ENDERECO", "127.0.0.1");
        amb.put("SOP_URL_PUBLICA", "http://localhost:" + porta);
        amb.put("SOP_WEB_DIR", web.toString());
        amb.put("SOP_ARQUIVOS_DIR", pasta.resolve("arquivos").toString());
        amb.put("SOP_ARQUIVOS_MAX_MB", "1");
        amb.put("SOP_FUSO", "America/Bahia");
        amb.put("SOP_DB_URL", "jdbc:h2:mem:portal" + System.nanoTime() + "_" + SEQUENCIA.incrementAndGet()
                + ";MODE=MySQL;DATABASE_TO_LOWER=TRUE;CASE_INSENSITIVE_IDENTIFIERS=TRUE;DB_CLOSE_DELAY=-1");
        amb.put("SOP_DB_USUARIO", "sa");
        amb.put("SOP_ADMIN_NOME", MENTOR_NOME);
        amb.put("SOP_ADMIN_EMAIL", MENTOR_EMAIL);
        amb.put("SOP_ADMIN_SENHA", MENTOR_SENHA);
        amb.put("SOP_SMTP_HOST", "localhost");
        amb.put("SOP_SMTP_PORTA", String.valueOf(smtp.porta()));
        amb.put("SOP_SMTP_SEGURANCA", "nenhuma");
        amb.put("SOP_SMTP_REMETENTE", "portal@exemplo.com");
        amb.put("SOP_SMTP_REMETENTE_NOME", "Monetize");
        amb.put("SOP_SMTP_INTERVALO_MS", "0");
        amb.putAll(extras);
        config = new Config(null, amb);
        base = "http://localhost:" + porta;
        try {
            app = Principal.iniciar(config, false);
        } catch (IOException | RuntimeException e) {
            smtp.close();
            throw e;
        }
    }

    public Cliente cliente() {
        return new Cliente(base);
    }

    /** Cliente já logado como o mentor criado na instalação. */
    public Cliente mentor() throws Exception {
        Cliente c = cliente();
        c.entrar(MENTOR_EMAIL, MENTOR_SENHA).exigir(200);
        return c;
    }

    @Override
    public void close() {
        app.close();
        smtp.close();
        try (Stream<Path> s = Files.walk(pasta)) {
            s.sorted(Comparator.reverseOrder()).forEach(p -> p.toFile().delete());
        } catch (IOException e) {
            /* pasta temporária: o sistema limpa depois */
        }
    }
}
