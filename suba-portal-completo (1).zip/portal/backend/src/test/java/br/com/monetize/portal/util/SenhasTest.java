package br.com.monetize.portal.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class SenhasTest {

    @Test
    public void geraEConfere() {
        String h = Senhas.gerar("Senha12345");
        assertTrue(h, h.matches("pbkdf2\\$310000\\$[A-Za-z0-9+/=]+\\$[A-Za-z0-9+/=]+"));
        assertTrue(Senhas.confere("Senha12345", h, "a@b.com"));
        assertFalse(Senhas.confere("senha12345", h, "a@b.com"));
        assertFalse(Senhas.confere("", h, "a@b.com"));
        assertFalse(Senhas.confere(null, h, "a@b.com"));
        assertFalse(Senhas.precisaAtualizar(h));
    }

    @Test
    public void cadaResumoTemSalProprio() {
        assertNotEquals(Senhas.gerar("Senha12345"), Senhas.gerar("Senha12345"));
    }

    @Test
    public void semSenhaGuardadaNinguemEntra() {
        assertFalse(Senhas.confere("qualquer1", null, "a@b.com"));
        assertFalse(Senhas.confere("qualquer1", "", "a@b.com"));
        assertFalse(Senhas.confere("qualquer1", "texto-que-nao-e-resumo", "a@b.com"));
        assertFalse(Senhas.confere("qualquer1", "pbkdf2$abc$x$y", "a@b.com"));
        assertFalse(Senhas.confere("qualquer1", "pbkdf2$1000$!!$!!", "a@b.com"));
    }

    @Test
    public void aceitaOResumoDoPortalAntigo() {
        /* O portal antigo guardava 5.000 rodadas de SHA-256 sobre "sop|email|senha", com o e-mail em minúsculas. */
        String antigo = Senhas.legado("ana@teste.com", "Aluna12345");
        assertEquals(64, antigo.length());
        String guardado = "legado$" + antigo;
        assertTrue(Senhas.confere("Aluna12345", guardado, "Ana@Teste.com"));
        assertFalse(Senhas.confere("Aluna12346", guardado, "ana@teste.com"));
        assertFalse(Senhas.confere("Aluna12345", guardado, "outra@teste.com"));
        assertTrue("resumo antigo deve ser regravado no formato novo no próximo login", Senhas.precisaAtualizar(guardado));
    }

    @Test
    public void resumoVindoDeUmaCopia() {
        String novo = Senhas.gerar("Senha12345");
        assertEquals(novo, Senhas.importado(novo));
        String antigo = Senhas.legado("ana@teste.com", "Aluna12345");
        assertEquals("legado$" + antigo, Senhas.importado(antigo));
        assertEquals("legado$" + antigo, Senhas.importado("legado$" + antigo));
        assertNull(Senhas.importado("Senha12345"));
        assertNull(Senhas.importado(""));
        assertNull(Senhas.importado(null));
        assertNull("iterações absurdas não entram", Senhas.importado("pbkdf2$9999999$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="));
        assertFalse(Senhas.confere("x", "pbkdf2$2000000000$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=", "a@b.com"));
    }

    @Test
    public void regraDeSenhaForte() {
        assertTrue(Senhas.forte("abcdefg1"));
        assertTrue(Senhas.forte("Senha Com Espaço 9"));
        assertFalse(Senhas.forte("abc1"));
        assertFalse(Senhas.forte("abcdefgh"));
        assertFalse(Senhas.forte("12345678"));
        assertFalse(Senhas.forte(null));
    }
}
