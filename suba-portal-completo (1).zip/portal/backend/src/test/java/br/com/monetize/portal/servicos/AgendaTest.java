package br.com.monetize.portal.servicos;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import br.com.monetize.portal.Config;
import br.com.monetize.portal.dados.Portal;
import br.com.monetize.portal.util.Json;

public class AgendaTest {

    private Agenda agenda;
    private Portal p;
    private Map<String, Object> ana;

    private static Map<String, Object> j(String json) {
        return Json.lerObjeto(json.replace('\'', '"'));
    }

    @Before
    public void montar() throws Exception {
        Map<String, String> amb = new HashMap<>();
        amb.put("SOP_URL_PUBLICA", "https://portal.exemplo.com/");
        amb.put("SOP_FUSO", "America/Bahia");
        agenda = new Agenda(null, new Config(null, amb));
        p = new Portal("2026-10-07");
        p.mentor = "Carlos Mentor";
        p.turmas.add(j("{'id':1,'nome':'Turma A','unidades':[]}"));
        ana = j("{'id':10,'nome':'Ana','turma':1,'status':'ativo','mat':'2026-09-01'}");
        p.alunos.add(ana);
        p.aulas.add(j("{'n':1,'nome':'Mentalidade; de dono, parte 1','date':'2026-10-08','hora':'20:00','dur':90,'status':'agendada','turmas':[1],'obj':'Linha 1\\nLinha 2','link':'https://meet.exemplo.com/abc'}"));
        p.aulas.add(j("{'n':2,'nome':'Daqui a um mes','date':'2026-11-08','hora':'19:30','status':'agendada','turmas':[1],'obj':'Pauta reservada','link':'https://meet.exemplo.com/futuro'}"));
        p.aulas.add(j("{'n':3,'nome':'Cancelada','date':'2026-10-15','hora':'20:00','status':'cancelada','turmas':[1]}"));
        p.aulas.add(j("{'n':4,'nome':'De outra turma','date':'2026-10-16','hora':'20:00','status':'agendada','turmas':[2]}"));
        p.eventos.add(j("{'id':'ev1','t':'Imersão presencial','d':'2026-12-05','turmas':[]}"));
        p.tarefas.add(j("{'id':100,'t':'Mapa de indicadores','due':'2026-10-10','turmas':[1]}"));
        p.tarefas.add(j("{'id':101,'t':'Ainda fechada','due':'2026-12-20','turmas':[1]}"));
    }

    private String doAluno() {
        return agenda.montar(p, ana, LocalDateTime.of(2026, 10, 7, 9, 0)).replace("\r\n ", "");
    }

    @Test
    public void estruturaDoArquivo() {
        String bruto = agenda.montar(p, ana, LocalDateTime.of(2026, 10, 7, 9, 0));
        assertTrue(bruto.startsWith("BEGIN:VCALENDAR\r\nVERSION:2.0\r\n"));
        assertTrue(bruto.endsWith("END:VCALENDAR\r\n"));
        assertFalse("toda quebra de linha é CRLF", bruto.replace("\r\n", "").contains("\n"));
        for (String linha : bruto.split("\r\n"))
            assertTrue("linha com mais de 75 bytes: " + linha, linha.getBytes(StandardCharsets.UTF_8).length <= 75);
        String ics = bruto.replace("\r\n ", "");
        assertEquals(count(ics, "BEGIN:VEVENT"), count(ics, "END:VEVENT"));
        assertEquals(count(ics, "BEGIN:VALARM"), count(ics, "END:VALARM"));
        assertTrue(ics.contains("X-WR-TIMEZONE:America/Bahia"));
        assertTrue(ics.contains("DTSTAMP:20261007T120000Z"));
    }

    private static int count(String s, String parte) {
        return s.split(java.util.regex.Pattern.quote(parte), -1).length - 1;
    }

    @Test
    public void encontroSaiEmUtcComDuracaoEAlarme() {
        String ics = doAluno();
        /* 20:00 em Salvador (UTC-3) = 23:00 UTC; 90 minutos depois = 00:30 UTC do dia seguinte. */
        assertTrue(ics, ics.contains("UID:aula-1@monetize-area-de-membros\r\nDTSTAMP:20261007T120000Z\r\nDTSTART:20261008T230000Z\r\nDTEND:20261009T003000Z\r\n"));
        assertTrue(ics.contains("SUMMARY:Monetize · Mentalidade\\; de dono\\, parte 1\r\n"));
        assertTrue(ics.contains("TRIGGER:-PT60M"));
        assertTrue(ics.contains("URL:https://portal.exemplo.com/\r\n"));
    }

    @Test
    public void pautaELinkAparecemParaOAlunoSoAPartirDaVespera() {
        String ics = doAluno();
        assertTrue(ics.contains("Pauta: Linha 1\\nLinha 2\\nLink da reunião: https://meet.exemplo.com/abc"));
        assertTrue(ics.contains("LOCATION:https://meet.exemplo.com/abc"));
        assertFalse("pauta de aula distante fica reservada", ics.contains("Pauta reservada"));
        assertFalse(ics.contains("meet.exemplo.com/futuro"));
        assertTrue(ics.contains("O link da reunião fica na página da aula\\, no portal."));

        String doMentor = agenda.montar(p, null, LocalDateTime.of(2026, 10, 7, 9, 0)).replace("\r\n ", "");
        assertTrue("o mentor vê tudo", doMentor.contains("Pauta reservada") && doMentor.contains("meet.exemplo.com/futuro"));
    }

    @Test
    public void alunoSoRecebeOQueEhDaTurmaDele() {
        String ics = doAluno();
        assertFalse(ics.contains("De outra turma"));
        assertFalse("aula cancelada sai da agenda", ics.contains("Cancelada"));
        String doMentor = agenda.montar(p, null, LocalDateTime.of(2026, 10, 7, 9, 0)).replace("\r\n ", "");
        assertTrue(doMentor.contains("De outra turma"));
        assertFalse(doMentor.contains("SUMMARY:Monetize · Cancelada"));
    }

    @Test
    public void eventoEPrazoSaoDeDiaInteiro() {
        String ics = doAluno();
        assertTrue(ics.contains("UID:evento-ev1@monetize-area-de-membros\r\nDTSTAMP:20261007T120000Z\r\nDTSTART;VALUE=DATE:20261205\r\nDTEND;VALUE=DATE:20261206\r\nSUMMARY:Monetize · Imersão presencial"));
        assertTrue(ics.contains("DTSTART;VALUE=DATE:20261010\r\nDTEND;VALUE=DATE:20261011\r\nSUMMARY:Prazo: Mapa de indicadores"));
        assertFalse("tarefa ainda não liberada não aparece para o aluno", ics.contains("Ainda fechada"));
    }

    @Test
    public void prazoSomeDepoisDaEntregaESegueOPrazoReaberto() {
        p.prazo.put("10-100", "2026-10-14");
        assertTrue(doAluno().contains("DTSTART;VALUE=DATE:20261014\r\nDTEND;VALUE=DATE:20261015\r\nSUMMARY:Prazo: Mapa de indicadores"));
        p.ent.put("10-100", j("{'txt':'feito'}"));
        assertFalse(doAluno().contains("Prazo: Mapa de indicadores"));
    }

    @Test
    public void linkQueNaoEhHttpsNaoEntra() {
        p.aulas.get(0).put("link", "javascript:alert(1)");
        String ics = doAluno();
        assertFalse(ics.contains("javascript"));
        assertFalse(ics.contains("LOCATION:"));
    }

    @Test
    public void escapaTexto() {
        assertEquals("a\\\\b\\, c\\; d\\ne\\nf", Agenda.esc("a\\b, c; d\ne\r\nf"));
        assertEquals("", Agenda.esc(null));
    }

    @Test
    public void dobraSemCortarCaractere() {
        StringBuilder b = new StringBuilder();
        String linha = "DESCRIPTION:" + "ação 🎉 ".repeat(40);
        Agenda.dobrar(b, linha);
        for (String l : b.toString().split("\r\n"))
            assertTrue(l.getBytes(StandardCharsets.UTF_8).length <= 75);
        assertEquals(linha, b.toString().replace("\r\n ", "").replace("\r\n", ""));
    }

    @Test
    public void enderecoDaAgendaNaoTemBarraDupla() {
        assertEquals("https://portal.exemplo.com/agenda/abc.ics", agenda.url("abc"));
    }

    @Test
    public void horaInvalidaViraOHorarioPadrao() {
        p.aulas.get(0).put("hora", "noite");
        assertTrue(doAluno().contains("DTSTART:20261008T230000Z"));
    }
}
