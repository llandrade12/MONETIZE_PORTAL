package br.com.monetize.portal.apoio;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import br.com.monetize.portal.util.Json;

/** Um "navegador" simples para os testes: guarda o cookie da sessão e fala JSON com a API. */
public final class Cliente {

    /** Resposta de uma chamada. */
    public static final class Resp {
        public int status;
        public byte[] bytes;
        public java.net.http.HttpHeaders cab;

        public String texto() {
            return new String(bytes, StandardCharsets.UTF_8);
        }

        public Map<String, Object> json() {
            return Json.lerObjeto(texto());
        }

        public String cabecalho(String nome) {
            return cab.firstValue(nome).orElse("");
        }

        /** Falha o teste se o código HTTP for outro. */
        public Resp exigir(int esperado) {
            if (status != esperado)
                throw new AssertionError("Esperava HTTP " + esperado + " e veio " + status + ": " + (bytes.length > 600 ? texto().substring(0, 600) : texto()));
            return this;
        }

        /** Código curto do erro ("login-invalido", "sem-permissao"...). */
        public String erro() {
            return Json.str(json(), "erro");
        }
    }

    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).followRedirects(HttpClient.Redirect.NEVER).build();

    public final String base;
    /** Cookie da sessão (vazio = sem sessão). */
    public String cookie = "";
    /** Último cabeçalho Set-Cookie recebido. */
    public String ultimoSetCookie = "";
    /** Manda o cabeçalho que identifica as chamadas do próprio portal? */
    public boolean cabecalhoDoPortal = true;
    /** Último número de alteração conhecido (para pedir só o que mudou). */
    public long rev;

    public Cliente(String base) {
        this.base = base;
    }

    private Resp enviar(String metodo, String caminho, byte[] corpo, String tipo, String... cabecalhos) throws Exception {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(caminho.startsWith("http") ? caminho : base + caminho)).timeout(Duration.ofSeconds(30));
        if (!cookie.isEmpty())
            b.header("Cookie", "sop_sessao=" + cookie);
        if (cabecalhoDoPortal && !metodo.equals("GET") && !metodo.equals("HEAD"))
            b.header("X-Portal", "1");
        if (tipo != null)
            b.header("Content-Type", tipo);
        for (int i = 0; i + 1 < cabecalhos.length; i += 2)
            b.header(cabecalhos[i], cabecalhos[i + 1]);
        b.method(metodo, corpo == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofByteArray(corpo));
        HttpResponse<byte[]> r = HTTP.send(b.build(), HttpResponse.BodyHandlers.ofByteArray());
        Resp resp = new Resp();
        resp.status = r.statusCode();
        resp.bytes = r.body() == null ? new byte[0] : r.body();
        resp.cab = r.headers();
        for (String sc : r.headers().allValues("Set-Cookie")) {
            if (sc.startsWith("sop_sessao=")) {
                ultimoSetCookie = sc;
                cookie = sc.substring("sop_sessao=".length(), sc.contains(";") ? sc.indexOf(';') : sc.length());
            }
        }
        return resp;
    }

    public Resp get(String caminho, String... cabecalhos) throws Exception {
        return enviar("GET", caminho, null, null, cabecalhos);
    }

    public Resp head(String caminho) throws Exception {
        return enviar("HEAD", caminho, null, null);
    }

    public Resp post(String caminho, Map<String, Object> corpo) throws Exception {
        return enviar("POST", caminho, Json.texto(corpo == null ? new LinkedHashMap<>() : corpo).getBytes(StandardCharsets.UTF_8), "application/json; charset=utf-8");
    }

    public Resp postBruto(String caminho, String corpo) throws Exception {
        return enviar("POST", caminho, corpo.getBytes(StandardCharsets.UTF_8), "application/json; charset=utf-8");
    }

    public Resp put(String caminho, byte[] corpo) throws Exception {
        return enviar("PUT", caminho, corpo, "application/octet-stream");
    }

    public Resp delete(String caminho) throws Exception {
        return enviar("DELETE", caminho, null, null);
    }

    /* ---------- atalhos da API ---------- */

    public Resp entrar(String email, String senha) throws Exception {
        return post("/api/auth/entrar", Json.mapa("email", email, "senha", senha, "manter", false));
    }

    /** Estado completo ({eu, srv, rev, dados}); guarda o número da alteração. */
    public Map<String, Object> estado() throws Exception {
        Map<String, Object> e = get("/api/estado").exigir(200).json();
        rev = Json.num(e, "rev", 0);
        return e;
    }

    public Map<String, Object> dados() throws Exception {
        return Json.obj(estado(), "dados");
    }

    /** Envia operações de gravação; devolve a resposta {rev, eco, recusadas}. */
    public Map<String, Object> sync(Object... ops) throws Exception {
        return post("/api/sync", Json.mapa("ops", new ArrayList<>(Arrays.asList(ops)))).exigir(200).json();
    }

    /** O que mudou desde a última conferência: lista de {c, k, v | rm}. */
    public List<Object> mudancas() throws Exception {
        Map<String, Object> m = get("/api/mudancas?rev=" + rev).exigir(200).json();
        rev = Json.num(m, "rev", rev);
        return Json.lista(m, "mud");
    }

    /** Motivo da recusa da primeira (ou única) operação enviada, ou "" se foi aceita. */
    public String recusa(Object op) throws Exception {
        List<Object> r = Json.lista(sync(op), "recusadas");
        return r.isEmpty() ? "" : Json.str(Json.obj(r.get(0)), "motivo");
    }

    /* ---------- montagem de operações ---------- */

    public static Map<String, Object> gravar(String colecao, Object chave, Object valor) {
        return Json.mapa("c", colecao, "k", String.valueOf(chave), "v", valor);
    }

    public static Map<String, Object> alterar(String colecao, Object chave, Map<String, Object> campos) {
        return Json.mapa("c", colecao, "k", String.valueOf(chave), "set", campos);
    }

    public static Map<String, Object> apagar(String colecao, Object chave) {
        return Json.mapa("c", colecao, "k", String.valueOf(chave), "rm", true);
    }

    /** Objeto a partir de JSON escrito com aspas simples (mais legível dentro do código Java). */
    public static Map<String, Object> j(String json) {
        return Json.lerObjeto(json.replace('\'', '"'));
    }
}
