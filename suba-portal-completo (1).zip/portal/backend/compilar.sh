#!/bin/sh
# Compila o servidor só com o JDK 17 (ou mais novo), sem Maven.
# Resultado: suba-portal.jar nesta pasta. O driver do banco fica em lib/ (veja docs/INSTALACAO.md).
set -e
cd "$(dirname "$0")"
command -v javac >/dev/null 2>&1 || { echo "JDK não encontrado. Instale o Java 17 (JDK) e tente de novo."; exit 1; }
rm -rf build
mkdir -p build/classes
find src/main/java -name "*.java" > build/fontes.txt
javac --release 17 -encoding UTF-8 -d build/classes @build/fontes.txt
cp -r src/main/resources/. build/classes/
printf 'Main-Class: br.com.monetize.portal.Principal\nClass-Path: lib/mysql-connector-j.jar lib/mariadb-java-client.jar\n' > build/manifesto.txt
jar --create --file suba-portal.jar --manifest build/manifesto.txt -C build/classes .
rm -rf build
echo "Pronto: $(pwd)/suba-portal.jar"
